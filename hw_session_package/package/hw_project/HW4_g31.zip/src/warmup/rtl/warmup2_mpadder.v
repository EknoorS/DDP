`timescale 1ns / 1ps

module warmup2_mpadder(
    input  wire         clk,
    input  wire         resetn,
    input  wire         start,
    input  wire [127:0] A,
    input  wire [127:0] B,
    output wire [128:0] C,
    output wire         done);

    // Task 1
    // Describe a 128-bit register for A
    // It will save the input data when enable signal is high
    // (Implemented below already for you, be sure you understand it)

    reg          regA_en;
    wire [127:0] regA_D;
    reg  [127:0] regA_Q;
    always @(posedge clk)
    begin
        if(~resetn)         regA_Q <= 128'd0;
        else if (regA_en)   regA_Q <= regA_D;
    end

    // Task 2
    // Describe a 128-bit register for B
    reg          regB_en;
    wire [127:0] regB_D;
    reg  [127:0] regB_Q;
    always @(posedge clk)
    begin
        if(~resetn)         regB_Q <= 128'd0;
        else if (regB_en)   regB_Q <= regB_D;
    end


    // Task 3
    // Describe a 2-input 128-bit Multiplexer for A
    // It should select either of these two:
    //   - the input A
    //   - the output of regA shifted-right by 64
    // Also connect the output of Mux to regA's input
    // (Implemented below already for you, be sure you understand it)

    reg          muxA_sel;
    wire [127:0] muxA_Out;
    assign muxA_Out = (muxA_sel == 0) ? A : {64'b0,regA_Q[127:64]};

    assign regA_D = muxA_Out;

    // Task 4
    // Describe a 2-input 64-bit Multiplexer for B
    // !! Use always@(*) statement for combinatorial logic this
    
    reg     muxB_sel;
    reg [63:0] muxB_Out;
    
    always@(*) begin
        if (muxB_sel == 0) muxB_Out <= B[127:64];
        else muxB_Out <= B[63:0];
         
    end
    
    assign regB_D = muxB_Out; 
    
    
    
    
    // Task 5
    // Describe an adder
    // It should be a combinatorial logic:
    // Its inputs are two 64-bit operands and 1-bit carry-in
    // Its outputs are one 64-bit result  and 1-bit carry-out

    wire [63:0] operandA;
    wire [63:0] operandB;
    wire        carry_in;
    wire [63:0] result;
    wire        carry_out;

    assign { carry_out, result } = (operandA + operandB + carry_in);

    // Task 6
    // Describe a 128-bit register for storing the result
    // The register should store adder's outputs at the msb 64-bits
    // and the shift the previous 64 msb bits to lsb when regResult_en is high.

    reg  regResult_en;
    reg [127:0] regResult;
    always @(posedge clk)
    begin
        if(~resetn)             regResult <= 128'b0;
        else if (regResult_en)  regResult <= {result, regResult[127:64]};
    end


    // Task 7
    // Describe a 1-bit register for storing the carry-out when regCout_en is high.

                reg  regCout_en;
                reg  regCout;
                always @(posedge clk)
                begin
                    if(~resetn)          regCout <= 1'b0;
                    else if (regCout_en) regCout <= carry_out;
                end

    
    

    // Task 8
    // Describe a 1-bit multiplexer for selecting carry-in based on muxCarryIn_sel.
    // It should select either of these two:
    //   - 0
    //   - carry-out

                reg  muxCarryIn_sel;
                wire muxCarryIn;

                assign muxCarryIn = (muxCarryIn_sel == 0) ? 1'b0 : regCout;


    // Task 9
    // Connect the inputs of adder to the outputs of A and B registers
    // and to the carry mux\
        assign operandA = regA_Q;
        assign operandB = regB_Q;
        assign carry_in = muxCarryIn;



    // Task 10
    // Describe output, concatenate the registers of carry_out and result
       assign C = {regCout, regResult};


    // Task 11
    // Describe state machine registers
    // (Implemented below already for you, be careful with their width.
    // Think about how many bits you will need.)

    reg [1:0] state, nextstate;

    always @(posedge clk)
    begin
        if(~resetn)	state <= 2'd0;
        else        state <= nextstate;
    end

    // Task 12
    // Define your states
    // Describe your signals at each state
    always @(*)
    begin
        case(state)

            // Idle state; Here the FSM waits for the start signal
            // Enable input registers to fetch the inputs A and B when start is received
            2'd0: begin
                regA_en        <= 1'b1;
                regB_en        <= 1'b1;
                regResult_en   <= 1'b0;
                regCout_en     <= 1'b0;
                muxA_sel       <= 1'b0;
                muxB_sel       <= 1'b0;
                muxCarryIn_sel <= 1'b0;
            end

            // Add low:
            // Disable input registers
            // Calculate the first addition
            2'd1: begin
                regA_en        <= 1'b1;
                regB_en        <= 1'b1;
                regResult_en   <= 1'b1;
                regCout_en     <= 1'b1;
                muxA_sel       <= 1'b1;
                muxB_sel       <= 1'b1;
                muxCarryIn_sel <= 1'b0;
            end

            // Add-High state:
            // Calculate the second addition
            2'd2: begin
                regA_en        <= 1'b0;
                regB_en        <= 1'b0;
                regResult_en   <= 1'b1;
                regCout_en     <= 1'b1;
                muxA_sel       <= 1'b1;
                muxB_sel       <= 1'b1;
                muxCarryIn_sel <= 1'b1;
            end

            default: begin
                regA_en        <= 1'b0;
                regB_en        <= 1'b0;
                regResult_en   <= 1'b1;
                regCout_en     <= 1'b0;
                muxA_sel       <= 1'b0;
                muxB_sel       <= 1'b0;
                muxCarryIn_sel <= 1'b0;
            end

        endcase
    end

    // Task 13
    // Describe next_state logic

    always @(*)
    begin
        case(state)
            2'd0: begin
                if(start)
                    nextstate <= 2'd1;
                else
                    nextstate <= 2'd0;
                end
	    
	    2'd1   : nextstate <= 2'd2;
	    2'd2   : nextstate <= 2'd0;
	    default: nextstate <= 2'd0;
	    
        endcase
    end

    // Task 14
    // Describe done signal
    // It should be high at the same clock cycle when the output ready




endmodule
