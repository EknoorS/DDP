// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2023.1 (lin64) Build 3865809 Sun May  7 15:04:56 MDT 2023
// Date        : Wed Nov 25 15:00:00 2026
// Host        : pc-klas1-14.esat.kuleuven.be running 64-bit Rocky Linux 9.9 (Blue Onyx)
// Command     : write_verilog -force -mode synth_stub -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ ecdsa_project_interfacer_0_0_stub.v
// Design      : ecdsa_project_interfacer_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* X_CORE_INFO = "interfacer,Vivado 2023.1" *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix(aclk, aresetn, m_axi_dma_awvalid, 
  m_axi_dma_awready, m_axi_dma_awaddr, m_axi_dma_awlen, m_axi_dma_awburst, 
  m_axi_dma_wvalid, m_axi_dma_wready, m_axi_dma_wdata, m_axi_dma_wlast, m_axi_dma_bvalid, 
  m_axi_dma_bready, m_axi_dma_arvalid, m_axi_dma_arready, m_axi_dma_araddr, 
  m_axi_dma_arlen, m_axi_dma_arburst, m_axi_dma_rvalid, m_axi_dma_rready, m_axi_dma_rdata, 
  m_axi_dma_rlast, s_axi_csrs_awvalid, s_axi_csrs_awready, s_axi_csrs_awaddr, 
  s_axi_csrs_wvalid, s_axi_csrs_wready, s_axi_csrs_wdata, s_axi_csrs_wstrb, 
  s_axi_csrs_bvalid, s_axi_csrs_bready, s_axi_csrs_bresp, s_axi_csrs_arvalid, 
  s_axi_csrs_arready, s_axi_csrs_araddr, s_axi_csrs_rvalid, s_axi_csrs_rready, 
  s_axi_csrs_rdata, s_axi_csrs_rresp, csr0_c2f, csr0_f2c, csr1_c2f, csr1_f2c, csr2_c2f, csr2_f2c, 
  csr3_c2f, csr3_f2c, csr4_c2f, csr4_f2c, csr5_c2f, csr5_f2c, csr6_c2f, csr6_f2c, csr7_c2f, csr7_f2c, 
  dma_c2f_start, dma_f2c_start, dma_c2f_data, dma_f2c_data, dma_c2f_addr, dma_f2c_addr, 
  dma_done, dma_idle, dma_error)
/* synthesis syn_black_box black_box_pad_pin="aresetn,m_axi_dma_awvalid,m_axi_dma_awready,m_axi_dma_awaddr[31:0],m_axi_dma_awlen[7:0],m_axi_dma_awburst[1:0],m_axi_dma_wvalid,m_axi_dma_wready,m_axi_dma_wdata[1023:0],m_axi_dma_wlast,m_axi_dma_bvalid,m_axi_dma_bready,m_axi_dma_arvalid,m_axi_dma_arready,m_axi_dma_araddr[31:0],m_axi_dma_arlen[7:0],m_axi_dma_arburst[1:0],m_axi_dma_rvalid,m_axi_dma_rready,m_axi_dma_rdata[1023:0],m_axi_dma_rlast,s_axi_csrs_awvalid,s_axi_csrs_awready,s_axi_csrs_awaddr[11:0],s_axi_csrs_wvalid,s_axi_csrs_wready,s_axi_csrs_wdata[31:0],s_axi_csrs_wstrb[3:0],s_axi_csrs_bvalid,s_axi_csrs_bready,s_axi_csrs_bresp[1:0],s_axi_csrs_arvalid,s_axi_csrs_arready,s_axi_csrs_araddr[11:0],s_axi_csrs_rvalid,s_axi_csrs_rready,s_axi_csrs_rdata[31:0],s_axi_csrs_rresp[1:0],csr0_c2f[31:0],csr0_f2c[31:0],csr1_c2f[31:0],csr1_f2c[31:0],csr2_c2f[31:0],csr2_f2c[31:0],csr3_c2f[31:0],csr3_f2c[31:0],csr4_c2f[31:0],csr4_f2c[31:0],csr5_c2f[31:0],csr5_f2c[31:0],csr6_c2f[31:0],csr6_f2c[31:0],csr7_c2f[31:0],csr7_f2c[31:0],dma_c2f_start,dma_f2c_start,dma_c2f_data[1023:0],dma_f2c_data[1023:0],dma_c2f_addr[31:0],dma_f2c_addr[31:0],dma_done,dma_idle,dma_error" */
/* synthesis syn_force_seq_prim="aclk" */;
  input aclk /* synthesis syn_isclock = 1 */;
  input aresetn;
  output m_axi_dma_awvalid;
  input m_axi_dma_awready;
  output [31:0]m_axi_dma_awaddr;
  output [7:0]m_axi_dma_awlen;
  output [1:0]m_axi_dma_awburst;
  output m_axi_dma_wvalid;
  input m_axi_dma_wready;
  output [1023:0]m_axi_dma_wdata;
  output m_axi_dma_wlast;
  input m_axi_dma_bvalid;
  output m_axi_dma_bready;
  output m_axi_dma_arvalid;
  input m_axi_dma_arready;
  output [31:0]m_axi_dma_araddr;
  output [7:0]m_axi_dma_arlen;
  output [1:0]m_axi_dma_arburst;
  input m_axi_dma_rvalid;
  output m_axi_dma_rready;
  input [1023:0]m_axi_dma_rdata;
  input m_axi_dma_rlast;
  input s_axi_csrs_awvalid;
  output s_axi_csrs_awready;
  input [11:0]s_axi_csrs_awaddr;
  input s_axi_csrs_wvalid;
  output s_axi_csrs_wready;
  input [31:0]s_axi_csrs_wdata;
  input [3:0]s_axi_csrs_wstrb;
  output s_axi_csrs_bvalid;
  input s_axi_csrs_bready;
  output [1:0]s_axi_csrs_bresp;
  input s_axi_csrs_arvalid;
  output s_axi_csrs_arready;
  input [11:0]s_axi_csrs_araddr;
  output s_axi_csrs_rvalid;
  input s_axi_csrs_rready;
  output [31:0]s_axi_csrs_rdata;
  output [1:0]s_axi_csrs_rresp;
  output [31:0]csr0_c2f;
  input [31:0]csr0_f2c;
  output [31:0]csr1_c2f;
  input [31:0]csr1_f2c;
  output [31:0]csr2_c2f;
  input [31:0]csr2_f2c;
  output [31:0]csr3_c2f;
  input [31:0]csr3_f2c;
  output [31:0]csr4_c2f;
  input [31:0]csr4_f2c;
  output [31:0]csr5_c2f;
  input [31:0]csr5_f2c;
  output [31:0]csr6_c2f;
  input [31:0]csr6_f2c;
  output [31:0]csr7_c2f;
  input [31:0]csr7_f2c;
  input dma_c2f_start;
  input dma_f2c_start;
  output [1023:0]dma_c2f_data;
  input [1023:0]dma_f2c_data;
  input [31:0]dma_c2f_addr;
  input [31:0]dma_f2c_addr;
  output dma_done;
  output dma_idle;
  output dma_error;
endmodule
