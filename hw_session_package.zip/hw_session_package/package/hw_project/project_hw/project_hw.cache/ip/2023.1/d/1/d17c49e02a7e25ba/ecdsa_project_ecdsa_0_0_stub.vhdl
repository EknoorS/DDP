-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2023.1 (lin64) Build 3865809 Sun May  7 15:04:56 MDT 2023
-- Date        : Wed Nov 25 15:00:04 2026
-- Host        : pc-klas1-14.esat.kuleuven.be running 64-bit Rocky Linux 9.9 (Blue Onyx)
-- Command     : write_vhdl -force -mode synth_stub -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ ecdsa_project_ecdsa_0_0_stub.vhdl
-- Design      : ecdsa_project_ecdsa_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  Port ( 
    clk : in STD_LOGIC;
    resetn : in STD_LOGIC;
    leds : out STD_LOGIC_VECTOR ( 3 downto 0 );
    rin0 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    rin1 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    rin2 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    rin3 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    rin4 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    rin5 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    rin6 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    rin7 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    rout0 : out STD_LOGIC_VECTOR ( 31 downto 0 );
    rout1 : out STD_LOGIC_VECTOR ( 31 downto 0 );
    rout2 : out STD_LOGIC_VECTOR ( 31 downto 0 );
    rout3 : out STD_LOGIC_VECTOR ( 31 downto 0 );
    rout4 : out STD_LOGIC_VECTOR ( 31 downto 0 );
    rout5 : out STD_LOGIC_VECTOR ( 31 downto 0 );
    rout6 : out STD_LOGIC_VECTOR ( 31 downto 0 );
    rout7 : out STD_LOGIC_VECTOR ( 31 downto 0 );
    dma_rx_data : in STD_LOGIC_VECTOR ( 1023 downto 0 );
    dma_tx_data : out STD_LOGIC_VECTOR ( 1023 downto 0 );
    dma_rx_address : out STD_LOGIC_VECTOR ( 31 downto 0 );
    dma_tx_address : out STD_LOGIC_VECTOR ( 31 downto 0 );
    dma_rx_start : out STD_LOGIC;
    dma_tx_start : out STD_LOGIC;
    dma_done : in STD_LOGIC;
    dma_idle : in STD_LOGIC;
    dma_error : in STD_LOGIC
  );

end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture stub of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "clk,resetn,leds[3:0],rin0[31:0],rin1[31:0],rin2[31:0],rin3[31:0],rin4[31:0],rin5[31:0],rin6[31:0],rin7[31:0],rout0[31:0],rout1[31:0],rout2[31:0],rout3[31:0],rout4[31:0],rout5[31:0],rout6[31:0],rout7[31:0],dma_rx_data[1023:0],dma_tx_data[1023:0],dma_rx_address[31:0],dma_tx_address[31:0],dma_rx_start,dma_tx_start,dma_done,dma_idle,dma_error";
attribute X_CORE_INFO : string;
attribute X_CORE_INFO of stub : architecture is "ecdsa,Vivado 2023.1";
begin
end;
