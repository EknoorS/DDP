-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2023.1 (lin64) Build 3865809 Sun May  7 15:04:56 MDT 2023
-- Date        : Wed Nov 25 15:00:00 2026
-- Host        : pc-klas1-14.esat.kuleuven.be running 64-bit Rocky Linux 9.9 (Blue Onyx)
-- Command     : write_vhdl -force -mode synth_stub -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ ecdsa_project_interfacer_0_0_stub.vhdl
-- Design      : ecdsa_project_interfacer_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  Port ( 
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    m_axi_dma_awvalid : out STD_LOGIC;
    m_axi_dma_awready : in STD_LOGIC;
    m_axi_dma_awaddr : out STD_LOGIC_VECTOR ( 31 downto 0 );
    m_axi_dma_awlen : out STD_LOGIC_VECTOR ( 7 downto 0 );
    m_axi_dma_awburst : out STD_LOGIC_VECTOR ( 1 downto 0 );
    m_axi_dma_wvalid : out STD_LOGIC;
    m_axi_dma_wready : in STD_LOGIC;
    m_axi_dma_wdata : out STD_LOGIC_VECTOR ( 1023 downto 0 );
    m_axi_dma_wlast : out STD_LOGIC;
    m_axi_dma_bvalid : in STD_LOGIC;
    m_axi_dma_bready : out STD_LOGIC;
    m_axi_dma_arvalid : out STD_LOGIC;
    m_axi_dma_arready : in STD_LOGIC;
    m_axi_dma_araddr : out STD_LOGIC_VECTOR ( 31 downto 0 );
    m_axi_dma_arlen : out STD_LOGIC_VECTOR ( 7 downto 0 );
    m_axi_dma_arburst : out STD_LOGIC_VECTOR ( 1 downto 0 );
    m_axi_dma_rvalid : in STD_LOGIC;
    m_axi_dma_rready : out STD_LOGIC;
    m_axi_dma_rdata : in STD_LOGIC_VECTOR ( 1023 downto 0 );
    m_axi_dma_rlast : in STD_LOGIC;
    s_axi_csrs_awvalid : in STD_LOGIC;
    s_axi_csrs_awready : out STD_LOGIC;
    s_axi_csrs_awaddr : in STD_LOGIC_VECTOR ( 11 downto 0 );
    s_axi_csrs_wvalid : in STD_LOGIC;
    s_axi_csrs_wready : out STD_LOGIC;
    s_axi_csrs_wdata : in STD_LOGIC_VECTOR ( 31 downto 0 );
    s_axi_csrs_wstrb : in STD_LOGIC_VECTOR ( 3 downto 0 );
    s_axi_csrs_bvalid : out STD_LOGIC;
    s_axi_csrs_bready : in STD_LOGIC;
    s_axi_csrs_bresp : out STD_LOGIC_VECTOR ( 1 downto 0 );
    s_axi_csrs_arvalid : in STD_LOGIC;
    s_axi_csrs_arready : out STD_LOGIC;
    s_axi_csrs_araddr : in STD_LOGIC_VECTOR ( 11 downto 0 );
    s_axi_csrs_rvalid : out STD_LOGIC;
    s_axi_csrs_rready : in STD_LOGIC;
    s_axi_csrs_rdata : out STD_LOGIC_VECTOR ( 31 downto 0 );
    s_axi_csrs_rresp : out STD_LOGIC_VECTOR ( 1 downto 0 );
    csr0_c2f : out STD_LOGIC_VECTOR ( 31 downto 0 );
    csr0_f2c : in STD_LOGIC_VECTOR ( 31 downto 0 );
    csr1_c2f : out STD_LOGIC_VECTOR ( 31 downto 0 );
    csr1_f2c : in STD_LOGIC_VECTOR ( 31 downto 0 );
    csr2_c2f : out STD_LOGIC_VECTOR ( 31 downto 0 );
    csr2_f2c : in STD_LOGIC_VECTOR ( 31 downto 0 );
    csr3_c2f : out STD_LOGIC_VECTOR ( 31 downto 0 );
    csr3_f2c : in STD_LOGIC_VECTOR ( 31 downto 0 );
    csr4_c2f : out STD_LOGIC_VECTOR ( 31 downto 0 );
    csr4_f2c : in STD_LOGIC_VECTOR ( 31 downto 0 );
    csr5_c2f : out STD_LOGIC_VECTOR ( 31 downto 0 );
    csr5_f2c : in STD_LOGIC_VECTOR ( 31 downto 0 );
    csr6_c2f : out STD_LOGIC_VECTOR ( 31 downto 0 );
    csr6_f2c : in STD_LOGIC_VECTOR ( 31 downto 0 );
    csr7_c2f : out STD_LOGIC_VECTOR ( 31 downto 0 );
    csr7_f2c : in STD_LOGIC_VECTOR ( 31 downto 0 );
    dma_c2f_start : in STD_LOGIC;
    dma_f2c_start : in STD_LOGIC;
    dma_c2f_data : out STD_LOGIC_VECTOR ( 1023 downto 0 );
    dma_f2c_data : in STD_LOGIC_VECTOR ( 1023 downto 0 );
    dma_c2f_addr : in STD_LOGIC_VECTOR ( 31 downto 0 );
    dma_f2c_addr : in STD_LOGIC_VECTOR ( 31 downto 0 );
    dma_done : out STD_LOGIC;
    dma_idle : out STD_LOGIC;
    dma_error : out STD_LOGIC
  );

end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture stub of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "aclk,aresetn,m_axi_dma_awvalid,m_axi_dma_awready,m_axi_dma_awaddr[31:0],m_axi_dma_awlen[7:0],m_axi_dma_awburst[1:0],m_axi_dma_wvalid,m_axi_dma_wready,m_axi_dma_wdata[1023:0],m_axi_dma_wlast,m_axi_dma_bvalid,m_axi_dma_bready,m_axi_dma_arvalid,m_axi_dma_arready,m_axi_dma_araddr[31:0],m_axi_dma_arlen[7:0],m_axi_dma_arburst[1:0],m_axi_dma_rvalid,m_axi_dma_rready,m_axi_dma_rdata[1023:0],m_axi_dma_rlast,s_axi_csrs_awvalid,s_axi_csrs_awready,s_axi_csrs_awaddr[11:0],s_axi_csrs_wvalid,s_axi_csrs_wready,s_axi_csrs_wdata[31:0],s_axi_csrs_wstrb[3:0],s_axi_csrs_bvalid,s_axi_csrs_bready,s_axi_csrs_bresp[1:0],s_axi_csrs_arvalid,s_axi_csrs_arready,s_axi_csrs_araddr[11:0],s_axi_csrs_rvalid,s_axi_csrs_rready,s_axi_csrs_rdata[31:0],s_axi_csrs_rresp[1:0],csr0_c2f[31:0],csr0_f2c[31:0],csr1_c2f[31:0],csr1_f2c[31:0],csr2_c2f[31:0],csr2_f2c[31:0],csr3_c2f[31:0],csr3_f2c[31:0],csr4_c2f[31:0],csr4_f2c[31:0],csr5_c2f[31:0],csr5_f2c[31:0],csr6_c2f[31:0],csr6_f2c[31:0],csr7_c2f[31:0],csr7_f2c[31:0],dma_c2f_start,dma_f2c_start,dma_c2f_data[1023:0],dma_f2c_data[1023:0],dma_c2f_addr[31:0],dma_f2c_addr[31:0],dma_done,dma_idle,dma_error";
attribute X_CORE_INFO : string;
attribute X_CORE_INFO of stub : architecture is "interfacer,Vivado 2023.1";
begin
end;
