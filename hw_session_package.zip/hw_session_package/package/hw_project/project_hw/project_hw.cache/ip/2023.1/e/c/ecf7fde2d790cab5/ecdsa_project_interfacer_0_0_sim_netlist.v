// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2023.1 (lin64) Build 3865809 Sun May  7 15:04:56 MDT 2023
// Date        : Wed Nov 25 15:00:00 2026
// Host        : pc-klas1-14.esat.kuleuven.be running 64-bit Rocky Linux 9.9 (Blue Onyx)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ ecdsa_project_interfacer_0_0_sim_netlist.v
// Design      : ecdsa_project_interfacer_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "ecdsa_project_interfacer_0_0,interfacer,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "interfacer,Vivado 2023.1" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (aclk,
    aresetn,
    m_axi_dma_awvalid,
    m_axi_dma_awready,
    m_axi_dma_awaddr,
    m_axi_dma_awlen,
    m_axi_dma_awburst,
    m_axi_dma_wvalid,
    m_axi_dma_wready,
    m_axi_dma_wdata,
    m_axi_dma_wlast,
    m_axi_dma_bvalid,
    m_axi_dma_bready,
    m_axi_dma_arvalid,
    m_axi_dma_arready,
    m_axi_dma_araddr,
    m_axi_dma_arlen,
    m_axi_dma_arburst,
    m_axi_dma_rvalid,
    m_axi_dma_rready,
    m_axi_dma_rdata,
    m_axi_dma_rlast,
    s_axi_csrs_awvalid,
    s_axi_csrs_awready,
    s_axi_csrs_awaddr,
    s_axi_csrs_wvalid,
    s_axi_csrs_wready,
    s_axi_csrs_wdata,
    s_axi_csrs_wstrb,
    s_axi_csrs_bvalid,
    s_axi_csrs_bready,
    s_axi_csrs_bresp,
    s_axi_csrs_arvalid,
    s_axi_csrs_arready,
    s_axi_csrs_araddr,
    s_axi_csrs_rvalid,
    s_axi_csrs_rready,
    s_axi_csrs_rdata,
    s_axi_csrs_rresp,
    csr0_c2f,
    csr0_f2c,
    csr1_c2f,
    csr1_f2c,
    csr2_c2f,
    csr2_f2c,
    csr3_c2f,
    csr3_f2c,
    csr4_c2f,
    csr4_f2c,
    csr5_c2f,
    csr5_f2c,
    csr6_c2f,
    csr6_f2c,
    csr7_c2f,
    csr7_f2c,
    dma_c2f_start,
    dma_f2c_start,
    dma_c2f_data,
    dma_f2c_data,
    dma_c2f_addr,
    dma_f2c_addr,
    dma_done,
    dma_idle,
    dma_error);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 aclk CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF m_axi_dma:s_axi_csrs, ASSOCIATED_RESET aresetn, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN ecdsa_project_processing_system7_0_0_FCLK_CLK0, INSERT_VIP 0" *) input aclk;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 aresetn RST" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input aresetn;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma AWVALID" *) output m_axi_dma_awvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma AWREADY" *) input m_axi_dma_awready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma AWADDR" *) output [31:0]m_axi_dma_awaddr;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma AWLEN" *) output [7:0]m_axi_dma_awlen;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma AWBURST" *) output [1:0]m_axi_dma_awburst;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma WVALID" *) output m_axi_dma_wvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma WREADY" *) input m_axi_dma_wready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma WDATA" *) output [1023:0]m_axi_dma_wdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma WLAST" *) output m_axi_dma_wlast;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma BVALID" *) input m_axi_dma_bvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma BREADY" *) output m_axi_dma_bready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma ARVALID" *) output m_axi_dma_arvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma ARREADY" *) input m_axi_dma_arready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma ARADDR" *) output [31:0]m_axi_dma_araddr;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma ARLEN" *) output [7:0]m_axi_dma_arlen;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma ARBURST" *) output [1:0]m_axi_dma_arburst;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma RVALID" *) input m_axi_dma_rvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma RREADY" *) output m_axi_dma_rready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma RDATA" *) input [1023:0]m_axi_dma_rdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma RLAST" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME m_axi_dma, DATA_WIDTH 1024, PROTOCOL AXI4, FREQ_HZ 100000000, ID_WIDTH 0, ADDR_WIDTH 32, AWUSER_WIDTH 0, ARUSER_WIDTH 0, WUSER_WIDTH 0, RUSER_WIDTH 0, BUSER_WIDTH 0, READ_WRITE_MODE READ_WRITE, HAS_BURST 1, HAS_LOCK 0, HAS_PROT 0, HAS_CACHE 0, HAS_QOS 0, HAS_REGION 0, HAS_WSTRB 0, HAS_BRESP 0, HAS_RRESP 0, SUPPORTS_NARROW_BURST 0, NUM_READ_OUTSTANDING 2, NUM_WRITE_OUTSTANDING 2, MAX_BURST_LENGTH 256, PHASE 0.0, CLK_DOMAIN ecdsa_project_processing_system7_0_0_FCLK_CLK0, NUM_READ_THREADS 1, NUM_WRITE_THREADS 1, RUSER_BITS_PER_BYTE 0, WUSER_BITS_PER_BYTE 0, INSERT_VIP 0" *) input m_axi_dma_rlast;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs AWVALID" *) input s_axi_csrs_awvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs AWREADY" *) output s_axi_csrs_awready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs AWADDR" *) input [11:0]s_axi_csrs_awaddr;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs WVALID" *) input s_axi_csrs_wvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs WREADY" *) output s_axi_csrs_wready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs WDATA" *) input [31:0]s_axi_csrs_wdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs WSTRB" *) input [3:0]s_axi_csrs_wstrb;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs BVALID" *) output s_axi_csrs_bvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs BREADY" *) input s_axi_csrs_bready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs BRESP" *) output [1:0]s_axi_csrs_bresp;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs ARVALID" *) input s_axi_csrs_arvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs ARREADY" *) output s_axi_csrs_arready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs ARADDR" *) input [11:0]s_axi_csrs_araddr;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs RVALID" *) output s_axi_csrs_rvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs RREADY" *) input s_axi_csrs_rready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs RDATA" *) output [31:0]s_axi_csrs_rdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs RRESP" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME s_axi_csrs, DATA_WIDTH 32, PROTOCOL AXI4LITE, FREQ_HZ 100000000, ID_WIDTH 0, ADDR_WIDTH 12, AWUSER_WIDTH 0, ARUSER_WIDTH 0, WUSER_WIDTH 0, RUSER_WIDTH 0, BUSER_WIDTH 0, READ_WRITE_MODE READ_WRITE, HAS_BURST 0, HAS_LOCK 0, HAS_PROT 0, HAS_CACHE 0, HAS_QOS 0, HAS_REGION 0, HAS_WSTRB 1, HAS_BRESP 1, HAS_RRESP 1, SUPPORTS_NARROW_BURST 0, NUM_READ_OUTSTANDING 1, NUM_WRITE_OUTSTANDING 1, MAX_BURST_LENGTH 1, PHASE 0.0, CLK_DOMAIN ecdsa_project_processing_system7_0_0_FCLK_CLK0, NUM_READ_THREADS 4, NUM_WRITE_THREADS 4, RUSER_BITS_PER_BYTE 0, WUSER_BITS_PER_BYTE 0, INSERT_VIP 0" *) output [1:0]s_axi_csrs_rresp;
  output [31:0]csr0_c2f;
  input [31:0]csr0_f2c;
  output [31:0]csr1_c2f;
  input [31:0]csr1_f2c;
  output [31:0]csr2_c2f;
  input [31:0]csr2_f2c;
  output [31:0]csr3_c2f;
  input [31:0]csr3_f2c;
  output [31:0]csr4_c2f;
  input [31:0]csr4_f2c;
  output [31:0]csr5_c2f;
  input [31:0]csr5_f2c;
  output [31:0]csr6_c2f;
  input [31:0]csr6_f2c;
  output [31:0]csr7_c2f;
  input [31:0]csr7_f2c;
  input dma_c2f_start;
  input dma_f2c_start;
  output [1023:0]dma_c2f_data;
  input [1023:0]dma_f2c_data;
  input [31:0]dma_c2f_addr;
  input [31:0]dma_f2c_addr;
  output dma_done;
  output dma_idle;
  output dma_error;

  wire \<const0> ;
  wire \<const1> ;
  wire aclk;
  wire aresetn;
  wire [31:0]csr0_c2f;
  wire [31:0]csr0_f2c;
  wire [31:0]csr1_c2f;
  wire [31:0]csr1_f2c;
  wire [31:0]csr2_c2f;
  wire [31:0]csr2_f2c;
  wire [31:0]csr3_c2f;
  wire [31:0]csr3_f2c;
  wire [31:0]csr4_c2f;
  wire [31:0]csr4_f2c;
  wire [31:0]csr5_c2f;
  wire [31:0]csr5_f2c;
  wire [31:0]csr6_c2f;
  wire [31:0]csr6_f2c;
  wire [31:0]csr7_c2f;
  wire [31:0]csr7_f2c;
  wire [31:0]dma_c2f_addr;
  wire dma_c2f_start;
  wire dma_done;
  wire dma_error;
  wire [31:0]dma_f2c_addr;
  wire [1023:0]dma_f2c_data;
  wire dma_f2c_start;
  wire dma_idle;
  wire m_axi_dma_arready;
  wire m_axi_dma_arvalid;
  wire m_axi_dma_awready;
  wire m_axi_dma_awvalid;
  wire m_axi_dma_bready;
  wire m_axi_dma_bvalid;
  wire [1023:0]m_axi_dma_rdata;
  wire m_axi_dma_rready;
  wire m_axi_dma_rvalid;
  wire m_axi_dma_wready;
  wire m_axi_dma_wvalid;
  wire [11:0]s_axi_csrs_araddr;
  wire s_axi_csrs_arready;
  wire s_axi_csrs_arvalid;
  wire [11:0]s_axi_csrs_awaddr;
  wire s_axi_csrs_awready;
  wire s_axi_csrs_awvalid;
  wire s_axi_csrs_bready;
  wire s_axi_csrs_bvalid;
  wire [31:0]s_axi_csrs_rdata;
  wire s_axi_csrs_rready;
  wire s_axi_csrs_rvalid;
  wire [31:0]s_axi_csrs_wdata;
  wire s_axi_csrs_wready;
  wire [3:0]s_axi_csrs_wstrb;
  wire s_axi_csrs_wvalid;

  assign dma_c2f_data[1023:0] = m_axi_dma_rdata;
  assign m_axi_dma_araddr[31:0] = dma_c2f_addr;
  assign m_axi_dma_arburst[1] = \<const0> ;
  assign m_axi_dma_arburst[0] = \<const1> ;
  assign m_axi_dma_arlen[7] = \<const0> ;
  assign m_axi_dma_arlen[6] = \<const0> ;
  assign m_axi_dma_arlen[5] = \<const0> ;
  assign m_axi_dma_arlen[4] = \<const0> ;
  assign m_axi_dma_arlen[3] = \<const0> ;
  assign m_axi_dma_arlen[2] = \<const0> ;
  assign m_axi_dma_arlen[1] = \<const0> ;
  assign m_axi_dma_arlen[0] = \<const0> ;
  assign m_axi_dma_awaddr[31:0] = dma_f2c_addr;
  assign m_axi_dma_awburst[1] = \<const0> ;
  assign m_axi_dma_awburst[0] = \<const1> ;
  assign m_axi_dma_awlen[7] = \<const0> ;
  assign m_axi_dma_awlen[6] = \<const0> ;
  assign m_axi_dma_awlen[5] = \<const0> ;
  assign m_axi_dma_awlen[4] = \<const0> ;
  assign m_axi_dma_awlen[3] = \<const0> ;
  assign m_axi_dma_awlen[2] = \<const0> ;
  assign m_axi_dma_awlen[1] = \<const0> ;
  assign m_axi_dma_awlen[0] = \<const0> ;
  assign m_axi_dma_wdata[1023:0] = dma_f2c_data;
  assign m_axi_dma_wlast = m_axi_dma_wvalid;
  assign s_axi_csrs_bresp[1] = \<const0> ;
  assign s_axi_csrs_bresp[0] = \<const0> ;
  assign s_axi_csrs_rresp[1] = \<const0> ;
  assign s_axi_csrs_rresp[0] = \<const0> ;
  GND GND
       (.G(\<const0> ));
  VCC VCC
       (.P(\<const1> ));
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_interfacer inst
       (.aclk(aclk),
        .aresetn(aresetn),
        .csr0_c2f(csr0_c2f),
        .csr0_f2c(csr0_f2c),
        .csr1_c2f(csr1_c2f),
        .csr1_f2c(csr1_f2c),
        .csr2_c2f(csr2_c2f),
        .csr2_f2c(csr2_f2c),
        .csr3_c2f(csr3_c2f),
        .csr3_f2c(csr3_f2c),
        .csr4_c2f(csr4_c2f),
        .csr4_f2c(csr4_f2c),
        .csr5_c2f(csr5_c2f),
        .csr5_f2c(csr5_f2c),
        .csr6_c2f(csr6_c2f),
        .csr6_f2c(csr6_f2c),
        .csr7_c2f(csr7_c2f),
        .csr7_f2c(csr7_f2c),
        .dma_c2f_addr(dma_c2f_addr[6:0]),
        .dma_c2f_start(dma_c2f_start),
        .dma_done(dma_done),
        .dma_error(dma_error),
        .dma_f2c_addr(dma_f2c_addr[6:0]),
        .dma_f2c_start(dma_f2c_start),
        .dma_idle(dma_idle),
        .m_axi_dma_arready(m_axi_dma_arready),
        .m_axi_dma_arvalid(m_axi_dma_arvalid),
        .m_axi_dma_awready(m_axi_dma_awready),
        .m_axi_dma_awvalid(m_axi_dma_awvalid),
        .m_axi_dma_bready(m_axi_dma_bready),
        .m_axi_dma_bvalid(m_axi_dma_bvalid),
        .m_axi_dma_rready(m_axi_dma_rready),
        .m_axi_dma_rvalid(m_axi_dma_rvalid),
        .m_axi_dma_wready(m_axi_dma_wready),
        .m_axi_dma_wvalid(m_axi_dma_wvalid),
        .s_axi_csrs_araddr(s_axi_csrs_araddr[4:0]),
        .s_axi_csrs_arready(s_axi_csrs_arready),
        .s_axi_csrs_arvalid(s_axi_csrs_arvalid),
        .s_axi_csrs_awaddr(s_axi_csrs_awaddr[4:0]),
        .s_axi_csrs_awready(s_axi_csrs_awready),
        .s_axi_csrs_awvalid(s_axi_csrs_awvalid),
        .s_axi_csrs_bready(s_axi_csrs_bready),
        .s_axi_csrs_bvalid(s_axi_csrs_bvalid),
        .s_axi_csrs_rdata(s_axi_csrs_rdata),
        .s_axi_csrs_rready(s_axi_csrs_rready),
        .s_axi_csrs_rvalid(s_axi_csrs_rvalid),
        .s_axi_csrs_wdata(s_axi_csrs_wdata),
        .s_axi_csrs_wready(s_axi_csrs_wready),
        .s_axi_csrs_wstrb(s_axi_csrs_wstrb),
        .s_axi_csrs_wvalid(s_axi_csrs_wvalid));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_interfacer
   (s_axi_csrs_wready,
    s_axi_csrs_rdata,
    csr0_c2f,
    csr1_c2f,
    csr2_c2f,
    csr3_c2f,
    csr4_c2f,
    csr5_c2f,
    csr6_c2f,
    csr7_c2f,
    m_axi_dma_bready,
    m_axi_dma_wvalid,
    dma_idle,
    m_axi_dma_awvalid,
    dma_done,
    m_axi_dma_rready,
    m_axi_dma_arvalid,
    s_axi_csrs_awready,
    s_axi_csrs_bvalid,
    s_axi_csrs_rvalid,
    s_axi_csrs_arready,
    dma_error,
    dma_c2f_start,
    dma_f2c_start,
    s_axi_csrs_wvalid,
    s_axi_csrs_awvalid,
    aclk,
    csr3_f2c,
    csr2_f2c,
    s_axi_csrs_araddr,
    csr1_f2c,
    csr0_f2c,
    csr7_f2c,
    csr6_f2c,
    csr5_f2c,
    csr4_f2c,
    s_axi_csrs_arvalid,
    s_axi_csrs_awaddr,
    m_axi_dma_bvalid,
    m_axi_dma_rvalid,
    m_axi_dma_awready,
    m_axi_dma_wready,
    m_axi_dma_arready,
    dma_f2c_addr,
    dma_c2f_addr,
    s_axi_csrs_rready,
    s_axi_csrs_bready,
    s_axi_csrs_wdata,
    s_axi_csrs_wstrb,
    aresetn);
  output s_axi_csrs_wready;
  output [31:0]s_axi_csrs_rdata;
  output [31:0]csr0_c2f;
  output [31:0]csr1_c2f;
  output [31:0]csr2_c2f;
  output [31:0]csr3_c2f;
  output [31:0]csr4_c2f;
  output [31:0]csr5_c2f;
  output [31:0]csr6_c2f;
  output [31:0]csr7_c2f;
  output m_axi_dma_bready;
  output m_axi_dma_wvalid;
  output dma_idle;
  output m_axi_dma_awvalid;
  output dma_done;
  output m_axi_dma_rready;
  output m_axi_dma_arvalid;
  output s_axi_csrs_awready;
  output s_axi_csrs_bvalid;
  output s_axi_csrs_rvalid;
  output s_axi_csrs_arready;
  output dma_error;
  input dma_c2f_start;
  input dma_f2c_start;
  input s_axi_csrs_wvalid;
  input s_axi_csrs_awvalid;
  input aclk;
  input [31:0]csr3_f2c;
  input [31:0]csr2_f2c;
  input [4:0]s_axi_csrs_araddr;
  input [31:0]csr1_f2c;
  input [31:0]csr0_f2c;
  input [31:0]csr7_f2c;
  input [31:0]csr6_f2c;
  input [31:0]csr5_f2c;
  input [31:0]csr4_f2c;
  input s_axi_csrs_arvalid;
  input [4:0]s_axi_csrs_awaddr;
  input m_axi_dma_bvalid;
  input m_axi_dma_rvalid;
  input m_axi_dma_awready;
  input m_axi_dma_wready;
  input m_axi_dma_arready;
  input [6:0]dma_f2c_addr;
  input [6:0]dma_c2f_addr;
  input s_axi_csrs_rready;
  input s_axi_csrs_bready;
  input [31:0]s_axi_csrs_wdata;
  input [3:0]s_axi_csrs_wstrb;
  input aresetn;

  wire aclk;
  wire ar_hs;
  wire aresetn;
  wire aw_hs;
  wire [31:0]csr00;
  wire \csr0[31]_i_1_n_0 ;
  wire \csr0[31]_i_3_n_0 ;
  wire \csr0[31]_i_4_n_0 ;
  wire [31:0]csr0_c2f;
  wire [31:0]csr0_f2c;
  wire [31:0]csr10;
  wire \csr1[31]_i_1_n_0 ;
  wire [31:0]csr1_c2f;
  wire [31:0]csr1_f2c;
  wire [31:0]csr20;
  wire \csr2[31]_i_1_n_0 ;
  wire [31:0]csr2_c2f;
  wire [31:0]csr2_f2c;
  wire [31:0]csr30;
  wire \csr3[31]_i_1_n_0 ;
  wire [31:0]csr3_c2f;
  wire [31:0]csr3_f2c;
  wire [31:0]csr40;
  wire \csr4[31]_i_1_n_0 ;
  wire \csr4[31]_i_3_n_0 ;
  wire [31:0]csr4_c2f;
  wire [31:0]csr4_f2c;
  wire [31:0]csr50;
  wire \csr5[31]_i_1_n_0 ;
  wire [31:0]csr5_c2f;
  wire [31:0]csr5_f2c;
  wire [31:0]csr60;
  wire \csr6[31]_i_1_n_0 ;
  wire [31:0]csr6_c2f;
  wire [31:0]csr6_f2c;
  wire [31:0]csr70;
  wire \csr7[31]_i_1_n_0 ;
  wire [31:0]csr7_c2f;
  wire [31:0]csr7_f2c;
  wire [6:0]dma_c2f_addr;
  wire dma_c2f_start;
  wire dma_done;
  wire dma_error;
  wire dma_error_set_i_1_n_0;
  wire dma_error_set_i_2_n_0;
  wire dma_error_set_i_5_n_0;
  wire dma_error_set_i_6_n_0;
  wire [6:0]dma_f2c_addr;
  wire dma_f2c_start;
  wire dma_idle;
  wire m_axi_dma_arready;
  wire m_axi_dma_arvalid;
  wire m_axi_dma_awready;
  wire m_axi_dma_awvalid;
  wire m_axi_dma_bready;
  wire m_axi_dma_bvalid;
  wire m_axi_dma_rready;
  wire m_axi_dma_rvalid;
  wire m_axi_dma_wready;
  wire m_axi_dma_wvalid;
  wire [5:1]next_state__0;
  wire next_state_n_0;
  wire \rdata[0]_i_2_n_0 ;
  wire \rdata[0]_i_3_n_0 ;
  wire \rdata[10]_i_2_n_0 ;
  wire \rdata[10]_i_3_n_0 ;
  wire \rdata[11]_i_2_n_0 ;
  wire \rdata[11]_i_3_n_0 ;
  wire \rdata[12]_i_2_n_0 ;
  wire \rdata[12]_i_3_n_0 ;
  wire \rdata[13]_i_2_n_0 ;
  wire \rdata[13]_i_3_n_0 ;
  wire \rdata[14]_i_2_n_0 ;
  wire \rdata[14]_i_3_n_0 ;
  wire \rdata[15]_i_2_n_0 ;
  wire \rdata[15]_i_3_n_0 ;
  wire \rdata[16]_i_2_n_0 ;
  wire \rdata[16]_i_3_n_0 ;
  wire \rdata[17]_i_2_n_0 ;
  wire \rdata[17]_i_3_n_0 ;
  wire \rdata[18]_i_2_n_0 ;
  wire \rdata[18]_i_3_n_0 ;
  wire \rdata[19]_i_2_n_0 ;
  wire \rdata[19]_i_3_n_0 ;
  wire \rdata[1]_i_2_n_0 ;
  wire \rdata[1]_i_3_n_0 ;
  wire \rdata[20]_i_2_n_0 ;
  wire \rdata[20]_i_3_n_0 ;
  wire \rdata[21]_i_2_n_0 ;
  wire \rdata[21]_i_3_n_0 ;
  wire \rdata[22]_i_2_n_0 ;
  wire \rdata[22]_i_3_n_0 ;
  wire \rdata[23]_i_2_n_0 ;
  wire \rdata[23]_i_3_n_0 ;
  wire \rdata[24]_i_2_n_0 ;
  wire \rdata[24]_i_3_n_0 ;
  wire \rdata[25]_i_2_n_0 ;
  wire \rdata[25]_i_3_n_0 ;
  wire \rdata[26]_i_2_n_0 ;
  wire \rdata[26]_i_3_n_0 ;
  wire \rdata[27]_i_2_n_0 ;
  wire \rdata[27]_i_3_n_0 ;
  wire \rdata[28]_i_2_n_0 ;
  wire \rdata[28]_i_3_n_0 ;
  wire \rdata[29]_i_2_n_0 ;
  wire \rdata[29]_i_3_n_0 ;
  wire \rdata[2]_i_2_n_0 ;
  wire \rdata[2]_i_3_n_0 ;
  wire \rdata[30]_i_2_n_0 ;
  wire \rdata[30]_i_3_n_0 ;
  wire \rdata[31]_i_1_n_0 ;
  wire \rdata[31]_i_4_n_0 ;
  wire \rdata[31]_i_5_n_0 ;
  wire \rdata[31]_i_6_n_0 ;
  wire \rdata[3]_i_2_n_0 ;
  wire \rdata[3]_i_3_n_0 ;
  wire \rdata[4]_i_2_n_0 ;
  wire \rdata[4]_i_3_n_0 ;
  wire \rdata[5]_i_2_n_0 ;
  wire \rdata[5]_i_3_n_0 ;
  wire \rdata[6]_i_2_n_0 ;
  wire \rdata[6]_i_3_n_0 ;
  wire \rdata[7]_i_2_n_0 ;
  wire \rdata[7]_i_3_n_0 ;
  wire \rdata[8]_i_2_n_0 ;
  wire \rdata[8]_i_3_n_0 ;
  wire \rdata[9]_i_2_n_0 ;
  wire \rdata[9]_i_3_n_0 ;
  wire \rdata_reg[0]_i_1_n_0 ;
  wire \rdata_reg[10]_i_1_n_0 ;
  wire \rdata_reg[11]_i_1_n_0 ;
  wire \rdata_reg[12]_i_1_n_0 ;
  wire \rdata_reg[13]_i_1_n_0 ;
  wire \rdata_reg[14]_i_1_n_0 ;
  wire \rdata_reg[15]_i_1_n_0 ;
  wire \rdata_reg[16]_i_1_n_0 ;
  wire \rdata_reg[17]_i_1_n_0 ;
  wire \rdata_reg[18]_i_1_n_0 ;
  wire \rdata_reg[19]_i_1_n_0 ;
  wire \rdata_reg[1]_i_1_n_0 ;
  wire \rdata_reg[20]_i_1_n_0 ;
  wire \rdata_reg[21]_i_1_n_0 ;
  wire \rdata_reg[22]_i_1_n_0 ;
  wire \rdata_reg[23]_i_1_n_0 ;
  wire \rdata_reg[24]_i_1_n_0 ;
  wire \rdata_reg[25]_i_1_n_0 ;
  wire \rdata_reg[26]_i_1_n_0 ;
  wire \rdata_reg[27]_i_1_n_0 ;
  wire \rdata_reg[28]_i_1_n_0 ;
  wire \rdata_reg[29]_i_1_n_0 ;
  wire \rdata_reg[2]_i_1_n_0 ;
  wire \rdata_reg[30]_i_1_n_0 ;
  wire \rdata_reg[31]_i_3_n_0 ;
  wire \rdata_reg[3]_i_1_n_0 ;
  wire \rdata_reg[4]_i_1_n_0 ;
  wire \rdata_reg[5]_i_1_n_0 ;
  wire \rdata_reg[6]_i_1_n_0 ;
  wire \rdata_reg[7]_i_1_n_0 ;
  wire \rdata_reg[8]_i_1_n_0 ;
  wire \rdata_reg[9]_i_1_n_0 ;
  wire [1:0]rnext;
  wire [1:0]rstate;
  wire [4:0]s_axi_csrs_araddr;
  wire s_axi_csrs_arready;
  wire s_axi_csrs_arvalid;
  wire [4:0]s_axi_csrs_awaddr;
  wire s_axi_csrs_awready;
  wire s_axi_csrs_awvalid;
  wire s_axi_csrs_bready;
  wire s_axi_csrs_bvalid;
  wire [31:0]s_axi_csrs_rdata;
  wire s_axi_csrs_rready;
  wire s_axi_csrs_rvalid;
  wire [31:0]s_axi_csrs_wdata;
  wire s_axi_csrs_wready;
  wire [3:0]s_axi_csrs_wstrb;
  wire s_axi_csrs_wvalid;
  wire [5:0]state;
  wire \state[0]_i_1_n_0 ;
  wire \state[0]_i_2_n_0 ;
  wire [4:0]waddr;
  wire [2:0]wnext;
  wire wrong_addr00_in;
  wire wrong_addr0__6;
  wire [3:0]wstate;
  wire \wstate[1]_i_1_n_0 ;

  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr0[0]_i_1 
       (.I0(s_axi_csrs_wdata[0]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr0_c2f[0]),
        .O(csr00[0]));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr0[10]_i_1 
       (.I0(s_axi_csrs_wdata[10]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr0_c2f[10]),
        .O(csr00[10]));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr0[11]_i_1 
       (.I0(s_axi_csrs_wdata[11]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr0_c2f[11]),
        .O(csr00[11]));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr0[12]_i_1 
       (.I0(s_axi_csrs_wdata[12]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr0_c2f[12]),
        .O(csr00[12]));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr0[13]_i_1 
       (.I0(s_axi_csrs_wdata[13]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr0_c2f[13]),
        .O(csr00[13]));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr0[14]_i_1 
       (.I0(s_axi_csrs_wdata[14]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr0_c2f[14]),
        .O(csr00[14]));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr0[15]_i_1 
       (.I0(s_axi_csrs_wdata[15]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr0_c2f[15]),
        .O(csr00[15]));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr0[16]_i_1 
       (.I0(s_axi_csrs_wdata[16]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr0_c2f[16]),
        .O(csr00[16]));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr0[17]_i_1 
       (.I0(s_axi_csrs_wdata[17]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr0_c2f[17]),
        .O(csr00[17]));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr0[18]_i_1 
       (.I0(s_axi_csrs_wdata[18]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr0_c2f[18]),
        .O(csr00[18]));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr0[19]_i_1 
       (.I0(s_axi_csrs_wdata[19]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr0_c2f[19]),
        .O(csr00[19]));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr0[1]_i_1 
       (.I0(s_axi_csrs_wdata[1]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr0_c2f[1]),
        .O(csr00[1]));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr0[20]_i_1 
       (.I0(s_axi_csrs_wdata[20]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr0_c2f[20]),
        .O(csr00[20]));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr0[21]_i_1 
       (.I0(s_axi_csrs_wdata[21]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr0_c2f[21]),
        .O(csr00[21]));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr0[22]_i_1 
       (.I0(s_axi_csrs_wdata[22]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr0_c2f[22]),
        .O(csr00[22]));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr0[23]_i_1 
       (.I0(s_axi_csrs_wdata[23]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr0_c2f[23]),
        .O(csr00[23]));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr0[24]_i_1 
       (.I0(s_axi_csrs_wdata[24]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr0_c2f[24]),
        .O(csr00[24]));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr0[25]_i_1 
       (.I0(s_axi_csrs_wdata[25]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr0_c2f[25]),
        .O(csr00[25]));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr0[26]_i_1 
       (.I0(s_axi_csrs_wdata[26]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr0_c2f[26]),
        .O(csr00[26]));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr0[27]_i_1 
       (.I0(s_axi_csrs_wdata[27]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr0_c2f[27]),
        .O(csr00[27]));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr0[28]_i_1 
       (.I0(s_axi_csrs_wdata[28]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr0_c2f[28]),
        .O(csr00[28]));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr0[29]_i_1 
       (.I0(s_axi_csrs_wdata[29]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr0_c2f[29]),
        .O(csr00[29]));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr0[2]_i_1 
       (.I0(s_axi_csrs_wdata[2]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr0_c2f[2]),
        .O(csr00[2]));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr0[30]_i_1 
       (.I0(s_axi_csrs_wdata[30]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr0_c2f[30]),
        .O(csr00[30]));
  LUT4 #(
    .INIT(16'h0004)) 
    \csr0[31]_i_1 
       (.I0(waddr[3]),
        .I1(\csr0[31]_i_3_n_0 ),
        .I2(waddr[4]),
        .I3(waddr[2]),
        .O(\csr0[31]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr0[31]_i_2 
       (.I0(s_axi_csrs_wdata[31]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr0_c2f[31]),
        .O(csr00[31]));
  LUT6 #(
    .INIT(64'h0000000000000400)) 
    \csr0[31]_i_3 
       (.I0(waddr[0]),
        .I1(s_axi_csrs_wvalid),
        .I2(wstate[0]),
        .I3(wstate[1]),
        .I4(\csr0[31]_i_4_n_0 ),
        .I5(waddr[1]),
        .O(\csr0[31]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \csr0[31]_i_4 
       (.I0(wstate[2]),
        .I1(wstate[3]),
        .O(\csr0[31]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr0[3]_i_1 
       (.I0(s_axi_csrs_wdata[3]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr0_c2f[3]),
        .O(csr00[3]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr0[4]_i_1 
       (.I0(s_axi_csrs_wdata[4]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr0_c2f[4]),
        .O(csr00[4]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr0[5]_i_1 
       (.I0(s_axi_csrs_wdata[5]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr0_c2f[5]),
        .O(csr00[5]));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr0[6]_i_1 
       (.I0(s_axi_csrs_wdata[6]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr0_c2f[6]),
        .O(csr00[6]));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr0[7]_i_1 
       (.I0(s_axi_csrs_wdata[7]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr0_c2f[7]),
        .O(csr00[7]));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr0[8]_i_1 
       (.I0(s_axi_csrs_wdata[8]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr0_c2f[8]),
        .O(csr00[8]));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr0[9]_i_1 
       (.I0(s_axi_csrs_wdata[9]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr0_c2f[9]),
        .O(csr00[9]));
  FDRE #(
    .INIT(1'b0)) 
    \csr0_reg[0] 
       (.C(aclk),
        .CE(\csr0[31]_i_1_n_0 ),
        .D(csr00[0]),
        .Q(csr0_c2f[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr0_reg[10] 
       (.C(aclk),
        .CE(\csr0[31]_i_1_n_0 ),
        .D(csr00[10]),
        .Q(csr0_c2f[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr0_reg[11] 
       (.C(aclk),
        .CE(\csr0[31]_i_1_n_0 ),
        .D(csr00[11]),
        .Q(csr0_c2f[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr0_reg[12] 
       (.C(aclk),
        .CE(\csr0[31]_i_1_n_0 ),
        .D(csr00[12]),
        .Q(csr0_c2f[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr0_reg[13] 
       (.C(aclk),
        .CE(\csr0[31]_i_1_n_0 ),
        .D(csr00[13]),
        .Q(csr0_c2f[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr0_reg[14] 
       (.C(aclk),
        .CE(\csr0[31]_i_1_n_0 ),
        .D(csr00[14]),
        .Q(csr0_c2f[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr0_reg[15] 
       (.C(aclk),
        .CE(\csr0[31]_i_1_n_0 ),
        .D(csr00[15]),
        .Q(csr0_c2f[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr0_reg[16] 
       (.C(aclk),
        .CE(\csr0[31]_i_1_n_0 ),
        .D(csr00[16]),
        .Q(csr0_c2f[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr0_reg[17] 
       (.C(aclk),
        .CE(\csr0[31]_i_1_n_0 ),
        .D(csr00[17]),
        .Q(csr0_c2f[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr0_reg[18] 
       (.C(aclk),
        .CE(\csr0[31]_i_1_n_0 ),
        .D(csr00[18]),
        .Q(csr0_c2f[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr0_reg[19] 
       (.C(aclk),
        .CE(\csr0[31]_i_1_n_0 ),
        .D(csr00[19]),
        .Q(csr0_c2f[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr0_reg[1] 
       (.C(aclk),
        .CE(\csr0[31]_i_1_n_0 ),
        .D(csr00[1]),
        .Q(csr0_c2f[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr0_reg[20] 
       (.C(aclk),
        .CE(\csr0[31]_i_1_n_0 ),
        .D(csr00[20]),
        .Q(csr0_c2f[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr0_reg[21] 
       (.C(aclk),
        .CE(\csr0[31]_i_1_n_0 ),
        .D(csr00[21]),
        .Q(csr0_c2f[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr0_reg[22] 
       (.C(aclk),
        .CE(\csr0[31]_i_1_n_0 ),
        .D(csr00[22]),
        .Q(csr0_c2f[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr0_reg[23] 
       (.C(aclk),
        .CE(\csr0[31]_i_1_n_0 ),
        .D(csr00[23]),
        .Q(csr0_c2f[23]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr0_reg[24] 
       (.C(aclk),
        .CE(\csr0[31]_i_1_n_0 ),
        .D(csr00[24]),
        .Q(csr0_c2f[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr0_reg[25] 
       (.C(aclk),
        .CE(\csr0[31]_i_1_n_0 ),
        .D(csr00[25]),
        .Q(csr0_c2f[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr0_reg[26] 
       (.C(aclk),
        .CE(\csr0[31]_i_1_n_0 ),
        .D(csr00[26]),
        .Q(csr0_c2f[26]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr0_reg[27] 
       (.C(aclk),
        .CE(\csr0[31]_i_1_n_0 ),
        .D(csr00[27]),
        .Q(csr0_c2f[27]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr0_reg[28] 
       (.C(aclk),
        .CE(\csr0[31]_i_1_n_0 ),
        .D(csr00[28]),
        .Q(csr0_c2f[28]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr0_reg[29] 
       (.C(aclk),
        .CE(\csr0[31]_i_1_n_0 ),
        .D(csr00[29]),
        .Q(csr0_c2f[29]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr0_reg[2] 
       (.C(aclk),
        .CE(\csr0[31]_i_1_n_0 ),
        .D(csr00[2]),
        .Q(csr0_c2f[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr0_reg[30] 
       (.C(aclk),
        .CE(\csr0[31]_i_1_n_0 ),
        .D(csr00[30]),
        .Q(csr0_c2f[30]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr0_reg[31] 
       (.C(aclk),
        .CE(\csr0[31]_i_1_n_0 ),
        .D(csr00[31]),
        .Q(csr0_c2f[31]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr0_reg[3] 
       (.C(aclk),
        .CE(\csr0[31]_i_1_n_0 ),
        .D(csr00[3]),
        .Q(csr0_c2f[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr0_reg[4] 
       (.C(aclk),
        .CE(\csr0[31]_i_1_n_0 ),
        .D(csr00[4]),
        .Q(csr0_c2f[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr0_reg[5] 
       (.C(aclk),
        .CE(\csr0[31]_i_1_n_0 ),
        .D(csr00[5]),
        .Q(csr0_c2f[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr0_reg[6] 
       (.C(aclk),
        .CE(\csr0[31]_i_1_n_0 ),
        .D(csr00[6]),
        .Q(csr0_c2f[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr0_reg[7] 
       (.C(aclk),
        .CE(\csr0[31]_i_1_n_0 ),
        .D(csr00[7]),
        .Q(csr0_c2f[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr0_reg[8] 
       (.C(aclk),
        .CE(\csr0[31]_i_1_n_0 ),
        .D(csr00[8]),
        .Q(csr0_c2f[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr0_reg[9] 
       (.C(aclk),
        .CE(\csr0[31]_i_1_n_0 ),
        .D(csr00[9]),
        .Q(csr0_c2f[9]),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr1[0]_i_1 
       (.I0(s_axi_csrs_wdata[0]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr1_c2f[0]),
        .O(csr10[0]));
  (* SOFT_HLUTNM = "soft_lutpair26" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr1[10]_i_1 
       (.I0(s_axi_csrs_wdata[10]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr1_c2f[10]),
        .O(csr10[10]));
  (* SOFT_HLUTNM = "soft_lutpair26" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr1[11]_i_1 
       (.I0(s_axi_csrs_wdata[11]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr1_c2f[11]),
        .O(csr10[11]));
  (* SOFT_HLUTNM = "soft_lutpair27" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr1[12]_i_1 
       (.I0(s_axi_csrs_wdata[12]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr1_c2f[12]),
        .O(csr10[12]));
  (* SOFT_HLUTNM = "soft_lutpair27" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr1[13]_i_1 
       (.I0(s_axi_csrs_wdata[13]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr1_c2f[13]),
        .O(csr10[13]));
  (* SOFT_HLUTNM = "soft_lutpair28" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr1[14]_i_1 
       (.I0(s_axi_csrs_wdata[14]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr1_c2f[14]),
        .O(csr10[14]));
  (* SOFT_HLUTNM = "soft_lutpair28" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr1[15]_i_1 
       (.I0(s_axi_csrs_wdata[15]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr1_c2f[15]),
        .O(csr10[15]));
  (* SOFT_HLUTNM = "soft_lutpair29" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr1[16]_i_1 
       (.I0(s_axi_csrs_wdata[16]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr1_c2f[16]),
        .O(csr10[16]));
  (* SOFT_HLUTNM = "soft_lutpair29" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr1[17]_i_1 
       (.I0(s_axi_csrs_wdata[17]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr1_c2f[17]),
        .O(csr10[17]));
  (* SOFT_HLUTNM = "soft_lutpair30" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr1[18]_i_1 
       (.I0(s_axi_csrs_wdata[18]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr1_c2f[18]),
        .O(csr10[18]));
  (* SOFT_HLUTNM = "soft_lutpair30" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr1[19]_i_1 
       (.I0(s_axi_csrs_wdata[19]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr1_c2f[19]),
        .O(csr10[19]));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr1[1]_i_1 
       (.I0(s_axi_csrs_wdata[1]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr1_c2f[1]),
        .O(csr10[1]));
  (* SOFT_HLUTNM = "soft_lutpair31" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr1[20]_i_1 
       (.I0(s_axi_csrs_wdata[20]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr1_c2f[20]),
        .O(csr10[20]));
  (* SOFT_HLUTNM = "soft_lutpair31" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr1[21]_i_1 
       (.I0(s_axi_csrs_wdata[21]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr1_c2f[21]),
        .O(csr10[21]));
  (* SOFT_HLUTNM = "soft_lutpair32" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr1[22]_i_1 
       (.I0(s_axi_csrs_wdata[22]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr1_c2f[22]),
        .O(csr10[22]));
  (* SOFT_HLUTNM = "soft_lutpair32" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr1[23]_i_1 
       (.I0(s_axi_csrs_wdata[23]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr1_c2f[23]),
        .O(csr10[23]));
  (* SOFT_HLUTNM = "soft_lutpair33" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr1[24]_i_1 
       (.I0(s_axi_csrs_wdata[24]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr1_c2f[24]),
        .O(csr10[24]));
  (* SOFT_HLUTNM = "soft_lutpair33" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr1[25]_i_1 
       (.I0(s_axi_csrs_wdata[25]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr1_c2f[25]),
        .O(csr10[25]));
  (* SOFT_HLUTNM = "soft_lutpair34" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr1[26]_i_1 
       (.I0(s_axi_csrs_wdata[26]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr1_c2f[26]),
        .O(csr10[26]));
  (* SOFT_HLUTNM = "soft_lutpair34" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr1[27]_i_1 
       (.I0(s_axi_csrs_wdata[27]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr1_c2f[27]),
        .O(csr10[27]));
  (* SOFT_HLUTNM = "soft_lutpair35" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr1[28]_i_1 
       (.I0(s_axi_csrs_wdata[28]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr1_c2f[28]),
        .O(csr10[28]));
  (* SOFT_HLUTNM = "soft_lutpair35" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr1[29]_i_1 
       (.I0(s_axi_csrs_wdata[29]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr1_c2f[29]),
        .O(csr10[29]));
  (* SOFT_HLUTNM = "soft_lutpair22" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr1[2]_i_1 
       (.I0(s_axi_csrs_wdata[2]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr1_c2f[2]),
        .O(csr10[2]));
  (* SOFT_HLUTNM = "soft_lutpair36" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr1[30]_i_1 
       (.I0(s_axi_csrs_wdata[30]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr1_c2f[30]),
        .O(csr10[30]));
  LUT4 #(
    .INIT(16'h0020)) 
    \csr1[31]_i_1 
       (.I0(waddr[2]),
        .I1(waddr[3]),
        .I2(\csr0[31]_i_3_n_0 ),
        .I3(waddr[4]),
        .O(\csr1[31]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair36" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr1[31]_i_2 
       (.I0(s_axi_csrs_wdata[31]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr1_c2f[31]),
        .O(csr10[31]));
  (* SOFT_HLUTNM = "soft_lutpair22" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr1[3]_i_1 
       (.I0(s_axi_csrs_wdata[3]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr1_c2f[3]),
        .O(csr10[3]));
  (* SOFT_HLUTNM = "soft_lutpair23" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr1[4]_i_1 
       (.I0(s_axi_csrs_wdata[4]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr1_c2f[4]),
        .O(csr10[4]));
  (* SOFT_HLUTNM = "soft_lutpair23" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr1[5]_i_1 
       (.I0(s_axi_csrs_wdata[5]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr1_c2f[5]),
        .O(csr10[5]));
  (* SOFT_HLUTNM = "soft_lutpair24" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr1[6]_i_1 
       (.I0(s_axi_csrs_wdata[6]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr1_c2f[6]),
        .O(csr10[6]));
  (* SOFT_HLUTNM = "soft_lutpair24" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr1[7]_i_1 
       (.I0(s_axi_csrs_wdata[7]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr1_c2f[7]),
        .O(csr10[7]));
  (* SOFT_HLUTNM = "soft_lutpair25" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr1[8]_i_1 
       (.I0(s_axi_csrs_wdata[8]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr1_c2f[8]),
        .O(csr10[8]));
  (* SOFT_HLUTNM = "soft_lutpair25" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr1[9]_i_1 
       (.I0(s_axi_csrs_wdata[9]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr1_c2f[9]),
        .O(csr10[9]));
  FDRE #(
    .INIT(1'b0)) 
    \csr1_reg[0] 
       (.C(aclk),
        .CE(\csr1[31]_i_1_n_0 ),
        .D(csr10[0]),
        .Q(csr1_c2f[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr1_reg[10] 
       (.C(aclk),
        .CE(\csr1[31]_i_1_n_0 ),
        .D(csr10[10]),
        .Q(csr1_c2f[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr1_reg[11] 
       (.C(aclk),
        .CE(\csr1[31]_i_1_n_0 ),
        .D(csr10[11]),
        .Q(csr1_c2f[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr1_reg[12] 
       (.C(aclk),
        .CE(\csr1[31]_i_1_n_0 ),
        .D(csr10[12]),
        .Q(csr1_c2f[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr1_reg[13] 
       (.C(aclk),
        .CE(\csr1[31]_i_1_n_0 ),
        .D(csr10[13]),
        .Q(csr1_c2f[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr1_reg[14] 
       (.C(aclk),
        .CE(\csr1[31]_i_1_n_0 ),
        .D(csr10[14]),
        .Q(csr1_c2f[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr1_reg[15] 
       (.C(aclk),
        .CE(\csr1[31]_i_1_n_0 ),
        .D(csr10[15]),
        .Q(csr1_c2f[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr1_reg[16] 
       (.C(aclk),
        .CE(\csr1[31]_i_1_n_0 ),
        .D(csr10[16]),
        .Q(csr1_c2f[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr1_reg[17] 
       (.C(aclk),
        .CE(\csr1[31]_i_1_n_0 ),
        .D(csr10[17]),
        .Q(csr1_c2f[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr1_reg[18] 
       (.C(aclk),
        .CE(\csr1[31]_i_1_n_0 ),
        .D(csr10[18]),
        .Q(csr1_c2f[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr1_reg[19] 
       (.C(aclk),
        .CE(\csr1[31]_i_1_n_0 ),
        .D(csr10[19]),
        .Q(csr1_c2f[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr1_reg[1] 
       (.C(aclk),
        .CE(\csr1[31]_i_1_n_0 ),
        .D(csr10[1]),
        .Q(csr1_c2f[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr1_reg[20] 
       (.C(aclk),
        .CE(\csr1[31]_i_1_n_0 ),
        .D(csr10[20]),
        .Q(csr1_c2f[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr1_reg[21] 
       (.C(aclk),
        .CE(\csr1[31]_i_1_n_0 ),
        .D(csr10[21]),
        .Q(csr1_c2f[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr1_reg[22] 
       (.C(aclk),
        .CE(\csr1[31]_i_1_n_0 ),
        .D(csr10[22]),
        .Q(csr1_c2f[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr1_reg[23] 
       (.C(aclk),
        .CE(\csr1[31]_i_1_n_0 ),
        .D(csr10[23]),
        .Q(csr1_c2f[23]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr1_reg[24] 
       (.C(aclk),
        .CE(\csr1[31]_i_1_n_0 ),
        .D(csr10[24]),
        .Q(csr1_c2f[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr1_reg[25] 
       (.C(aclk),
        .CE(\csr1[31]_i_1_n_0 ),
        .D(csr10[25]),
        .Q(csr1_c2f[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr1_reg[26] 
       (.C(aclk),
        .CE(\csr1[31]_i_1_n_0 ),
        .D(csr10[26]),
        .Q(csr1_c2f[26]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr1_reg[27] 
       (.C(aclk),
        .CE(\csr1[31]_i_1_n_0 ),
        .D(csr10[27]),
        .Q(csr1_c2f[27]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr1_reg[28] 
       (.C(aclk),
        .CE(\csr1[31]_i_1_n_0 ),
        .D(csr10[28]),
        .Q(csr1_c2f[28]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr1_reg[29] 
       (.C(aclk),
        .CE(\csr1[31]_i_1_n_0 ),
        .D(csr10[29]),
        .Q(csr1_c2f[29]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr1_reg[2] 
       (.C(aclk),
        .CE(\csr1[31]_i_1_n_0 ),
        .D(csr10[2]),
        .Q(csr1_c2f[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr1_reg[30] 
       (.C(aclk),
        .CE(\csr1[31]_i_1_n_0 ),
        .D(csr10[30]),
        .Q(csr1_c2f[30]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr1_reg[31] 
       (.C(aclk),
        .CE(\csr1[31]_i_1_n_0 ),
        .D(csr10[31]),
        .Q(csr1_c2f[31]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr1_reg[3] 
       (.C(aclk),
        .CE(\csr1[31]_i_1_n_0 ),
        .D(csr10[3]),
        .Q(csr1_c2f[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr1_reg[4] 
       (.C(aclk),
        .CE(\csr1[31]_i_1_n_0 ),
        .D(csr10[4]),
        .Q(csr1_c2f[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr1_reg[5] 
       (.C(aclk),
        .CE(\csr1[31]_i_1_n_0 ),
        .D(csr10[5]),
        .Q(csr1_c2f[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr1_reg[6] 
       (.C(aclk),
        .CE(\csr1[31]_i_1_n_0 ),
        .D(csr10[6]),
        .Q(csr1_c2f[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr1_reg[7] 
       (.C(aclk),
        .CE(\csr1[31]_i_1_n_0 ),
        .D(csr10[7]),
        .Q(csr1_c2f[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr1_reg[8] 
       (.C(aclk),
        .CE(\csr1[31]_i_1_n_0 ),
        .D(csr10[8]),
        .Q(csr1_c2f[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr1_reg[9] 
       (.C(aclk),
        .CE(\csr1[31]_i_1_n_0 ),
        .D(csr10[9]),
        .Q(csr1_c2f[9]),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair37" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr2[0]_i_1 
       (.I0(s_axi_csrs_wdata[0]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr2_c2f[0]),
        .O(csr20[0]));
  (* SOFT_HLUTNM = "soft_lutpair42" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr2[10]_i_1 
       (.I0(s_axi_csrs_wdata[10]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr2_c2f[10]),
        .O(csr20[10]));
  (* SOFT_HLUTNM = "soft_lutpair42" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr2[11]_i_1 
       (.I0(s_axi_csrs_wdata[11]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr2_c2f[11]),
        .O(csr20[11]));
  (* SOFT_HLUTNM = "soft_lutpair43" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr2[12]_i_1 
       (.I0(s_axi_csrs_wdata[12]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr2_c2f[12]),
        .O(csr20[12]));
  (* SOFT_HLUTNM = "soft_lutpair43" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr2[13]_i_1 
       (.I0(s_axi_csrs_wdata[13]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr2_c2f[13]),
        .O(csr20[13]));
  (* SOFT_HLUTNM = "soft_lutpair44" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr2[14]_i_1 
       (.I0(s_axi_csrs_wdata[14]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr2_c2f[14]),
        .O(csr20[14]));
  (* SOFT_HLUTNM = "soft_lutpair44" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr2[15]_i_1 
       (.I0(s_axi_csrs_wdata[15]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr2_c2f[15]),
        .O(csr20[15]));
  (* SOFT_HLUTNM = "soft_lutpair45" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr2[16]_i_1 
       (.I0(s_axi_csrs_wdata[16]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr2_c2f[16]),
        .O(csr20[16]));
  (* SOFT_HLUTNM = "soft_lutpair45" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr2[17]_i_1 
       (.I0(s_axi_csrs_wdata[17]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr2_c2f[17]),
        .O(csr20[17]));
  (* SOFT_HLUTNM = "soft_lutpair46" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr2[18]_i_1 
       (.I0(s_axi_csrs_wdata[18]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr2_c2f[18]),
        .O(csr20[18]));
  (* SOFT_HLUTNM = "soft_lutpair46" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr2[19]_i_1 
       (.I0(s_axi_csrs_wdata[19]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr2_c2f[19]),
        .O(csr20[19]));
  (* SOFT_HLUTNM = "soft_lutpair37" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr2[1]_i_1 
       (.I0(s_axi_csrs_wdata[1]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr2_c2f[1]),
        .O(csr20[1]));
  (* SOFT_HLUTNM = "soft_lutpair47" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr2[20]_i_1 
       (.I0(s_axi_csrs_wdata[20]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr2_c2f[20]),
        .O(csr20[20]));
  (* SOFT_HLUTNM = "soft_lutpair47" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr2[21]_i_1 
       (.I0(s_axi_csrs_wdata[21]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr2_c2f[21]),
        .O(csr20[21]));
  (* SOFT_HLUTNM = "soft_lutpair48" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr2[22]_i_1 
       (.I0(s_axi_csrs_wdata[22]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr2_c2f[22]),
        .O(csr20[22]));
  (* SOFT_HLUTNM = "soft_lutpair48" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr2[23]_i_1 
       (.I0(s_axi_csrs_wdata[23]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr2_c2f[23]),
        .O(csr20[23]));
  (* SOFT_HLUTNM = "soft_lutpair49" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr2[24]_i_1 
       (.I0(s_axi_csrs_wdata[24]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr2_c2f[24]),
        .O(csr20[24]));
  (* SOFT_HLUTNM = "soft_lutpair49" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr2[25]_i_1 
       (.I0(s_axi_csrs_wdata[25]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr2_c2f[25]),
        .O(csr20[25]));
  (* SOFT_HLUTNM = "soft_lutpair50" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr2[26]_i_1 
       (.I0(s_axi_csrs_wdata[26]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr2_c2f[26]),
        .O(csr20[26]));
  (* SOFT_HLUTNM = "soft_lutpair50" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr2[27]_i_1 
       (.I0(s_axi_csrs_wdata[27]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr2_c2f[27]),
        .O(csr20[27]));
  (* SOFT_HLUTNM = "soft_lutpair51" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr2[28]_i_1 
       (.I0(s_axi_csrs_wdata[28]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr2_c2f[28]),
        .O(csr20[28]));
  (* SOFT_HLUTNM = "soft_lutpair51" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr2[29]_i_1 
       (.I0(s_axi_csrs_wdata[29]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr2_c2f[29]),
        .O(csr20[29]));
  (* SOFT_HLUTNM = "soft_lutpair38" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr2[2]_i_1 
       (.I0(s_axi_csrs_wdata[2]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr2_c2f[2]),
        .O(csr20[2]));
  (* SOFT_HLUTNM = "soft_lutpair52" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr2[30]_i_1 
       (.I0(s_axi_csrs_wdata[30]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr2_c2f[30]),
        .O(csr20[30]));
  LUT4 #(
    .INIT(16'h0020)) 
    \csr2[31]_i_1 
       (.I0(\csr0[31]_i_3_n_0 ),
        .I1(waddr[4]),
        .I2(waddr[3]),
        .I3(waddr[2]),
        .O(\csr2[31]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair52" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr2[31]_i_2 
       (.I0(s_axi_csrs_wdata[31]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr2_c2f[31]),
        .O(csr20[31]));
  (* SOFT_HLUTNM = "soft_lutpair38" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr2[3]_i_1 
       (.I0(s_axi_csrs_wdata[3]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr2_c2f[3]),
        .O(csr20[3]));
  (* SOFT_HLUTNM = "soft_lutpair39" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr2[4]_i_1 
       (.I0(s_axi_csrs_wdata[4]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr2_c2f[4]),
        .O(csr20[4]));
  (* SOFT_HLUTNM = "soft_lutpair39" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr2[5]_i_1 
       (.I0(s_axi_csrs_wdata[5]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr2_c2f[5]),
        .O(csr20[5]));
  (* SOFT_HLUTNM = "soft_lutpair40" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr2[6]_i_1 
       (.I0(s_axi_csrs_wdata[6]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr2_c2f[6]),
        .O(csr20[6]));
  (* SOFT_HLUTNM = "soft_lutpair40" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr2[7]_i_1 
       (.I0(s_axi_csrs_wdata[7]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr2_c2f[7]),
        .O(csr20[7]));
  (* SOFT_HLUTNM = "soft_lutpair41" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr2[8]_i_1 
       (.I0(s_axi_csrs_wdata[8]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr2_c2f[8]),
        .O(csr20[8]));
  (* SOFT_HLUTNM = "soft_lutpair41" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr2[9]_i_1 
       (.I0(s_axi_csrs_wdata[9]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr2_c2f[9]),
        .O(csr20[9]));
  FDRE #(
    .INIT(1'b0)) 
    \csr2_reg[0] 
       (.C(aclk),
        .CE(\csr2[31]_i_1_n_0 ),
        .D(csr20[0]),
        .Q(csr2_c2f[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr2_reg[10] 
       (.C(aclk),
        .CE(\csr2[31]_i_1_n_0 ),
        .D(csr20[10]),
        .Q(csr2_c2f[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr2_reg[11] 
       (.C(aclk),
        .CE(\csr2[31]_i_1_n_0 ),
        .D(csr20[11]),
        .Q(csr2_c2f[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr2_reg[12] 
       (.C(aclk),
        .CE(\csr2[31]_i_1_n_0 ),
        .D(csr20[12]),
        .Q(csr2_c2f[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr2_reg[13] 
       (.C(aclk),
        .CE(\csr2[31]_i_1_n_0 ),
        .D(csr20[13]),
        .Q(csr2_c2f[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr2_reg[14] 
       (.C(aclk),
        .CE(\csr2[31]_i_1_n_0 ),
        .D(csr20[14]),
        .Q(csr2_c2f[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr2_reg[15] 
       (.C(aclk),
        .CE(\csr2[31]_i_1_n_0 ),
        .D(csr20[15]),
        .Q(csr2_c2f[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr2_reg[16] 
       (.C(aclk),
        .CE(\csr2[31]_i_1_n_0 ),
        .D(csr20[16]),
        .Q(csr2_c2f[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr2_reg[17] 
       (.C(aclk),
        .CE(\csr2[31]_i_1_n_0 ),
        .D(csr20[17]),
        .Q(csr2_c2f[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr2_reg[18] 
       (.C(aclk),
        .CE(\csr2[31]_i_1_n_0 ),
        .D(csr20[18]),
        .Q(csr2_c2f[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr2_reg[19] 
       (.C(aclk),
        .CE(\csr2[31]_i_1_n_0 ),
        .D(csr20[19]),
        .Q(csr2_c2f[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr2_reg[1] 
       (.C(aclk),
        .CE(\csr2[31]_i_1_n_0 ),
        .D(csr20[1]),
        .Q(csr2_c2f[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr2_reg[20] 
       (.C(aclk),
        .CE(\csr2[31]_i_1_n_0 ),
        .D(csr20[20]),
        .Q(csr2_c2f[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr2_reg[21] 
       (.C(aclk),
        .CE(\csr2[31]_i_1_n_0 ),
        .D(csr20[21]),
        .Q(csr2_c2f[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr2_reg[22] 
       (.C(aclk),
        .CE(\csr2[31]_i_1_n_0 ),
        .D(csr20[22]),
        .Q(csr2_c2f[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr2_reg[23] 
       (.C(aclk),
        .CE(\csr2[31]_i_1_n_0 ),
        .D(csr20[23]),
        .Q(csr2_c2f[23]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr2_reg[24] 
       (.C(aclk),
        .CE(\csr2[31]_i_1_n_0 ),
        .D(csr20[24]),
        .Q(csr2_c2f[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr2_reg[25] 
       (.C(aclk),
        .CE(\csr2[31]_i_1_n_0 ),
        .D(csr20[25]),
        .Q(csr2_c2f[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr2_reg[26] 
       (.C(aclk),
        .CE(\csr2[31]_i_1_n_0 ),
        .D(csr20[26]),
        .Q(csr2_c2f[26]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr2_reg[27] 
       (.C(aclk),
        .CE(\csr2[31]_i_1_n_0 ),
        .D(csr20[27]),
        .Q(csr2_c2f[27]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr2_reg[28] 
       (.C(aclk),
        .CE(\csr2[31]_i_1_n_0 ),
        .D(csr20[28]),
        .Q(csr2_c2f[28]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr2_reg[29] 
       (.C(aclk),
        .CE(\csr2[31]_i_1_n_0 ),
        .D(csr20[29]),
        .Q(csr2_c2f[29]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr2_reg[2] 
       (.C(aclk),
        .CE(\csr2[31]_i_1_n_0 ),
        .D(csr20[2]),
        .Q(csr2_c2f[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr2_reg[30] 
       (.C(aclk),
        .CE(\csr2[31]_i_1_n_0 ),
        .D(csr20[30]),
        .Q(csr2_c2f[30]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr2_reg[31] 
       (.C(aclk),
        .CE(\csr2[31]_i_1_n_0 ),
        .D(csr20[31]),
        .Q(csr2_c2f[31]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr2_reg[3] 
       (.C(aclk),
        .CE(\csr2[31]_i_1_n_0 ),
        .D(csr20[3]),
        .Q(csr2_c2f[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr2_reg[4] 
       (.C(aclk),
        .CE(\csr2[31]_i_1_n_0 ),
        .D(csr20[4]),
        .Q(csr2_c2f[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr2_reg[5] 
       (.C(aclk),
        .CE(\csr2[31]_i_1_n_0 ),
        .D(csr20[5]),
        .Q(csr2_c2f[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr2_reg[6] 
       (.C(aclk),
        .CE(\csr2[31]_i_1_n_0 ),
        .D(csr20[6]),
        .Q(csr2_c2f[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr2_reg[7] 
       (.C(aclk),
        .CE(\csr2[31]_i_1_n_0 ),
        .D(csr20[7]),
        .Q(csr2_c2f[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr2_reg[8] 
       (.C(aclk),
        .CE(\csr2[31]_i_1_n_0 ),
        .D(csr20[8]),
        .Q(csr2_c2f[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr2_reg[9] 
       (.C(aclk),
        .CE(\csr2[31]_i_1_n_0 ),
        .D(csr20[9]),
        .Q(csr2_c2f[9]),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair53" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr3[0]_i_1 
       (.I0(s_axi_csrs_wdata[0]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr3_c2f[0]),
        .O(csr30[0]));
  (* SOFT_HLUTNM = "soft_lutpair58" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr3[10]_i_1 
       (.I0(s_axi_csrs_wdata[10]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr3_c2f[10]),
        .O(csr30[10]));
  (* SOFT_HLUTNM = "soft_lutpair58" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr3[11]_i_1 
       (.I0(s_axi_csrs_wdata[11]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr3_c2f[11]),
        .O(csr30[11]));
  (* SOFT_HLUTNM = "soft_lutpair59" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr3[12]_i_1 
       (.I0(s_axi_csrs_wdata[12]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr3_c2f[12]),
        .O(csr30[12]));
  (* SOFT_HLUTNM = "soft_lutpair59" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr3[13]_i_1 
       (.I0(s_axi_csrs_wdata[13]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr3_c2f[13]),
        .O(csr30[13]));
  (* SOFT_HLUTNM = "soft_lutpair60" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr3[14]_i_1 
       (.I0(s_axi_csrs_wdata[14]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr3_c2f[14]),
        .O(csr30[14]));
  (* SOFT_HLUTNM = "soft_lutpair60" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr3[15]_i_1 
       (.I0(s_axi_csrs_wdata[15]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr3_c2f[15]),
        .O(csr30[15]));
  (* SOFT_HLUTNM = "soft_lutpair61" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr3[16]_i_1 
       (.I0(s_axi_csrs_wdata[16]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr3_c2f[16]),
        .O(csr30[16]));
  (* SOFT_HLUTNM = "soft_lutpair61" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr3[17]_i_1 
       (.I0(s_axi_csrs_wdata[17]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr3_c2f[17]),
        .O(csr30[17]));
  (* SOFT_HLUTNM = "soft_lutpair62" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr3[18]_i_1 
       (.I0(s_axi_csrs_wdata[18]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr3_c2f[18]),
        .O(csr30[18]));
  (* SOFT_HLUTNM = "soft_lutpair62" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr3[19]_i_1 
       (.I0(s_axi_csrs_wdata[19]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr3_c2f[19]),
        .O(csr30[19]));
  (* SOFT_HLUTNM = "soft_lutpair53" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr3[1]_i_1 
       (.I0(s_axi_csrs_wdata[1]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr3_c2f[1]),
        .O(csr30[1]));
  (* SOFT_HLUTNM = "soft_lutpair63" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr3[20]_i_1 
       (.I0(s_axi_csrs_wdata[20]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr3_c2f[20]),
        .O(csr30[20]));
  (* SOFT_HLUTNM = "soft_lutpair63" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr3[21]_i_1 
       (.I0(s_axi_csrs_wdata[21]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr3_c2f[21]),
        .O(csr30[21]));
  (* SOFT_HLUTNM = "soft_lutpair64" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr3[22]_i_1 
       (.I0(s_axi_csrs_wdata[22]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr3_c2f[22]),
        .O(csr30[22]));
  (* SOFT_HLUTNM = "soft_lutpair64" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr3[23]_i_1 
       (.I0(s_axi_csrs_wdata[23]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr3_c2f[23]),
        .O(csr30[23]));
  (* SOFT_HLUTNM = "soft_lutpair65" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr3[24]_i_1 
       (.I0(s_axi_csrs_wdata[24]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr3_c2f[24]),
        .O(csr30[24]));
  (* SOFT_HLUTNM = "soft_lutpair65" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr3[25]_i_1 
       (.I0(s_axi_csrs_wdata[25]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr3_c2f[25]),
        .O(csr30[25]));
  (* SOFT_HLUTNM = "soft_lutpair66" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr3[26]_i_1 
       (.I0(s_axi_csrs_wdata[26]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr3_c2f[26]),
        .O(csr30[26]));
  (* SOFT_HLUTNM = "soft_lutpair66" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr3[27]_i_1 
       (.I0(s_axi_csrs_wdata[27]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr3_c2f[27]),
        .O(csr30[27]));
  (* SOFT_HLUTNM = "soft_lutpair67" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr3[28]_i_1 
       (.I0(s_axi_csrs_wdata[28]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr3_c2f[28]),
        .O(csr30[28]));
  (* SOFT_HLUTNM = "soft_lutpair67" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr3[29]_i_1 
       (.I0(s_axi_csrs_wdata[29]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr3_c2f[29]),
        .O(csr30[29]));
  (* SOFT_HLUTNM = "soft_lutpair54" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr3[2]_i_1 
       (.I0(s_axi_csrs_wdata[2]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr3_c2f[2]),
        .O(csr30[2]));
  (* SOFT_HLUTNM = "soft_lutpair68" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr3[30]_i_1 
       (.I0(s_axi_csrs_wdata[30]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr3_c2f[30]),
        .O(csr30[30]));
  LUT4 #(
    .INIT(16'h0800)) 
    \csr3[31]_i_1 
       (.I0(waddr[2]),
        .I1(waddr[3]),
        .I2(waddr[4]),
        .I3(\csr0[31]_i_3_n_0 ),
        .O(\csr3[31]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair68" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr3[31]_i_2 
       (.I0(s_axi_csrs_wdata[31]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr3_c2f[31]),
        .O(csr30[31]));
  (* SOFT_HLUTNM = "soft_lutpair54" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr3[3]_i_1 
       (.I0(s_axi_csrs_wdata[3]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr3_c2f[3]),
        .O(csr30[3]));
  (* SOFT_HLUTNM = "soft_lutpair55" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr3[4]_i_1 
       (.I0(s_axi_csrs_wdata[4]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr3_c2f[4]),
        .O(csr30[4]));
  (* SOFT_HLUTNM = "soft_lutpair55" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr3[5]_i_1 
       (.I0(s_axi_csrs_wdata[5]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr3_c2f[5]),
        .O(csr30[5]));
  (* SOFT_HLUTNM = "soft_lutpair56" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr3[6]_i_1 
       (.I0(s_axi_csrs_wdata[6]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr3_c2f[6]),
        .O(csr30[6]));
  (* SOFT_HLUTNM = "soft_lutpair56" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr3[7]_i_1 
       (.I0(s_axi_csrs_wdata[7]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr3_c2f[7]),
        .O(csr30[7]));
  (* SOFT_HLUTNM = "soft_lutpair57" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr3[8]_i_1 
       (.I0(s_axi_csrs_wdata[8]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr3_c2f[8]),
        .O(csr30[8]));
  (* SOFT_HLUTNM = "soft_lutpair57" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr3[9]_i_1 
       (.I0(s_axi_csrs_wdata[9]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr3_c2f[9]),
        .O(csr30[9]));
  FDRE #(
    .INIT(1'b0)) 
    \csr3_reg[0] 
       (.C(aclk),
        .CE(\csr3[31]_i_1_n_0 ),
        .D(csr30[0]),
        .Q(csr3_c2f[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr3_reg[10] 
       (.C(aclk),
        .CE(\csr3[31]_i_1_n_0 ),
        .D(csr30[10]),
        .Q(csr3_c2f[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr3_reg[11] 
       (.C(aclk),
        .CE(\csr3[31]_i_1_n_0 ),
        .D(csr30[11]),
        .Q(csr3_c2f[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr3_reg[12] 
       (.C(aclk),
        .CE(\csr3[31]_i_1_n_0 ),
        .D(csr30[12]),
        .Q(csr3_c2f[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr3_reg[13] 
       (.C(aclk),
        .CE(\csr3[31]_i_1_n_0 ),
        .D(csr30[13]),
        .Q(csr3_c2f[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr3_reg[14] 
       (.C(aclk),
        .CE(\csr3[31]_i_1_n_0 ),
        .D(csr30[14]),
        .Q(csr3_c2f[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr3_reg[15] 
       (.C(aclk),
        .CE(\csr3[31]_i_1_n_0 ),
        .D(csr30[15]),
        .Q(csr3_c2f[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr3_reg[16] 
       (.C(aclk),
        .CE(\csr3[31]_i_1_n_0 ),
        .D(csr30[16]),
        .Q(csr3_c2f[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr3_reg[17] 
       (.C(aclk),
        .CE(\csr3[31]_i_1_n_0 ),
        .D(csr30[17]),
        .Q(csr3_c2f[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr3_reg[18] 
       (.C(aclk),
        .CE(\csr3[31]_i_1_n_0 ),
        .D(csr30[18]),
        .Q(csr3_c2f[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr3_reg[19] 
       (.C(aclk),
        .CE(\csr3[31]_i_1_n_0 ),
        .D(csr30[19]),
        .Q(csr3_c2f[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr3_reg[1] 
       (.C(aclk),
        .CE(\csr3[31]_i_1_n_0 ),
        .D(csr30[1]),
        .Q(csr3_c2f[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr3_reg[20] 
       (.C(aclk),
        .CE(\csr3[31]_i_1_n_0 ),
        .D(csr30[20]),
        .Q(csr3_c2f[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr3_reg[21] 
       (.C(aclk),
        .CE(\csr3[31]_i_1_n_0 ),
        .D(csr30[21]),
        .Q(csr3_c2f[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr3_reg[22] 
       (.C(aclk),
        .CE(\csr3[31]_i_1_n_0 ),
        .D(csr30[22]),
        .Q(csr3_c2f[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr3_reg[23] 
       (.C(aclk),
        .CE(\csr3[31]_i_1_n_0 ),
        .D(csr30[23]),
        .Q(csr3_c2f[23]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr3_reg[24] 
       (.C(aclk),
        .CE(\csr3[31]_i_1_n_0 ),
        .D(csr30[24]),
        .Q(csr3_c2f[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr3_reg[25] 
       (.C(aclk),
        .CE(\csr3[31]_i_1_n_0 ),
        .D(csr30[25]),
        .Q(csr3_c2f[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr3_reg[26] 
       (.C(aclk),
        .CE(\csr3[31]_i_1_n_0 ),
        .D(csr30[26]),
        .Q(csr3_c2f[26]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr3_reg[27] 
       (.C(aclk),
        .CE(\csr3[31]_i_1_n_0 ),
        .D(csr30[27]),
        .Q(csr3_c2f[27]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr3_reg[28] 
       (.C(aclk),
        .CE(\csr3[31]_i_1_n_0 ),
        .D(csr30[28]),
        .Q(csr3_c2f[28]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr3_reg[29] 
       (.C(aclk),
        .CE(\csr3[31]_i_1_n_0 ),
        .D(csr30[29]),
        .Q(csr3_c2f[29]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr3_reg[2] 
       (.C(aclk),
        .CE(\csr3[31]_i_1_n_0 ),
        .D(csr30[2]),
        .Q(csr3_c2f[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr3_reg[30] 
       (.C(aclk),
        .CE(\csr3[31]_i_1_n_0 ),
        .D(csr30[30]),
        .Q(csr3_c2f[30]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr3_reg[31] 
       (.C(aclk),
        .CE(\csr3[31]_i_1_n_0 ),
        .D(csr30[31]),
        .Q(csr3_c2f[31]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr3_reg[3] 
       (.C(aclk),
        .CE(\csr3[31]_i_1_n_0 ),
        .D(csr30[3]),
        .Q(csr3_c2f[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr3_reg[4] 
       (.C(aclk),
        .CE(\csr3[31]_i_1_n_0 ),
        .D(csr30[4]),
        .Q(csr3_c2f[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr3_reg[5] 
       (.C(aclk),
        .CE(\csr3[31]_i_1_n_0 ),
        .D(csr30[5]),
        .Q(csr3_c2f[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr3_reg[6] 
       (.C(aclk),
        .CE(\csr3[31]_i_1_n_0 ),
        .D(csr30[6]),
        .Q(csr3_c2f[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr3_reg[7] 
       (.C(aclk),
        .CE(\csr3[31]_i_1_n_0 ),
        .D(csr30[7]),
        .Q(csr3_c2f[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr3_reg[8] 
       (.C(aclk),
        .CE(\csr3[31]_i_1_n_0 ),
        .D(csr30[8]),
        .Q(csr3_c2f[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr3_reg[9] 
       (.C(aclk),
        .CE(\csr3[31]_i_1_n_0 ),
        .D(csr30[9]),
        .Q(csr3_c2f[9]),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair69" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr4[0]_i_1 
       (.I0(s_axi_csrs_wdata[0]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr4_c2f[0]),
        .O(csr40[0]));
  (* SOFT_HLUTNM = "soft_lutpair74" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr4[10]_i_1 
       (.I0(s_axi_csrs_wdata[10]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr4_c2f[10]),
        .O(csr40[10]));
  (* SOFT_HLUTNM = "soft_lutpair74" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr4[11]_i_1 
       (.I0(s_axi_csrs_wdata[11]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr4_c2f[11]),
        .O(csr40[11]));
  (* SOFT_HLUTNM = "soft_lutpair75" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr4[12]_i_1 
       (.I0(s_axi_csrs_wdata[12]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr4_c2f[12]),
        .O(csr40[12]));
  (* SOFT_HLUTNM = "soft_lutpair75" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr4[13]_i_1 
       (.I0(s_axi_csrs_wdata[13]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr4_c2f[13]),
        .O(csr40[13]));
  (* SOFT_HLUTNM = "soft_lutpair76" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr4[14]_i_1 
       (.I0(s_axi_csrs_wdata[14]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr4_c2f[14]),
        .O(csr40[14]));
  (* SOFT_HLUTNM = "soft_lutpair76" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr4[15]_i_1 
       (.I0(s_axi_csrs_wdata[15]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr4_c2f[15]),
        .O(csr40[15]));
  (* SOFT_HLUTNM = "soft_lutpair77" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr4[16]_i_1 
       (.I0(s_axi_csrs_wdata[16]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr4_c2f[16]),
        .O(csr40[16]));
  (* SOFT_HLUTNM = "soft_lutpair77" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr4[17]_i_1 
       (.I0(s_axi_csrs_wdata[17]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr4_c2f[17]),
        .O(csr40[17]));
  (* SOFT_HLUTNM = "soft_lutpair78" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr4[18]_i_1 
       (.I0(s_axi_csrs_wdata[18]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr4_c2f[18]),
        .O(csr40[18]));
  (* SOFT_HLUTNM = "soft_lutpair78" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr4[19]_i_1 
       (.I0(s_axi_csrs_wdata[19]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr4_c2f[19]),
        .O(csr40[19]));
  (* SOFT_HLUTNM = "soft_lutpair69" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr4[1]_i_1 
       (.I0(s_axi_csrs_wdata[1]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr4_c2f[1]),
        .O(csr40[1]));
  (* SOFT_HLUTNM = "soft_lutpair79" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr4[20]_i_1 
       (.I0(s_axi_csrs_wdata[20]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr4_c2f[20]),
        .O(csr40[20]));
  (* SOFT_HLUTNM = "soft_lutpair79" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr4[21]_i_1 
       (.I0(s_axi_csrs_wdata[21]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr4_c2f[21]),
        .O(csr40[21]));
  (* SOFT_HLUTNM = "soft_lutpair80" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr4[22]_i_1 
       (.I0(s_axi_csrs_wdata[22]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr4_c2f[22]),
        .O(csr40[22]));
  (* SOFT_HLUTNM = "soft_lutpair80" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr4[23]_i_1 
       (.I0(s_axi_csrs_wdata[23]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr4_c2f[23]),
        .O(csr40[23]));
  (* SOFT_HLUTNM = "soft_lutpair81" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr4[24]_i_1 
       (.I0(s_axi_csrs_wdata[24]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr4_c2f[24]),
        .O(csr40[24]));
  (* SOFT_HLUTNM = "soft_lutpair81" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr4[25]_i_1 
       (.I0(s_axi_csrs_wdata[25]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr4_c2f[25]),
        .O(csr40[25]));
  (* SOFT_HLUTNM = "soft_lutpair82" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr4[26]_i_1 
       (.I0(s_axi_csrs_wdata[26]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr4_c2f[26]),
        .O(csr40[26]));
  (* SOFT_HLUTNM = "soft_lutpair82" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr4[27]_i_1 
       (.I0(s_axi_csrs_wdata[27]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr4_c2f[27]),
        .O(csr40[27]));
  (* SOFT_HLUTNM = "soft_lutpair83" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr4[28]_i_1 
       (.I0(s_axi_csrs_wdata[28]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr4_c2f[28]),
        .O(csr40[28]));
  (* SOFT_HLUTNM = "soft_lutpair83" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr4[29]_i_1 
       (.I0(s_axi_csrs_wdata[29]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr4_c2f[29]),
        .O(csr40[29]));
  (* SOFT_HLUTNM = "soft_lutpair70" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr4[2]_i_1 
       (.I0(s_axi_csrs_wdata[2]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr4_c2f[2]),
        .O(csr40[2]));
  (* SOFT_HLUTNM = "soft_lutpair84" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr4[30]_i_1 
       (.I0(s_axi_csrs_wdata[30]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr4_c2f[30]),
        .O(csr40[30]));
  LUT3 #(
    .INIT(8'h04)) 
    \csr4[31]_i_1 
       (.I0(waddr[3]),
        .I1(\csr4[31]_i_3_n_0 ),
        .I2(waddr[2]),
        .O(\csr4[31]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair84" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr4[31]_i_2 
       (.I0(s_axi_csrs_wdata[31]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr4_c2f[31]),
        .O(csr40[31]));
  LUT5 #(
    .INIT(32'h00002000)) 
    \csr4[31]_i_3 
       (.I0(waddr[4]),
        .I1(waddr[1]),
        .I2(s_axi_csrs_wready),
        .I3(s_axi_csrs_wvalid),
        .I4(waddr[0]),
        .O(\csr4[31]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair70" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr4[3]_i_1 
       (.I0(s_axi_csrs_wdata[3]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr4_c2f[3]),
        .O(csr40[3]));
  (* SOFT_HLUTNM = "soft_lutpair71" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr4[4]_i_1 
       (.I0(s_axi_csrs_wdata[4]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr4_c2f[4]),
        .O(csr40[4]));
  (* SOFT_HLUTNM = "soft_lutpair71" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr4[5]_i_1 
       (.I0(s_axi_csrs_wdata[5]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr4_c2f[5]),
        .O(csr40[5]));
  (* SOFT_HLUTNM = "soft_lutpair72" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr4[6]_i_1 
       (.I0(s_axi_csrs_wdata[6]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr4_c2f[6]),
        .O(csr40[6]));
  (* SOFT_HLUTNM = "soft_lutpair72" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr4[7]_i_1 
       (.I0(s_axi_csrs_wdata[7]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr4_c2f[7]),
        .O(csr40[7]));
  (* SOFT_HLUTNM = "soft_lutpair73" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr4[8]_i_1 
       (.I0(s_axi_csrs_wdata[8]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr4_c2f[8]),
        .O(csr40[8]));
  (* SOFT_HLUTNM = "soft_lutpair73" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr4[9]_i_1 
       (.I0(s_axi_csrs_wdata[9]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr4_c2f[9]),
        .O(csr40[9]));
  FDRE #(
    .INIT(1'b0)) 
    \csr4_reg[0] 
       (.C(aclk),
        .CE(\csr4[31]_i_1_n_0 ),
        .D(csr40[0]),
        .Q(csr4_c2f[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr4_reg[10] 
       (.C(aclk),
        .CE(\csr4[31]_i_1_n_0 ),
        .D(csr40[10]),
        .Q(csr4_c2f[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr4_reg[11] 
       (.C(aclk),
        .CE(\csr4[31]_i_1_n_0 ),
        .D(csr40[11]),
        .Q(csr4_c2f[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr4_reg[12] 
       (.C(aclk),
        .CE(\csr4[31]_i_1_n_0 ),
        .D(csr40[12]),
        .Q(csr4_c2f[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr4_reg[13] 
       (.C(aclk),
        .CE(\csr4[31]_i_1_n_0 ),
        .D(csr40[13]),
        .Q(csr4_c2f[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr4_reg[14] 
       (.C(aclk),
        .CE(\csr4[31]_i_1_n_0 ),
        .D(csr40[14]),
        .Q(csr4_c2f[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr4_reg[15] 
       (.C(aclk),
        .CE(\csr4[31]_i_1_n_0 ),
        .D(csr40[15]),
        .Q(csr4_c2f[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr4_reg[16] 
       (.C(aclk),
        .CE(\csr4[31]_i_1_n_0 ),
        .D(csr40[16]),
        .Q(csr4_c2f[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr4_reg[17] 
       (.C(aclk),
        .CE(\csr4[31]_i_1_n_0 ),
        .D(csr40[17]),
        .Q(csr4_c2f[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr4_reg[18] 
       (.C(aclk),
        .CE(\csr4[31]_i_1_n_0 ),
        .D(csr40[18]),
        .Q(csr4_c2f[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr4_reg[19] 
       (.C(aclk),
        .CE(\csr4[31]_i_1_n_0 ),
        .D(csr40[19]),
        .Q(csr4_c2f[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr4_reg[1] 
       (.C(aclk),
        .CE(\csr4[31]_i_1_n_0 ),
        .D(csr40[1]),
        .Q(csr4_c2f[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr4_reg[20] 
       (.C(aclk),
        .CE(\csr4[31]_i_1_n_0 ),
        .D(csr40[20]),
        .Q(csr4_c2f[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr4_reg[21] 
       (.C(aclk),
        .CE(\csr4[31]_i_1_n_0 ),
        .D(csr40[21]),
        .Q(csr4_c2f[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr4_reg[22] 
       (.C(aclk),
        .CE(\csr4[31]_i_1_n_0 ),
        .D(csr40[22]),
        .Q(csr4_c2f[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr4_reg[23] 
       (.C(aclk),
        .CE(\csr4[31]_i_1_n_0 ),
        .D(csr40[23]),
        .Q(csr4_c2f[23]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr4_reg[24] 
       (.C(aclk),
        .CE(\csr4[31]_i_1_n_0 ),
        .D(csr40[24]),
        .Q(csr4_c2f[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr4_reg[25] 
       (.C(aclk),
        .CE(\csr4[31]_i_1_n_0 ),
        .D(csr40[25]),
        .Q(csr4_c2f[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr4_reg[26] 
       (.C(aclk),
        .CE(\csr4[31]_i_1_n_0 ),
        .D(csr40[26]),
        .Q(csr4_c2f[26]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr4_reg[27] 
       (.C(aclk),
        .CE(\csr4[31]_i_1_n_0 ),
        .D(csr40[27]),
        .Q(csr4_c2f[27]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr4_reg[28] 
       (.C(aclk),
        .CE(\csr4[31]_i_1_n_0 ),
        .D(csr40[28]),
        .Q(csr4_c2f[28]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr4_reg[29] 
       (.C(aclk),
        .CE(\csr4[31]_i_1_n_0 ),
        .D(csr40[29]),
        .Q(csr4_c2f[29]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr4_reg[2] 
       (.C(aclk),
        .CE(\csr4[31]_i_1_n_0 ),
        .D(csr40[2]),
        .Q(csr4_c2f[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr4_reg[30] 
       (.C(aclk),
        .CE(\csr4[31]_i_1_n_0 ),
        .D(csr40[30]),
        .Q(csr4_c2f[30]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr4_reg[31] 
       (.C(aclk),
        .CE(\csr4[31]_i_1_n_0 ),
        .D(csr40[31]),
        .Q(csr4_c2f[31]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr4_reg[3] 
       (.C(aclk),
        .CE(\csr4[31]_i_1_n_0 ),
        .D(csr40[3]),
        .Q(csr4_c2f[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr4_reg[4] 
       (.C(aclk),
        .CE(\csr4[31]_i_1_n_0 ),
        .D(csr40[4]),
        .Q(csr4_c2f[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr4_reg[5] 
       (.C(aclk),
        .CE(\csr4[31]_i_1_n_0 ),
        .D(csr40[5]),
        .Q(csr4_c2f[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr4_reg[6] 
       (.C(aclk),
        .CE(\csr4[31]_i_1_n_0 ),
        .D(csr40[6]),
        .Q(csr4_c2f[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr4_reg[7] 
       (.C(aclk),
        .CE(\csr4[31]_i_1_n_0 ),
        .D(csr40[7]),
        .Q(csr4_c2f[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr4_reg[8] 
       (.C(aclk),
        .CE(\csr4[31]_i_1_n_0 ),
        .D(csr40[8]),
        .Q(csr4_c2f[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr4_reg[9] 
       (.C(aclk),
        .CE(\csr4[31]_i_1_n_0 ),
        .D(csr40[9]),
        .Q(csr4_c2f[9]),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair85" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr5[0]_i_1 
       (.I0(s_axi_csrs_wdata[0]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr5_c2f[0]),
        .O(csr50[0]));
  (* SOFT_HLUTNM = "soft_lutpair90" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr5[10]_i_1 
       (.I0(s_axi_csrs_wdata[10]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr5_c2f[10]),
        .O(csr50[10]));
  (* SOFT_HLUTNM = "soft_lutpair90" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr5[11]_i_1 
       (.I0(s_axi_csrs_wdata[11]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr5_c2f[11]),
        .O(csr50[11]));
  (* SOFT_HLUTNM = "soft_lutpair91" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr5[12]_i_1 
       (.I0(s_axi_csrs_wdata[12]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr5_c2f[12]),
        .O(csr50[12]));
  (* SOFT_HLUTNM = "soft_lutpair91" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr5[13]_i_1 
       (.I0(s_axi_csrs_wdata[13]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr5_c2f[13]),
        .O(csr50[13]));
  (* SOFT_HLUTNM = "soft_lutpair92" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr5[14]_i_1 
       (.I0(s_axi_csrs_wdata[14]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr5_c2f[14]),
        .O(csr50[14]));
  (* SOFT_HLUTNM = "soft_lutpair92" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr5[15]_i_1 
       (.I0(s_axi_csrs_wdata[15]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr5_c2f[15]),
        .O(csr50[15]));
  (* SOFT_HLUTNM = "soft_lutpair93" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr5[16]_i_1 
       (.I0(s_axi_csrs_wdata[16]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr5_c2f[16]),
        .O(csr50[16]));
  (* SOFT_HLUTNM = "soft_lutpair93" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr5[17]_i_1 
       (.I0(s_axi_csrs_wdata[17]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr5_c2f[17]),
        .O(csr50[17]));
  (* SOFT_HLUTNM = "soft_lutpair94" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr5[18]_i_1 
       (.I0(s_axi_csrs_wdata[18]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr5_c2f[18]),
        .O(csr50[18]));
  (* SOFT_HLUTNM = "soft_lutpair94" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr5[19]_i_1 
       (.I0(s_axi_csrs_wdata[19]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr5_c2f[19]),
        .O(csr50[19]));
  (* SOFT_HLUTNM = "soft_lutpair85" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr5[1]_i_1 
       (.I0(s_axi_csrs_wdata[1]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr5_c2f[1]),
        .O(csr50[1]));
  (* SOFT_HLUTNM = "soft_lutpair95" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr5[20]_i_1 
       (.I0(s_axi_csrs_wdata[20]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr5_c2f[20]),
        .O(csr50[20]));
  (* SOFT_HLUTNM = "soft_lutpair95" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr5[21]_i_1 
       (.I0(s_axi_csrs_wdata[21]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr5_c2f[21]),
        .O(csr50[21]));
  (* SOFT_HLUTNM = "soft_lutpair96" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr5[22]_i_1 
       (.I0(s_axi_csrs_wdata[22]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr5_c2f[22]),
        .O(csr50[22]));
  (* SOFT_HLUTNM = "soft_lutpair96" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr5[23]_i_1 
       (.I0(s_axi_csrs_wdata[23]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr5_c2f[23]),
        .O(csr50[23]));
  (* SOFT_HLUTNM = "soft_lutpair97" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr5[24]_i_1 
       (.I0(s_axi_csrs_wdata[24]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr5_c2f[24]),
        .O(csr50[24]));
  (* SOFT_HLUTNM = "soft_lutpair97" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr5[25]_i_1 
       (.I0(s_axi_csrs_wdata[25]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr5_c2f[25]),
        .O(csr50[25]));
  (* SOFT_HLUTNM = "soft_lutpair98" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr5[26]_i_1 
       (.I0(s_axi_csrs_wdata[26]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr5_c2f[26]),
        .O(csr50[26]));
  (* SOFT_HLUTNM = "soft_lutpair98" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr5[27]_i_1 
       (.I0(s_axi_csrs_wdata[27]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr5_c2f[27]),
        .O(csr50[27]));
  (* SOFT_HLUTNM = "soft_lutpair99" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr5[28]_i_1 
       (.I0(s_axi_csrs_wdata[28]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr5_c2f[28]),
        .O(csr50[28]));
  (* SOFT_HLUTNM = "soft_lutpair99" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr5[29]_i_1 
       (.I0(s_axi_csrs_wdata[29]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr5_c2f[29]),
        .O(csr50[29]));
  (* SOFT_HLUTNM = "soft_lutpair86" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr5[2]_i_1 
       (.I0(s_axi_csrs_wdata[2]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr5_c2f[2]),
        .O(csr50[2]));
  (* SOFT_HLUTNM = "soft_lutpair100" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr5[30]_i_1 
       (.I0(s_axi_csrs_wdata[30]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr5_c2f[30]),
        .O(csr50[30]));
  LUT3 #(
    .INIT(8'h20)) 
    \csr5[31]_i_1 
       (.I0(waddr[2]),
        .I1(waddr[3]),
        .I2(\csr4[31]_i_3_n_0 ),
        .O(\csr5[31]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair100" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr5[31]_i_2 
       (.I0(s_axi_csrs_wdata[31]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr5_c2f[31]),
        .O(csr50[31]));
  (* SOFT_HLUTNM = "soft_lutpair86" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr5[3]_i_1 
       (.I0(s_axi_csrs_wdata[3]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr5_c2f[3]),
        .O(csr50[3]));
  (* SOFT_HLUTNM = "soft_lutpair87" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr5[4]_i_1 
       (.I0(s_axi_csrs_wdata[4]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr5_c2f[4]),
        .O(csr50[4]));
  (* SOFT_HLUTNM = "soft_lutpair87" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr5[5]_i_1 
       (.I0(s_axi_csrs_wdata[5]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr5_c2f[5]),
        .O(csr50[5]));
  (* SOFT_HLUTNM = "soft_lutpair88" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr5[6]_i_1 
       (.I0(s_axi_csrs_wdata[6]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr5_c2f[6]),
        .O(csr50[6]));
  (* SOFT_HLUTNM = "soft_lutpair88" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr5[7]_i_1 
       (.I0(s_axi_csrs_wdata[7]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr5_c2f[7]),
        .O(csr50[7]));
  (* SOFT_HLUTNM = "soft_lutpair89" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr5[8]_i_1 
       (.I0(s_axi_csrs_wdata[8]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr5_c2f[8]),
        .O(csr50[8]));
  (* SOFT_HLUTNM = "soft_lutpair89" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr5[9]_i_1 
       (.I0(s_axi_csrs_wdata[9]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr5_c2f[9]),
        .O(csr50[9]));
  FDRE #(
    .INIT(1'b0)) 
    \csr5_reg[0] 
       (.C(aclk),
        .CE(\csr5[31]_i_1_n_0 ),
        .D(csr50[0]),
        .Q(csr5_c2f[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr5_reg[10] 
       (.C(aclk),
        .CE(\csr5[31]_i_1_n_0 ),
        .D(csr50[10]),
        .Q(csr5_c2f[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr5_reg[11] 
       (.C(aclk),
        .CE(\csr5[31]_i_1_n_0 ),
        .D(csr50[11]),
        .Q(csr5_c2f[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr5_reg[12] 
       (.C(aclk),
        .CE(\csr5[31]_i_1_n_0 ),
        .D(csr50[12]),
        .Q(csr5_c2f[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr5_reg[13] 
       (.C(aclk),
        .CE(\csr5[31]_i_1_n_0 ),
        .D(csr50[13]),
        .Q(csr5_c2f[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr5_reg[14] 
       (.C(aclk),
        .CE(\csr5[31]_i_1_n_0 ),
        .D(csr50[14]),
        .Q(csr5_c2f[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr5_reg[15] 
       (.C(aclk),
        .CE(\csr5[31]_i_1_n_0 ),
        .D(csr50[15]),
        .Q(csr5_c2f[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr5_reg[16] 
       (.C(aclk),
        .CE(\csr5[31]_i_1_n_0 ),
        .D(csr50[16]),
        .Q(csr5_c2f[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr5_reg[17] 
       (.C(aclk),
        .CE(\csr5[31]_i_1_n_0 ),
        .D(csr50[17]),
        .Q(csr5_c2f[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr5_reg[18] 
       (.C(aclk),
        .CE(\csr5[31]_i_1_n_0 ),
        .D(csr50[18]),
        .Q(csr5_c2f[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr5_reg[19] 
       (.C(aclk),
        .CE(\csr5[31]_i_1_n_0 ),
        .D(csr50[19]),
        .Q(csr5_c2f[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr5_reg[1] 
       (.C(aclk),
        .CE(\csr5[31]_i_1_n_0 ),
        .D(csr50[1]),
        .Q(csr5_c2f[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr5_reg[20] 
       (.C(aclk),
        .CE(\csr5[31]_i_1_n_0 ),
        .D(csr50[20]),
        .Q(csr5_c2f[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr5_reg[21] 
       (.C(aclk),
        .CE(\csr5[31]_i_1_n_0 ),
        .D(csr50[21]),
        .Q(csr5_c2f[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr5_reg[22] 
       (.C(aclk),
        .CE(\csr5[31]_i_1_n_0 ),
        .D(csr50[22]),
        .Q(csr5_c2f[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr5_reg[23] 
       (.C(aclk),
        .CE(\csr5[31]_i_1_n_0 ),
        .D(csr50[23]),
        .Q(csr5_c2f[23]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr5_reg[24] 
       (.C(aclk),
        .CE(\csr5[31]_i_1_n_0 ),
        .D(csr50[24]),
        .Q(csr5_c2f[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr5_reg[25] 
       (.C(aclk),
        .CE(\csr5[31]_i_1_n_0 ),
        .D(csr50[25]),
        .Q(csr5_c2f[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr5_reg[26] 
       (.C(aclk),
        .CE(\csr5[31]_i_1_n_0 ),
        .D(csr50[26]),
        .Q(csr5_c2f[26]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr5_reg[27] 
       (.C(aclk),
        .CE(\csr5[31]_i_1_n_0 ),
        .D(csr50[27]),
        .Q(csr5_c2f[27]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr5_reg[28] 
       (.C(aclk),
        .CE(\csr5[31]_i_1_n_0 ),
        .D(csr50[28]),
        .Q(csr5_c2f[28]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr5_reg[29] 
       (.C(aclk),
        .CE(\csr5[31]_i_1_n_0 ),
        .D(csr50[29]),
        .Q(csr5_c2f[29]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr5_reg[2] 
       (.C(aclk),
        .CE(\csr5[31]_i_1_n_0 ),
        .D(csr50[2]),
        .Q(csr5_c2f[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr5_reg[30] 
       (.C(aclk),
        .CE(\csr5[31]_i_1_n_0 ),
        .D(csr50[30]),
        .Q(csr5_c2f[30]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr5_reg[31] 
       (.C(aclk),
        .CE(\csr5[31]_i_1_n_0 ),
        .D(csr50[31]),
        .Q(csr5_c2f[31]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr5_reg[3] 
       (.C(aclk),
        .CE(\csr5[31]_i_1_n_0 ),
        .D(csr50[3]),
        .Q(csr5_c2f[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr5_reg[4] 
       (.C(aclk),
        .CE(\csr5[31]_i_1_n_0 ),
        .D(csr50[4]),
        .Q(csr5_c2f[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr5_reg[5] 
       (.C(aclk),
        .CE(\csr5[31]_i_1_n_0 ),
        .D(csr50[5]),
        .Q(csr5_c2f[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr5_reg[6] 
       (.C(aclk),
        .CE(\csr5[31]_i_1_n_0 ),
        .D(csr50[6]),
        .Q(csr5_c2f[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr5_reg[7] 
       (.C(aclk),
        .CE(\csr5[31]_i_1_n_0 ),
        .D(csr50[7]),
        .Q(csr5_c2f[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr5_reg[8] 
       (.C(aclk),
        .CE(\csr5[31]_i_1_n_0 ),
        .D(csr50[8]),
        .Q(csr5_c2f[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr5_reg[9] 
       (.C(aclk),
        .CE(\csr5[31]_i_1_n_0 ),
        .D(csr50[9]),
        .Q(csr5_c2f[9]),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair101" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr6[0]_i_1 
       (.I0(s_axi_csrs_wdata[0]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr6_c2f[0]),
        .O(csr60[0]));
  (* SOFT_HLUTNM = "soft_lutpair106" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr6[10]_i_1 
       (.I0(s_axi_csrs_wdata[10]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr6_c2f[10]),
        .O(csr60[10]));
  (* SOFT_HLUTNM = "soft_lutpair106" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr6[11]_i_1 
       (.I0(s_axi_csrs_wdata[11]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr6_c2f[11]),
        .O(csr60[11]));
  (* SOFT_HLUTNM = "soft_lutpair107" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr6[12]_i_1 
       (.I0(s_axi_csrs_wdata[12]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr6_c2f[12]),
        .O(csr60[12]));
  (* SOFT_HLUTNM = "soft_lutpair107" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr6[13]_i_1 
       (.I0(s_axi_csrs_wdata[13]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr6_c2f[13]),
        .O(csr60[13]));
  (* SOFT_HLUTNM = "soft_lutpair108" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr6[14]_i_1 
       (.I0(s_axi_csrs_wdata[14]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr6_c2f[14]),
        .O(csr60[14]));
  (* SOFT_HLUTNM = "soft_lutpair108" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr6[15]_i_1 
       (.I0(s_axi_csrs_wdata[15]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr6_c2f[15]),
        .O(csr60[15]));
  (* SOFT_HLUTNM = "soft_lutpair109" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr6[16]_i_1 
       (.I0(s_axi_csrs_wdata[16]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr6_c2f[16]),
        .O(csr60[16]));
  (* SOFT_HLUTNM = "soft_lutpair109" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr6[17]_i_1 
       (.I0(s_axi_csrs_wdata[17]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr6_c2f[17]),
        .O(csr60[17]));
  (* SOFT_HLUTNM = "soft_lutpair110" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr6[18]_i_1 
       (.I0(s_axi_csrs_wdata[18]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr6_c2f[18]),
        .O(csr60[18]));
  (* SOFT_HLUTNM = "soft_lutpair110" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr6[19]_i_1 
       (.I0(s_axi_csrs_wdata[19]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr6_c2f[19]),
        .O(csr60[19]));
  (* SOFT_HLUTNM = "soft_lutpair101" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr6[1]_i_1 
       (.I0(s_axi_csrs_wdata[1]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr6_c2f[1]),
        .O(csr60[1]));
  (* SOFT_HLUTNM = "soft_lutpair111" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr6[20]_i_1 
       (.I0(s_axi_csrs_wdata[20]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr6_c2f[20]),
        .O(csr60[20]));
  (* SOFT_HLUTNM = "soft_lutpair111" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr6[21]_i_1 
       (.I0(s_axi_csrs_wdata[21]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr6_c2f[21]),
        .O(csr60[21]));
  (* SOFT_HLUTNM = "soft_lutpair112" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr6[22]_i_1 
       (.I0(s_axi_csrs_wdata[22]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr6_c2f[22]),
        .O(csr60[22]));
  (* SOFT_HLUTNM = "soft_lutpair112" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr6[23]_i_1 
       (.I0(s_axi_csrs_wdata[23]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr6_c2f[23]),
        .O(csr60[23]));
  (* SOFT_HLUTNM = "soft_lutpair113" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr6[24]_i_1 
       (.I0(s_axi_csrs_wdata[24]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr6_c2f[24]),
        .O(csr60[24]));
  (* SOFT_HLUTNM = "soft_lutpair113" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr6[25]_i_1 
       (.I0(s_axi_csrs_wdata[25]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr6_c2f[25]),
        .O(csr60[25]));
  (* SOFT_HLUTNM = "soft_lutpair114" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr6[26]_i_1 
       (.I0(s_axi_csrs_wdata[26]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr6_c2f[26]),
        .O(csr60[26]));
  (* SOFT_HLUTNM = "soft_lutpair114" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr6[27]_i_1 
       (.I0(s_axi_csrs_wdata[27]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr6_c2f[27]),
        .O(csr60[27]));
  (* SOFT_HLUTNM = "soft_lutpair115" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr6[28]_i_1 
       (.I0(s_axi_csrs_wdata[28]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr6_c2f[28]),
        .O(csr60[28]));
  (* SOFT_HLUTNM = "soft_lutpair115" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr6[29]_i_1 
       (.I0(s_axi_csrs_wdata[29]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr6_c2f[29]),
        .O(csr60[29]));
  (* SOFT_HLUTNM = "soft_lutpair102" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr6[2]_i_1 
       (.I0(s_axi_csrs_wdata[2]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr6_c2f[2]),
        .O(csr60[2]));
  (* SOFT_HLUTNM = "soft_lutpair116" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr6[30]_i_1 
       (.I0(s_axi_csrs_wdata[30]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr6_c2f[30]),
        .O(csr60[30]));
  LUT3 #(
    .INIT(8'h08)) 
    \csr6[31]_i_1 
       (.I0(\csr4[31]_i_3_n_0 ),
        .I1(waddr[3]),
        .I2(waddr[2]),
        .O(\csr6[31]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair116" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr6[31]_i_2 
       (.I0(s_axi_csrs_wdata[31]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr6_c2f[31]),
        .O(csr60[31]));
  (* SOFT_HLUTNM = "soft_lutpair102" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr6[3]_i_1 
       (.I0(s_axi_csrs_wdata[3]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr6_c2f[3]),
        .O(csr60[3]));
  (* SOFT_HLUTNM = "soft_lutpair103" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr6[4]_i_1 
       (.I0(s_axi_csrs_wdata[4]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr6_c2f[4]),
        .O(csr60[4]));
  (* SOFT_HLUTNM = "soft_lutpair103" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr6[5]_i_1 
       (.I0(s_axi_csrs_wdata[5]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr6_c2f[5]),
        .O(csr60[5]));
  (* SOFT_HLUTNM = "soft_lutpair104" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr6[6]_i_1 
       (.I0(s_axi_csrs_wdata[6]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr6_c2f[6]),
        .O(csr60[6]));
  (* SOFT_HLUTNM = "soft_lutpair104" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr6[7]_i_1 
       (.I0(s_axi_csrs_wdata[7]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr6_c2f[7]),
        .O(csr60[7]));
  (* SOFT_HLUTNM = "soft_lutpair105" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr6[8]_i_1 
       (.I0(s_axi_csrs_wdata[8]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr6_c2f[8]),
        .O(csr60[8]));
  (* SOFT_HLUTNM = "soft_lutpair105" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr6[9]_i_1 
       (.I0(s_axi_csrs_wdata[9]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr6_c2f[9]),
        .O(csr60[9]));
  FDRE #(
    .INIT(1'b0)) 
    \csr6_reg[0] 
       (.C(aclk),
        .CE(\csr6[31]_i_1_n_0 ),
        .D(csr60[0]),
        .Q(csr6_c2f[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr6_reg[10] 
       (.C(aclk),
        .CE(\csr6[31]_i_1_n_0 ),
        .D(csr60[10]),
        .Q(csr6_c2f[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr6_reg[11] 
       (.C(aclk),
        .CE(\csr6[31]_i_1_n_0 ),
        .D(csr60[11]),
        .Q(csr6_c2f[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr6_reg[12] 
       (.C(aclk),
        .CE(\csr6[31]_i_1_n_0 ),
        .D(csr60[12]),
        .Q(csr6_c2f[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr6_reg[13] 
       (.C(aclk),
        .CE(\csr6[31]_i_1_n_0 ),
        .D(csr60[13]),
        .Q(csr6_c2f[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr6_reg[14] 
       (.C(aclk),
        .CE(\csr6[31]_i_1_n_0 ),
        .D(csr60[14]),
        .Q(csr6_c2f[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr6_reg[15] 
       (.C(aclk),
        .CE(\csr6[31]_i_1_n_0 ),
        .D(csr60[15]),
        .Q(csr6_c2f[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr6_reg[16] 
       (.C(aclk),
        .CE(\csr6[31]_i_1_n_0 ),
        .D(csr60[16]),
        .Q(csr6_c2f[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr6_reg[17] 
       (.C(aclk),
        .CE(\csr6[31]_i_1_n_0 ),
        .D(csr60[17]),
        .Q(csr6_c2f[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr6_reg[18] 
       (.C(aclk),
        .CE(\csr6[31]_i_1_n_0 ),
        .D(csr60[18]),
        .Q(csr6_c2f[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr6_reg[19] 
       (.C(aclk),
        .CE(\csr6[31]_i_1_n_0 ),
        .D(csr60[19]),
        .Q(csr6_c2f[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr6_reg[1] 
       (.C(aclk),
        .CE(\csr6[31]_i_1_n_0 ),
        .D(csr60[1]),
        .Q(csr6_c2f[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr6_reg[20] 
       (.C(aclk),
        .CE(\csr6[31]_i_1_n_0 ),
        .D(csr60[20]),
        .Q(csr6_c2f[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr6_reg[21] 
       (.C(aclk),
        .CE(\csr6[31]_i_1_n_0 ),
        .D(csr60[21]),
        .Q(csr6_c2f[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr6_reg[22] 
       (.C(aclk),
        .CE(\csr6[31]_i_1_n_0 ),
        .D(csr60[22]),
        .Q(csr6_c2f[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr6_reg[23] 
       (.C(aclk),
        .CE(\csr6[31]_i_1_n_0 ),
        .D(csr60[23]),
        .Q(csr6_c2f[23]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr6_reg[24] 
       (.C(aclk),
        .CE(\csr6[31]_i_1_n_0 ),
        .D(csr60[24]),
        .Q(csr6_c2f[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr6_reg[25] 
       (.C(aclk),
        .CE(\csr6[31]_i_1_n_0 ),
        .D(csr60[25]),
        .Q(csr6_c2f[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr6_reg[26] 
       (.C(aclk),
        .CE(\csr6[31]_i_1_n_0 ),
        .D(csr60[26]),
        .Q(csr6_c2f[26]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr6_reg[27] 
       (.C(aclk),
        .CE(\csr6[31]_i_1_n_0 ),
        .D(csr60[27]),
        .Q(csr6_c2f[27]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr6_reg[28] 
       (.C(aclk),
        .CE(\csr6[31]_i_1_n_0 ),
        .D(csr60[28]),
        .Q(csr6_c2f[28]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr6_reg[29] 
       (.C(aclk),
        .CE(\csr6[31]_i_1_n_0 ),
        .D(csr60[29]),
        .Q(csr6_c2f[29]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr6_reg[2] 
       (.C(aclk),
        .CE(\csr6[31]_i_1_n_0 ),
        .D(csr60[2]),
        .Q(csr6_c2f[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr6_reg[30] 
       (.C(aclk),
        .CE(\csr6[31]_i_1_n_0 ),
        .D(csr60[30]),
        .Q(csr6_c2f[30]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr6_reg[31] 
       (.C(aclk),
        .CE(\csr6[31]_i_1_n_0 ),
        .D(csr60[31]),
        .Q(csr6_c2f[31]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr6_reg[3] 
       (.C(aclk),
        .CE(\csr6[31]_i_1_n_0 ),
        .D(csr60[3]),
        .Q(csr6_c2f[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr6_reg[4] 
       (.C(aclk),
        .CE(\csr6[31]_i_1_n_0 ),
        .D(csr60[4]),
        .Q(csr6_c2f[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr6_reg[5] 
       (.C(aclk),
        .CE(\csr6[31]_i_1_n_0 ),
        .D(csr60[5]),
        .Q(csr6_c2f[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr6_reg[6] 
       (.C(aclk),
        .CE(\csr6[31]_i_1_n_0 ),
        .D(csr60[6]),
        .Q(csr6_c2f[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr6_reg[7] 
       (.C(aclk),
        .CE(\csr6[31]_i_1_n_0 ),
        .D(csr60[7]),
        .Q(csr6_c2f[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr6_reg[8] 
       (.C(aclk),
        .CE(\csr6[31]_i_1_n_0 ),
        .D(csr60[8]),
        .Q(csr6_c2f[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr6_reg[9] 
       (.C(aclk),
        .CE(\csr6[31]_i_1_n_0 ),
        .D(csr60[9]),
        .Q(csr6_c2f[9]),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair117" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr7[0]_i_1 
       (.I0(s_axi_csrs_wdata[0]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr7_c2f[0]),
        .O(csr70[0]));
  (* SOFT_HLUTNM = "soft_lutpair122" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr7[10]_i_1 
       (.I0(s_axi_csrs_wdata[10]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr7_c2f[10]),
        .O(csr70[10]));
  (* SOFT_HLUTNM = "soft_lutpair122" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr7[11]_i_1 
       (.I0(s_axi_csrs_wdata[11]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr7_c2f[11]),
        .O(csr70[11]));
  (* SOFT_HLUTNM = "soft_lutpair123" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr7[12]_i_1 
       (.I0(s_axi_csrs_wdata[12]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr7_c2f[12]),
        .O(csr70[12]));
  (* SOFT_HLUTNM = "soft_lutpair123" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr7[13]_i_1 
       (.I0(s_axi_csrs_wdata[13]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr7_c2f[13]),
        .O(csr70[13]));
  (* SOFT_HLUTNM = "soft_lutpair124" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr7[14]_i_1 
       (.I0(s_axi_csrs_wdata[14]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr7_c2f[14]),
        .O(csr70[14]));
  (* SOFT_HLUTNM = "soft_lutpair124" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr7[15]_i_1 
       (.I0(s_axi_csrs_wdata[15]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr7_c2f[15]),
        .O(csr70[15]));
  (* SOFT_HLUTNM = "soft_lutpair125" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr7[16]_i_1 
       (.I0(s_axi_csrs_wdata[16]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr7_c2f[16]),
        .O(csr70[16]));
  (* SOFT_HLUTNM = "soft_lutpair125" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr7[17]_i_1 
       (.I0(s_axi_csrs_wdata[17]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr7_c2f[17]),
        .O(csr70[17]));
  (* SOFT_HLUTNM = "soft_lutpair126" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr7[18]_i_1 
       (.I0(s_axi_csrs_wdata[18]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr7_c2f[18]),
        .O(csr70[18]));
  (* SOFT_HLUTNM = "soft_lutpair126" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr7[19]_i_1 
       (.I0(s_axi_csrs_wdata[19]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr7_c2f[19]),
        .O(csr70[19]));
  (* SOFT_HLUTNM = "soft_lutpair117" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr7[1]_i_1 
       (.I0(s_axi_csrs_wdata[1]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr7_c2f[1]),
        .O(csr70[1]));
  (* SOFT_HLUTNM = "soft_lutpair127" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr7[20]_i_1 
       (.I0(s_axi_csrs_wdata[20]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr7_c2f[20]),
        .O(csr70[20]));
  (* SOFT_HLUTNM = "soft_lutpair127" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr7[21]_i_1 
       (.I0(s_axi_csrs_wdata[21]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr7_c2f[21]),
        .O(csr70[21]));
  (* SOFT_HLUTNM = "soft_lutpair128" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr7[22]_i_1 
       (.I0(s_axi_csrs_wdata[22]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr7_c2f[22]),
        .O(csr70[22]));
  (* SOFT_HLUTNM = "soft_lutpair128" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr7[23]_i_1 
       (.I0(s_axi_csrs_wdata[23]),
        .I1(s_axi_csrs_wstrb[2]),
        .I2(csr7_c2f[23]),
        .O(csr70[23]));
  (* SOFT_HLUTNM = "soft_lutpair129" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr7[24]_i_1 
       (.I0(s_axi_csrs_wdata[24]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr7_c2f[24]),
        .O(csr70[24]));
  (* SOFT_HLUTNM = "soft_lutpair129" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr7[25]_i_1 
       (.I0(s_axi_csrs_wdata[25]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr7_c2f[25]),
        .O(csr70[25]));
  (* SOFT_HLUTNM = "soft_lutpair130" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr7[26]_i_1 
       (.I0(s_axi_csrs_wdata[26]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr7_c2f[26]),
        .O(csr70[26]));
  (* SOFT_HLUTNM = "soft_lutpair130" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr7[27]_i_1 
       (.I0(s_axi_csrs_wdata[27]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr7_c2f[27]),
        .O(csr70[27]));
  (* SOFT_HLUTNM = "soft_lutpair131" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr7[28]_i_1 
       (.I0(s_axi_csrs_wdata[28]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr7_c2f[28]),
        .O(csr70[28]));
  (* SOFT_HLUTNM = "soft_lutpair131" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr7[29]_i_1 
       (.I0(s_axi_csrs_wdata[29]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr7_c2f[29]),
        .O(csr70[29]));
  (* SOFT_HLUTNM = "soft_lutpair118" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr7[2]_i_1 
       (.I0(s_axi_csrs_wdata[2]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr7_c2f[2]),
        .O(csr70[2]));
  (* SOFT_HLUTNM = "soft_lutpair132" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr7[30]_i_1 
       (.I0(s_axi_csrs_wdata[30]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr7_c2f[30]),
        .O(csr70[30]));
  LUT3 #(
    .INIT(8'h80)) 
    \csr7[31]_i_1 
       (.I0(waddr[2]),
        .I1(\csr4[31]_i_3_n_0 ),
        .I2(waddr[3]),
        .O(\csr7[31]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair132" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr7[31]_i_2 
       (.I0(s_axi_csrs_wdata[31]),
        .I1(s_axi_csrs_wstrb[3]),
        .I2(csr7_c2f[31]),
        .O(csr70[31]));
  (* SOFT_HLUTNM = "soft_lutpair118" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr7[3]_i_1 
       (.I0(s_axi_csrs_wdata[3]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr7_c2f[3]),
        .O(csr70[3]));
  (* SOFT_HLUTNM = "soft_lutpair119" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr7[4]_i_1 
       (.I0(s_axi_csrs_wdata[4]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr7_c2f[4]),
        .O(csr70[4]));
  (* SOFT_HLUTNM = "soft_lutpair119" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr7[5]_i_1 
       (.I0(s_axi_csrs_wdata[5]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr7_c2f[5]),
        .O(csr70[5]));
  (* SOFT_HLUTNM = "soft_lutpair120" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr7[6]_i_1 
       (.I0(s_axi_csrs_wdata[6]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr7_c2f[6]),
        .O(csr70[6]));
  (* SOFT_HLUTNM = "soft_lutpair120" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr7[7]_i_1 
       (.I0(s_axi_csrs_wdata[7]),
        .I1(s_axi_csrs_wstrb[0]),
        .I2(csr7_c2f[7]),
        .O(csr70[7]));
  (* SOFT_HLUTNM = "soft_lutpair121" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr7[8]_i_1 
       (.I0(s_axi_csrs_wdata[8]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr7_c2f[8]),
        .O(csr70[8]));
  (* SOFT_HLUTNM = "soft_lutpair121" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \csr7[9]_i_1 
       (.I0(s_axi_csrs_wdata[9]),
        .I1(s_axi_csrs_wstrb[1]),
        .I2(csr7_c2f[9]),
        .O(csr70[9]));
  FDRE #(
    .INIT(1'b0)) 
    \csr7_reg[0] 
       (.C(aclk),
        .CE(\csr7[31]_i_1_n_0 ),
        .D(csr70[0]),
        .Q(csr7_c2f[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr7_reg[10] 
       (.C(aclk),
        .CE(\csr7[31]_i_1_n_0 ),
        .D(csr70[10]),
        .Q(csr7_c2f[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr7_reg[11] 
       (.C(aclk),
        .CE(\csr7[31]_i_1_n_0 ),
        .D(csr70[11]),
        .Q(csr7_c2f[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr7_reg[12] 
       (.C(aclk),
        .CE(\csr7[31]_i_1_n_0 ),
        .D(csr70[12]),
        .Q(csr7_c2f[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr7_reg[13] 
       (.C(aclk),
        .CE(\csr7[31]_i_1_n_0 ),
        .D(csr70[13]),
        .Q(csr7_c2f[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr7_reg[14] 
       (.C(aclk),
        .CE(\csr7[31]_i_1_n_0 ),
        .D(csr70[14]),
        .Q(csr7_c2f[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr7_reg[15] 
       (.C(aclk),
        .CE(\csr7[31]_i_1_n_0 ),
        .D(csr70[15]),
        .Q(csr7_c2f[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr7_reg[16] 
       (.C(aclk),
        .CE(\csr7[31]_i_1_n_0 ),
        .D(csr70[16]),
        .Q(csr7_c2f[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr7_reg[17] 
       (.C(aclk),
        .CE(\csr7[31]_i_1_n_0 ),
        .D(csr70[17]),
        .Q(csr7_c2f[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr7_reg[18] 
       (.C(aclk),
        .CE(\csr7[31]_i_1_n_0 ),
        .D(csr70[18]),
        .Q(csr7_c2f[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr7_reg[19] 
       (.C(aclk),
        .CE(\csr7[31]_i_1_n_0 ),
        .D(csr70[19]),
        .Q(csr7_c2f[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr7_reg[1] 
       (.C(aclk),
        .CE(\csr7[31]_i_1_n_0 ),
        .D(csr70[1]),
        .Q(csr7_c2f[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr7_reg[20] 
       (.C(aclk),
        .CE(\csr7[31]_i_1_n_0 ),
        .D(csr70[20]),
        .Q(csr7_c2f[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr7_reg[21] 
       (.C(aclk),
        .CE(\csr7[31]_i_1_n_0 ),
        .D(csr70[21]),
        .Q(csr7_c2f[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr7_reg[22] 
       (.C(aclk),
        .CE(\csr7[31]_i_1_n_0 ),
        .D(csr70[22]),
        .Q(csr7_c2f[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr7_reg[23] 
       (.C(aclk),
        .CE(\csr7[31]_i_1_n_0 ),
        .D(csr70[23]),
        .Q(csr7_c2f[23]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr7_reg[24] 
       (.C(aclk),
        .CE(\csr7[31]_i_1_n_0 ),
        .D(csr70[24]),
        .Q(csr7_c2f[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr7_reg[25] 
       (.C(aclk),
        .CE(\csr7[31]_i_1_n_0 ),
        .D(csr70[25]),
        .Q(csr7_c2f[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr7_reg[26] 
       (.C(aclk),
        .CE(\csr7[31]_i_1_n_0 ),
        .D(csr70[26]),
        .Q(csr7_c2f[26]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr7_reg[27] 
       (.C(aclk),
        .CE(\csr7[31]_i_1_n_0 ),
        .D(csr70[27]),
        .Q(csr7_c2f[27]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr7_reg[28] 
       (.C(aclk),
        .CE(\csr7[31]_i_1_n_0 ),
        .D(csr70[28]),
        .Q(csr7_c2f[28]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr7_reg[29] 
       (.C(aclk),
        .CE(\csr7[31]_i_1_n_0 ),
        .D(csr70[29]),
        .Q(csr7_c2f[29]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr7_reg[2] 
       (.C(aclk),
        .CE(\csr7[31]_i_1_n_0 ),
        .D(csr70[2]),
        .Q(csr7_c2f[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr7_reg[30] 
       (.C(aclk),
        .CE(\csr7[31]_i_1_n_0 ),
        .D(csr70[30]),
        .Q(csr7_c2f[30]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr7_reg[31] 
       (.C(aclk),
        .CE(\csr7[31]_i_1_n_0 ),
        .D(csr70[31]),
        .Q(csr7_c2f[31]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr7_reg[3] 
       (.C(aclk),
        .CE(\csr7[31]_i_1_n_0 ),
        .D(csr70[3]),
        .Q(csr7_c2f[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr7_reg[4] 
       (.C(aclk),
        .CE(\csr7[31]_i_1_n_0 ),
        .D(csr70[4]),
        .Q(csr7_c2f[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr7_reg[5] 
       (.C(aclk),
        .CE(\csr7[31]_i_1_n_0 ),
        .D(csr70[5]),
        .Q(csr7_c2f[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr7_reg[6] 
       (.C(aclk),
        .CE(\csr7[31]_i_1_n_0 ),
        .D(csr70[6]),
        .Q(csr7_c2f[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr7_reg[7] 
       (.C(aclk),
        .CE(\csr7[31]_i_1_n_0 ),
        .D(csr70[7]),
        .Q(csr7_c2f[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr7_reg[8] 
       (.C(aclk),
        .CE(\csr7[31]_i_1_n_0 ),
        .D(csr70[8]),
        .Q(csr7_c2f[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \csr7_reg[9] 
       (.C(aclk),
        .CE(\csr7[31]_i_1_n_0 ),
        .D(csr70[9]),
        .Q(csr7_c2f[9]),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT3 #(
    .INIT(8'hF8)) 
    dma_done_INST_0
       (.I0(m_axi_dma_rvalid),
        .I1(m_axi_dma_rready),
        .I2(m_axi_dma_bvalid),
        .O(dma_done));
  LUT1 #(
    .INIT(2'h1)) 
    dma_error_set_i_1
       (.I0(aresetn),
        .O(dma_error_set_i_1_n_0));
  LUT3 #(
    .INIT(8'hFE)) 
    dma_error_set_i_2
       (.I0(wrong_addr0__6),
        .I1(wrong_addr00_in),
        .I2(dma_error),
        .O(dma_error_set_i_2_n_0));
  LUT5 #(
    .INIT(32'hAAAAAAA8)) 
    dma_error_set_i_3
       (.I0(dma_f2c_start),
        .I1(dma_error_set_i_5_n_0),
        .I2(dma_f2c_addr[0]),
        .I3(dma_f2c_addr[2]),
        .I4(dma_f2c_addr[1]),
        .O(wrong_addr0__6));
  LUT5 #(
    .INIT(32'hAAAAAAA8)) 
    dma_error_set_i_4
       (.I0(dma_c2f_start),
        .I1(dma_error_set_i_6_n_0),
        .I2(dma_c2f_addr[0]),
        .I3(dma_c2f_addr[2]),
        .I4(dma_c2f_addr[1]),
        .O(wrong_addr00_in));
  LUT4 #(
    .INIT(16'hFFFE)) 
    dma_error_set_i_5
       (.I0(dma_f2c_addr[4]),
        .I1(dma_f2c_addr[3]),
        .I2(dma_f2c_addr[6]),
        .I3(dma_f2c_addr[5]),
        .O(dma_error_set_i_5_n_0));
  LUT4 #(
    .INIT(16'hFFFE)) 
    dma_error_set_i_6
       (.I0(dma_c2f_addr[4]),
        .I1(dma_c2f_addr[3]),
        .I2(dma_c2f_addr[6]),
        .I3(dma_c2f_addr[5]),
        .O(dma_error_set_i_6_n_0));
  FDRE #(
    .INIT(1'b0)) 
    dma_error_set_reg
       (.C(aclk),
        .CE(1'b1),
        .D(dma_error_set_i_2_n_0),
        .Q(dma_error),
        .R(dma_error_set_i_1_n_0));
  LUT6 #(
    .INIT(64'h0000000000000004)) 
    dma_idle_INST_0
       (.I0(state[1]),
        .I1(state[0]),
        .I2(state[3]),
        .I3(state[5]),
        .I4(state[4]),
        .I5(state[2]),
        .O(dma_idle));
  LUT6 #(
    .INIT(64'h0000000000000100)) 
    m_axi_dma_arvalid_INST_0
       (.I0(state[5]),
        .I1(state[1]),
        .I2(state[0]),
        .I3(state[4]),
        .I4(state[3]),
        .I5(state[2]),
        .O(m_axi_dma_arvalid));
  LUT6 #(
    .INIT(64'h0000000000000004)) 
    m_axi_dma_awvalid_INST_0
       (.I0(state[0]),
        .I1(state[1]),
        .I2(state[3]),
        .I3(state[5]),
        .I4(state[4]),
        .I5(state[2]),
        .O(m_axi_dma_awvalid));
  LUT6 #(
    .INIT(64'h0000000000000002)) 
    m_axi_dma_bready_INST_0
       (.I0(state[3]),
        .I1(state[2]),
        .I2(state[5]),
        .I3(state[4]),
        .I4(state[1]),
        .I5(state[0]),
        .O(m_axi_dma_bready));
  LUT6 #(
    .INIT(64'h0000000000000100)) 
    m_axi_dma_rready_INST_0
       (.I0(state[1]),
        .I1(state[4]),
        .I2(state[0]),
        .I3(state[5]),
        .I4(state[3]),
        .I5(state[2]),
        .O(m_axi_dma_rready));
  LUT6 #(
    .INIT(64'h0000000000000010)) 
    m_axi_dma_wlast_INST_0
       (.I0(state[0]),
        .I1(state[1]),
        .I2(state[2]),
        .I3(state[3]),
        .I4(state[5]),
        .I5(state[4]),
        .O(m_axi_dma_wvalid));
  LUT6 #(
    .INIT(64'h0000000100010116)) 
    next_state
       (.I0(state[0]),
        .I1(state[1]),
        .I2(state[2]),
        .I3(state[3]),
        .I4(state[4]),
        .I5(state[5]),
        .O(next_state_n_0));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[0]_i_2 
       (.I0(csr3_f2c[0]),
        .I1(csr2_f2c[0]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr1_f2c[0]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr0_f2c[0]),
        .O(\rdata[0]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[0]_i_3 
       (.I0(csr7_f2c[0]),
        .I1(csr6_f2c[0]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr5_f2c[0]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr4_f2c[0]),
        .O(\rdata[0]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[10]_i_2 
       (.I0(csr3_f2c[10]),
        .I1(csr2_f2c[10]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr1_f2c[10]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr0_f2c[10]),
        .O(\rdata[10]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[10]_i_3 
       (.I0(csr7_f2c[10]),
        .I1(csr6_f2c[10]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr5_f2c[10]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr4_f2c[10]),
        .O(\rdata[10]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[11]_i_2 
       (.I0(csr3_f2c[11]),
        .I1(csr2_f2c[11]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr1_f2c[11]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr0_f2c[11]),
        .O(\rdata[11]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[11]_i_3 
       (.I0(csr7_f2c[11]),
        .I1(csr6_f2c[11]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr5_f2c[11]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr4_f2c[11]),
        .O(\rdata[11]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[12]_i_2 
       (.I0(csr3_f2c[12]),
        .I1(csr2_f2c[12]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr1_f2c[12]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr0_f2c[12]),
        .O(\rdata[12]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[12]_i_3 
       (.I0(csr7_f2c[12]),
        .I1(csr6_f2c[12]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr5_f2c[12]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr4_f2c[12]),
        .O(\rdata[12]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[13]_i_2 
       (.I0(csr3_f2c[13]),
        .I1(csr2_f2c[13]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr1_f2c[13]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr0_f2c[13]),
        .O(\rdata[13]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[13]_i_3 
       (.I0(csr7_f2c[13]),
        .I1(csr6_f2c[13]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr5_f2c[13]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr4_f2c[13]),
        .O(\rdata[13]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[14]_i_2 
       (.I0(csr3_f2c[14]),
        .I1(csr2_f2c[14]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr1_f2c[14]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr0_f2c[14]),
        .O(\rdata[14]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[14]_i_3 
       (.I0(csr7_f2c[14]),
        .I1(csr6_f2c[14]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr5_f2c[14]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr4_f2c[14]),
        .O(\rdata[14]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[15]_i_2 
       (.I0(csr3_f2c[15]),
        .I1(csr2_f2c[15]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr1_f2c[15]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr0_f2c[15]),
        .O(\rdata[15]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[15]_i_3 
       (.I0(csr7_f2c[15]),
        .I1(csr6_f2c[15]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr5_f2c[15]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr4_f2c[15]),
        .O(\rdata[15]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[16]_i_2 
       (.I0(csr3_f2c[16]),
        .I1(csr2_f2c[16]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr1_f2c[16]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr0_f2c[16]),
        .O(\rdata[16]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[16]_i_3 
       (.I0(csr7_f2c[16]),
        .I1(csr6_f2c[16]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr5_f2c[16]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr4_f2c[16]),
        .O(\rdata[16]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[17]_i_2 
       (.I0(csr3_f2c[17]),
        .I1(csr2_f2c[17]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr1_f2c[17]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr0_f2c[17]),
        .O(\rdata[17]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[17]_i_3 
       (.I0(csr7_f2c[17]),
        .I1(csr6_f2c[17]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr5_f2c[17]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr4_f2c[17]),
        .O(\rdata[17]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[18]_i_2 
       (.I0(csr3_f2c[18]),
        .I1(csr2_f2c[18]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr1_f2c[18]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr0_f2c[18]),
        .O(\rdata[18]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[18]_i_3 
       (.I0(csr7_f2c[18]),
        .I1(csr6_f2c[18]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr5_f2c[18]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr4_f2c[18]),
        .O(\rdata[18]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[19]_i_2 
       (.I0(csr3_f2c[19]),
        .I1(csr2_f2c[19]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr1_f2c[19]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr0_f2c[19]),
        .O(\rdata[19]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[19]_i_3 
       (.I0(csr7_f2c[19]),
        .I1(csr6_f2c[19]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr5_f2c[19]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr4_f2c[19]),
        .O(\rdata[19]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[1]_i_2 
       (.I0(csr3_f2c[1]),
        .I1(csr2_f2c[1]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr1_f2c[1]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr0_f2c[1]),
        .O(\rdata[1]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[1]_i_3 
       (.I0(csr7_f2c[1]),
        .I1(csr6_f2c[1]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr5_f2c[1]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr4_f2c[1]),
        .O(\rdata[1]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[20]_i_2 
       (.I0(csr3_f2c[20]),
        .I1(csr2_f2c[20]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr1_f2c[20]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr0_f2c[20]),
        .O(\rdata[20]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[20]_i_3 
       (.I0(csr7_f2c[20]),
        .I1(csr6_f2c[20]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr5_f2c[20]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr4_f2c[20]),
        .O(\rdata[20]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[21]_i_2 
       (.I0(csr3_f2c[21]),
        .I1(csr2_f2c[21]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr1_f2c[21]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr0_f2c[21]),
        .O(\rdata[21]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[21]_i_3 
       (.I0(csr7_f2c[21]),
        .I1(csr6_f2c[21]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr5_f2c[21]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr4_f2c[21]),
        .O(\rdata[21]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[22]_i_2 
       (.I0(csr3_f2c[22]),
        .I1(csr2_f2c[22]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr1_f2c[22]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr0_f2c[22]),
        .O(\rdata[22]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[22]_i_3 
       (.I0(csr7_f2c[22]),
        .I1(csr6_f2c[22]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr5_f2c[22]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr4_f2c[22]),
        .O(\rdata[22]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[23]_i_2 
       (.I0(csr3_f2c[23]),
        .I1(csr2_f2c[23]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr1_f2c[23]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr0_f2c[23]),
        .O(\rdata[23]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[23]_i_3 
       (.I0(csr7_f2c[23]),
        .I1(csr6_f2c[23]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr5_f2c[23]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr4_f2c[23]),
        .O(\rdata[23]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[24]_i_2 
       (.I0(csr3_f2c[24]),
        .I1(csr2_f2c[24]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr1_f2c[24]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr0_f2c[24]),
        .O(\rdata[24]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[24]_i_3 
       (.I0(csr7_f2c[24]),
        .I1(csr6_f2c[24]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr5_f2c[24]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr4_f2c[24]),
        .O(\rdata[24]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[25]_i_2 
       (.I0(csr3_f2c[25]),
        .I1(csr2_f2c[25]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr1_f2c[25]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr0_f2c[25]),
        .O(\rdata[25]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[25]_i_3 
       (.I0(csr7_f2c[25]),
        .I1(csr6_f2c[25]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr5_f2c[25]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr4_f2c[25]),
        .O(\rdata[25]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[26]_i_2 
       (.I0(csr3_f2c[26]),
        .I1(csr2_f2c[26]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr1_f2c[26]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr0_f2c[26]),
        .O(\rdata[26]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[26]_i_3 
       (.I0(csr7_f2c[26]),
        .I1(csr6_f2c[26]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr5_f2c[26]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr4_f2c[26]),
        .O(\rdata[26]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[27]_i_2 
       (.I0(csr3_f2c[27]),
        .I1(csr2_f2c[27]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr1_f2c[27]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr0_f2c[27]),
        .O(\rdata[27]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[27]_i_3 
       (.I0(csr7_f2c[27]),
        .I1(csr6_f2c[27]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr5_f2c[27]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr4_f2c[27]),
        .O(\rdata[27]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[28]_i_2 
       (.I0(csr3_f2c[28]),
        .I1(csr2_f2c[28]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr1_f2c[28]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr0_f2c[28]),
        .O(\rdata[28]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[28]_i_3 
       (.I0(csr7_f2c[28]),
        .I1(csr6_f2c[28]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr5_f2c[28]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr4_f2c[28]),
        .O(\rdata[28]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[29]_i_2 
       (.I0(csr3_f2c[29]),
        .I1(csr2_f2c[29]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr1_f2c[29]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr0_f2c[29]),
        .O(\rdata[29]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[29]_i_3 
       (.I0(csr7_f2c[29]),
        .I1(csr6_f2c[29]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr5_f2c[29]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr4_f2c[29]),
        .O(\rdata[29]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[2]_i_2 
       (.I0(csr3_f2c[2]),
        .I1(csr2_f2c[2]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr1_f2c[2]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr0_f2c[2]),
        .O(\rdata[2]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[2]_i_3 
       (.I0(csr7_f2c[2]),
        .I1(csr6_f2c[2]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr5_f2c[2]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr4_f2c[2]),
        .O(\rdata[2]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[30]_i_2 
       (.I0(csr3_f2c[30]),
        .I1(csr2_f2c[30]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr1_f2c[30]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr0_f2c[30]),
        .O(\rdata[30]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[30]_i_3 
       (.I0(csr7_f2c[30]),
        .I1(csr6_f2c[30]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr5_f2c[30]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr4_f2c[30]),
        .O(\rdata[30]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h000000E000000000)) 
    \rdata[31]_i_1 
       (.I0(s_axi_csrs_araddr[1]),
        .I1(s_axi_csrs_araddr[0]),
        .I2(rstate[0]),
        .I3(wstate[3]),
        .I4(rstate[1]),
        .I5(s_axi_csrs_arvalid),
        .O(\rdata[31]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'h0200)) 
    \rdata[31]_i_2 
       (.I0(s_axi_csrs_arvalid),
        .I1(rstate[1]),
        .I2(wstate[3]),
        .I3(rstate[0]),
        .O(ar_hs));
  LUT3 #(
    .INIT(8'hBA)) 
    \rdata[31]_i_4 
       (.I0(s_axi_csrs_araddr[1]),
        .I1(s_axi_csrs_araddr[0]),
        .I2(s_axi_csrs_araddr[4]),
        .O(\rdata[31]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[31]_i_5 
       (.I0(csr3_f2c[31]),
        .I1(csr2_f2c[31]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr1_f2c[31]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr0_f2c[31]),
        .O(\rdata[31]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[31]_i_6 
       (.I0(csr7_f2c[31]),
        .I1(csr6_f2c[31]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr5_f2c[31]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr4_f2c[31]),
        .O(\rdata[31]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[3]_i_2 
       (.I0(csr3_f2c[3]),
        .I1(csr2_f2c[3]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr1_f2c[3]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr0_f2c[3]),
        .O(\rdata[3]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[3]_i_3 
       (.I0(csr7_f2c[3]),
        .I1(csr6_f2c[3]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr5_f2c[3]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr4_f2c[3]),
        .O(\rdata[3]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[4]_i_2 
       (.I0(csr3_f2c[4]),
        .I1(csr2_f2c[4]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr1_f2c[4]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr0_f2c[4]),
        .O(\rdata[4]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[4]_i_3 
       (.I0(csr7_f2c[4]),
        .I1(csr6_f2c[4]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr5_f2c[4]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr4_f2c[4]),
        .O(\rdata[4]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[5]_i_2 
       (.I0(csr3_f2c[5]),
        .I1(csr2_f2c[5]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr1_f2c[5]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr0_f2c[5]),
        .O(\rdata[5]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[5]_i_3 
       (.I0(csr7_f2c[5]),
        .I1(csr6_f2c[5]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr5_f2c[5]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr4_f2c[5]),
        .O(\rdata[5]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[6]_i_2 
       (.I0(csr3_f2c[6]),
        .I1(csr2_f2c[6]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr1_f2c[6]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr0_f2c[6]),
        .O(\rdata[6]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[6]_i_3 
       (.I0(csr7_f2c[6]),
        .I1(csr6_f2c[6]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr5_f2c[6]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr4_f2c[6]),
        .O(\rdata[6]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[7]_i_2 
       (.I0(csr3_f2c[7]),
        .I1(csr2_f2c[7]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr1_f2c[7]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr0_f2c[7]),
        .O(\rdata[7]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[7]_i_3 
       (.I0(csr7_f2c[7]),
        .I1(csr6_f2c[7]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr5_f2c[7]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr4_f2c[7]),
        .O(\rdata[7]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[8]_i_2 
       (.I0(csr3_f2c[8]),
        .I1(csr2_f2c[8]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr1_f2c[8]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr0_f2c[8]),
        .O(\rdata[8]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[8]_i_3 
       (.I0(csr7_f2c[8]),
        .I1(csr6_f2c[8]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr5_f2c[8]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr4_f2c[8]),
        .O(\rdata[8]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[9]_i_2 
       (.I0(csr3_f2c[9]),
        .I1(csr2_f2c[9]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr1_f2c[9]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr0_f2c[9]),
        .O(\rdata[9]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \rdata[9]_i_3 
       (.I0(csr7_f2c[9]),
        .I1(csr6_f2c[9]),
        .I2(s_axi_csrs_araddr[3]),
        .I3(csr5_f2c[9]),
        .I4(s_axi_csrs_araddr[2]),
        .I5(csr4_f2c[9]),
        .O(\rdata[9]_i_3_n_0 ));
  FDRE \rdata_reg[0] 
       (.C(aclk),
        .CE(ar_hs),
        .D(\rdata_reg[0]_i_1_n_0 ),
        .Q(s_axi_csrs_rdata[0]),
        .R(\rdata[31]_i_1_n_0 ));
  MUXF7 \rdata_reg[0]_i_1 
       (.I0(\rdata[0]_i_2_n_0 ),
        .I1(\rdata[0]_i_3_n_0 ),
        .O(\rdata_reg[0]_i_1_n_0 ),
        .S(\rdata[31]_i_4_n_0 ));
  FDRE \rdata_reg[10] 
       (.C(aclk),
        .CE(ar_hs),
        .D(\rdata_reg[10]_i_1_n_0 ),
        .Q(s_axi_csrs_rdata[10]),
        .R(\rdata[31]_i_1_n_0 ));
  MUXF7 \rdata_reg[10]_i_1 
       (.I0(\rdata[10]_i_2_n_0 ),
        .I1(\rdata[10]_i_3_n_0 ),
        .O(\rdata_reg[10]_i_1_n_0 ),
        .S(\rdata[31]_i_4_n_0 ));
  FDRE \rdata_reg[11] 
       (.C(aclk),
        .CE(ar_hs),
        .D(\rdata_reg[11]_i_1_n_0 ),
        .Q(s_axi_csrs_rdata[11]),
        .R(\rdata[31]_i_1_n_0 ));
  MUXF7 \rdata_reg[11]_i_1 
       (.I0(\rdata[11]_i_2_n_0 ),
        .I1(\rdata[11]_i_3_n_0 ),
        .O(\rdata_reg[11]_i_1_n_0 ),
        .S(\rdata[31]_i_4_n_0 ));
  FDRE \rdata_reg[12] 
       (.C(aclk),
        .CE(ar_hs),
        .D(\rdata_reg[12]_i_1_n_0 ),
        .Q(s_axi_csrs_rdata[12]),
        .R(\rdata[31]_i_1_n_0 ));
  MUXF7 \rdata_reg[12]_i_1 
       (.I0(\rdata[12]_i_2_n_0 ),
        .I1(\rdata[12]_i_3_n_0 ),
        .O(\rdata_reg[12]_i_1_n_0 ),
        .S(\rdata[31]_i_4_n_0 ));
  FDRE \rdata_reg[13] 
       (.C(aclk),
        .CE(ar_hs),
        .D(\rdata_reg[13]_i_1_n_0 ),
        .Q(s_axi_csrs_rdata[13]),
        .R(\rdata[31]_i_1_n_0 ));
  MUXF7 \rdata_reg[13]_i_1 
       (.I0(\rdata[13]_i_2_n_0 ),
        .I1(\rdata[13]_i_3_n_0 ),
        .O(\rdata_reg[13]_i_1_n_0 ),
        .S(\rdata[31]_i_4_n_0 ));
  FDRE \rdata_reg[14] 
       (.C(aclk),
        .CE(ar_hs),
        .D(\rdata_reg[14]_i_1_n_0 ),
        .Q(s_axi_csrs_rdata[14]),
        .R(\rdata[31]_i_1_n_0 ));
  MUXF7 \rdata_reg[14]_i_1 
       (.I0(\rdata[14]_i_2_n_0 ),
        .I1(\rdata[14]_i_3_n_0 ),
        .O(\rdata_reg[14]_i_1_n_0 ),
        .S(\rdata[31]_i_4_n_0 ));
  FDRE \rdata_reg[15] 
       (.C(aclk),
        .CE(ar_hs),
        .D(\rdata_reg[15]_i_1_n_0 ),
        .Q(s_axi_csrs_rdata[15]),
        .R(\rdata[31]_i_1_n_0 ));
  MUXF7 \rdata_reg[15]_i_1 
       (.I0(\rdata[15]_i_2_n_0 ),
        .I1(\rdata[15]_i_3_n_0 ),
        .O(\rdata_reg[15]_i_1_n_0 ),
        .S(\rdata[31]_i_4_n_0 ));
  FDRE \rdata_reg[16] 
       (.C(aclk),
        .CE(ar_hs),
        .D(\rdata_reg[16]_i_1_n_0 ),
        .Q(s_axi_csrs_rdata[16]),
        .R(\rdata[31]_i_1_n_0 ));
  MUXF7 \rdata_reg[16]_i_1 
       (.I0(\rdata[16]_i_2_n_0 ),
        .I1(\rdata[16]_i_3_n_0 ),
        .O(\rdata_reg[16]_i_1_n_0 ),
        .S(\rdata[31]_i_4_n_0 ));
  FDRE \rdata_reg[17] 
       (.C(aclk),
        .CE(ar_hs),
        .D(\rdata_reg[17]_i_1_n_0 ),
        .Q(s_axi_csrs_rdata[17]),
        .R(\rdata[31]_i_1_n_0 ));
  MUXF7 \rdata_reg[17]_i_1 
       (.I0(\rdata[17]_i_2_n_0 ),
        .I1(\rdata[17]_i_3_n_0 ),
        .O(\rdata_reg[17]_i_1_n_0 ),
        .S(\rdata[31]_i_4_n_0 ));
  FDRE \rdata_reg[18] 
       (.C(aclk),
        .CE(ar_hs),
        .D(\rdata_reg[18]_i_1_n_0 ),
        .Q(s_axi_csrs_rdata[18]),
        .R(\rdata[31]_i_1_n_0 ));
  MUXF7 \rdata_reg[18]_i_1 
       (.I0(\rdata[18]_i_2_n_0 ),
        .I1(\rdata[18]_i_3_n_0 ),
        .O(\rdata_reg[18]_i_1_n_0 ),
        .S(\rdata[31]_i_4_n_0 ));
  FDRE \rdata_reg[19] 
       (.C(aclk),
        .CE(ar_hs),
        .D(\rdata_reg[19]_i_1_n_0 ),
        .Q(s_axi_csrs_rdata[19]),
        .R(\rdata[31]_i_1_n_0 ));
  MUXF7 \rdata_reg[19]_i_1 
       (.I0(\rdata[19]_i_2_n_0 ),
        .I1(\rdata[19]_i_3_n_0 ),
        .O(\rdata_reg[19]_i_1_n_0 ),
        .S(\rdata[31]_i_4_n_0 ));
  FDRE \rdata_reg[1] 
       (.C(aclk),
        .CE(ar_hs),
        .D(\rdata_reg[1]_i_1_n_0 ),
        .Q(s_axi_csrs_rdata[1]),
        .R(\rdata[31]_i_1_n_0 ));
  MUXF7 \rdata_reg[1]_i_1 
       (.I0(\rdata[1]_i_2_n_0 ),
        .I1(\rdata[1]_i_3_n_0 ),
        .O(\rdata_reg[1]_i_1_n_0 ),
        .S(\rdata[31]_i_4_n_0 ));
  FDRE \rdata_reg[20] 
       (.C(aclk),
        .CE(ar_hs),
        .D(\rdata_reg[20]_i_1_n_0 ),
        .Q(s_axi_csrs_rdata[20]),
        .R(\rdata[31]_i_1_n_0 ));
  MUXF7 \rdata_reg[20]_i_1 
       (.I0(\rdata[20]_i_2_n_0 ),
        .I1(\rdata[20]_i_3_n_0 ),
        .O(\rdata_reg[20]_i_1_n_0 ),
        .S(\rdata[31]_i_4_n_0 ));
  FDRE \rdata_reg[21] 
       (.C(aclk),
        .CE(ar_hs),
        .D(\rdata_reg[21]_i_1_n_0 ),
        .Q(s_axi_csrs_rdata[21]),
        .R(\rdata[31]_i_1_n_0 ));
  MUXF7 \rdata_reg[21]_i_1 
       (.I0(\rdata[21]_i_2_n_0 ),
        .I1(\rdata[21]_i_3_n_0 ),
        .O(\rdata_reg[21]_i_1_n_0 ),
        .S(\rdata[31]_i_4_n_0 ));
  FDRE \rdata_reg[22] 
       (.C(aclk),
        .CE(ar_hs),
        .D(\rdata_reg[22]_i_1_n_0 ),
        .Q(s_axi_csrs_rdata[22]),
        .R(\rdata[31]_i_1_n_0 ));
  MUXF7 \rdata_reg[22]_i_1 
       (.I0(\rdata[22]_i_2_n_0 ),
        .I1(\rdata[22]_i_3_n_0 ),
        .O(\rdata_reg[22]_i_1_n_0 ),
        .S(\rdata[31]_i_4_n_0 ));
  FDRE \rdata_reg[23] 
       (.C(aclk),
        .CE(ar_hs),
        .D(\rdata_reg[23]_i_1_n_0 ),
        .Q(s_axi_csrs_rdata[23]),
        .R(\rdata[31]_i_1_n_0 ));
  MUXF7 \rdata_reg[23]_i_1 
       (.I0(\rdata[23]_i_2_n_0 ),
        .I1(\rdata[23]_i_3_n_0 ),
        .O(\rdata_reg[23]_i_1_n_0 ),
        .S(\rdata[31]_i_4_n_0 ));
  FDRE \rdata_reg[24] 
       (.C(aclk),
        .CE(ar_hs),
        .D(\rdata_reg[24]_i_1_n_0 ),
        .Q(s_axi_csrs_rdata[24]),
        .R(\rdata[31]_i_1_n_0 ));
  MUXF7 \rdata_reg[24]_i_1 
       (.I0(\rdata[24]_i_2_n_0 ),
        .I1(\rdata[24]_i_3_n_0 ),
        .O(\rdata_reg[24]_i_1_n_0 ),
        .S(\rdata[31]_i_4_n_0 ));
  FDRE \rdata_reg[25] 
       (.C(aclk),
        .CE(ar_hs),
        .D(\rdata_reg[25]_i_1_n_0 ),
        .Q(s_axi_csrs_rdata[25]),
        .R(\rdata[31]_i_1_n_0 ));
  MUXF7 \rdata_reg[25]_i_1 
       (.I0(\rdata[25]_i_2_n_0 ),
        .I1(\rdata[25]_i_3_n_0 ),
        .O(\rdata_reg[25]_i_1_n_0 ),
        .S(\rdata[31]_i_4_n_0 ));
  FDRE \rdata_reg[26] 
       (.C(aclk),
        .CE(ar_hs),
        .D(\rdata_reg[26]_i_1_n_0 ),
        .Q(s_axi_csrs_rdata[26]),
        .R(\rdata[31]_i_1_n_0 ));
  MUXF7 \rdata_reg[26]_i_1 
       (.I0(\rdata[26]_i_2_n_0 ),
        .I1(\rdata[26]_i_3_n_0 ),
        .O(\rdata_reg[26]_i_1_n_0 ),
        .S(\rdata[31]_i_4_n_0 ));
  FDRE \rdata_reg[27] 
       (.C(aclk),
        .CE(ar_hs),
        .D(\rdata_reg[27]_i_1_n_0 ),
        .Q(s_axi_csrs_rdata[27]),
        .R(\rdata[31]_i_1_n_0 ));
  MUXF7 \rdata_reg[27]_i_1 
       (.I0(\rdata[27]_i_2_n_0 ),
        .I1(\rdata[27]_i_3_n_0 ),
        .O(\rdata_reg[27]_i_1_n_0 ),
        .S(\rdata[31]_i_4_n_0 ));
  FDRE \rdata_reg[28] 
       (.C(aclk),
        .CE(ar_hs),
        .D(\rdata_reg[28]_i_1_n_0 ),
        .Q(s_axi_csrs_rdata[28]),
        .R(\rdata[31]_i_1_n_0 ));
  MUXF7 \rdata_reg[28]_i_1 
       (.I0(\rdata[28]_i_2_n_0 ),
        .I1(\rdata[28]_i_3_n_0 ),
        .O(\rdata_reg[28]_i_1_n_0 ),
        .S(\rdata[31]_i_4_n_0 ));
  FDRE \rdata_reg[29] 
       (.C(aclk),
        .CE(ar_hs),
        .D(\rdata_reg[29]_i_1_n_0 ),
        .Q(s_axi_csrs_rdata[29]),
        .R(\rdata[31]_i_1_n_0 ));
  MUXF7 \rdata_reg[29]_i_1 
       (.I0(\rdata[29]_i_2_n_0 ),
        .I1(\rdata[29]_i_3_n_0 ),
        .O(\rdata_reg[29]_i_1_n_0 ),
        .S(\rdata[31]_i_4_n_0 ));
  FDRE \rdata_reg[2] 
       (.C(aclk),
        .CE(ar_hs),
        .D(\rdata_reg[2]_i_1_n_0 ),
        .Q(s_axi_csrs_rdata[2]),
        .R(\rdata[31]_i_1_n_0 ));
  MUXF7 \rdata_reg[2]_i_1 
       (.I0(\rdata[2]_i_2_n_0 ),
        .I1(\rdata[2]_i_3_n_0 ),
        .O(\rdata_reg[2]_i_1_n_0 ),
        .S(\rdata[31]_i_4_n_0 ));
  FDRE \rdata_reg[30] 
       (.C(aclk),
        .CE(ar_hs),
        .D(\rdata_reg[30]_i_1_n_0 ),
        .Q(s_axi_csrs_rdata[30]),
        .R(\rdata[31]_i_1_n_0 ));
  MUXF7 \rdata_reg[30]_i_1 
       (.I0(\rdata[30]_i_2_n_0 ),
        .I1(\rdata[30]_i_3_n_0 ),
        .O(\rdata_reg[30]_i_1_n_0 ),
        .S(\rdata[31]_i_4_n_0 ));
  FDRE \rdata_reg[31] 
       (.C(aclk),
        .CE(ar_hs),
        .D(\rdata_reg[31]_i_3_n_0 ),
        .Q(s_axi_csrs_rdata[31]),
        .R(\rdata[31]_i_1_n_0 ));
  MUXF7 \rdata_reg[31]_i_3 
       (.I0(\rdata[31]_i_5_n_0 ),
        .I1(\rdata[31]_i_6_n_0 ),
        .O(\rdata_reg[31]_i_3_n_0 ),
        .S(\rdata[31]_i_4_n_0 ));
  FDRE \rdata_reg[3] 
       (.C(aclk),
        .CE(ar_hs),
        .D(\rdata_reg[3]_i_1_n_0 ),
        .Q(s_axi_csrs_rdata[3]),
        .R(\rdata[31]_i_1_n_0 ));
  MUXF7 \rdata_reg[3]_i_1 
       (.I0(\rdata[3]_i_2_n_0 ),
        .I1(\rdata[3]_i_3_n_0 ),
        .O(\rdata_reg[3]_i_1_n_0 ),
        .S(\rdata[31]_i_4_n_0 ));
  FDRE \rdata_reg[4] 
       (.C(aclk),
        .CE(ar_hs),
        .D(\rdata_reg[4]_i_1_n_0 ),
        .Q(s_axi_csrs_rdata[4]),
        .R(\rdata[31]_i_1_n_0 ));
  MUXF7 \rdata_reg[4]_i_1 
       (.I0(\rdata[4]_i_2_n_0 ),
        .I1(\rdata[4]_i_3_n_0 ),
        .O(\rdata_reg[4]_i_1_n_0 ),
        .S(\rdata[31]_i_4_n_0 ));
  FDRE \rdata_reg[5] 
       (.C(aclk),
        .CE(ar_hs),
        .D(\rdata_reg[5]_i_1_n_0 ),
        .Q(s_axi_csrs_rdata[5]),
        .R(\rdata[31]_i_1_n_0 ));
  MUXF7 \rdata_reg[5]_i_1 
       (.I0(\rdata[5]_i_2_n_0 ),
        .I1(\rdata[5]_i_3_n_0 ),
        .O(\rdata_reg[5]_i_1_n_0 ),
        .S(\rdata[31]_i_4_n_0 ));
  FDRE \rdata_reg[6] 
       (.C(aclk),
        .CE(ar_hs),
        .D(\rdata_reg[6]_i_1_n_0 ),
        .Q(s_axi_csrs_rdata[6]),
        .R(\rdata[31]_i_1_n_0 ));
  MUXF7 \rdata_reg[6]_i_1 
       (.I0(\rdata[6]_i_2_n_0 ),
        .I1(\rdata[6]_i_3_n_0 ),
        .O(\rdata_reg[6]_i_1_n_0 ),
        .S(\rdata[31]_i_4_n_0 ));
  FDRE \rdata_reg[7] 
       (.C(aclk),
        .CE(ar_hs),
        .D(\rdata_reg[7]_i_1_n_0 ),
        .Q(s_axi_csrs_rdata[7]),
        .R(\rdata[31]_i_1_n_0 ));
  MUXF7 \rdata_reg[7]_i_1 
       (.I0(\rdata[7]_i_2_n_0 ),
        .I1(\rdata[7]_i_3_n_0 ),
        .O(\rdata_reg[7]_i_1_n_0 ),
        .S(\rdata[31]_i_4_n_0 ));
  FDRE \rdata_reg[8] 
       (.C(aclk),
        .CE(ar_hs),
        .D(\rdata_reg[8]_i_1_n_0 ),
        .Q(s_axi_csrs_rdata[8]),
        .R(\rdata[31]_i_1_n_0 ));
  MUXF7 \rdata_reg[8]_i_1 
       (.I0(\rdata[8]_i_2_n_0 ),
        .I1(\rdata[8]_i_3_n_0 ),
        .O(\rdata_reg[8]_i_1_n_0 ),
        .S(\rdata[31]_i_4_n_0 ));
  FDRE \rdata_reg[9] 
       (.C(aclk),
        .CE(ar_hs),
        .D(\rdata_reg[9]_i_1_n_0 ),
        .Q(s_axi_csrs_rdata[9]),
        .R(\rdata[31]_i_1_n_0 ));
  MUXF7 \rdata_reg[9]_i_1 
       (.I0(\rdata[9]_i_2_n_0 ),
        .I1(\rdata[9]_i_3_n_0 ),
        .O(\rdata_reg[9]_i_1_n_0 ),
        .S(\rdata[31]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'hFFD9FFFB)) 
    \rstate[0]_i_1 
       (.I0(rstate[0]),
        .I1(rstate[1]),
        .I2(s_axi_csrs_rready),
        .I3(wstate[3]),
        .I4(s_axi_csrs_arvalid),
        .O(rnext[0]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h00000838)) 
    \rstate[1]_i_1 
       (.I0(s_axi_csrs_arvalid),
        .I1(rstate[0]),
        .I2(rstate[1]),
        .I3(s_axi_csrs_rready),
        .I4(wstate[3]),
        .O(rnext[1]));
  (* FSM_ENCODED_STATES = "RDDATA:010,RDIDLE:001,iSTATE:100" *) 
  FDRE #(
    .INIT(1'b0)) 
    \rstate_reg[0] 
       (.C(aclk),
        .CE(1'b1),
        .D(rnext[0]),
        .Q(rstate[0]),
        .R(dma_error_set_i_1_n_0));
  (* FSM_ENCODED_STATES = "RDDATA:010,RDIDLE:001,iSTATE:100" *) 
  FDRE #(
    .INIT(1'b0)) 
    \rstate_reg[1] 
       (.C(aclk),
        .CE(1'b1),
        .D(rnext[1]),
        .Q(rstate[1]),
        .R(dma_error_set_i_1_n_0));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'h02)) 
    s_axi_csrs_arready_INST_0
       (.I0(rstate[0]),
        .I1(wstate[3]),
        .I2(rstate[1]),
        .O(s_axi_csrs_arready));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'h0010)) 
    s_axi_csrs_awready_INST_0
       (.I0(wstate[3]),
        .I1(wstate[2]),
        .I2(wstate[0]),
        .I3(wstate[1]),
        .O(s_axi_csrs_awready));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'h0010)) 
    s_axi_csrs_bvalid_INST_0
       (.I0(wstate[3]),
        .I1(wstate[0]),
        .I2(wstate[2]),
        .I3(wstate[1]),
        .O(s_axi_csrs_bvalid));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'h02)) 
    s_axi_csrs_rvalid_INST_0
       (.I0(rstate[1]),
        .I1(wstate[3]),
        .I2(rstate[0]),
        .O(s_axi_csrs_rvalid));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'h0010)) 
    s_axi_csrs_wready_INST_0
       (.I0(wstate[3]),
        .I1(wstate[2]),
        .I2(wstate[1]),
        .I3(wstate[0]),
        .O(s_axi_csrs_wready));
  LUT5 #(
    .INIT(32'hAAAEFFFF)) 
    \state[0]_i_1 
       (.I0(\state[0]_i_2_n_0 ),
        .I1(state[0]),
        .I2(dma_c2f_start),
        .I3(dma_f2c_start),
        .I4(next_state_n_0),
        .O(\state[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'hF888)) 
    \state[0]_i_2 
       (.I0(m_axi_dma_bvalid),
        .I1(state[3]),
        .I2(m_axi_dma_rvalid),
        .I3(state[5]),
        .O(\state[0]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hAA080808)) 
    \state[1]_i_1 
       (.I0(next_state_n_0),
        .I1(state[1]),
        .I2(m_axi_dma_awready),
        .I3(state[0]),
        .I4(dma_f2c_start),
        .O(next_state__0[1]));
  LUT5 #(
    .INIT(32'hAA080808)) 
    \state[2]_i_1 
       (.I0(next_state_n_0),
        .I1(state[2]),
        .I2(m_axi_dma_wready),
        .I3(state[1]),
        .I4(m_axi_dma_awready),
        .O(next_state__0[2]));
  LUT5 #(
    .INIT(32'hAA080808)) 
    \state[3]_i_1 
       (.I0(next_state_n_0),
        .I1(state[3]),
        .I2(m_axi_dma_bvalid),
        .I3(state[2]),
        .I4(m_axi_dma_wready),
        .O(next_state__0[3]));
  LUT6 #(
    .INIT(64'h0808AA0808080808)) 
    \state[4]_i_1 
       (.I0(next_state_n_0),
        .I1(state[4]),
        .I2(m_axi_dma_arready),
        .I3(state[0]),
        .I4(dma_f2c_start),
        .I5(dma_c2f_start),
        .O(next_state__0[4]));
  LUT5 #(
    .INIT(32'hAA080808)) 
    \state[5]_i_1 
       (.I0(next_state_n_0),
        .I1(state[5]),
        .I2(m_axi_dma_rvalid),
        .I3(state[4]),
        .I4(m_axi_dma_arready),
        .O(next_state__0[5]));
  (* FSM_ENCODED_STATES = "S_WR:000010,S_WRDATA:000100,S_WRRESP:001000,S_RD:010000,S_RDDATA:100000,S_IDLE:000001" *) 
  FDSE #(
    .INIT(1'b1)) 
    \state_reg[0] 
       (.C(aclk),
        .CE(1'b1),
        .D(\state[0]_i_1_n_0 ),
        .Q(state[0]),
        .S(dma_error_set_i_1_n_0));
  (* FSM_ENCODED_STATES = "S_WR:000010,S_WRDATA:000100,S_WRRESP:001000,S_RD:010000,S_RDDATA:100000,S_IDLE:000001" *) 
  FDRE #(
    .INIT(1'b0)) 
    \state_reg[1] 
       (.C(aclk),
        .CE(1'b1),
        .D(next_state__0[1]),
        .Q(state[1]),
        .R(dma_error_set_i_1_n_0));
  (* FSM_ENCODED_STATES = "S_WR:000010,S_WRDATA:000100,S_WRRESP:001000,S_RD:010000,S_RDDATA:100000,S_IDLE:000001" *) 
  FDRE #(
    .INIT(1'b0)) 
    \state_reg[2] 
       (.C(aclk),
        .CE(1'b1),
        .D(next_state__0[2]),
        .Q(state[2]),
        .R(dma_error_set_i_1_n_0));
  (* FSM_ENCODED_STATES = "S_WR:000010,S_WRDATA:000100,S_WRRESP:001000,S_RD:010000,S_RDDATA:100000,S_IDLE:000001" *) 
  FDRE #(
    .INIT(1'b0)) 
    \state_reg[3] 
       (.C(aclk),
        .CE(1'b1),
        .D(next_state__0[3]),
        .Q(state[3]),
        .R(dma_error_set_i_1_n_0));
  (* FSM_ENCODED_STATES = "S_WR:000010,S_WRDATA:000100,S_WRRESP:001000,S_RD:010000,S_RDDATA:100000,S_IDLE:000001" *) 
  FDRE #(
    .INIT(1'b0)) 
    \state_reg[4] 
       (.C(aclk),
        .CE(1'b1),
        .D(next_state__0[4]),
        .Q(state[4]),
        .R(dma_error_set_i_1_n_0));
  (* FSM_ENCODED_STATES = "S_WR:000010,S_WRDATA:000100,S_WRRESP:001000,S_RD:010000,S_RDDATA:100000,S_IDLE:000001" *) 
  FDRE #(
    .INIT(1'b0)) 
    \state_reg[5] 
       (.C(aclk),
        .CE(1'b1),
        .D(next_state__0[5]),
        .Q(state[5]),
        .R(dma_error_set_i_1_n_0));
  LUT5 #(
    .INIT(32'h00000020)) 
    \waddr[4]_i_1 
       (.I0(s_axi_csrs_awvalid),
        .I1(wstate[1]),
        .I2(wstate[0]),
        .I3(wstate[2]),
        .I4(wstate[3]),
        .O(aw_hs));
  FDRE \waddr_reg[0] 
       (.C(aclk),
        .CE(aw_hs),
        .D(s_axi_csrs_awaddr[0]),
        .Q(waddr[0]),
        .R(1'b0));
  FDRE \waddr_reg[1] 
       (.C(aclk),
        .CE(aw_hs),
        .D(s_axi_csrs_awaddr[1]),
        .Q(waddr[1]),
        .R(1'b0));
  FDRE \waddr_reg[2] 
       (.C(aclk),
        .CE(aw_hs),
        .D(s_axi_csrs_awaddr[2]),
        .Q(waddr[2]),
        .R(1'b0));
  FDRE \waddr_reg[3] 
       (.C(aclk),
        .CE(aw_hs),
        .D(s_axi_csrs_awaddr[3]),
        .Q(waddr[3]),
        .R(1'b0));
  FDRE \waddr_reg[4] 
       (.C(aclk),
        .CE(aw_hs),
        .D(s_axi_csrs_awaddr[4]),
        .Q(waddr[4]),
        .R(1'b0));
  LUT6 #(
    .INIT(64'hFFFAFFFFFAEFFAEF)) 
    \wstate[0]_i_1 
       (.I0(wstate[3]),
        .I1(s_axi_csrs_bready),
        .I2(wstate[2]),
        .I3(wstate[1]),
        .I4(s_axi_csrs_awvalid),
        .I5(wstate[0]),
        .O(wnext[0]));
  LUT6 #(
    .INIT(64'h0000000000003404)) 
    \wstate[1]_i_1 
       (.I0(s_axi_csrs_wvalid),
        .I1(wstate[1]),
        .I2(wstate[0]),
        .I3(s_axi_csrs_awvalid),
        .I4(wstate[3]),
        .I5(wstate[2]),
        .O(\wstate[1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0005001000000010)) 
    \wstate[2]_i_1 
       (.I0(wstate[0]),
        .I1(s_axi_csrs_bready),
        .I2(wstate[2]),
        .I3(wstate[3]),
        .I4(wstate[1]),
        .I5(s_axi_csrs_wvalid),
        .O(wnext[2]));
  (* FSM_ENCODED_STATES = "WRDATA:0010,WRRESP:0100,WRIDLE:0001,iSTATE:1000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \wstate_reg[0] 
       (.C(aclk),
        .CE(1'b1),
        .D(wnext[0]),
        .Q(wstate[0]),
        .R(dma_error_set_i_1_n_0));
  (* FSM_ENCODED_STATES = "WRDATA:0010,WRRESP:0100,WRIDLE:0001,iSTATE:1000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \wstate_reg[1] 
       (.C(aclk),
        .CE(1'b1),
        .D(\wstate[1]_i_1_n_0 ),
        .Q(wstate[1]),
        .R(dma_error_set_i_1_n_0));
  (* FSM_ENCODED_STATES = "WRDATA:0010,WRRESP:0100,WRIDLE:0001,iSTATE:1000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \wstate_reg[2] 
       (.C(aclk),
        .CE(1'b1),
        .D(wnext[2]),
        .Q(wstate[2]),
        .R(dma_error_set_i_1_n_0));
  (* FSM_ENCODED_STATES = "WRDATA:0010,WRRESP:0100,WRIDLE:0001,iSTATE:1000" *) 
  FDSE #(
    .INIT(1'b1)) 
    \wstate_reg[3] 
       (.C(aclk),
        .CE(1'b1),
        .D(1'b0),
        .Q(wstate[3]),
        .S(dma_error_set_i_1_n_0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
