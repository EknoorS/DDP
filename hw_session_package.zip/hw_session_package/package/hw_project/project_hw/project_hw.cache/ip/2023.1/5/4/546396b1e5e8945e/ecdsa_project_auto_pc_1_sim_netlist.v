// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2023.1 (lin64) Build 3865809 Sun May  7 15:04:56 MDT 2023
// Date        : Wed Nov 25 15:00:41 2026
// Host        : pc-klas1-14.esat.kuleuven.be running 64-bit Rocky Linux 9.9 (Blue Onyx)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ ecdsa_project_auto_pc_1_sim_netlist.v
// Design      : ecdsa_project_auto_pc_1
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_axi_data_fifo_v2_1_27_axic_fifo
   (dout,
    empty,
    SR,
    aresetn_0,
    m_axi_awvalid,
    length_counter_1_reg_1_sp_1,
    empty_fwft_i_reg,
    m_axi_wvalid,
    S_AXI_AREADY_I_reg,
    \areset_d_reg[1] ,
    aclk,
    m_axi_awlen,
    rd_en,
    aresetn,
    m_axi_awvalid_0,
    command_ongoing,
    m_axi_awready,
    length_counter_1_reg,
    first_mi_word,
    s_axi_wvalid,
    m_axi_wready,
    E,
    s_axi_awvalid,
    Q);
  output [3:0]dout;
  output empty;
  output [0:0]SR;
  output aresetn_0;
  output m_axi_awvalid;
  output length_counter_1_reg_1_sp_1;
  output empty_fwft_i_reg;
  output m_axi_wvalid;
  output S_AXI_AREADY_I_reg;
  output \areset_d_reg[1] ;
  input aclk;
  input [3:0]m_axi_awlen;
  input rd_en;
  input aresetn;
  input m_axi_awvalid_0;
  input command_ongoing;
  input m_axi_awready;
  input [1:0]length_counter_1_reg;
  input first_mi_word;
  input s_axi_wvalid;
  input m_axi_wready;
  input [0:0]E;
  input s_axi_awvalid;
  input [1:0]Q;

  wire [0:0]E;
  wire [1:0]Q;
  wire [0:0]SR;
  wire S_AXI_AREADY_I_reg;
  wire aclk;
  wire \areset_d_reg[1] ;
  wire aresetn;
  wire aresetn_0;
  wire command_ongoing;
  wire [3:0]dout;
  wire empty;
  wire empty_fwft_i_reg;
  wire first_mi_word;
  wire [1:0]length_counter_1_reg;
  wire length_counter_1_reg_1_sn_1;
  wire [3:0]m_axi_awlen;
  wire m_axi_awready;
  wire m_axi_awvalid;
  wire m_axi_awvalid_0;
  wire m_axi_wready;
  wire m_axi_wvalid;
  wire rd_en;
  wire s_axi_awvalid;
  wire s_axi_wvalid;

  assign length_counter_1_reg_1_sp_1 = length_counter_1_reg_1_sn_1;
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_axi_data_fifo_v2_1_27_fifo_gen inst
       (.E(E),
        .Q(Q),
        .SR(SR),
        .S_AXI_AREADY_I_reg(S_AXI_AREADY_I_reg),
        .aclk(aclk),
        .\areset_d_reg[1] (\areset_d_reg[1] ),
        .aresetn(aresetn),
        .aresetn_0(aresetn_0),
        .command_ongoing(command_ongoing),
        .dout(dout),
        .empty(empty),
        .empty_fwft_i_reg(empty_fwft_i_reg),
        .first_mi_word(first_mi_word),
        .length_counter_1_reg(length_counter_1_reg),
        .length_counter_1_reg_1_sp_1(length_counter_1_reg_1_sn_1),
        .m_axi_awlen(m_axi_awlen),
        .m_axi_awready(m_axi_awready),
        .m_axi_awvalid(m_axi_awvalid),
        .m_axi_awvalid_0(m_axi_awvalid_0),
        .m_axi_wready(m_axi_wready),
        .m_axi_wvalid(m_axi_wvalid),
        .rd_en(rd_en),
        .s_axi_awvalid(s_axi_awvalid),
        .s_axi_wvalid(s_axi_wvalid));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_axi_data_fifo_v2_1_27_fifo_gen
   (dout,
    empty,
    SR,
    aresetn_0,
    m_axi_awvalid,
    length_counter_1_reg_1_sp_1,
    empty_fwft_i_reg,
    m_axi_wvalid,
    S_AXI_AREADY_I_reg,
    \areset_d_reg[1] ,
    aclk,
    m_axi_awlen,
    rd_en,
    aresetn,
    m_axi_awvalid_0,
    command_ongoing,
    m_axi_awready,
    length_counter_1_reg,
    first_mi_word,
    s_axi_wvalid,
    m_axi_wready,
    E,
    s_axi_awvalid,
    Q);
  output [3:0]dout;
  output empty;
  output [0:0]SR;
  output aresetn_0;
  output m_axi_awvalid;
  output length_counter_1_reg_1_sp_1;
  output empty_fwft_i_reg;
  output m_axi_wvalid;
  output S_AXI_AREADY_I_reg;
  output \areset_d_reg[1] ;
  input aclk;
  input [3:0]m_axi_awlen;
  input rd_en;
  input aresetn;
  input m_axi_awvalid_0;
  input command_ongoing;
  input m_axi_awready;
  input [1:0]length_counter_1_reg;
  input first_mi_word;
  input s_axi_wvalid;
  input m_axi_wready;
  input [0:0]E;
  input s_axi_awvalid;
  input [1:0]Q;

  wire [0:0]E;
  wire [1:0]Q;
  wire [0:0]SR;
  wire S_AXI_AREADY_I_i_3_n_0;
  wire S_AXI_AREADY_I_reg;
  wire aclk;
  wire \areset_d_reg[1] ;
  wire aresetn;
  wire aresetn_0;
  wire cmd_push;
  wire command_ongoing;
  wire command_ongoing_i_2_n_0;
  wire [3:0]dout;
  wire empty;
  wire empty_fwft_i_reg;
  wire first_mi_word;
  wire full;
  wire [1:0]length_counter_1_reg;
  wire length_counter_1_reg_1_sn_1;
  wire [3:0]m_axi_awlen;
  wire m_axi_awready;
  wire m_axi_awvalid;
  wire m_axi_awvalid_0;
  wire m_axi_wready;
  wire m_axi_wvalid;
  wire rd_en;
  wire s_axi_awvalid;
  wire s_axi_wvalid;
  wire NLW_fifo_gen_inst_almost_empty_UNCONNECTED;
  wire NLW_fifo_gen_inst_almost_full_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_ar_dbiterr_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_ar_overflow_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_ar_prog_empty_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_ar_prog_full_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_ar_sbiterr_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_ar_underflow_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_aw_dbiterr_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_aw_overflow_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_aw_prog_empty_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_aw_prog_full_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_aw_sbiterr_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_aw_underflow_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_b_dbiterr_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_b_overflow_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_b_prog_empty_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_b_prog_full_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_b_sbiterr_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_b_underflow_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_r_dbiterr_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_r_overflow_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_r_prog_empty_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_r_prog_full_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_r_sbiterr_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_r_underflow_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_w_dbiterr_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_w_overflow_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_w_prog_empty_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_w_prog_full_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_w_sbiterr_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_w_underflow_UNCONNECTED;
  wire NLW_fifo_gen_inst_axis_dbiterr_UNCONNECTED;
  wire NLW_fifo_gen_inst_axis_overflow_UNCONNECTED;
  wire NLW_fifo_gen_inst_axis_prog_empty_UNCONNECTED;
  wire NLW_fifo_gen_inst_axis_prog_full_UNCONNECTED;
  wire NLW_fifo_gen_inst_axis_sbiterr_UNCONNECTED;
  wire NLW_fifo_gen_inst_axis_underflow_UNCONNECTED;
  wire NLW_fifo_gen_inst_dbiterr_UNCONNECTED;
  wire NLW_fifo_gen_inst_m_axi_arvalid_UNCONNECTED;
  wire NLW_fifo_gen_inst_m_axi_awvalid_UNCONNECTED;
  wire NLW_fifo_gen_inst_m_axi_bready_UNCONNECTED;
  wire NLW_fifo_gen_inst_m_axi_rready_UNCONNECTED;
  wire NLW_fifo_gen_inst_m_axi_wlast_UNCONNECTED;
  wire NLW_fifo_gen_inst_m_axi_wvalid_UNCONNECTED;
  wire NLW_fifo_gen_inst_m_axis_tlast_UNCONNECTED;
  wire NLW_fifo_gen_inst_m_axis_tvalid_UNCONNECTED;
  wire NLW_fifo_gen_inst_overflow_UNCONNECTED;
  wire NLW_fifo_gen_inst_prog_empty_UNCONNECTED;
  wire NLW_fifo_gen_inst_prog_full_UNCONNECTED;
  wire NLW_fifo_gen_inst_rd_rst_busy_UNCONNECTED;
  wire NLW_fifo_gen_inst_s_axi_arready_UNCONNECTED;
  wire NLW_fifo_gen_inst_s_axi_awready_UNCONNECTED;
  wire NLW_fifo_gen_inst_s_axi_bvalid_UNCONNECTED;
  wire NLW_fifo_gen_inst_s_axi_rlast_UNCONNECTED;
  wire NLW_fifo_gen_inst_s_axi_rvalid_UNCONNECTED;
  wire NLW_fifo_gen_inst_s_axi_wready_UNCONNECTED;
  wire NLW_fifo_gen_inst_s_axis_tready_UNCONNECTED;
  wire NLW_fifo_gen_inst_sbiterr_UNCONNECTED;
  wire NLW_fifo_gen_inst_underflow_UNCONNECTED;
  wire NLW_fifo_gen_inst_valid_UNCONNECTED;
  wire NLW_fifo_gen_inst_wr_ack_UNCONNECTED;
  wire NLW_fifo_gen_inst_wr_rst_busy_UNCONNECTED;
  wire [4:0]NLW_fifo_gen_inst_axi_ar_data_count_UNCONNECTED;
  wire [4:0]NLW_fifo_gen_inst_axi_ar_rd_data_count_UNCONNECTED;
  wire [4:0]NLW_fifo_gen_inst_axi_ar_wr_data_count_UNCONNECTED;
  wire [4:0]NLW_fifo_gen_inst_axi_aw_data_count_UNCONNECTED;
  wire [4:0]NLW_fifo_gen_inst_axi_aw_rd_data_count_UNCONNECTED;
  wire [4:0]NLW_fifo_gen_inst_axi_aw_wr_data_count_UNCONNECTED;
  wire [4:0]NLW_fifo_gen_inst_axi_b_data_count_UNCONNECTED;
  wire [4:0]NLW_fifo_gen_inst_axi_b_rd_data_count_UNCONNECTED;
  wire [4:0]NLW_fifo_gen_inst_axi_b_wr_data_count_UNCONNECTED;
  wire [10:0]NLW_fifo_gen_inst_axi_r_data_count_UNCONNECTED;
  wire [10:0]NLW_fifo_gen_inst_axi_r_rd_data_count_UNCONNECTED;
  wire [10:0]NLW_fifo_gen_inst_axi_r_wr_data_count_UNCONNECTED;
  wire [10:0]NLW_fifo_gen_inst_axi_w_data_count_UNCONNECTED;
  wire [10:0]NLW_fifo_gen_inst_axi_w_rd_data_count_UNCONNECTED;
  wire [10:0]NLW_fifo_gen_inst_axi_w_wr_data_count_UNCONNECTED;
  wire [10:0]NLW_fifo_gen_inst_axis_data_count_UNCONNECTED;
  wire [10:0]NLW_fifo_gen_inst_axis_rd_data_count_UNCONNECTED;
  wire [10:0]NLW_fifo_gen_inst_axis_wr_data_count_UNCONNECTED;
  wire [5:0]NLW_fifo_gen_inst_data_count_UNCONNECTED;
  wire [4:4]NLW_fifo_gen_inst_dout_UNCONNECTED;
  wire [31:0]NLW_fifo_gen_inst_m_axi_araddr_UNCONNECTED;
  wire [1:0]NLW_fifo_gen_inst_m_axi_arburst_UNCONNECTED;
  wire [3:0]NLW_fifo_gen_inst_m_axi_arcache_UNCONNECTED;
  wire [3:0]NLW_fifo_gen_inst_m_axi_arid_UNCONNECTED;
  wire [7:0]NLW_fifo_gen_inst_m_axi_arlen_UNCONNECTED;
  wire [1:0]NLW_fifo_gen_inst_m_axi_arlock_UNCONNECTED;
  wire [2:0]NLW_fifo_gen_inst_m_axi_arprot_UNCONNECTED;
  wire [3:0]NLW_fifo_gen_inst_m_axi_arqos_UNCONNECTED;
  wire [3:0]NLW_fifo_gen_inst_m_axi_arregion_UNCONNECTED;
  wire [2:0]NLW_fifo_gen_inst_m_axi_arsize_UNCONNECTED;
  wire [0:0]NLW_fifo_gen_inst_m_axi_aruser_UNCONNECTED;
  wire [31:0]NLW_fifo_gen_inst_m_axi_awaddr_UNCONNECTED;
  wire [1:0]NLW_fifo_gen_inst_m_axi_awburst_UNCONNECTED;
  wire [3:0]NLW_fifo_gen_inst_m_axi_awcache_UNCONNECTED;
  wire [3:0]NLW_fifo_gen_inst_m_axi_awid_UNCONNECTED;
  wire [7:0]NLW_fifo_gen_inst_m_axi_awlen_UNCONNECTED;
  wire [1:0]NLW_fifo_gen_inst_m_axi_awlock_UNCONNECTED;
  wire [2:0]NLW_fifo_gen_inst_m_axi_awprot_UNCONNECTED;
  wire [3:0]NLW_fifo_gen_inst_m_axi_awqos_UNCONNECTED;
  wire [3:0]NLW_fifo_gen_inst_m_axi_awregion_UNCONNECTED;
  wire [2:0]NLW_fifo_gen_inst_m_axi_awsize_UNCONNECTED;
  wire [0:0]NLW_fifo_gen_inst_m_axi_awuser_UNCONNECTED;
  wire [63:0]NLW_fifo_gen_inst_m_axi_wdata_UNCONNECTED;
  wire [3:0]NLW_fifo_gen_inst_m_axi_wid_UNCONNECTED;
  wire [7:0]NLW_fifo_gen_inst_m_axi_wstrb_UNCONNECTED;
  wire [0:0]NLW_fifo_gen_inst_m_axi_wuser_UNCONNECTED;
  wire [63:0]NLW_fifo_gen_inst_m_axis_tdata_UNCONNECTED;
  wire [3:0]NLW_fifo_gen_inst_m_axis_tdest_UNCONNECTED;
  wire [7:0]NLW_fifo_gen_inst_m_axis_tid_UNCONNECTED;
  wire [3:0]NLW_fifo_gen_inst_m_axis_tkeep_UNCONNECTED;
  wire [3:0]NLW_fifo_gen_inst_m_axis_tstrb_UNCONNECTED;
  wire [3:0]NLW_fifo_gen_inst_m_axis_tuser_UNCONNECTED;
  wire [5:0]NLW_fifo_gen_inst_rd_data_count_UNCONNECTED;
  wire [3:0]NLW_fifo_gen_inst_s_axi_bid_UNCONNECTED;
  wire [1:0]NLW_fifo_gen_inst_s_axi_bresp_UNCONNECTED;
  wire [0:0]NLW_fifo_gen_inst_s_axi_buser_UNCONNECTED;
  wire [63:0]NLW_fifo_gen_inst_s_axi_rdata_UNCONNECTED;
  wire [3:0]NLW_fifo_gen_inst_s_axi_rid_UNCONNECTED;
  wire [1:0]NLW_fifo_gen_inst_s_axi_rresp_UNCONNECTED;
  wire [0:0]NLW_fifo_gen_inst_s_axi_ruser_UNCONNECTED;
  wire [5:0]NLW_fifo_gen_inst_wr_data_count_UNCONNECTED;

  assign length_counter_1_reg_1_sp_1 = length_counter_1_reg_1_sn_1;
  LUT1 #(
    .INIT(2'h1)) 
    S_AXI_AREADY_I_i_1
       (.I0(aresetn),
        .O(SR));
  LUT6 #(
    .INIT(64'h22722272FFFF2272)) 
    S_AXI_AREADY_I_i_2
       (.I0(E),
        .I1(s_axi_awvalid),
        .I2(m_axi_awready),
        .I3(S_AXI_AREADY_I_i_3_n_0),
        .I4(Q[1]),
        .I5(Q[0]),
        .O(S_AXI_AREADY_I_reg));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'h4F)) 
    S_AXI_AREADY_I_i_3
       (.I0(m_axi_awvalid_0),
        .I1(full),
        .I2(command_ongoing),
        .O(S_AXI_AREADY_I_i_3_n_0));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT5 #(
    .INIT(32'h00888A88)) 
    cmd_push_block_i_1
       (.I0(aresetn),
        .I1(m_axi_awvalid_0),
        .I2(full),
        .I3(command_ongoing),
        .I4(m_axi_awready),
        .O(aresetn_0));
  LUT6 #(
    .INIT(64'hF222FFFFD000D000)) 
    command_ongoing_i_1
       (.I0(Q[1]),
        .I1(Q[0]),
        .I2(E),
        .I3(s_axi_awvalid),
        .I4(command_ongoing_i_2_n_0),
        .I5(command_ongoing),
        .O(\areset_d_reg[1] ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT4 #(
    .INIT(16'h8808)) 
    command_ongoing_i_2
       (.I0(m_axi_awready),
        .I1(command_ongoing),
        .I2(full),
        .I3(m_axi_awvalid_0),
        .O(command_ongoing_i_2_n_0));
  (* C_ADD_NGC_CONSTRAINT = "0" *) 
  (* C_APPLICATION_TYPE_AXIS = "0" *) 
  (* C_APPLICATION_TYPE_RACH = "0" *) 
  (* C_APPLICATION_TYPE_RDCH = "0" *) 
  (* C_APPLICATION_TYPE_WACH = "0" *) 
  (* C_APPLICATION_TYPE_WDCH = "0" *) 
  (* C_APPLICATION_TYPE_WRCH = "0" *) 
  (* C_AXIS_TDATA_WIDTH = "64" *) 
  (* C_AXIS_TDEST_WIDTH = "4" *) 
  (* C_AXIS_TID_WIDTH = "8" *) 
  (* C_AXIS_TKEEP_WIDTH = "4" *) 
  (* C_AXIS_TSTRB_WIDTH = "4" *) 
  (* C_AXIS_TUSER_WIDTH = "4" *) 
  (* C_AXIS_TYPE = "0" *) 
  (* C_AXI_ADDR_WIDTH = "32" *) 
  (* C_AXI_ARUSER_WIDTH = "1" *) 
  (* C_AXI_AWUSER_WIDTH = "1" *) 
  (* C_AXI_BUSER_WIDTH = "1" *) 
  (* C_AXI_DATA_WIDTH = "64" *) 
  (* C_AXI_ID_WIDTH = "4" *) 
  (* C_AXI_LEN_WIDTH = "8" *) 
  (* C_AXI_LOCK_WIDTH = "2" *) 
  (* C_AXI_RUSER_WIDTH = "1" *) 
  (* C_AXI_TYPE = "0" *) 
  (* C_AXI_WUSER_WIDTH = "1" *) 
  (* C_COMMON_CLOCK = "1" *) 
  (* C_COUNT_TYPE = "0" *) 
  (* C_DATA_COUNT_WIDTH = "6" *) 
  (* C_DEFAULT_VALUE = "BlankString" *) 
  (* C_DIN_WIDTH = "5" *) 
  (* C_DIN_WIDTH_AXIS = "1" *) 
  (* C_DIN_WIDTH_RACH = "32" *) 
  (* C_DIN_WIDTH_RDCH = "64" *) 
  (* C_DIN_WIDTH_WACH = "32" *) 
  (* C_DIN_WIDTH_WDCH = "64" *) 
  (* C_DIN_WIDTH_WRCH = "2" *) 
  (* C_DOUT_RST_VAL = "0" *) 
  (* C_DOUT_WIDTH = "5" *) 
  (* C_ENABLE_RLOCS = "0" *) 
  (* C_ENABLE_RST_SYNC = "1" *) 
  (* C_EN_SAFETY_CKT = "0" *) 
  (* C_ERROR_INJECTION_TYPE = "0" *) 
  (* C_ERROR_INJECTION_TYPE_AXIS = "0" *) 
  (* C_ERROR_INJECTION_TYPE_RACH = "0" *) 
  (* C_ERROR_INJECTION_TYPE_RDCH = "0" *) 
  (* C_ERROR_INJECTION_TYPE_WACH = "0" *) 
  (* C_ERROR_INJECTION_TYPE_WDCH = "0" *) 
  (* C_ERROR_INJECTION_TYPE_WRCH = "0" *) 
  (* C_FAMILY = "zynq" *) 
  (* C_FULL_FLAGS_RST_VAL = "0" *) 
  (* C_HAS_ALMOST_EMPTY = "0" *) 
  (* C_HAS_ALMOST_FULL = "0" *) 
  (* C_HAS_AXIS_TDATA = "0" *) 
  (* C_HAS_AXIS_TDEST = "0" *) 
  (* C_HAS_AXIS_TID = "0" *) 
  (* C_HAS_AXIS_TKEEP = "0" *) 
  (* C_HAS_AXIS_TLAST = "0" *) 
  (* C_HAS_AXIS_TREADY = "1" *) 
  (* C_HAS_AXIS_TSTRB = "0" *) 
  (* C_HAS_AXIS_TUSER = "0" *) 
  (* C_HAS_AXI_ARUSER = "0" *) 
  (* C_HAS_AXI_AWUSER = "0" *) 
  (* C_HAS_AXI_BUSER = "0" *) 
  (* C_HAS_AXI_ID = "0" *) 
  (* C_HAS_AXI_RD_CHANNEL = "0" *) 
  (* C_HAS_AXI_RUSER = "0" *) 
  (* C_HAS_AXI_WR_CHANNEL = "0" *) 
  (* C_HAS_AXI_WUSER = "0" *) 
  (* C_HAS_BACKUP = "0" *) 
  (* C_HAS_DATA_COUNT = "0" *) 
  (* C_HAS_DATA_COUNTS_AXIS = "0" *) 
  (* C_HAS_DATA_COUNTS_RACH = "0" *) 
  (* C_HAS_DATA_COUNTS_RDCH = "0" *) 
  (* C_HAS_DATA_COUNTS_WACH = "0" *) 
  (* C_HAS_DATA_COUNTS_WDCH = "0" *) 
  (* C_HAS_DATA_COUNTS_WRCH = "0" *) 
  (* C_HAS_INT_CLK = "0" *) 
  (* C_HAS_MASTER_CE = "0" *) 
  (* C_HAS_MEMINIT_FILE = "0" *) 
  (* C_HAS_OVERFLOW = "0" *) 
  (* C_HAS_PROG_FLAGS_AXIS = "0" *) 
  (* C_HAS_PROG_FLAGS_RACH = "0" *) 
  (* C_HAS_PROG_FLAGS_RDCH = "0" *) 
  (* C_HAS_PROG_FLAGS_WACH = "0" *) 
  (* C_HAS_PROG_FLAGS_WDCH = "0" *) 
  (* C_HAS_PROG_FLAGS_WRCH = "0" *) 
  (* C_HAS_RD_DATA_COUNT = "0" *) 
  (* C_HAS_RD_RST = "0" *) 
  (* C_HAS_RST = "1" *) 
  (* C_HAS_SLAVE_CE = "0" *) 
  (* C_HAS_SRST = "0" *) 
  (* C_HAS_UNDERFLOW = "0" *) 
  (* C_HAS_VALID = "0" *) 
  (* C_HAS_WR_ACK = "0" *) 
  (* C_HAS_WR_DATA_COUNT = "0" *) 
  (* C_HAS_WR_RST = "0" *) 
  (* C_IMPLEMENTATION_TYPE = "0" *) 
  (* C_IMPLEMENTATION_TYPE_AXIS = "1" *) 
  (* C_IMPLEMENTATION_TYPE_RACH = "1" *) 
  (* C_IMPLEMENTATION_TYPE_RDCH = "1" *) 
  (* C_IMPLEMENTATION_TYPE_WACH = "1" *) 
  (* C_IMPLEMENTATION_TYPE_WDCH = "1" *) 
  (* C_IMPLEMENTATION_TYPE_WRCH = "1" *) 
  (* C_INIT_WR_PNTR_VAL = "0" *) 
  (* C_INTERFACE_TYPE = "0" *) 
  (* C_MEMORY_TYPE = "2" *) 
  (* C_MIF_FILE_NAME = "BlankString" *) 
  (* C_MSGON_VAL = "1" *) 
  (* C_OPTIMIZATION_MODE = "0" *) 
  (* C_OVERFLOW_LOW = "0" *) 
  (* C_POWER_SAVING_MODE = "0" *) 
  (* C_PRELOAD_LATENCY = "0" *) 
  (* C_PRELOAD_REGS = "1" *) 
  (* C_PRIM_FIFO_TYPE = "512x36" *) 
  (* C_PRIM_FIFO_TYPE_AXIS = "512x36" *) 
  (* C_PRIM_FIFO_TYPE_RACH = "512x36" *) 
  (* C_PRIM_FIFO_TYPE_RDCH = "512x36" *) 
  (* C_PRIM_FIFO_TYPE_WACH = "512x36" *) 
  (* C_PRIM_FIFO_TYPE_WDCH = "512x36" *) 
  (* C_PRIM_FIFO_TYPE_WRCH = "512x36" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL = "4" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_AXIS = "1022" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_RACH = "1022" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_RDCH = "1022" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_WACH = "1022" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_WDCH = "1022" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_WRCH = "1022" *) 
  (* C_PROG_EMPTY_THRESH_NEGATE_VAL = "5" *) 
  (* C_PROG_EMPTY_TYPE = "0" *) 
  (* C_PROG_EMPTY_TYPE_AXIS = "0" *) 
  (* C_PROG_EMPTY_TYPE_RACH = "0" *) 
  (* C_PROG_EMPTY_TYPE_RDCH = "0" *) 
  (* C_PROG_EMPTY_TYPE_WACH = "0" *) 
  (* C_PROG_EMPTY_TYPE_WDCH = "0" *) 
  (* C_PROG_EMPTY_TYPE_WRCH = "0" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL = "31" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_AXIS = "1023" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_RACH = "1023" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_RDCH = "1023" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_WACH = "1023" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_WDCH = "1023" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_WRCH = "1023" *) 
  (* C_PROG_FULL_THRESH_NEGATE_VAL = "30" *) 
  (* C_PROG_FULL_TYPE = "0" *) 
  (* C_PROG_FULL_TYPE_AXIS = "0" *) 
  (* C_PROG_FULL_TYPE_RACH = "0" *) 
  (* C_PROG_FULL_TYPE_RDCH = "0" *) 
  (* C_PROG_FULL_TYPE_WACH = "0" *) 
  (* C_PROG_FULL_TYPE_WDCH = "0" *) 
  (* C_PROG_FULL_TYPE_WRCH = "0" *) 
  (* C_RACH_TYPE = "0" *) 
  (* C_RDCH_TYPE = "0" *) 
  (* C_RD_DATA_COUNT_WIDTH = "6" *) 
  (* C_RD_DEPTH = "32" *) 
  (* C_RD_FREQ = "1" *) 
  (* C_RD_PNTR_WIDTH = "5" *) 
  (* C_REG_SLICE_MODE_AXIS = "0" *) 
  (* C_REG_SLICE_MODE_RACH = "0" *) 
  (* C_REG_SLICE_MODE_RDCH = "0" *) 
  (* C_REG_SLICE_MODE_WACH = "0" *) 
  (* C_REG_SLICE_MODE_WDCH = "0" *) 
  (* C_REG_SLICE_MODE_WRCH = "0" *) 
  (* C_SELECT_XPM = "0" *) 
  (* C_SYNCHRONIZER_STAGE = "3" *) 
  (* C_UNDERFLOW_LOW = "0" *) 
  (* C_USE_COMMON_OVERFLOW = "0" *) 
  (* C_USE_COMMON_UNDERFLOW = "0" *) 
  (* C_USE_DEFAULT_SETTINGS = "0" *) 
  (* C_USE_DOUT_RST = "0" *) 
  (* C_USE_ECC = "0" *) 
  (* C_USE_ECC_AXIS = "0" *) 
  (* C_USE_ECC_RACH = "0" *) 
  (* C_USE_ECC_RDCH = "0" *) 
  (* C_USE_ECC_WACH = "0" *) 
  (* C_USE_ECC_WDCH = "0" *) 
  (* C_USE_ECC_WRCH = "0" *) 
  (* C_USE_EMBEDDED_REG = "0" *) 
  (* C_USE_FIFO16_FLAGS = "0" *) 
  (* C_USE_FWFT_DATA_COUNT = "1" *) 
  (* C_USE_PIPELINE_REG = "0" *) 
  (* C_VALID_LOW = "0" *) 
  (* C_WACH_TYPE = "0" *) 
  (* C_WDCH_TYPE = "0" *) 
  (* C_WRCH_TYPE = "0" *) 
  (* C_WR_ACK_LOW = "0" *) 
  (* C_WR_DATA_COUNT_WIDTH = "6" *) 
  (* C_WR_DEPTH = "32" *) 
  (* C_WR_DEPTH_AXIS = "1024" *) 
  (* C_WR_DEPTH_RACH = "16" *) 
  (* C_WR_DEPTH_RDCH = "1024" *) 
  (* C_WR_DEPTH_WACH = "16" *) 
  (* C_WR_DEPTH_WDCH = "1024" *) 
  (* C_WR_DEPTH_WRCH = "16" *) 
  (* C_WR_FREQ = "1" *) 
  (* C_WR_PNTR_WIDTH = "5" *) 
  (* C_WR_PNTR_WIDTH_AXIS = "10" *) 
  (* C_WR_PNTR_WIDTH_RACH = "4" *) 
  (* C_WR_PNTR_WIDTH_RDCH = "10" *) 
  (* C_WR_PNTR_WIDTH_WACH = "4" *) 
  (* C_WR_PNTR_WIDTH_WDCH = "10" *) 
  (* C_WR_PNTR_WIDTH_WRCH = "4" *) 
  (* C_WR_RESPONSE_LATENCY = "1" *) 
  (* KEEP_HIERARCHY = "soft" *) 
  (* is_du_within_envelope = "true" *) 
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_fifo_generator_v13_2_8 fifo_gen_inst
       (.almost_empty(NLW_fifo_gen_inst_almost_empty_UNCONNECTED),
        .almost_full(NLW_fifo_gen_inst_almost_full_UNCONNECTED),
        .axi_ar_data_count(NLW_fifo_gen_inst_axi_ar_data_count_UNCONNECTED[4:0]),
        .axi_ar_dbiterr(NLW_fifo_gen_inst_axi_ar_dbiterr_UNCONNECTED),
        .axi_ar_injectdbiterr(1'b0),
        .axi_ar_injectsbiterr(1'b0),
        .axi_ar_overflow(NLW_fifo_gen_inst_axi_ar_overflow_UNCONNECTED),
        .axi_ar_prog_empty(NLW_fifo_gen_inst_axi_ar_prog_empty_UNCONNECTED),
        .axi_ar_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_ar_prog_full(NLW_fifo_gen_inst_axi_ar_prog_full_UNCONNECTED),
        .axi_ar_prog_full_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_ar_rd_data_count(NLW_fifo_gen_inst_axi_ar_rd_data_count_UNCONNECTED[4:0]),
        .axi_ar_sbiterr(NLW_fifo_gen_inst_axi_ar_sbiterr_UNCONNECTED),
        .axi_ar_underflow(NLW_fifo_gen_inst_axi_ar_underflow_UNCONNECTED),
        .axi_ar_wr_data_count(NLW_fifo_gen_inst_axi_ar_wr_data_count_UNCONNECTED[4:0]),
        .axi_aw_data_count(NLW_fifo_gen_inst_axi_aw_data_count_UNCONNECTED[4:0]),
        .axi_aw_dbiterr(NLW_fifo_gen_inst_axi_aw_dbiterr_UNCONNECTED),
        .axi_aw_injectdbiterr(1'b0),
        .axi_aw_injectsbiterr(1'b0),
        .axi_aw_overflow(NLW_fifo_gen_inst_axi_aw_overflow_UNCONNECTED),
        .axi_aw_prog_empty(NLW_fifo_gen_inst_axi_aw_prog_empty_UNCONNECTED),
        .axi_aw_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_aw_prog_full(NLW_fifo_gen_inst_axi_aw_prog_full_UNCONNECTED),
        .axi_aw_prog_full_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_aw_rd_data_count(NLW_fifo_gen_inst_axi_aw_rd_data_count_UNCONNECTED[4:0]),
        .axi_aw_sbiterr(NLW_fifo_gen_inst_axi_aw_sbiterr_UNCONNECTED),
        .axi_aw_underflow(NLW_fifo_gen_inst_axi_aw_underflow_UNCONNECTED),
        .axi_aw_wr_data_count(NLW_fifo_gen_inst_axi_aw_wr_data_count_UNCONNECTED[4:0]),
        .axi_b_data_count(NLW_fifo_gen_inst_axi_b_data_count_UNCONNECTED[4:0]),
        .axi_b_dbiterr(NLW_fifo_gen_inst_axi_b_dbiterr_UNCONNECTED),
        .axi_b_injectdbiterr(1'b0),
        .axi_b_injectsbiterr(1'b0),
        .axi_b_overflow(NLW_fifo_gen_inst_axi_b_overflow_UNCONNECTED),
        .axi_b_prog_empty(NLW_fifo_gen_inst_axi_b_prog_empty_UNCONNECTED),
        .axi_b_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_b_prog_full(NLW_fifo_gen_inst_axi_b_prog_full_UNCONNECTED),
        .axi_b_prog_full_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_b_rd_data_count(NLW_fifo_gen_inst_axi_b_rd_data_count_UNCONNECTED[4:0]),
        .axi_b_sbiterr(NLW_fifo_gen_inst_axi_b_sbiterr_UNCONNECTED),
        .axi_b_underflow(NLW_fifo_gen_inst_axi_b_underflow_UNCONNECTED),
        .axi_b_wr_data_count(NLW_fifo_gen_inst_axi_b_wr_data_count_UNCONNECTED[4:0]),
        .axi_r_data_count(NLW_fifo_gen_inst_axi_r_data_count_UNCONNECTED[10:0]),
        .axi_r_dbiterr(NLW_fifo_gen_inst_axi_r_dbiterr_UNCONNECTED),
        .axi_r_injectdbiterr(1'b0),
        .axi_r_injectsbiterr(1'b0),
        .axi_r_overflow(NLW_fifo_gen_inst_axi_r_overflow_UNCONNECTED),
        .axi_r_prog_empty(NLW_fifo_gen_inst_axi_r_prog_empty_UNCONNECTED),
        .axi_r_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axi_r_prog_full(NLW_fifo_gen_inst_axi_r_prog_full_UNCONNECTED),
        .axi_r_prog_full_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axi_r_rd_data_count(NLW_fifo_gen_inst_axi_r_rd_data_count_UNCONNECTED[10:0]),
        .axi_r_sbiterr(NLW_fifo_gen_inst_axi_r_sbiterr_UNCONNECTED),
        .axi_r_underflow(NLW_fifo_gen_inst_axi_r_underflow_UNCONNECTED),
        .axi_r_wr_data_count(NLW_fifo_gen_inst_axi_r_wr_data_count_UNCONNECTED[10:0]),
        .axi_w_data_count(NLW_fifo_gen_inst_axi_w_data_count_UNCONNECTED[10:0]),
        .axi_w_dbiterr(NLW_fifo_gen_inst_axi_w_dbiterr_UNCONNECTED),
        .axi_w_injectdbiterr(1'b0),
        .axi_w_injectsbiterr(1'b0),
        .axi_w_overflow(NLW_fifo_gen_inst_axi_w_overflow_UNCONNECTED),
        .axi_w_prog_empty(NLW_fifo_gen_inst_axi_w_prog_empty_UNCONNECTED),
        .axi_w_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axi_w_prog_full(NLW_fifo_gen_inst_axi_w_prog_full_UNCONNECTED),
        .axi_w_prog_full_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axi_w_rd_data_count(NLW_fifo_gen_inst_axi_w_rd_data_count_UNCONNECTED[10:0]),
        .axi_w_sbiterr(NLW_fifo_gen_inst_axi_w_sbiterr_UNCONNECTED),
        .axi_w_underflow(NLW_fifo_gen_inst_axi_w_underflow_UNCONNECTED),
        .axi_w_wr_data_count(NLW_fifo_gen_inst_axi_w_wr_data_count_UNCONNECTED[10:0]),
        .axis_data_count(NLW_fifo_gen_inst_axis_data_count_UNCONNECTED[10:0]),
        .axis_dbiterr(NLW_fifo_gen_inst_axis_dbiterr_UNCONNECTED),
        .axis_injectdbiterr(1'b0),
        .axis_injectsbiterr(1'b0),
        .axis_overflow(NLW_fifo_gen_inst_axis_overflow_UNCONNECTED),
        .axis_prog_empty(NLW_fifo_gen_inst_axis_prog_empty_UNCONNECTED),
        .axis_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axis_prog_full(NLW_fifo_gen_inst_axis_prog_full_UNCONNECTED),
        .axis_prog_full_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axis_rd_data_count(NLW_fifo_gen_inst_axis_rd_data_count_UNCONNECTED[10:0]),
        .axis_sbiterr(NLW_fifo_gen_inst_axis_sbiterr_UNCONNECTED),
        .axis_underflow(NLW_fifo_gen_inst_axis_underflow_UNCONNECTED),
        .axis_wr_data_count(NLW_fifo_gen_inst_axis_wr_data_count_UNCONNECTED[10:0]),
        .backup(1'b0),
        .backup_marker(1'b0),
        .clk(aclk),
        .data_count(NLW_fifo_gen_inst_data_count_UNCONNECTED[5:0]),
        .dbiterr(NLW_fifo_gen_inst_dbiterr_UNCONNECTED),
        .din({1'b0,m_axi_awlen}),
        .dout({NLW_fifo_gen_inst_dout_UNCONNECTED[4],dout}),
        .empty(empty),
        .full(full),
        .injectdbiterr(1'b0),
        .injectsbiterr(1'b0),
        .int_clk(1'b0),
        .m_aclk(1'b0),
        .m_aclk_en(1'b0),
        .m_axi_araddr(NLW_fifo_gen_inst_m_axi_araddr_UNCONNECTED[31:0]),
        .m_axi_arburst(NLW_fifo_gen_inst_m_axi_arburst_UNCONNECTED[1:0]),
        .m_axi_arcache(NLW_fifo_gen_inst_m_axi_arcache_UNCONNECTED[3:0]),
        .m_axi_arid(NLW_fifo_gen_inst_m_axi_arid_UNCONNECTED[3:0]),
        .m_axi_arlen(NLW_fifo_gen_inst_m_axi_arlen_UNCONNECTED[7:0]),
        .m_axi_arlock(NLW_fifo_gen_inst_m_axi_arlock_UNCONNECTED[1:0]),
        .m_axi_arprot(NLW_fifo_gen_inst_m_axi_arprot_UNCONNECTED[2:0]),
        .m_axi_arqos(NLW_fifo_gen_inst_m_axi_arqos_UNCONNECTED[3:0]),
        .m_axi_arready(1'b0),
        .m_axi_arregion(NLW_fifo_gen_inst_m_axi_arregion_UNCONNECTED[3:0]),
        .m_axi_arsize(NLW_fifo_gen_inst_m_axi_arsize_UNCONNECTED[2:0]),
        .m_axi_aruser(NLW_fifo_gen_inst_m_axi_aruser_UNCONNECTED[0]),
        .m_axi_arvalid(NLW_fifo_gen_inst_m_axi_arvalid_UNCONNECTED),
        .m_axi_awaddr(NLW_fifo_gen_inst_m_axi_awaddr_UNCONNECTED[31:0]),
        .m_axi_awburst(NLW_fifo_gen_inst_m_axi_awburst_UNCONNECTED[1:0]),
        .m_axi_awcache(NLW_fifo_gen_inst_m_axi_awcache_UNCONNECTED[3:0]),
        .m_axi_awid(NLW_fifo_gen_inst_m_axi_awid_UNCONNECTED[3:0]),
        .m_axi_awlen(NLW_fifo_gen_inst_m_axi_awlen_UNCONNECTED[7:0]),
        .m_axi_awlock(NLW_fifo_gen_inst_m_axi_awlock_UNCONNECTED[1:0]),
        .m_axi_awprot(NLW_fifo_gen_inst_m_axi_awprot_UNCONNECTED[2:0]),
        .m_axi_awqos(NLW_fifo_gen_inst_m_axi_awqos_UNCONNECTED[3:0]),
        .m_axi_awready(1'b0),
        .m_axi_awregion(NLW_fifo_gen_inst_m_axi_awregion_UNCONNECTED[3:0]),
        .m_axi_awsize(NLW_fifo_gen_inst_m_axi_awsize_UNCONNECTED[2:0]),
        .m_axi_awuser(NLW_fifo_gen_inst_m_axi_awuser_UNCONNECTED[0]),
        .m_axi_awvalid(NLW_fifo_gen_inst_m_axi_awvalid_UNCONNECTED),
        .m_axi_bid({1'b0,1'b0,1'b0,1'b0}),
        .m_axi_bready(NLW_fifo_gen_inst_m_axi_bready_UNCONNECTED),
        .m_axi_bresp({1'b0,1'b0}),
        .m_axi_buser(1'b0),
        .m_axi_bvalid(1'b0),
        .m_axi_rdata({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .m_axi_rid({1'b0,1'b0,1'b0,1'b0}),
        .m_axi_rlast(1'b0),
        .m_axi_rready(NLW_fifo_gen_inst_m_axi_rready_UNCONNECTED),
        .m_axi_rresp({1'b0,1'b0}),
        .m_axi_ruser(1'b0),
        .m_axi_rvalid(1'b0),
        .m_axi_wdata(NLW_fifo_gen_inst_m_axi_wdata_UNCONNECTED[63:0]),
        .m_axi_wid(NLW_fifo_gen_inst_m_axi_wid_UNCONNECTED[3:0]),
        .m_axi_wlast(NLW_fifo_gen_inst_m_axi_wlast_UNCONNECTED),
        .m_axi_wready(1'b0),
        .m_axi_wstrb(NLW_fifo_gen_inst_m_axi_wstrb_UNCONNECTED[7:0]),
        .m_axi_wuser(NLW_fifo_gen_inst_m_axi_wuser_UNCONNECTED[0]),
        .m_axi_wvalid(NLW_fifo_gen_inst_m_axi_wvalid_UNCONNECTED),
        .m_axis_tdata(NLW_fifo_gen_inst_m_axis_tdata_UNCONNECTED[63:0]),
        .m_axis_tdest(NLW_fifo_gen_inst_m_axis_tdest_UNCONNECTED[3:0]),
        .m_axis_tid(NLW_fifo_gen_inst_m_axis_tid_UNCONNECTED[7:0]),
        .m_axis_tkeep(NLW_fifo_gen_inst_m_axis_tkeep_UNCONNECTED[3:0]),
        .m_axis_tlast(NLW_fifo_gen_inst_m_axis_tlast_UNCONNECTED),
        .m_axis_tready(1'b0),
        .m_axis_tstrb(NLW_fifo_gen_inst_m_axis_tstrb_UNCONNECTED[3:0]),
        .m_axis_tuser(NLW_fifo_gen_inst_m_axis_tuser_UNCONNECTED[3:0]),
        .m_axis_tvalid(NLW_fifo_gen_inst_m_axis_tvalid_UNCONNECTED),
        .overflow(NLW_fifo_gen_inst_overflow_UNCONNECTED),
        .prog_empty(NLW_fifo_gen_inst_prog_empty_UNCONNECTED),
        .prog_empty_thresh({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .prog_empty_thresh_assert({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .prog_empty_thresh_negate({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .prog_full(NLW_fifo_gen_inst_prog_full_UNCONNECTED),
        .prog_full_thresh({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .prog_full_thresh_assert({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .prog_full_thresh_negate({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .rd_clk(1'b0),
        .rd_data_count(NLW_fifo_gen_inst_rd_data_count_UNCONNECTED[5:0]),
        .rd_en(rd_en),
        .rd_rst(1'b0),
        .rd_rst_busy(NLW_fifo_gen_inst_rd_rst_busy_UNCONNECTED),
        .rst(SR),
        .s_aclk(1'b0),
        .s_aclk_en(1'b0),
        .s_aresetn(1'b0),
        .s_axi_araddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arburst({1'b0,1'b0}),
        .s_axi_arcache({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arid({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arlock({1'b0,1'b0}),
        .s_axi_arprot({1'b0,1'b0,1'b0}),
        .s_axi_arqos({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arready(NLW_fifo_gen_inst_s_axi_arready_UNCONNECTED),
        .s_axi_arregion({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arsize({1'b0,1'b0,1'b0}),
        .s_axi_aruser(1'b0),
        .s_axi_arvalid(1'b0),
        .s_axi_awaddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awburst({1'b0,1'b0}),
        .s_axi_awcache({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awid({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awlock({1'b0,1'b0}),
        .s_axi_awprot({1'b0,1'b0,1'b0}),
        .s_axi_awqos({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awready(NLW_fifo_gen_inst_s_axi_awready_UNCONNECTED),
        .s_axi_awregion({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awsize({1'b0,1'b0,1'b0}),
        .s_axi_awuser(1'b0),
        .s_axi_awvalid(1'b0),
        .s_axi_bid(NLW_fifo_gen_inst_s_axi_bid_UNCONNECTED[3:0]),
        .s_axi_bready(1'b0),
        .s_axi_bresp(NLW_fifo_gen_inst_s_axi_bresp_UNCONNECTED[1:0]),
        .s_axi_buser(NLW_fifo_gen_inst_s_axi_buser_UNCONNECTED[0]),
        .s_axi_bvalid(NLW_fifo_gen_inst_s_axi_bvalid_UNCONNECTED),
        .s_axi_rdata(NLW_fifo_gen_inst_s_axi_rdata_UNCONNECTED[63:0]),
        .s_axi_rid(NLW_fifo_gen_inst_s_axi_rid_UNCONNECTED[3:0]),
        .s_axi_rlast(NLW_fifo_gen_inst_s_axi_rlast_UNCONNECTED),
        .s_axi_rready(1'b0),
        .s_axi_rresp(NLW_fifo_gen_inst_s_axi_rresp_UNCONNECTED[1:0]),
        .s_axi_ruser(NLW_fifo_gen_inst_s_axi_ruser_UNCONNECTED[0]),
        .s_axi_rvalid(NLW_fifo_gen_inst_s_axi_rvalid_UNCONNECTED),
        .s_axi_wdata({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_wid({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_wlast(1'b0),
        .s_axi_wready(NLW_fifo_gen_inst_s_axi_wready_UNCONNECTED),
        .s_axi_wstrb({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_wuser(1'b0),
        .s_axi_wvalid(1'b0),
        .s_axis_tdata({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axis_tdest({1'b0,1'b0,1'b0,1'b0}),
        .s_axis_tid({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axis_tkeep({1'b0,1'b0,1'b0,1'b0}),
        .s_axis_tlast(1'b0),
        .s_axis_tready(NLW_fifo_gen_inst_s_axis_tready_UNCONNECTED),
        .s_axis_tstrb({1'b0,1'b0,1'b0,1'b0}),
        .s_axis_tuser({1'b0,1'b0,1'b0,1'b0}),
        .s_axis_tvalid(1'b0),
        .sbiterr(NLW_fifo_gen_inst_sbiterr_UNCONNECTED),
        .sleep(1'b0),
        .srst(1'b0),
        .underflow(NLW_fifo_gen_inst_underflow_UNCONNECTED),
        .valid(NLW_fifo_gen_inst_valid_UNCONNECTED),
        .wr_ack(NLW_fifo_gen_inst_wr_ack_UNCONNECTED),
        .wr_clk(1'b0),
        .wr_data_count(NLW_fifo_gen_inst_wr_data_count_UNCONNECTED[5:0]),
        .wr_en(cmd_push),
        .wr_rst(1'b0),
        .wr_rst_busy(NLW_fifo_gen_inst_wr_rst_busy_UNCONNECTED));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'h02)) 
    fifo_gen_inst_i_1
       (.I0(command_ongoing),
        .I1(full),
        .I2(m_axi_awvalid_0),
        .O(cmd_push));
  LUT6 #(
    .INIT(64'hE4E4CC664E4ECC66)) 
    \length_counter_1[1]_i_1 
       (.I0(empty_fwft_i_reg),
        .I1(length_counter_1_reg[1]),
        .I2(dout[1]),
        .I3(length_counter_1_reg[0]),
        .I4(first_mi_word),
        .I5(dout[0]),
        .O(length_counter_1_reg_1_sn_1));
  LUT3 #(
    .INIT(8'hA2)) 
    m_axi_awvalid_INST_0
       (.I0(command_ongoing),
        .I1(full),
        .I2(m_axi_awvalid_0),
        .O(m_axi_awvalid));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT2 #(
    .INIT(4'h2)) 
    m_axi_wvalid_INST_0
       (.I0(s_axi_wvalid),
        .I1(empty),
        .O(m_axi_wvalid));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'h40)) 
    s_axi_wready_INST_0
       (.I0(empty),
        .I1(s_axi_wvalid),
        .I2(m_axi_wready),
        .O(empty_fwft_i_reg));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_axi_protocol_converter_v2_1_28_a_axi3_conv
   (dout,
    empty,
    SR,
    m_axi_awlen,
    m_axi_awlock,
    E,
    m_axi_awvalid,
    length_counter_1_reg_1_sp_1,
    empty_fwft_i_reg,
    m_axi_wvalid,
    m_axi_awaddr,
    m_axi_awsize,
    m_axi_awburst,
    m_axi_awcache,
    m_axi_awprot,
    m_axi_awqos,
    aclk,
    rd_en,
    s_axi_awlock,
    aresetn,
    m_axi_awready,
    length_counter_1_reg,
    first_mi_word,
    s_axi_wvalid,
    m_axi_wready,
    s_axi_awvalid,
    s_axi_awaddr,
    s_axi_awlen,
    s_axi_awsize,
    s_axi_awburst,
    s_axi_awcache,
    s_axi_awprot,
    s_axi_awqos);
  output [3:0]dout;
  output empty;
  output [0:0]SR;
  output [3:0]m_axi_awlen;
  output [0:0]m_axi_awlock;
  output [0:0]E;
  output m_axi_awvalid;
  output length_counter_1_reg_1_sp_1;
  output empty_fwft_i_reg;
  output m_axi_wvalid;
  output [31:0]m_axi_awaddr;
  output [2:0]m_axi_awsize;
  output [1:0]m_axi_awburst;
  output [3:0]m_axi_awcache;
  output [2:0]m_axi_awprot;
  output [3:0]m_axi_awqos;
  input aclk;
  input rd_en;
  input [0:0]s_axi_awlock;
  input aresetn;
  input m_axi_awready;
  input [1:0]length_counter_1_reg;
  input first_mi_word;
  input s_axi_wvalid;
  input m_axi_wready;
  input s_axi_awvalid;
  input [31:0]s_axi_awaddr;
  input [3:0]s_axi_awlen;
  input [2:0]s_axi_awsize;
  input [1:0]s_axi_awburst;
  input [3:0]s_axi_awcache;
  input [2:0]s_axi_awprot;
  input [3:0]s_axi_awqos;

  wire [0:0]E;
  wire [0:0]SR;
  wire \USE_BURSTS.cmd_queue_n_11 ;
  wire \USE_BURSTS.cmd_queue_n_12 ;
  wire \USE_BURSTS.cmd_queue_n_6 ;
  wire aclk;
  wire [1:0]areset_d;
  wire aresetn;
  wire cmd_push_block_reg_n_0;
  wire command_ongoing;
  wire [3:0]dout;
  wire empty;
  wire empty_fwft_i_reg;
  wire first_mi_word;
  wire [1:0]length_counter_1_reg;
  wire length_counter_1_reg_1_sn_1;
  wire [31:0]m_axi_awaddr;
  wire [1:0]m_axi_awburst;
  wire [3:0]m_axi_awcache;
  wire [3:0]m_axi_awlen;
  wire [0:0]m_axi_awlock;
  wire [2:0]m_axi_awprot;
  wire [3:0]m_axi_awqos;
  wire m_axi_awready;
  wire [2:0]m_axi_awsize;
  wire m_axi_awvalid;
  wire m_axi_wready;
  wire m_axi_wvalid;
  wire rd_en;
  wire [31:0]s_axi_awaddr;
  wire [1:0]s_axi_awburst;
  wire [3:0]s_axi_awcache;
  wire [3:0]s_axi_awlen;
  wire [0:0]s_axi_awlock;
  wire [2:0]s_axi_awprot;
  wire [3:0]s_axi_awqos;
  wire [2:0]s_axi_awsize;
  wire s_axi_awvalid;
  wire s_axi_wvalid;

  assign length_counter_1_reg_1_sp_1 = length_counter_1_reg_1_sn_1;
  FDRE \S_AXI_AADDR_Q_reg[0] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[0]),
        .Q(m_axi_awaddr[0]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[10] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[10]),
        .Q(m_axi_awaddr[10]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[11] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[11]),
        .Q(m_axi_awaddr[11]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[12] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[12]),
        .Q(m_axi_awaddr[12]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[13] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[13]),
        .Q(m_axi_awaddr[13]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[14] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[14]),
        .Q(m_axi_awaddr[14]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[15] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[15]),
        .Q(m_axi_awaddr[15]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[16] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[16]),
        .Q(m_axi_awaddr[16]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[17] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[17]),
        .Q(m_axi_awaddr[17]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[18] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[18]),
        .Q(m_axi_awaddr[18]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[19] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[19]),
        .Q(m_axi_awaddr[19]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[1] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[1]),
        .Q(m_axi_awaddr[1]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[20] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[20]),
        .Q(m_axi_awaddr[20]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[21] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[21]),
        .Q(m_axi_awaddr[21]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[22] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[22]),
        .Q(m_axi_awaddr[22]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[23] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[23]),
        .Q(m_axi_awaddr[23]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[24] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[24]),
        .Q(m_axi_awaddr[24]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[25] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[25]),
        .Q(m_axi_awaddr[25]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[26] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[26]),
        .Q(m_axi_awaddr[26]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[27] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[27]),
        .Q(m_axi_awaddr[27]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[28] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[28]),
        .Q(m_axi_awaddr[28]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[29] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[29]),
        .Q(m_axi_awaddr[29]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[2] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[2]),
        .Q(m_axi_awaddr[2]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[30] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[30]),
        .Q(m_axi_awaddr[30]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[31] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[31]),
        .Q(m_axi_awaddr[31]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[3] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[3]),
        .Q(m_axi_awaddr[3]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[4] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[4]),
        .Q(m_axi_awaddr[4]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[5] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[5]),
        .Q(m_axi_awaddr[5]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[6] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[6]),
        .Q(m_axi_awaddr[6]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[7] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[7]),
        .Q(m_axi_awaddr[7]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[8] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[8]),
        .Q(m_axi_awaddr[8]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[9] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[9]),
        .Q(m_axi_awaddr[9]),
        .R(SR));
  FDRE \S_AXI_ABURST_Q_reg[0] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awburst[0]),
        .Q(m_axi_awburst[0]),
        .R(SR));
  FDRE \S_AXI_ABURST_Q_reg[1] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awburst[1]),
        .Q(m_axi_awburst[1]),
        .R(SR));
  FDRE \S_AXI_ACACHE_Q_reg[0] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awcache[0]),
        .Q(m_axi_awcache[0]),
        .R(SR));
  FDRE \S_AXI_ACACHE_Q_reg[1] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awcache[1]),
        .Q(m_axi_awcache[1]),
        .R(SR));
  FDRE \S_AXI_ACACHE_Q_reg[2] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awcache[2]),
        .Q(m_axi_awcache[2]),
        .R(SR));
  FDRE \S_AXI_ACACHE_Q_reg[3] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awcache[3]),
        .Q(m_axi_awcache[3]),
        .R(SR));
  FDRE \S_AXI_ALEN_Q_reg[0] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awlen[0]),
        .Q(m_axi_awlen[0]),
        .R(SR));
  FDRE \S_AXI_ALEN_Q_reg[1] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awlen[1]),
        .Q(m_axi_awlen[1]),
        .R(SR));
  FDRE \S_AXI_ALEN_Q_reg[2] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awlen[2]),
        .Q(m_axi_awlen[2]),
        .R(SR));
  FDRE \S_AXI_ALEN_Q_reg[3] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awlen[3]),
        .Q(m_axi_awlen[3]),
        .R(SR));
  FDRE \S_AXI_ALOCK_Q_reg[0] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awlock),
        .Q(m_axi_awlock),
        .R(SR));
  FDRE \S_AXI_APROT_Q_reg[0] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awprot[0]),
        .Q(m_axi_awprot[0]),
        .R(SR));
  FDRE \S_AXI_APROT_Q_reg[1] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awprot[1]),
        .Q(m_axi_awprot[1]),
        .R(SR));
  FDRE \S_AXI_APROT_Q_reg[2] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awprot[2]),
        .Q(m_axi_awprot[2]),
        .R(SR));
  FDRE \S_AXI_AQOS_Q_reg[0] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awqos[0]),
        .Q(m_axi_awqos[0]),
        .R(SR));
  FDRE \S_AXI_AQOS_Q_reg[1] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awqos[1]),
        .Q(m_axi_awqos[1]),
        .R(SR));
  FDRE \S_AXI_AQOS_Q_reg[2] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awqos[2]),
        .Q(m_axi_awqos[2]),
        .R(SR));
  FDRE \S_AXI_AQOS_Q_reg[3] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awqos[3]),
        .Q(m_axi_awqos[3]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    S_AXI_AREADY_I_reg
       (.C(aclk),
        .CE(1'b1),
        .D(\USE_BURSTS.cmd_queue_n_11 ),
        .Q(E),
        .R(SR));
  FDRE \S_AXI_ASIZE_Q_reg[0] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awsize[0]),
        .Q(m_axi_awsize[0]),
        .R(SR));
  FDRE \S_AXI_ASIZE_Q_reg[1] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awsize[1]),
        .Q(m_axi_awsize[1]),
        .R(SR));
  FDRE \S_AXI_ASIZE_Q_reg[2] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awsize[2]),
        .Q(m_axi_awsize[2]),
        .R(SR));
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_axi_data_fifo_v2_1_27_axic_fifo \USE_BURSTS.cmd_queue 
       (.E(E),
        .Q(areset_d),
        .SR(SR),
        .S_AXI_AREADY_I_reg(\USE_BURSTS.cmd_queue_n_11 ),
        .aclk(aclk),
        .\areset_d_reg[1] (\USE_BURSTS.cmd_queue_n_12 ),
        .aresetn(aresetn),
        .aresetn_0(\USE_BURSTS.cmd_queue_n_6 ),
        .command_ongoing(command_ongoing),
        .dout(dout),
        .empty(empty),
        .empty_fwft_i_reg(empty_fwft_i_reg),
        .first_mi_word(first_mi_word),
        .length_counter_1_reg(length_counter_1_reg),
        .length_counter_1_reg_1_sp_1(length_counter_1_reg_1_sn_1),
        .m_axi_awlen(m_axi_awlen),
        .m_axi_awready(m_axi_awready),
        .m_axi_awvalid(m_axi_awvalid),
        .m_axi_awvalid_0(cmd_push_block_reg_n_0),
        .m_axi_wready(m_axi_wready),
        .m_axi_wvalid(m_axi_wvalid),
        .rd_en(rd_en),
        .s_axi_awvalid(s_axi_awvalid),
        .s_axi_wvalid(s_axi_wvalid));
  FDRE #(
    .INIT(1'b0)) 
    \areset_d_reg[0] 
       (.C(aclk),
        .CE(1'b1),
        .D(SR),
        .Q(areset_d[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \areset_d_reg[1] 
       (.C(aclk),
        .CE(1'b1),
        .D(areset_d[0]),
        .Q(areset_d[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    cmd_push_block_reg
       (.C(aclk),
        .CE(1'b1),
        .D(\USE_BURSTS.cmd_queue_n_6 ),
        .Q(cmd_push_block_reg_n_0),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    command_ongoing_reg
       (.C(aclk),
        .CE(1'b1),
        .D(\USE_BURSTS.cmd_queue_n_12 ),
        .Q(command_ongoing),
        .R(SR));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_axi_protocol_converter_v2_1_28_axi3_conv
   (m_axi_awlen,
    m_axi_awaddr,
    E,
    m_axi_awsize,
    m_axi_awburst,
    m_axi_awlock,
    m_axi_awcache,
    m_axi_awprot,
    m_axi_awqos,
    m_axi_awvalid,
    empty_fwft_i_reg,
    m_axi_wvalid,
    m_axi_wlast,
    aresetn,
    m_axi_awready,
    aclk,
    s_axi_awaddr,
    s_axi_awlen,
    s_axi_awsize,
    s_axi_awburst,
    s_axi_awlock,
    s_axi_awcache,
    s_axi_awprot,
    s_axi_awqos,
    m_axi_wready,
    s_axi_wvalid,
    s_axi_awvalid);
  output [3:0]m_axi_awlen;
  output [31:0]m_axi_awaddr;
  output [0:0]E;
  output [2:0]m_axi_awsize;
  output [1:0]m_axi_awburst;
  output [0:0]m_axi_awlock;
  output [3:0]m_axi_awcache;
  output [2:0]m_axi_awprot;
  output [3:0]m_axi_awqos;
  output m_axi_awvalid;
  output empty_fwft_i_reg;
  output m_axi_wvalid;
  output m_axi_wlast;
  input aresetn;
  input m_axi_awready;
  input aclk;
  input [31:0]s_axi_awaddr;
  input [3:0]s_axi_awlen;
  input [2:0]s_axi_awsize;
  input [1:0]s_axi_awburst;
  input [0:0]s_axi_awlock;
  input [3:0]s_axi_awcache;
  input [2:0]s_axi_awprot;
  input [3:0]s_axi_awqos;
  input m_axi_wready;
  input s_axi_wvalid;
  input s_axi_awvalid;

  wire [0:0]E;
  wire \USE_BURSTS.cmd_queue/inst/empty ;
  wire [3:0]\USE_WRITE.wr_cmd_length ;
  wire \USE_WRITE.wr_cmd_ready ;
  wire \USE_WRITE.write_addr_inst_n_13 ;
  wire \USE_WRITE.write_addr_inst_n_5 ;
  wire aclk;
  wire aresetn;
  wire empty_fwft_i_reg;
  wire first_mi_word;
  wire [1:0]length_counter_1_reg;
  wire [31:0]m_axi_awaddr;
  wire [1:0]m_axi_awburst;
  wire [3:0]m_axi_awcache;
  wire [3:0]m_axi_awlen;
  wire [0:0]m_axi_awlock;
  wire [2:0]m_axi_awprot;
  wire [3:0]m_axi_awqos;
  wire m_axi_awready;
  wire [2:0]m_axi_awsize;
  wire m_axi_awvalid;
  wire m_axi_wlast;
  wire m_axi_wready;
  wire m_axi_wvalid;
  wire [31:0]s_axi_awaddr;
  wire [1:0]s_axi_awburst;
  wire [3:0]s_axi_awcache;
  wire [3:0]s_axi_awlen;
  wire [0:0]s_axi_awlock;
  wire [2:0]s_axi_awprot;
  wire [3:0]s_axi_awqos;
  wire [2:0]s_axi_awsize;
  wire s_axi_awvalid;
  wire s_axi_wvalid;

  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_axi_protocol_converter_v2_1_28_a_axi3_conv \USE_WRITE.write_addr_inst 
       (.E(E),
        .SR(\USE_WRITE.write_addr_inst_n_5 ),
        .aclk(aclk),
        .aresetn(aresetn),
        .dout(\USE_WRITE.wr_cmd_length ),
        .empty(\USE_BURSTS.cmd_queue/inst/empty ),
        .empty_fwft_i_reg(empty_fwft_i_reg),
        .first_mi_word(first_mi_word),
        .length_counter_1_reg(length_counter_1_reg),
        .length_counter_1_reg_1_sp_1(\USE_WRITE.write_addr_inst_n_13 ),
        .m_axi_awaddr(m_axi_awaddr),
        .m_axi_awburst(m_axi_awburst),
        .m_axi_awcache(m_axi_awcache),
        .m_axi_awlen(m_axi_awlen),
        .m_axi_awlock(m_axi_awlock),
        .m_axi_awprot(m_axi_awprot),
        .m_axi_awqos(m_axi_awqos),
        .m_axi_awready(m_axi_awready),
        .m_axi_awsize(m_axi_awsize),
        .m_axi_awvalid(m_axi_awvalid),
        .m_axi_wready(m_axi_wready),
        .m_axi_wvalid(m_axi_wvalid),
        .rd_en(\USE_WRITE.wr_cmd_ready ),
        .s_axi_awaddr(s_axi_awaddr),
        .s_axi_awburst(s_axi_awburst),
        .s_axi_awcache(s_axi_awcache),
        .s_axi_awlen(s_axi_awlen),
        .s_axi_awlock(s_axi_awlock),
        .s_axi_awprot(s_axi_awprot),
        .s_axi_awqos(s_axi_awqos),
        .s_axi_awsize(s_axi_awsize),
        .s_axi_awvalid(s_axi_awvalid),
        .s_axi_wvalid(s_axi_wvalid));
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_axi_protocol_converter_v2_1_28_w_axi3_conv \USE_WRITE.write_data_inst 
       (.SR(\USE_WRITE.write_addr_inst_n_5 ),
        .aclk(aclk),
        .dout(\USE_WRITE.wr_cmd_length ),
        .empty(\USE_BURSTS.cmd_queue/inst/empty ),
        .first_mi_word(first_mi_word),
        .\length_counter_1_reg[1]_0 (length_counter_1_reg),
        .\length_counter_1_reg[1]_1 (\USE_WRITE.write_addr_inst_n_13 ),
        .\length_counter_1_reg[2]_0 (empty_fwft_i_reg),
        .m_axi_wlast(m_axi_wlast),
        .m_axi_wready(m_axi_wready),
        .rd_en(\USE_WRITE.wr_cmd_ready ),
        .s_axi_wvalid(s_axi_wvalid));
endmodule

(* C_AXI_ADDR_WIDTH = "32" *) (* C_AXI_ARUSER_WIDTH = "1" *) (* C_AXI_AWUSER_WIDTH = "1" *) 
(* C_AXI_BUSER_WIDTH = "1" *) (* C_AXI_DATA_WIDTH = "64" *) (* C_AXI_ID_WIDTH = "1" *) 
(* C_AXI_RUSER_WIDTH = "1" *) (* C_AXI_SUPPORTS_READ = "1" *) (* C_AXI_SUPPORTS_USER_SIGNALS = "0" *) 
(* C_AXI_SUPPORTS_WRITE = "1" *) (* C_AXI_WUSER_WIDTH = "1" *) (* C_FAMILY = "zynq" *) 
(* C_IGNORE_ID = "1" *) (* C_M_AXI_PROTOCOL = "1" *) (* C_S_AXI_PROTOCOL = "0" *) 
(* C_TRANSLATION_MODE = "0" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* P_AXI3 = "1" *) 
(* P_AXI4 = "0" *) (* P_AXILITE = "2" *) (* P_AXILITE_SIZE = "3'b011" *) 
(* P_CONVERSION = "2" *) (* P_DECERR = "2'b11" *) (* P_INCR = "2'b01" *) 
(* P_PROTECTION = "1" *) (* P_SLVERR = "2'b10" *) 
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_axi_protocol_converter_v2_1_28_axi_protocol_converter
   (aclk,
    aresetn,
    s_axi_awid,
    s_axi_awaddr,
    s_axi_awlen,
    s_axi_awsize,
    s_axi_awburst,
    s_axi_awlock,
    s_axi_awcache,
    s_axi_awprot,
    s_axi_awregion,
    s_axi_awqos,
    s_axi_awuser,
    s_axi_awvalid,
    s_axi_awready,
    s_axi_wid,
    s_axi_wdata,
    s_axi_wstrb,
    s_axi_wlast,
    s_axi_wuser,
    s_axi_wvalid,
    s_axi_wready,
    s_axi_bid,
    s_axi_bresp,
    s_axi_buser,
    s_axi_bvalid,
    s_axi_bready,
    s_axi_arid,
    s_axi_araddr,
    s_axi_arlen,
    s_axi_arsize,
    s_axi_arburst,
    s_axi_arlock,
    s_axi_arcache,
    s_axi_arprot,
    s_axi_arregion,
    s_axi_arqos,
    s_axi_aruser,
    s_axi_arvalid,
    s_axi_arready,
    s_axi_rid,
    s_axi_rdata,
    s_axi_rresp,
    s_axi_rlast,
    s_axi_ruser,
    s_axi_rvalid,
    s_axi_rready,
    m_axi_awid,
    m_axi_awaddr,
    m_axi_awlen,
    m_axi_awsize,
    m_axi_awburst,
    m_axi_awlock,
    m_axi_awcache,
    m_axi_awprot,
    m_axi_awregion,
    m_axi_awqos,
    m_axi_awuser,
    m_axi_awvalid,
    m_axi_awready,
    m_axi_wid,
    m_axi_wdata,
    m_axi_wstrb,
    m_axi_wlast,
    m_axi_wuser,
    m_axi_wvalid,
    m_axi_wready,
    m_axi_bid,
    m_axi_bresp,
    m_axi_buser,
    m_axi_bvalid,
    m_axi_bready,
    m_axi_arid,
    m_axi_araddr,
    m_axi_arlen,
    m_axi_arsize,
    m_axi_arburst,
    m_axi_arlock,
    m_axi_arcache,
    m_axi_arprot,
    m_axi_arregion,
    m_axi_arqos,
    m_axi_aruser,
    m_axi_arvalid,
    m_axi_arready,
    m_axi_rid,
    m_axi_rdata,
    m_axi_rresp,
    m_axi_rlast,
    m_axi_ruser,
    m_axi_rvalid,
    m_axi_rready);
  input aclk;
  input aresetn;
  input [0:0]s_axi_awid;
  input [31:0]s_axi_awaddr;
  input [7:0]s_axi_awlen;
  input [2:0]s_axi_awsize;
  input [1:0]s_axi_awburst;
  input [0:0]s_axi_awlock;
  input [3:0]s_axi_awcache;
  input [2:0]s_axi_awprot;
  input [3:0]s_axi_awregion;
  input [3:0]s_axi_awqos;
  input [0:0]s_axi_awuser;
  input s_axi_awvalid;
  output s_axi_awready;
  input [0:0]s_axi_wid;
  input [63:0]s_axi_wdata;
  input [7:0]s_axi_wstrb;
  input s_axi_wlast;
  input [0:0]s_axi_wuser;
  input s_axi_wvalid;
  output s_axi_wready;
  output [0:0]s_axi_bid;
  output [1:0]s_axi_bresp;
  output [0:0]s_axi_buser;
  output s_axi_bvalid;
  input s_axi_bready;
  input [0:0]s_axi_arid;
  input [31:0]s_axi_araddr;
  input [7:0]s_axi_arlen;
  input [2:0]s_axi_arsize;
  input [1:0]s_axi_arburst;
  input [0:0]s_axi_arlock;
  input [3:0]s_axi_arcache;
  input [2:0]s_axi_arprot;
  input [3:0]s_axi_arregion;
  input [3:0]s_axi_arqos;
  input [0:0]s_axi_aruser;
  input s_axi_arvalid;
  output s_axi_arready;
  output [0:0]s_axi_rid;
  output [63:0]s_axi_rdata;
  output [1:0]s_axi_rresp;
  output s_axi_rlast;
  output [0:0]s_axi_ruser;
  output s_axi_rvalid;
  input s_axi_rready;
  output [0:0]m_axi_awid;
  output [31:0]m_axi_awaddr;
  output [3:0]m_axi_awlen;
  output [2:0]m_axi_awsize;
  output [1:0]m_axi_awburst;
  output [1:0]m_axi_awlock;
  output [3:0]m_axi_awcache;
  output [2:0]m_axi_awprot;
  output [3:0]m_axi_awregion;
  output [3:0]m_axi_awqos;
  output [0:0]m_axi_awuser;
  output m_axi_awvalid;
  input m_axi_awready;
  output [0:0]m_axi_wid;
  output [63:0]m_axi_wdata;
  output [7:0]m_axi_wstrb;
  output m_axi_wlast;
  output [0:0]m_axi_wuser;
  output m_axi_wvalid;
  input m_axi_wready;
  input [0:0]m_axi_bid;
  input [1:0]m_axi_bresp;
  input [0:0]m_axi_buser;
  input m_axi_bvalid;
  output m_axi_bready;
  output [0:0]m_axi_arid;
  output [31:0]m_axi_araddr;
  output [3:0]m_axi_arlen;
  output [2:0]m_axi_arsize;
  output [1:0]m_axi_arburst;
  output [1:0]m_axi_arlock;
  output [3:0]m_axi_arcache;
  output [2:0]m_axi_arprot;
  output [3:0]m_axi_arregion;
  output [3:0]m_axi_arqos;
  output [0:0]m_axi_aruser;
  output m_axi_arvalid;
  input m_axi_arready;
  input [0:0]m_axi_rid;
  input [63:0]m_axi_rdata;
  input [1:0]m_axi_rresp;
  input m_axi_rlast;
  input [0:0]m_axi_ruser;
  input m_axi_rvalid;
  output m_axi_rready;

  wire \<const0> ;
  wire aclk;
  wire aresetn;
  wire m_axi_arready;
  wire [31:0]m_axi_awaddr;
  wire [1:0]m_axi_awburst;
  wire [3:0]m_axi_awcache;
  wire [3:0]m_axi_awlen;
  wire [0:0]\^m_axi_awlock ;
  wire [2:0]m_axi_awprot;
  wire [3:0]m_axi_awqos;
  wire m_axi_awready;
  wire [2:0]m_axi_awsize;
  wire m_axi_awvalid;
  wire [1:0]m_axi_bresp;
  wire m_axi_bvalid;
  wire [63:0]m_axi_rdata;
  wire m_axi_rlast;
  wire [1:0]m_axi_rresp;
  wire m_axi_rvalid;
  wire m_axi_wlast;
  wire m_axi_wready;
  wire m_axi_wvalid;
  wire [31:0]s_axi_araddr;
  wire [1:0]s_axi_arburst;
  wire [3:0]s_axi_arcache;
  wire [7:0]s_axi_arlen;
  wire [0:0]s_axi_arlock;
  wire [2:0]s_axi_arprot;
  wire [3:0]s_axi_arqos;
  wire [2:0]s_axi_arsize;
  wire s_axi_arvalid;
  wire [31:0]s_axi_awaddr;
  wire [1:0]s_axi_awburst;
  wire [3:0]s_axi_awcache;
  wire [7:0]s_axi_awlen;
  wire [0:0]s_axi_awlock;
  wire [2:0]s_axi_awprot;
  wire [3:0]s_axi_awqos;
  wire s_axi_awready;
  wire [2:0]s_axi_awsize;
  wire s_axi_awvalid;
  wire s_axi_bready;
  wire s_axi_rready;
  wire [63:0]s_axi_wdata;
  wire s_axi_wready;
  wire [7:0]s_axi_wstrb;
  wire s_axi_wvalid;

  assign m_axi_araddr[31:0] = s_axi_araddr;
  assign m_axi_arburst[1:0] = s_axi_arburst;
  assign m_axi_arcache[3:0] = s_axi_arcache;
  assign m_axi_arid[0] = \<const0> ;
  assign m_axi_arlen[3:0] = s_axi_arlen[3:0];
  assign m_axi_arlock[1] = \<const0> ;
  assign m_axi_arlock[0] = s_axi_arlock;
  assign m_axi_arprot[2:0] = s_axi_arprot;
  assign m_axi_arqos[3:0] = s_axi_arqos;
  assign m_axi_arregion[3] = \<const0> ;
  assign m_axi_arregion[2] = \<const0> ;
  assign m_axi_arregion[1] = \<const0> ;
  assign m_axi_arregion[0] = \<const0> ;
  assign m_axi_arsize[2:0] = s_axi_arsize;
  assign m_axi_aruser[0] = \<const0> ;
  assign m_axi_arvalid = s_axi_arvalid;
  assign m_axi_awid[0] = \<const0> ;
  assign m_axi_awlock[1] = \<const0> ;
  assign m_axi_awlock[0] = \^m_axi_awlock [0];
  assign m_axi_awregion[3] = \<const0> ;
  assign m_axi_awregion[2] = \<const0> ;
  assign m_axi_awregion[1] = \<const0> ;
  assign m_axi_awregion[0] = \<const0> ;
  assign m_axi_awuser[0] = \<const0> ;
  assign m_axi_bready = s_axi_bready;
  assign m_axi_rready = s_axi_rready;
  assign m_axi_wdata[63:0] = s_axi_wdata;
  assign m_axi_wid[0] = \<const0> ;
  assign m_axi_wstrb[7:0] = s_axi_wstrb;
  assign m_axi_wuser[0] = \<const0> ;
  assign s_axi_arready = m_axi_arready;
  assign s_axi_bid[0] = \<const0> ;
  assign s_axi_bresp[1:0] = m_axi_bresp;
  assign s_axi_buser[0] = \<const0> ;
  assign s_axi_bvalid = m_axi_bvalid;
  assign s_axi_rdata[63:0] = m_axi_rdata;
  assign s_axi_rid[0] = \<const0> ;
  assign s_axi_rlast = m_axi_rlast;
  assign s_axi_rresp[1:0] = m_axi_rresp;
  assign s_axi_ruser[0] = \<const0> ;
  assign s_axi_rvalid = m_axi_rvalid;
  GND GND
       (.G(\<const0> ));
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_axi_protocol_converter_v2_1_28_axi3_conv \gen_axi4_axi3.axi3_conv_inst 
       (.E(s_axi_awready),
        .aclk(aclk),
        .aresetn(aresetn),
        .empty_fwft_i_reg(s_axi_wready),
        .m_axi_awaddr(m_axi_awaddr),
        .m_axi_awburst(m_axi_awburst),
        .m_axi_awcache(m_axi_awcache),
        .m_axi_awlen(m_axi_awlen),
        .m_axi_awlock(\^m_axi_awlock ),
        .m_axi_awprot(m_axi_awprot),
        .m_axi_awqos(m_axi_awqos),
        .m_axi_awready(m_axi_awready),
        .m_axi_awsize(m_axi_awsize),
        .m_axi_awvalid(m_axi_awvalid),
        .m_axi_wlast(m_axi_wlast),
        .m_axi_wready(m_axi_wready),
        .m_axi_wvalid(m_axi_wvalid),
        .s_axi_awaddr(s_axi_awaddr),
        .s_axi_awburst(s_axi_awburst),
        .s_axi_awcache(s_axi_awcache),
        .s_axi_awlen(s_axi_awlen[3:0]),
        .s_axi_awlock(s_axi_awlock),
        .s_axi_awprot(s_axi_awprot),
        .s_axi_awqos(s_axi_awqos),
        .s_axi_awsize(s_axi_awsize),
        .s_axi_awvalid(s_axi_awvalid),
        .s_axi_wvalid(s_axi_wvalid));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_axi_protocol_converter_v2_1_28_w_axi3_conv
   (\length_counter_1_reg[1]_0 ,
    first_mi_word,
    rd_en,
    m_axi_wlast,
    SR,
    aclk,
    \length_counter_1_reg[1]_1 ,
    \length_counter_1_reg[2]_0 ,
    m_axi_wready,
    s_axi_wvalid,
    empty,
    dout);
  output [1:0]\length_counter_1_reg[1]_0 ;
  output first_mi_word;
  output rd_en;
  output m_axi_wlast;
  input [0:0]SR;
  input aclk;
  input \length_counter_1_reg[1]_1 ;
  input \length_counter_1_reg[2]_0 ;
  input m_axi_wready;
  input s_axi_wvalid;
  input empty;
  input [3:0]dout;

  wire [0:0]SR;
  wire aclk;
  wire [3:0]dout;
  wire empty;
  wire first_mi_word;
  wire first_mi_word_i_1_n_0;
  wire \length_counter_1[0]_i_1_n_0 ;
  wire \length_counter_1[2]_i_1_n_0 ;
  wire \length_counter_1[3]_i_1_n_0 ;
  wire \length_counter_1[4]_i_1_n_0 ;
  wire \length_counter_1[4]_i_2_n_0 ;
  wire \length_counter_1[5]_i_1_n_0 ;
  wire \length_counter_1[6]_i_1_n_0 ;
  wire \length_counter_1[7]_i_1_n_0 ;
  wire [7:2]length_counter_1_reg;
  wire [1:0]\length_counter_1_reg[1]_0 ;
  wire \length_counter_1_reg[1]_1 ;
  wire \length_counter_1_reg[2]_0 ;
  wire m_axi_wlast;
  wire m_axi_wlast_INST_0_i_1_n_0;
  wire m_axi_wlast_INST_0_i_2_n_0;
  wire m_axi_wlast_INST_0_i_3_n_0;
  wire m_axi_wready;
  wire rd_en;
  wire s_axi_wvalid;

  LUT6 #(
    .INIT(64'h0000CC000000CC04)) 
    fifo_gen_inst_i_2
       (.I0(length_counter_1_reg[7]),
        .I1(\length_counter_1_reg[2]_0 ),
        .I2(length_counter_1_reg[5]),
        .I3(first_mi_word),
        .I4(m_axi_wlast_INST_0_i_1_n_0),
        .I5(length_counter_1_reg[6]),
        .O(rd_en));
  LUT6 #(
    .INIT(64'h0F0FFFFF00010000)) 
    first_mi_word_i_1
       (.I0(length_counter_1_reg[7]),
        .I1(length_counter_1_reg[5]),
        .I2(m_axi_wlast_INST_0_i_1_n_0),
        .I3(length_counter_1_reg[6]),
        .I4(\length_counter_1_reg[2]_0 ),
        .I5(first_mi_word),
        .O(first_mi_word_i_1_n_0));
  FDSE #(
    .INIT(1'b0)) 
    first_mi_word_reg
       (.C(aclk),
        .CE(1'b1),
        .D(first_mi_word_i_1_n_0),
        .Q(first_mi_word),
        .S(SR));
  LUT6 #(
    .INIT(64'hF2FFFFFF07000000)) 
    \length_counter_1[0]_i_1 
       (.I0(first_mi_word),
        .I1(dout[0]),
        .I2(empty),
        .I3(s_axi_wvalid),
        .I4(m_axi_wready),
        .I5(\length_counter_1_reg[1]_0 [0]),
        .O(\length_counter_1[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT5 #(
    .INIT(32'hD8D272D2)) 
    \length_counter_1[2]_i_1 
       (.I0(\length_counter_1_reg[2]_0 ),
        .I1(m_axi_wlast_INST_0_i_3_n_0),
        .I2(length_counter_1_reg[2]),
        .I3(first_mi_word),
        .I4(dout[2]),
        .O(\length_counter_1[2]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT5 #(
    .INIT(32'hB8B474B4)) 
    \length_counter_1[3]_i_1 
       (.I0(\length_counter_1[4]_i_2_n_0 ),
        .I1(\length_counter_1_reg[2]_0 ),
        .I2(length_counter_1_reg[3]),
        .I3(first_mi_word),
        .I4(dout[3]),
        .O(\length_counter_1[3]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0A0A3A35AAAAAAAA)) 
    \length_counter_1[4]_i_1 
       (.I0(length_counter_1_reg[4]),
        .I1(dout[3]),
        .I2(first_mi_word),
        .I3(length_counter_1_reg[3]),
        .I4(\length_counter_1[4]_i_2_n_0 ),
        .I5(\length_counter_1_reg[2]_0 ),
        .O(\length_counter_1[4]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT4 #(
    .INIT(16'hFEAE)) 
    \length_counter_1[4]_i_2 
       (.I0(m_axi_wlast_INST_0_i_3_n_0),
        .I1(length_counter_1_reg[2]),
        .I2(first_mi_word),
        .I3(dout[2]),
        .O(\length_counter_1[4]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hF7FF0000FFF70808)) 
    \length_counter_1[5]_i_1 
       (.I0(m_axi_wready),
        .I1(s_axi_wvalid),
        .I2(empty),
        .I3(first_mi_word),
        .I4(length_counter_1_reg[5]),
        .I5(m_axi_wlast_INST_0_i_1_n_0),
        .O(\length_counter_1[5]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h3EFF0D00)) 
    \length_counter_1[6]_i_1 
       (.I0(length_counter_1_reg[5]),
        .I1(first_mi_word),
        .I2(m_axi_wlast_INST_0_i_1_n_0),
        .I3(\length_counter_1_reg[2]_0 ),
        .I4(length_counter_1_reg[6]),
        .O(\length_counter_1[6]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h3F3EFFFF30310000)) 
    \length_counter_1[7]_i_1 
       (.I0(length_counter_1_reg[6]),
        .I1(m_axi_wlast_INST_0_i_1_n_0),
        .I2(first_mi_word),
        .I3(length_counter_1_reg[5]),
        .I4(\length_counter_1_reg[2]_0 ),
        .I5(length_counter_1_reg[7]),
        .O(\length_counter_1[7]_i_1_n_0 ));
  FDRE \length_counter_1_reg[0] 
       (.C(aclk),
        .CE(1'b1),
        .D(\length_counter_1[0]_i_1_n_0 ),
        .Q(\length_counter_1_reg[1]_0 [0]),
        .R(SR));
  FDRE \length_counter_1_reg[1] 
       (.C(aclk),
        .CE(1'b1),
        .D(\length_counter_1_reg[1]_1 ),
        .Q(\length_counter_1_reg[1]_0 [1]),
        .R(SR));
  FDRE \length_counter_1_reg[2] 
       (.C(aclk),
        .CE(1'b1),
        .D(\length_counter_1[2]_i_1_n_0 ),
        .Q(length_counter_1_reg[2]),
        .R(SR));
  FDRE \length_counter_1_reg[3] 
       (.C(aclk),
        .CE(1'b1),
        .D(\length_counter_1[3]_i_1_n_0 ),
        .Q(length_counter_1_reg[3]),
        .R(SR));
  FDRE \length_counter_1_reg[4] 
       (.C(aclk),
        .CE(1'b1),
        .D(\length_counter_1[4]_i_1_n_0 ),
        .Q(length_counter_1_reg[4]),
        .R(SR));
  FDRE \length_counter_1_reg[5] 
       (.C(aclk),
        .CE(1'b1),
        .D(\length_counter_1[5]_i_1_n_0 ),
        .Q(length_counter_1_reg[5]),
        .R(SR));
  FDRE \length_counter_1_reg[6] 
       (.C(aclk),
        .CE(1'b1),
        .D(\length_counter_1[6]_i_1_n_0 ),
        .Q(length_counter_1_reg[6]),
        .R(SR));
  FDRE \length_counter_1_reg[7] 
       (.C(aclk),
        .CE(1'b1),
        .D(\length_counter_1[7]_i_1_n_0 ),
        .Q(length_counter_1_reg[7]),
        .R(SR));
  LUT5 #(
    .INIT(32'h00F000F1)) 
    m_axi_wlast_INST_0
       (.I0(length_counter_1_reg[7]),
        .I1(length_counter_1_reg[5]),
        .I2(first_mi_word),
        .I3(m_axi_wlast_INST_0_i_1_n_0),
        .I4(length_counter_1_reg[6]),
        .O(m_axi_wlast));
  LUT6 #(
    .INIT(64'hFFFFFFFEFCFCFFFE)) 
    m_axi_wlast_INST_0_i_1
       (.I0(length_counter_1_reg[4]),
        .I1(m_axi_wlast_INST_0_i_2_n_0),
        .I2(m_axi_wlast_INST_0_i_3_n_0),
        .I3(length_counter_1_reg[2]),
        .I4(first_mi_word),
        .I5(dout[2]),
        .O(m_axi_wlast_INST_0_i_1_n_0));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    m_axi_wlast_INST_0_i_2
       (.I0(dout[3]),
        .I1(first_mi_word),
        .I2(length_counter_1_reg[3]),
        .O(m_axi_wlast_INST_0_i_2_n_0));
  LUT5 #(
    .INIT(32'hFFFACCFA)) 
    m_axi_wlast_INST_0_i_3
       (.I0(\length_counter_1_reg[1]_0 [1]),
        .I1(dout[1]),
        .I2(\length_counter_1_reg[1]_0 [0]),
        .I3(first_mi_word),
        .I4(dout[0]),
        .O(m_axi_wlast_INST_0_i_3_n_0));
endmodule

(* CHECK_LICENSE_TYPE = "ecdsa_project_auto_pc_1,axi_protocol_converter_v2_1_28_axi_protocol_converter,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* X_CORE_INFO = "axi_protocol_converter_v2_1_28_axi_protocol_converter,Vivado 2023.1" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (aclk,
    aresetn,
    s_axi_awaddr,
    s_axi_awlen,
    s_axi_awsize,
    s_axi_awburst,
    s_axi_awlock,
    s_axi_awcache,
    s_axi_awprot,
    s_axi_awregion,
    s_axi_awqos,
    s_axi_awvalid,
    s_axi_awready,
    s_axi_wdata,
    s_axi_wstrb,
    s_axi_wlast,
    s_axi_wvalid,
    s_axi_wready,
    s_axi_bresp,
    s_axi_bvalid,
    s_axi_bready,
    s_axi_araddr,
    s_axi_arlen,
    s_axi_arsize,
    s_axi_arburst,
    s_axi_arlock,
    s_axi_arcache,
    s_axi_arprot,
    s_axi_arregion,
    s_axi_arqos,
    s_axi_arvalid,
    s_axi_arready,
    s_axi_rdata,
    s_axi_rresp,
    s_axi_rlast,
    s_axi_rvalid,
    s_axi_rready,
    m_axi_awaddr,
    m_axi_awlen,
    m_axi_awsize,
    m_axi_awburst,
    m_axi_awlock,
    m_axi_awcache,
    m_axi_awprot,
    m_axi_awqos,
    m_axi_awvalid,
    m_axi_awready,
    m_axi_wdata,
    m_axi_wstrb,
    m_axi_wlast,
    m_axi_wvalid,
    m_axi_wready,
    m_axi_bresp,
    m_axi_bvalid,
    m_axi_bready,
    m_axi_araddr,
    m_axi_arlen,
    m_axi_arsize,
    m_axi_arburst,
    m_axi_arlock,
    m_axi_arcache,
    m_axi_arprot,
    m_axi_arqos,
    m_axi_arvalid,
    m_axi_arready,
    m_axi_rdata,
    m_axi_rresp,
    m_axi_rlast,
    m_axi_rvalid,
    m_axi_rready);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN ecdsa_project_processing_system7_0_0_FCLK_CLK0, ASSOCIATED_BUSIF S_AXI:M_AXI, ASSOCIATED_RESET ARESETN, INSERT_VIP 0" *) input aclk;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 RST RST" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME RST, POLARITY ACTIVE_LOW, INSERT_VIP 0, TYPE INTERCONNECT" *) input aresetn;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI AWADDR" *) input [31:0]s_axi_awaddr;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI AWLEN" *) input [7:0]s_axi_awlen;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI AWSIZE" *) input [2:0]s_axi_awsize;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI AWBURST" *) input [1:0]s_axi_awburst;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI AWLOCK" *) input [0:0]s_axi_awlock;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI AWCACHE" *) input [3:0]s_axi_awcache;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI AWPROT" *) input [2:0]s_axi_awprot;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI AWREGION" *) input [3:0]s_axi_awregion;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI AWQOS" *) input [3:0]s_axi_awqos;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI AWVALID" *) input s_axi_awvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI AWREADY" *) output s_axi_awready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI WDATA" *) input [63:0]s_axi_wdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI WSTRB" *) input [7:0]s_axi_wstrb;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI WLAST" *) input s_axi_wlast;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI WVALID" *) input s_axi_wvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI WREADY" *) output s_axi_wready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI BRESP" *) output [1:0]s_axi_bresp;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI BVALID" *) output s_axi_bvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI BREADY" *) input s_axi_bready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI ARADDR" *) input [31:0]s_axi_araddr;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI ARLEN" *) input [7:0]s_axi_arlen;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI ARSIZE" *) input [2:0]s_axi_arsize;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI ARBURST" *) input [1:0]s_axi_arburst;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI ARLOCK" *) input [0:0]s_axi_arlock;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI ARCACHE" *) input [3:0]s_axi_arcache;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI ARPROT" *) input [2:0]s_axi_arprot;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI ARREGION" *) input [3:0]s_axi_arregion;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI ARQOS" *) input [3:0]s_axi_arqos;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI ARVALID" *) input s_axi_arvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI ARREADY" *) output s_axi_arready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI RDATA" *) output [63:0]s_axi_rdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI RRESP" *) output [1:0]s_axi_rresp;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI RLAST" *) output s_axi_rlast;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI RVALID" *) output s_axi_rvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI RREADY" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME S_AXI, DATA_WIDTH 64, PROTOCOL AXI4, FREQ_HZ 100000000, ID_WIDTH 0, ADDR_WIDTH 32, AWUSER_WIDTH 0, ARUSER_WIDTH 0, WUSER_WIDTH 0, RUSER_WIDTH 0, BUSER_WIDTH 0, READ_WRITE_MODE READ_WRITE, HAS_BURST 1, HAS_LOCK 1, HAS_PROT 1, HAS_CACHE 1, HAS_QOS 1, HAS_REGION 1, HAS_WSTRB 1, HAS_BRESP 1, HAS_RRESP 1, SUPPORTS_NARROW_BURST 0, NUM_READ_OUTSTANDING 8, NUM_WRITE_OUTSTANDING 8, MAX_BURST_LENGTH 256, PHASE 0.0, CLK_DOMAIN ecdsa_project_processing_system7_0_0_FCLK_CLK0, NUM_READ_THREADS 1, NUM_WRITE_THREADS 1, RUSER_BITS_PER_BYTE 0, WUSER_BITS_PER_BYTE 0, INSERT_VIP 0" *) input s_axi_rready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI AWADDR" *) output [31:0]m_axi_awaddr;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI AWLEN" *) output [3:0]m_axi_awlen;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI AWSIZE" *) output [2:0]m_axi_awsize;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI AWBURST" *) output [1:0]m_axi_awburst;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI AWLOCK" *) output [1:0]m_axi_awlock;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI AWCACHE" *) output [3:0]m_axi_awcache;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI AWPROT" *) output [2:0]m_axi_awprot;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI AWQOS" *) output [3:0]m_axi_awqos;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI AWVALID" *) output m_axi_awvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI AWREADY" *) input m_axi_awready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI WDATA" *) output [63:0]m_axi_wdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI WSTRB" *) output [7:0]m_axi_wstrb;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI WLAST" *) output m_axi_wlast;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI WVALID" *) output m_axi_wvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI WREADY" *) input m_axi_wready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI BRESP" *) input [1:0]m_axi_bresp;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI BVALID" *) input m_axi_bvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI BREADY" *) output m_axi_bready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI ARADDR" *) output [31:0]m_axi_araddr;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI ARLEN" *) output [3:0]m_axi_arlen;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI ARSIZE" *) output [2:0]m_axi_arsize;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI ARBURST" *) output [1:0]m_axi_arburst;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI ARLOCK" *) output [1:0]m_axi_arlock;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI ARCACHE" *) output [3:0]m_axi_arcache;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI ARPROT" *) output [2:0]m_axi_arprot;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI ARQOS" *) output [3:0]m_axi_arqos;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI ARVALID" *) output m_axi_arvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI ARREADY" *) input m_axi_arready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI RDATA" *) input [63:0]m_axi_rdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI RRESP" *) input [1:0]m_axi_rresp;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI RLAST" *) input m_axi_rlast;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI RVALID" *) input m_axi_rvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI RREADY" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME M_AXI, DATA_WIDTH 64, PROTOCOL AXI3, FREQ_HZ 100000000, ID_WIDTH 0, ADDR_WIDTH 32, AWUSER_WIDTH 0, ARUSER_WIDTH 0, WUSER_WIDTH 0, RUSER_WIDTH 0, BUSER_WIDTH 0, READ_WRITE_MODE READ_WRITE, HAS_BURST 1, HAS_LOCK 0, HAS_PROT 0, HAS_CACHE 0, HAS_QOS 0, HAS_REGION 0, HAS_WSTRB 0, HAS_BRESP 0, HAS_RRESP 1, SUPPORTS_NARROW_BURST 0, NUM_READ_OUTSTANDING 8, NUM_WRITE_OUTSTANDING 8, MAX_BURST_LENGTH 16, PHASE 0.0, CLK_DOMAIN ecdsa_project_processing_system7_0_0_FCLK_CLK0, NUM_READ_THREADS 1, NUM_WRITE_THREADS 1, RUSER_BITS_PER_BYTE 0, WUSER_BITS_PER_BYTE 0, INSERT_VIP 0" *) output m_axi_rready;

  wire \<const0> ;
  wire aclk;
  wire aresetn;
  wire [31:0]m_axi_araddr;
  wire [1:0]m_axi_arburst;
  wire [3:0]m_axi_arcache;
  wire [3:0]m_axi_arlen;
  wire [0:0]\^m_axi_arlock ;
  wire [2:0]m_axi_arprot;
  wire [3:0]m_axi_arqos;
  wire m_axi_arready;
  wire [2:0]m_axi_arsize;
  wire m_axi_arvalid;
  wire [31:0]m_axi_awaddr;
  wire [1:0]m_axi_awburst;
  wire [3:0]m_axi_awcache;
  wire [3:0]m_axi_awlen;
  wire [0:0]\^m_axi_awlock ;
  wire [2:0]m_axi_awprot;
  wire [3:0]m_axi_awqos;
  wire m_axi_awready;
  wire [2:0]m_axi_awsize;
  wire m_axi_awvalid;
  wire m_axi_bready;
  wire [1:0]m_axi_bresp;
  wire m_axi_bvalid;
  wire [63:0]m_axi_rdata;
  wire m_axi_rlast;
  wire m_axi_rready;
  wire [1:0]m_axi_rresp;
  wire m_axi_rvalid;
  wire [63:0]m_axi_wdata;
  wire m_axi_wlast;
  wire m_axi_wready;
  wire [7:0]m_axi_wstrb;
  wire m_axi_wvalid;
  wire [31:0]s_axi_araddr;
  wire [1:0]s_axi_arburst;
  wire [3:0]s_axi_arcache;
  wire [7:0]s_axi_arlen;
  wire [0:0]s_axi_arlock;
  wire [2:0]s_axi_arprot;
  wire [3:0]s_axi_arqos;
  wire s_axi_arready;
  wire [2:0]s_axi_arsize;
  wire s_axi_arvalid;
  wire [31:0]s_axi_awaddr;
  wire [1:0]s_axi_awburst;
  wire [3:0]s_axi_awcache;
  wire [7:0]s_axi_awlen;
  wire [0:0]s_axi_awlock;
  wire [2:0]s_axi_awprot;
  wire [3:0]s_axi_awqos;
  wire s_axi_awready;
  wire [2:0]s_axi_awsize;
  wire s_axi_awvalid;
  wire s_axi_bready;
  wire [1:0]s_axi_bresp;
  wire s_axi_bvalid;
  wire [63:0]s_axi_rdata;
  wire s_axi_rlast;
  wire s_axi_rready;
  wire [1:0]s_axi_rresp;
  wire s_axi_rvalid;
  wire [63:0]s_axi_wdata;
  wire s_axi_wready;
  wire [7:0]s_axi_wstrb;
  wire s_axi_wvalid;
  wire [0:0]NLW_inst_m_axi_arid_UNCONNECTED;
  wire [1:1]NLW_inst_m_axi_arlock_UNCONNECTED;
  wire [3:0]NLW_inst_m_axi_arregion_UNCONNECTED;
  wire [0:0]NLW_inst_m_axi_aruser_UNCONNECTED;
  wire [0:0]NLW_inst_m_axi_awid_UNCONNECTED;
  wire [1:1]NLW_inst_m_axi_awlock_UNCONNECTED;
  wire [3:0]NLW_inst_m_axi_awregion_UNCONNECTED;
  wire [0:0]NLW_inst_m_axi_awuser_UNCONNECTED;
  wire [0:0]NLW_inst_m_axi_wid_UNCONNECTED;
  wire [0:0]NLW_inst_m_axi_wuser_UNCONNECTED;
  wire [0:0]NLW_inst_s_axi_bid_UNCONNECTED;
  wire [0:0]NLW_inst_s_axi_buser_UNCONNECTED;
  wire [0:0]NLW_inst_s_axi_rid_UNCONNECTED;
  wire [0:0]NLW_inst_s_axi_ruser_UNCONNECTED;

  assign m_axi_arlock[1] = \<const0> ;
  assign m_axi_arlock[0] = \^m_axi_arlock [0];
  assign m_axi_awlock[1] = \<const0> ;
  assign m_axi_awlock[0] = \^m_axi_awlock [0];
  GND GND
       (.G(\<const0> ));
  (* C_AXI_ADDR_WIDTH = "32" *) 
  (* C_AXI_ARUSER_WIDTH = "1" *) 
  (* C_AXI_AWUSER_WIDTH = "1" *) 
  (* C_AXI_BUSER_WIDTH = "1" *) 
  (* C_AXI_DATA_WIDTH = "64" *) 
  (* C_AXI_ID_WIDTH = "1" *) 
  (* C_AXI_RUSER_WIDTH = "1" *) 
  (* C_AXI_SUPPORTS_READ = "1" *) 
  (* C_AXI_SUPPORTS_USER_SIGNALS = "0" *) 
  (* C_AXI_SUPPORTS_WRITE = "1" *) 
  (* C_AXI_WUSER_WIDTH = "1" *) 
  (* C_FAMILY = "zynq" *) 
  (* C_IGNORE_ID = "1" *) 
  (* C_M_AXI_PROTOCOL = "1" *) 
  (* C_S_AXI_PROTOCOL = "0" *) 
  (* C_TRANSLATION_MODE = "0" *) 
  (* P_AXI3 = "1" *) 
  (* P_AXI4 = "0" *) 
  (* P_AXILITE = "2" *) 
  (* P_AXILITE_SIZE = "3'b011" *) 
  (* P_CONVERSION = "2" *) 
  (* P_DECERR = "2'b11" *) 
  (* P_INCR = "2'b01" *) 
  (* P_PROTECTION = "1" *) 
  (* P_SLVERR = "2'b10" *) 
  (* downgradeipidentifiedwarnings = "yes" *) 
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_axi_protocol_converter_v2_1_28_axi_protocol_converter inst
       (.aclk(aclk),
        .aresetn(aresetn),
        .m_axi_araddr(m_axi_araddr),
        .m_axi_arburst(m_axi_arburst),
        .m_axi_arcache(m_axi_arcache),
        .m_axi_arid(NLW_inst_m_axi_arid_UNCONNECTED[0]),
        .m_axi_arlen(m_axi_arlen),
        .m_axi_arlock({NLW_inst_m_axi_arlock_UNCONNECTED[1],\^m_axi_arlock }),
        .m_axi_arprot(m_axi_arprot),
        .m_axi_arqos(m_axi_arqos),
        .m_axi_arready(m_axi_arready),
        .m_axi_arregion(NLW_inst_m_axi_arregion_UNCONNECTED[3:0]),
        .m_axi_arsize(m_axi_arsize),
        .m_axi_aruser(NLW_inst_m_axi_aruser_UNCONNECTED[0]),
        .m_axi_arvalid(m_axi_arvalid),
        .m_axi_awaddr(m_axi_awaddr),
        .m_axi_awburst(m_axi_awburst),
        .m_axi_awcache(m_axi_awcache),
        .m_axi_awid(NLW_inst_m_axi_awid_UNCONNECTED[0]),
        .m_axi_awlen(m_axi_awlen),
        .m_axi_awlock({NLW_inst_m_axi_awlock_UNCONNECTED[1],\^m_axi_awlock }),
        .m_axi_awprot(m_axi_awprot),
        .m_axi_awqos(m_axi_awqos),
        .m_axi_awready(m_axi_awready),
        .m_axi_awregion(NLW_inst_m_axi_awregion_UNCONNECTED[3:0]),
        .m_axi_awsize(m_axi_awsize),
        .m_axi_awuser(NLW_inst_m_axi_awuser_UNCONNECTED[0]),
        .m_axi_awvalid(m_axi_awvalid),
        .m_axi_bid(1'b0),
        .m_axi_bready(m_axi_bready),
        .m_axi_bresp(m_axi_bresp),
        .m_axi_buser(1'b0),
        .m_axi_bvalid(m_axi_bvalid),
        .m_axi_rdata(m_axi_rdata),
        .m_axi_rid(1'b0),
        .m_axi_rlast(m_axi_rlast),
        .m_axi_rready(m_axi_rready),
        .m_axi_rresp(m_axi_rresp),
        .m_axi_ruser(1'b0),
        .m_axi_rvalid(m_axi_rvalid),
        .m_axi_wdata(m_axi_wdata),
        .m_axi_wid(NLW_inst_m_axi_wid_UNCONNECTED[0]),
        .m_axi_wlast(m_axi_wlast),
        .m_axi_wready(m_axi_wready),
        .m_axi_wstrb(m_axi_wstrb),
        .m_axi_wuser(NLW_inst_m_axi_wuser_UNCONNECTED[0]),
        .m_axi_wvalid(m_axi_wvalid),
        .s_axi_araddr(s_axi_araddr),
        .s_axi_arburst(s_axi_arburst),
        .s_axi_arcache(s_axi_arcache),
        .s_axi_arid(1'b0),
        .s_axi_arlen({1'b0,1'b0,1'b0,1'b0,s_axi_arlen[3:0]}),
        .s_axi_arlock(s_axi_arlock),
        .s_axi_arprot(s_axi_arprot),
        .s_axi_arqos(s_axi_arqos),
        .s_axi_arready(s_axi_arready),
        .s_axi_arregion({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arsize(s_axi_arsize),
        .s_axi_aruser(1'b0),
        .s_axi_arvalid(s_axi_arvalid),
        .s_axi_awaddr(s_axi_awaddr),
        .s_axi_awburst(s_axi_awburst),
        .s_axi_awcache(s_axi_awcache),
        .s_axi_awid(1'b0),
        .s_axi_awlen({1'b0,1'b0,1'b0,1'b0,s_axi_awlen[3:0]}),
        .s_axi_awlock(s_axi_awlock),
        .s_axi_awprot(s_axi_awprot),
        .s_axi_awqos(s_axi_awqos),
        .s_axi_awready(s_axi_awready),
        .s_axi_awregion({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awsize(s_axi_awsize),
        .s_axi_awuser(1'b0),
        .s_axi_awvalid(s_axi_awvalid),
        .s_axi_bid(NLW_inst_s_axi_bid_UNCONNECTED[0]),
        .s_axi_bready(s_axi_bready),
        .s_axi_bresp(s_axi_bresp),
        .s_axi_buser(NLW_inst_s_axi_buser_UNCONNECTED[0]),
        .s_axi_bvalid(s_axi_bvalid),
        .s_axi_rdata(s_axi_rdata),
        .s_axi_rid(NLW_inst_s_axi_rid_UNCONNECTED[0]),
        .s_axi_rlast(s_axi_rlast),
        .s_axi_rready(s_axi_rready),
        .s_axi_rresp(s_axi_rresp),
        .s_axi_ruser(NLW_inst_s_axi_ruser_UNCONNECTED[0]),
        .s_axi_rvalid(s_axi_rvalid),
        .s_axi_wdata(s_axi_wdata),
        .s_axi_wid(1'b0),
        .s_axi_wlast(1'b0),
        .s_axi_wready(s_axi_wready),
        .s_axi_wstrb(s_axi_wstrb),
        .s_axi_wuser(1'b0),
        .s_axi_wvalid(s_axi_wvalid));
endmodule

(* DEF_VAL = "1'b0" *) (* DEST_SYNC_FF = "2" *) (* INIT_SYNC_FF = "0" *) 
(* INV_DEF_VAL = "1'b1" *) (* RST_ACTIVE_HIGH = "1" *) (* VERSION = "0" *) 
(* XPM_MODULE = "TRUE" *) (* is_du_within_envelope = "true" *) (* keep_hierarchy = "true" *) 
(* xpm_cdc = "ASYNC_RST" *) 
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_xpm_cdc_async_rst
   (src_arst,
    dest_clk,
    dest_arst);
  input src_arst;
  input dest_clk;
  output dest_arst;

  (* RTL_KEEP = "true" *) (* async_reg = "true" *) (* xpm_cdc = "ASYNC_RST" *) wire [1:0]arststages_ff;
  wire dest_clk;
  wire src_arst;

  assign dest_arst = arststages_ff[1];
  (* ASYNC_REG *) 
  (* KEEP = "true" *) 
  (* XPM_CDC = "ASYNC_RST" *) 
  FDPE #(
    .INIT(1'b0)) 
    \arststages_ff_reg[0] 
       (.C(dest_clk),
        .CE(1'b1),
        .D(1'b0),
        .PRE(src_arst),
        .Q(arststages_ff[0]));
  (* ASYNC_REG *) 
  (* KEEP = "true" *) 
  (* XPM_CDC = "ASYNC_RST" *) 
  FDPE #(
    .INIT(1'b0)) 
    \arststages_ff_reg[1] 
       (.C(dest_clk),
        .CE(1'b1),
        .D(arststages_ff[0]),
        .PRE(src_arst),
        .Q(arststages_ff[1]));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2023.1"
`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
Qpp66Ic61NR0mkVmjG7vgOL0NB6CTFb3Lsi4qxXFnJ8tqqKShAriiJmn7uXBNCBvGZLnXCb4uZ8i
EqR6IQq34abN0LrooQu7rm3+Pw0iYYKzN1lcF+6EclZnFEeAIj7bGbLI9X3Ib88Mjvj0+p4IA3Fj
9ZGHNW+O+knchfmqAlY=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
aPxGoOnJHTAqFdFSzG9ru8Bw31YY71SqnXPbyZfA86PxaAjm6NpQtu/8fWeHlM19Jz2a+1ZDAj2o
VkuAl+PF18BGfMNo3Sar4bSJm8QwGYpdMiLM+06C76IY/redmJfNEXBnwDGx1NRihbIrHe17Fsp0
wci4ZT2n5HHVBuhowg8un8abF3TR6B1Ll1huon8bmUC1ZCG/4nJpwwhcE9pfhZYPxzBDs7qGqe8g
84QrDMzU6WhHqgMvR8Uor517l0pItAYj4pxMvaZhC0k3EgSYp/MQytJr+HF3vsw+o0eF1bHVU6Na
eXWSV3ijxUZXCyCMZ7YmEZa9JX5uKS5m5eiP0w==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
mWzZIcmTvZaO1EYxJJAY0jRMaMCjTyRzPU6SbUzrKHfep0pA4LS/MlSJytRY9FYloq8LonlEJmOa
YvTXus6Gximwd82NfOWOU+xAliGI4hqn0DLAX0dSg8OERUorJfPsNqrBuHvDufz9efGQs7Upr74j
TMlZiW0gSVGHMQSLqUU=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
lzrP+qu7wbNhDwJym0tPh2ytzSxetAAI7sMgVeTkF4E0aGc202oEP6AjkTk508CVci4/F5/oGOgY
jKPpZya27mqQoisM8ilYqvcw5pXx0/pQGRu7JZF08b+k4spPXeJ2wn8IDY3FWSHnOcvi4dOebH/q
+4u19fu74aqk1ECrIQzbVZpwcWeMDGDUSHDy4FPk9OjOswCxOQPuglJjXYv+hMg/7JiOUBTJX0uZ
Xmdtxy8L9z4EWzfRzOSHsJFjTkSLmdTFavs61PfZS4KYT25LV10DOvmL3fy7M6+bBXN5qE6rW0RO
W75E2gYB5D04Qa/SgER8JeFW1M0T8RacJUUV3w==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
FMe5G7+i5Dg2OTIM7CinNcesmx+3xFOKOCTYsoHWrp5MlbAPNqriPe41pqSx7Zo2+ype18VVw+tF
lEjRQQF5TsKrIoc8kQqO2Ck9JGAZjsyrFM5jTWzQZBawoJBB/EbM32rM+O963qqQdP9ruUzt4aM6
vf/tdyfOgxkUcl6+JJNYOQDIdBGzvk/dQUeNjJV2gWOsMrT/8aQJJMjp2XPW18IEhMSdUT+e8kM3
NlZcNyywDkNOLcIS8VKNtRSuC1gLTR2zXKL9eJomOGg66N8dfL808FNqNi+dtOqd2OhDKPCh9VYN
gJ7hSggqdHhUVsYY5qT37vUMUZG37ITEHavSug==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2022_10", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
IZp7wGosl6Ef78SQeUxKofUHVTZqkQHJJU3t0K53ysy/heNabWQpu3n2M8+eCIHOAio8FR6+AOlT
IAA4JAFJfJ70Sm8r1CV0vuXGNVDhIlFr8HhnDDJc8CLdz8yaFrENXgAR92A47cxMlNwaJCGipXa/
922mJ6b2pGDdjdTLUcKsU1DD92Kou08spouWrbB/PrcgiC0dc9Vh5gbveNqmUuOyH3mlBam3FvZl
pgofpiJBXCkR1i8+hAEtpYGjmSGUTUQ6uHMUKX0u24I2h77iOiDKYTNJT6jVuiYM/DRD2IfylgS4
u7QDnvP07bndi2AIocxrw7LHdjJ9XWVyHUaXIQ==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
mcmaj6yfbZVEKTiuHl5s5QU2BU2VRdOtz/pVopoNI21Pt4eUkknoHSgdfu7K976MpUo+bkHQ7sJi
/0kAsbTsCHtz7UWvsCk9A5SyLMykdZnWyjEbf0dHlFcgzZooebDG2zm4mibiRUIKwAMgFxTWk4RV
k5Ay3X64cOudFYqRbTCUmp1L8ijVoYJo0zi23fsL0jwpEG5FTTnJ1h5mK9rFtj4nIzmKqwwP+7JP
esKOwY5A74OZa9Q2+Oc/k4UmgeZgw5q/xkt1aAjxDyRRfCIJizymNuJw9sa/nQXTKX0zCMrY0MnQ
PN3c4p5wkiNcAHR4g0673PQsVxTSpFZkCNMkwQ==

`pragma protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`pragma protect key_block
mo2NT2/CRe5fYBwkxXV4DV2r4VY+mW8FieM9wY58cqg6XakgyeQ/Du2w01ie+Sko3Okr8ziahuNO
XBMXX0d4rR94Cwxf6q8vsbxZgbIlknsXsEuTwNfsw6ywD3/7leL6Kapx3fGSVuIHDMHjwpstoX+8
phs6lpM0VeRML4QJl7ITOuweBx9b+hHFRy5duNtva30fSyVWHLpzAsS+sS+gCcFxsDn+K9lQj/Kh
u11IaBweyu8d5W2ClTN46tdIzlVw6S962vDsk1+h6BQzF9y3z3BJfLpfR+9jdhy5wqng0ejlOpbT
G22gnlE/BqKGgLqVQKaeXfnp5NnReQcYXQTMossrLWwi2JUvDGuA6egmN+38JdoIzDHxNPxvAOZ/
mF9Qjn64t2tHB5iHybi3qFxlysWYSczGHStpTKrEoNAcQV/kMTe5coIDdy3mGIpwuduxq1OYPA9m
VKKE/GCL1MQzfgEx1Az+ts8Oo9hgM/A/cJ2envlpTKlt5itG9ciBZ41m

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
RXuoomA7HXqxfp6NbzOyYrUYOntlNDrjnrws4DzEIh4YC3p8BdX9/zrLD3AxALpTnAeHyk3lFxEI
uDCpL9/tP6yT5BmfL2N/oyWIQ7y53Env+IFaJMMaBIG9U1LBtkcnhV/FW9tkUePJ8EbKyE9tP/kp
RScK28UNuQEHp0OPznrb1v+AWO/DiSNPuA44x+Ig5nBALVW9qfA4+tvzfHYpcke67vIFYWLthZx9
NC9+R793F9ypEZMOjinKDbEk0gDUoqsmcmgF819P1JtLnGnuwtr1uER6OP17CsHbFowAmPsPPA55
QkDMyp68B+cHNNW23VXNPbIXLvPilhp/ypT+iw==

`pragma protect key_keyowner="Synplicity", key_keyname="SYNP15_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
6BvoQpuoVy9vIT9h44IRmW7Bo+8MCKJj5ZfOShjmujfjeFOwPLw2GCUNvV3ipB1eThHomI5yXGiO
fxOovfDeVP2hfGVaO1qz9Lz6NGhPt8K9Z+sH2rq47t68akOCSgmAoKJ/5BbwL/t0FtUVgTtq7Si+
HqZAUgbX8TCY6IRkFibfSSK6UarmhEpPrPOpvsevKx4OaMU1jfgaJvIMRd257kSQy5o7pyO0n7VX
LK6V93O0bi7Aa/TTt9W2MSK5pIDw9DmkTCLFjsS7gBYQYaFaba+LGfjQ782nQK2+KDz85b5qKPM1
h19t51h74j2WjWCadIgjRVfMYVvsErL0ehA3Xw==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-PREC-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
MMpJ8DorVcMATHbuGSlNSCGkzTOL3lRnFD2u4TUx1W94+tAqA8Ktjam9MqFHuJh/5PX5VUq6FgP7
1oYcR65DRc8C5iUj4h0vhHLi42ruJU++GUuIdS9gvoiQ246hdXMefRe5wcEOnqmxKzf7fyduaSpG
7SdN9PpubFzyeck9cLJj2CYMY1XoujEAxeBG5YKJtFkQkCeHZWr6R8PkNR2oyQGuZuMeJdgNh4Lg
5yYuOk0BGcB7bwSjic5zqk+8Veyp/ZGAVMgpH80juQjINIxDcLbvhqTIZX4gKUQjcJYcBhVuPgVt
Ms7dqARwL9nkpmZ/SuNzUmGdEIhVlblWNDRV3A==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 71792)
`pragma protect data_block
RVeLESEtohPKFvIEvQEAz2RxGVC/7Ad0jfXED0yYCq19Cp/wt16KImGMaR6922M2cOyjlVHav26A
Z5AE5jIBinj9BdggfMGRUKeveopEPhBv1Y2ZcL4R/oK9nqVd59dWXCJ3bZ02rYVxedQs4MnBPx6E
Gjjzj0TpNktbSIky9JJhdUfwaiqrZhnr+UK6z8CGTeMcHNv8bIV1WqLwaYfgN9Pb3c/tPKFaKAIf
w+nRzs2R64NrGUmGFBmJSAW9wEd7fJKNwmNjb1cOETDPQnNvwS7EggYANL3+NCN6kVowEEFL3P1U
Fgv1JrOJUGcZQlCfGv+ZdmUKom02OLsdX9pOx/4CeGejhQKqwmzGYIU/v0eGTm1/8UdM117+kMYI
Rui2n4nI6eH4mXkrtbGZMOIzOPG9yIY5NZ1BmqNciEUEzx3Rxf6C/lPboINEM81ebNc2JTWRUzhm
flE3wOUFEKxW6oY7s+hxwIBqk4x/qYwhZy8GAqg/HkDKXZzg1mPywP+b3vbAts2Vf57iv73QxiuD
BDKjX0LI1l4e5qdWiE4JhlGDaPWPSyFiqsNrCmkx8qwUZXfOSDNM46/wOGEdxUXKtTD7UKal9+D9
SnWmhY0UHYMiCmv4ybcq9Bc7AZSi2A/AQXXU11wF1sQRruvL9mfsvFz5iXXhhLxqPsklEY0RTTsg
rbk265OeldUdRskgEizk50bjUca938pykq6hdNoM3psqdXHaFMlOj8FMRUoA9o4MuBgEzzazKElx
jRumy/E+y5wWsFZHBeSFB6IsOiJj2xdj8Stu2aqq/11xTXLHDAbPYMXFtJZ71aczQQch72+B3bL4
l562RSSEHAsNJjdS0P5q0Qpvns7g3LdOiSgCBtJyKtS1BQS4/fxnbjxoA0UJD99VULYXufRDVWCO
Tyopj/LqFmIsL3TlIEKOM+nMicPMxZC41yRVuOLLSqhXFCvnPXai/ypDKrKz0QSR/x8g7rAGrcP3
bJuCnoLb6he3TxPge6+uSGei2xoypTSNNT2gks1U5iHD6SR4ktDGzgf7WpGLlO+y5y6y/q8Ss5L8
Rlhsdj58NB6jBPHaORQ4hUgM4qIbExwv/540bl7A250JQZI6a1WP8NZdAH/4BTnV6Ht5+XAPNuJE
q0+VRW25mt62eyM+lXJPoqdpPhXGYb04aoFWPJ2/M/M6J6XzcVYotpn4tcKFWpxQgJMtTWWjtT8z
TnWe4HV2/xvM8jomRKcRdJklAWY5tHOfidN1ERJHgHBvB8mldb98KSlXnr7zpfw8ePmTrH0b1BiI
DDRmsH7P+nLTpFvhvkMThLIodrAxXNbwmf9SCm08Va4gqLglXKlyB+FRwUuITOyBssRWEzhnp//Z
erauV6RnJ0fYHTa2agqww2zQRvcmrwTtAopn0D8KQKYDrQ1G4fGwvV9WeH+Nu+yah30zCiJPoMC+
jiZhF6UoDXYV1q2sIbUiqfqOAH4ZFiHHvUGeP56N4X0NJb7g52meD0zLBZ0CBC7enEB02NQcP4O2
1Zb67moMWY6NvN7KtEh+9WLE4b8AEAX8I8VIfRypM6rVOUBHphDjLikfhZnPSTsoz2hGASPljdsK
mgUR39MDhh2G7nqnYULJKraT7oH0CPiJClXrN6xeNHUV+ZfGgjdUxHbEVJ+ulT7C/q4otzURo/NH
ZbIza9Z/OGrnfy/U4hARTfidkw9ZA8RVb8g3k3oB8JimzJCl9VsB+PqQb1bK1XTc8HwX4jN7ruI6
TbO5Wj4LNIvL6b/Tc1w6VogK+iftoDNFmTrb3rOhiqXqIFOzpDdp+xE7cBkj4OLQFKxoADIVP3Oj
h6aS+QZb1FKR1eMDSL7EeFKzuJgmTbYvdaPJheZUZsud1QRNhTUmqeY1M4lLuOA4m6NzenZ2f7nO
wwnC0SDANbhe+j+NxbiMTtnZAByjeZZ4Q3+ZPwYpANtb8Gwi3rPXUH4XeSrGCGf4LMkl0ycthchA
z6OxVfxeB/5Gk93RDOIDqPfIo/4CT0v3u/pI6fwKeXY0exxL4STbr4csLFrb0IXArhYQ3/HnPg7z
B3n1PGnJOpPgea3v9QWP2fSDfqJQAKX2BiJztw9ZKxeEDWVZ20/tuv0xKyKXUNJLkWYkVN3I95eH
UXKWrm7RD3Ktf2ONZgIAeqCHcR7xnvZPl1z1wBv+nzA3SbXMQko0EQZQise2e9bANjs0uT/OAbkl
axJTWsNLN3Qu0Rr9g2m1q0EDyHdB48VDAewn4odBtmY61xQ+Y3I5/npziguXJs+Bu3PTYfi2/6G1
JkHf7HJ47IlqMbxMA97/Z2y1Af3pmtfVDiuXXLZiKruzWqrR5FbrcI3V/5wLJXudWHkL1ZAHRyin
Iwb4Vc7GvJc09PNSAm2U8m/z58eIogL+fpVPbeg+zTmcfV4UyWAmF8Q5RTKp8WeHNl3+o//+zZSd
JJW4cgf5XnNioGGWcmv6UG7ftpP0DngdSxNB52sH7XUmwZGkpRuNphm+GSfAvHo8uf9ety5UHQ0S
ULtWdEHf2Tp6PRCswJRyUBvmBA2Pcr/0x7Dp3RvYCFYEcoHXPqA8aqV+S1daHSxd7kcA+WMpBGOl
Zrl8n9vJbSU1TKZniCpRePJUWA3jzJj05wwz+78pJJRsahx1GCcE8dHPgvhqoTRQiGtobHrmXDt/
3Olr+eBc4P45LtMijHWfRodFCrzsVgIaim76voij8rBGbod/R4Csh+5JUqgE/JEgfZCpqcQ8BEgU
DmY8RxGzqZTvWndTm1rs7n/lmBaCWXf+45a3kXY5TOrclOU6xiA9bI0qt94CVX7khM1C1e1ZUPzk
2auq9ruchfaLRkjudoSmf3RefrabvP/U4qAcJbnEc+6oB77MgUIehGJyz/cbX97raUcF6FMjryAY
D5VeBBeL9R+EMvhlH2ihYXRohWkrev9i/GyTJ4QXXj71dJVYSRc3BRcV1hDOZUzb37Zx1VIB72IX
ddNSuM78iLq6dNRFs3w7LPJnaHrEkXKWniOUYmhjct6Smaf1QlZrGx0rix4K1nfx15kis5QzDc36
33NNHMykXicVUE6d7a2HUISGY99q7M4v/00fCW5LBgjFzORA9pDA95tpj291hnQy/z45sYGScU8q
wzLbPVq7NX6W6TElyiHiR7Ezt1UcLUFBvZgEYaTuYJqKpVkvZT8ldcliMCqD0p4vxi4mX/3nA/ab
QEnMwOf+EhUh2ypQ3xbNaX3Jw/OmlCFjBS2ntfAiSvXPQ/iI3ad6K6wm0NjQsrko2RSrIPqZyH3S
QcnUzrvBb/B/ajNTrGU8fkMPSD1NFIHW+BomCxAEwV1o4Cpy4eZ3DHaznvAQCogY3Vk2eIMuV+hW
q2E5F/p0O2kLOGtG3wHLPK2/kRoJyhIw1+i1JvvsJvbKW+vLA4/h889Tgd5AKxhnX3HBEoML+3jp
xYtK30XAnU1hWyXTKASQmPMioqxKS8t9ceCZWmpXPtyi9OR4pHN1ld8ONv8HW2XNRCXS4z89L3nw
mBkEcODftZmMTVxygTTVw46Gr7fMw8MV3IcLM/iP87Nd4hXm/A3Kvqm1nWLbLsaIT+mBEbTi9vkc
ljeGVpvqglZ4BU2ATEw2oNaXfGo9QgOw8i7yg1l0Ub7dOUfmAgeZGbR2mXZWZsqjhj0u8qx00F8C
5knfveXZaXFa16sGn711eRqq0UA/Y9OnZzelJko/UsRZblRGnH7uBhCcOcxK8c31iADOTepNWwzz
UloeOxAUHoL7gywsZaAwDqqzvW2/zRX4HsKV8pr12GpUk0G6oIMns4xxQxr2JNfNX0VQYdd3bJW3
D00kMGJK4VMoJHDcvbMAOiNvxHZL1qUH+HBQSFL0oq3O6H6lnEqvPt9PkQuUJzyGNNUGVs3rHZM4
zny89FqotHczbAySKrpEgbVA6jqOpdZ1F4kK6lpPwe1e5flsDcau+7IZGck92vy2HyPhKkEaa6T+
hxB8fqNgrXapKLOU0C0DdXg1BO9/h4q7ggOC7SGcyqKRpZprKoxh0SfHOTDrYqXBO2RMXj85/OdG
2iUM6rgJIb6TMDhg0np4JpheHGwLkB1qIL5fYGRjfaLySGZW/DEi/ecBs50W7n+GeugONN7RS4SZ
y4pC+FExRtV0RXvHrrQbT2Wv18xh1mBHj8pRVBDCB0dTzRlrhxH3tTfjXWJWwWIyTYQVWa1dkqdT
YoUpdgPEPczQybjaZ4NbFszcje11s0RsEcV5T7oLGVdp5Mfgwd4Dt9+TXRWbFempqoXj8DqUJno8
6XILk/eF5aBaMGPzv8ut56jkVLV0Ge5ukoY7OOhG+i9ot1BZ4KqCJEGixCDLzaBsbrHuGUCWkVio
OE6SygCbhurr0uNxLI45vdrkHA1tmLz5SETiiQ5DVv2Ytfcqekj4dEXL4Tg/BzpItJZMwvWi2e3d
jv3pf8Wdjiju6YLwTYFbJJBQdqqdhjC55PQUF48L9KsF7R6d9t7rMcV4k6qWqn6uZquT+PSxpYBz
cI/NnHT4+PbDAdmWIhn6/yPaqUgG/DmTiYf+a17iz2ONlfCnKPZ426u84SCrgv/jlx0gRq7iCm9j
Rutg4buqE3s3P6LVgle1Ny9OXrO1TuL3eqyo2o9MI/NYXsg1Co6DRaR2+sQ9ZWUreEP2ZtK/SQiZ
4srcptb/goWFv4fWtXyl1Mv4XiKbQdbLodhWJH+tPlhGZyrGWws2cZejyMP4y9mbZSyj+x85YG/p
UZL+7i1ov5Mih8AEv4DgUKo7i2VIjjR4YpkhxtP8zsvHsWGTwfQgdEeiVpqsWBQ5ZRh1VnYc+qEb
DmJbMq7LhAzOaYlZySdANOiEIJGgR0xQvr/fntMmKZLMsBeCAePYgTG4dtK5GzY54Ee4HM6GlW0x
tcsg0hTg1lmCVDO82vJ+fZ3IF/e45rkUfhQIgGonlWfGRKdkuNU9EuyZMWURUVDMeS2naYXjXgxr
5nOFI+xeCglF6gKHNkw791DOs0qlNKFQhaduw0zgacOxOaUuKVko8NoX2SQl2TX8Mdv7nzdGJ+zE
KSrSZMD3RpJUweln2GNqj6onk5xEtwG7enk2S3obVI+3TBlNYZji1aLCnV1VSoKnJF+fp72gqPuj
Tm/H+WP5QilkDUiiyQRNQyivQLznZaZjYmrxQcxlc79ZlAW7Ke0sqDjn1kcJedoGBmhYVftYahRi
wapOgdRSO3DRI6gZwwrgNMrXm8Ufln3q6rGI7Nt6zmnAhnwSVVnJ5j+dFHe5kTYfJeAlZyb5UMwt
/l+PvJPKqKTBVv6Nj+qYIT54Hvmv4XyGPkyh8rEct5+ruOiPFYARYWzHiYj8RG8//dwJGJJJvqWI
x9EDRuyS4t1uejLKcU/rjhF7YULIuG7N6ppywiJX5EBxHRvRGJIQxJkWwkYv0gMi+lDBSdAjT27x
UKWqepuwDI7MM1+yULEtJe6X6sAGwq+9u0lHXXEmf2yPCG2EPUfrXbczJStRR7WTzOlD6wCV5yq5
/OLe/S3eFD7sQN+FNgZBrEK5w+VSCs7SoXTcTGBlaOsTmb+X23vIfS4m8CQaE3jhzQqprd28U+Ie
/I58CVwKIKUtO5XbspCo/jvS9XfeMkrGcUMUBxoS6O/2WLuHzybJwDqEQlJsARer9WOp0bIn41xI
BxbYski/64r8k/yTxeN0R5m+RV9yGDfNw03FIw7me4/eydzTb3AN1CyHf6UqoF1I5hJSNMCrqQN3
b2CxrzNRzeumyTo0N5+tc3fzw8nU24amTFspvEBic4wQAqyFrAC262S9O604kexfym74gTnPogRJ
mb+vIBnOwxyrai9wopPAbg+HCboFXl9tr85VxPlGG++vHBwjX9IrYoThfK8c+L7uDobdpMX5L92Q
oIFskkS/FIToIVRCeOLL7kf1usdCTcb1Nan8VVxAIxs1F1C+uls+gm5pTahJ0iHeL614hLUZolxi
PGFLdIXgDCFE4okHRZSq7/xRTMUeF+y5dFn9ToxVY33LM4dyWeZ7yBbV2lliyq7aSGEw1JMwDptr
ra1h6k60ChWfG6kmEGGMUqnuGLfVmCAGnJzdc22rL8EATtFqeTPcyZzq57DBMPPtFSl98xJgHKR8
qkNC27/2ZF3mx9NjiplmhTRT03Je92T2caxQkYABCtkiVbWy0oqhETV2PlNaeEFadQF4SCpSld8U
CDsFaouKRRBTS8K75Asbo1aJ1fOxgDM4iI4M0T2IiudL4+PTVqAjT5qy/vpLsZTxlMQPLK2h5psS
5wrUcPmPKh5OFnUg/0yGzbR9dIqbQ1XQ+yw4ii+oayK8+/cXTcTyGyULAtJ6/bEhMb6YFZipv2Nx
W50HbiIczf46I91qd2D3VJpa2GS2/W4XFEo8Eut5Zt5ZU+AyYAUfhXeELwV4yj7bFw4goWeWunTV
c8+QA8bBNzsSsjw8ez597rv0Jk8uu7O6CrKDIHUCEEo3caVohI2UZxZ013N/zNPwe4WlVC9hLbFA
Y7f4IJL/4u6crP/kahkgQKEwoLXCYBdWlV2u2BIQhxjzmKugEtRWqggNBP6oBNbuO7zv17ApaHDI
6VeOuCNtpqDtM3aYo2dPAsFTspU/hZiUUvaj7/3QYLYA8a3KWp8/kjabV+j1bMU/T6DbwJuT05mr
p+UO/3+GGINPllYoW+sNbPHGqakGSlfo1zA4Sd0xnN3dVQX9UKwkVuZQekwEVlGnPlfNRXFXUB4M
vWDi1lDHJUdM6NsrDF8eBZgZEVezZRKPRfM6t5moRV6uwNesVvrw902CgiRvp0fAJglrGW25qY0c
HtCrxCTdG7SnuC5kzMkcj42YPEYYsnWzLRjoSjcwEROhXoUsdGLvamWZKAaLpzT06A6cO8Tu/x0R
YOpgXjC6QTR5W2VtmewVvCrkPVUbjC1AmAaABD3PSM/VFbl4veDP9UHxRuu8mcb54MkNcQeALoGF
T1t3WTvSiBQnR6uZc6AJFCOisNQLOQXAxNbMkop110S5aQZa8+9/ODeLib4OlKJcMlwaUgUvr1is
2bDQDdEdB9mC+SuIhXv1mXpL2AERgBd0gOlajN6KVrd0EH9d/SD3RBmArH0WmPxio084XkS6VNob
0cfOtuPUPdejJCq+NlAmo1zyYVBwh1AJy65DOh6rcRUQgDmzHXeWiGLymjeQelyCf8sBZXJ5skZ2
AQgH/BGb90uhm1lSmlIACA5MFL5KKIqpuwFrgFHczuSpHxdG5jVEAhIWkcf1ePt9mjQYk2wrySjX
ZGlan2A6hBA3rQlg97ySbk7s1vAep4/3tWnWDeX9/TiclKBHHu3ea7i5S/SlDHV7mDzgNdmRMHUy
UU88grFubVcd+WjJKh4EM4rsdw1JQg7RLkxfjKxNU3xRk2b3p0EyOVIaN+9PcGUGwHm2fCXB5wdW
eDEtonjwZNRDSQr90cR37H3kL+0oG1LN3N59b7/IzXVkddvmAX5GVLb6VVqjCMpUz/8CPHJPqD6M
4rmlqEHrRCWYRHlodui3N5+uKyL4Pop2pxEL262ReOpKr+3THoaJtTAq5U5V/mOEZblecG1lPWwR
7oEE0Mr8EgS/072WiYZFzeMb6P+q4ejD4Oig0IlELo8vkNMKtqn7b4unkL/kl/KNpJufC1yyc/rm
qDGlTbsoRFObnPhnBseGGkLgCU89zrCgXKbxgbgjdIsfTP/1Q4cj09+cMge45TuZvcwHuC187aDh
ct7q+BLVYlrkcW5sxulVpFpzGsNIMy+OpLOlRlMnIqkwE0HgGIxShEz0Y+ZNJFMm3dam/2aykQMT
UNbIv35/RMIZoxOwtN5bgF/szJv7X/e3TamU+ONXRqjAC83+3NEERZLVjOMKjADkoB8S2j95mwou
95kihLI5VVwD6IsncVbFPl7njkcNbCUwLrvsk40S9KDqtcJqjd9fg1A7VfuZmVly7znS2nEDNBu6
dhC/bPYIMTg8m0hOHvy0dmDaK3+yTuFZ/WoiW+6OBVApeK9wVM6jhNvWkBhFl1CM6VRG1Y1NZIFp
dJ9ESKUJOyTLYMvQDaFUGZEcl+xZ1HM07xUXwCVbPF7xL1tdjVtv1gerGusNvnz0qYB2HY0qHBFM
my0EGfbel7fs3KGKgBUQb0s6j1G9Et/P35+I83FcNZwNxwj928SAAf1wz/F0uZ2jwgTaLquatvGS
a8AbT3lJk+muve9CiuMQJ5O0uRsAbhYg8zvz48R6wdaN93m34NiagbA798xdc60H3wCD11n85mFb
bad+/ke/PGhrP218MytDP67X7WusVjhJI6AEG+D0os2Wyb6Gfx3ID2KUO9KDPEK1Q9M74N0vBYTz
xapHRCiOtPn9SSIBko22kVwhfy8ga6o5ai1OHxVFpRQrT034JkesSs+R33wmFM4KYHzQlWgqDi1a
//zgqfa1/XkttwgLwGHbs5qR2G91yEGqHHsFtvDIR8Eq1ejc4eHG1zYrSLzXhk71Q53McXXoEOcU
MqlNSyq3dVHxxMP8/ENjyVPzso/n6JKqvazfnYOwGoBEf6AS2vr4c7888KtX3V2aa6kcJgaLRnCY
c9I133e3I6Q0du6v5lKvRfHQhLkSvdnCLgTkH9qD/Pxv2UpVoFQ7MdFDxCY4g/WxclWOKJHuSTRB
ukR7RvpIqWRBbC1hGwwiejW4P3UE3rgPUUBPLXCIUhecSx8QQyrxwBQArKTr1x+kBLvR/qJuCQPD
gL9MwtuoAxV93sop+D6ZsIRMXtAin1xqdy2Gha0mNmDU20Dz9yiPOWgQm7YsNXE6RSHAjrhnLNVn
9CLqHwiCVmY9U2VRflxlKylzeTIa710R9uq1/hEmqIo4RHoW/jfMg1hwB/AT8os2m/H1sCiH64x+
0F+h8gZPsm+KyK/3/3ajsmaLrmzIzkT8mLyiYGadkRHKHVj7V+paOk6sy3v5Z9peHdH27VwFORHR
DAKor/bDtFmWaQZLEf/tQ5CrUDaQQFS6bQwk3lGGJa1nysBpiwNyTLVjEJ61m5wEvaxTbLS+RL+G
EIGkE1TugtRkxYmg8wETEQ05PI5zn4LkO1KRIi6qnQI2OA7UrJPvWqT1oefYMnL6UYJK+r23jAAi
VTS6xgo9itsWvTiEhbVYx8YrrQbvzr2I+Fzw+sWYBtZ03YhcPzn0rh5GLRG/QLrcoEzHdLA6vC3Z
ds/rX1GX5BCKGA71ZOPZQWRBBpXnflaAKNWXeRhek84EGp5TIa5vg/SdAhgq4OjSUVSrdzEg3OCD
CA1NtR8Pr6n3To+IV+LxIzjFGj5+a/PKM5Mu+6aGd5IxwshfcAK7NltREBWJm+avjk8W1rYVflKO
eg0hXgJ2T7Jl+I8q9+cOv3MX9HaoRQeqwRRMqm7jBrGrvkz3AaFQ/TSMb0sBPQW1m5/x2CDhI/S4
JchXCjJcBQSskTsEvFeymvE2YjmtKekLTmEdTsiiyyw9XBF6e00ItgoWW+NMlCx8XXybb7XTFbUd
VCpDj28IqCQGUqERZ8PQTe2F5DrxtGagpSoGccrBd0REo1ntSYuVY5DGoZ9z/yMe+P7mzmhbTkXA
ffn89l/rZjNP9Y4m7HKewvn0SJE5yQA+gGFtxXGcMdieqbFPvaroGl6/3gq+vbAGcY2qIvZuSE2B
voQk+bUY4EgsXGt8Jvx9EOPoeprrSnBc516hgeSqZyEGj8kkISFgqVN9LWFwA6ipg352Dln19si+
vomzPydVIha1EqpkU3FkcH2/LUg3TDCbwBztzoPyN0Ek26t3dofTn899kQnjZYqOlMWS7JPlXrr4
VBcmsKmAGWhqYfGs+K/sKSw7Hpg9yVvKLZRg+dJ7kZAXtwjvNzz0NsUWFC8avQToFyJCaiuhPGQi
ekK1eaXhYhEWJFzXCmlGh93RMduCfrS6vvASZgL1dGyQEQhOMDH0uXYum5UpqGGMyexociJEgL3W
sFMPJ3lQ9Qyvo0wxBkFPHZP6obRzeIivQw+jSnsDu7/mtm5ivOdZsj5a4CcE1W84OTwVJukoZ8Gn
5lA50swcRlMBlgMlf9ZCNkrRsATqmmDlCJKQenZe2zJDIuuB5O3JqK50/Mh+AQNj2P4uz6d8CB+X
9dCudvhG6QSzdaAzY0qCCaGBL3rX8N8jK4Os0NzxKkr2EVTB2ahR0EsFFHOPAgFSlk7HBiXZyv1n
mIQPqyaIRj2M27ujfGQxgUnh12LW4XpL6gJ6BhymBEGT9Pp1xO+cWYaeO2JlRTn0sMDJ+3s9D4y5
MrnWfPUpKHcZSCXkwEHrIVdR47lV5+OTQeSEoyn8n++tLOXdnFPRJo8JoZnPjp76HcvYuY4tFPD5
fJEQDfc0U+/WrbI1+QCQn1N9i4kvckzpYVxl2rhWMh2a2+5Tq29CMFmSNc0kABzmremjM94uJezE
F7AJtkD+k2L7uxqR3UzgmJc4c9DPiU7wmVY27Iwcx14uul9S4U7ibK3/yY62hzQf9y+PH+tJkxLQ
OKvLJLNaywL07myJerHUMb+FovkGFVfyhSHxpIhFVg18H2eztWzW60CyvoLmTmr5Lh+7BKmKHAeE
lEG/5+xws/VJhduXkibzELhv28QgWiVVUSJaHskvE5j3gzx8kBT0QfJ+IWTpkyV9VlMUFMozbQvQ
vgvcX3HnM5A0EjOVB8IzH7JIOGwZw63if0Ban+EedHnX8XMIJVurcC0lPl0m7Z7R48xxY5H7WoQn
y4S8wKBmzrKVo+K/XPQVv+F371LbLUS72dLvxHo9ZRow3ZkkqF93lkOylE3E+dcSBqCOCxzH7scS
au1fF59gtHiBaK2OW+rR/EUk6L4qCn5aff6mrTW2GPEB4RSx/h4ZeCvzwV2hxtP8425DjHTw2MQe
qkpjHT+JpNE7LDYCi9dMs63nYzkj+iC5+H3np0F1MFYJbQLCediIZVhCpxrlXr87iVcCH7Bkcqxn
lyGjxpXHP2fse3zPIbssTdot0N7cgJDcw9289UIeeMKc+Y/1IHhMixcksboJ5ihUoaOy4mqBmwVX
OYfnS+iX+eCpWOHY9Z32hMzhOiA6ZsDbPU+KFGWONS/9IL4/dLWUU8AHqoBwO9/oBZiWa+ONzHrn
JwhRdDqA8FUqLuIGoclk1AE2bFmXq2A2yfA5RemyBYc9MRUv01xYu2XsPrx834i//0ZOxIJuXQ4H
sNbgMeH0R5xiSIjJGrD7ysPAQiF4MNaZ71MtZMLquM1/pCM5DOFcu5VHRqgl9akW22u6f2DBKEFa
9D/z/799/bYglJrbEC/BJpNrpEEpgiEDAgBXplFr6kjC0KwF2cxrz9ml6ZpHbgcq47NlDnatz60d
uXOaEAk+i4olhdmh6lw5hZ9eoxRS55/P2NEq9dEpflLPhNEV5My3A2bhLp6UYLv/mB629egavHFv
rSCcOxWD6pozEY9KzXt5dM4pEUrXAHWJDlqa54I2sPsNCjla/Rz1Tajayfw28SFwTIzwM1QLmiR/
2fz25zEwZ+GdI5kzwC0L3sgD8KZIKyLFiGyXCxiTgfDBTinvBD+3quGvCDgnga4wbcv6dAp7I5m2
/xxkCVdvb0b6C0VWNnVtg4Bj4mWAa4OpnQVck/l2sqXG0Om/E4Sy3EIoXXQMwscz5dKH/bMXkQ6P
aFtJjcO8eZ/dAd33yRTpi1KE0F9XoIoYL8luCJm8w3NSR95jmKkUhgau56zYEOG7S7ldpsRDA6hH
zLS/S0Lq7kX7UFdDpL6hQDjJfX+tHAFXpppneGxhhjowLRoMow4qhd4aET5p4jyeBoyLYCFzeq3d
cxIQkcxEN8L35w3Brbucvs0ksCGDF2LfJyVKscBQm2ybYCOGHpWKBzRCDT+pYTvTQE0MgDOq9fqH
8O0ft0oLJ7VD2VXSb4gSkAqLmGlfx+qmJ25hrhWIdc3vUwt9yp2yVcnH9djOTlLEe6Guw+H5I2aB
sLSNbykZhbwZlKmBPswR2Xks4SODxdnR3r7xpQ/3H467Flpi+thTbp6GLhbg5HUGuTxwzXtXmmT3
YnB4Q7QWOh3mhP/irwPsG6NdX7iI4Ddd+7oRI06CehyNwBUBVPOLGGleDICaefKV8fVzRwL7TedJ
5MN+azmeZhJP4RWK0eGoJs9fc1lWvb6lgY/wGZ4JgWAvEsX+nhnqFmwgKECQrxzWYIMG5Z6JKPVV
17eA9bYujsLwjQxG1TsUhiST/14fXkfjVQR3YdOP4vw889/UXPccJBGEjqPlerV1EMLULxOSjJz4
i0gd3cRW1XkpNqFl2KfXK+51WYJ8qqb+7Q0//P2l4746Jb4B2DH4B0Zek+rqBvbAkSzPWM+zwYc3
LU7mnKn1g5cvFZtxbBu0KeyCVexublyA6nCcWhRhH2Fc65vkXZEncz+bjtUcF99zrhDSiKpaGPxT
Jj4gCk+oEM2j+wszsKwLBRxCI9TQJZL/VFb70GI07CW3YQM/DGTmXRPr1Q25Y/1NQDkdz6QW8EWp
D1dRqsX6/wyfdurOwRJHayn/bNsj72AX1nY05BLz312ccnXU2JBftApeR7NgNERoTJXvEgoy3MHj
Os8uxh0KKTuNZUfS8r10rV7H9nT3VmOkqdK2U73ak1Aw6aDicKflCDwYV3qU5LBVkm4AvuwO5SWo
axeccb5dBA84qZgnv5Ij7ZseTZFAY5Rgfqq+OPpueEpDDOHdReTkL66dmge/IwC6BktzD63KiMlh
D+ekRo3McCAcih3S9M+UIrgnGFI+h4gG1ddJ8f/Fni70Rvb4hOL8Ptbq4P9TOPShQX8BAlj6pwHZ
HlieOcarD5kCgwaO6O/6W5ai2EcZUQGcKuk7Rphfo8lEgMg+eH7RTzIuquZZ9quZJdQDScTPHoHC
SItlAeNd7nAE6bftjDlM+7RR4RBzJvMMNJ7zN43BwVf01IUTlVH+9P75Rlci/J0EmaNiT95yIF8I
TgiGVq3Tpn3Xrc5JIt3pDAjY5XxWa3/E4e1coG5daoaE9sfd+VNK+vWayqdWfPj/iw1uOdrYyJPc
2pMuFeF51ybVnyyQnjFyNgJeTqHPHeitTOim3T+y65mHtC6PaoWsDc0XCCubAXZFUwwYSa96bx21
xsIeuTJW0tFY3Dge12xXsmfGMSPI69U2iEOZvGddMMEtCrlOBk+kV7hZtWu8qY/uIg/ZMfstZOI0
4cxSszy34odNQReo9sswJD3zK3RnWqnUSrGUiGGf+3v1EgZndeRwrkMDuKjHYidfQmi65CjCNSb5
/gaMqXof8HsEk8piEPbgNIdSvBL6ipwHxdFfBdCdZJatmZzekyZLbrzGAgmBsmoF30PkfohTl1vK
wvVuzjMJduvbal1CNIX8LeM2cLusN7728sPsD8yEKdrRse+m5VjFvkNeI1kpUbmVfv0BAWjm3dpD
gcpnkp6z0GxZk5ZcpJOlPRGU8aK/r7UMoVGWF+RDaHIccDFmhse54O//NrRsMLCJEnwJvP6RgkRc
yCZALuXpsLBjm5GTQYPljPtMhdN5M+xufn9Xdfzuyr3djhdEm5fBnuGDwzKLvceaz9hcvogkmQrc
Zh/lznfmF6CZYrcBeivRZY0p8bCUKkXrWXEmeBZYp4U5Tt5jcTDtuBiusOH0lWgM0VZdhTBD6lFb
aXOrdBUfpG98H3Pdy+AKAnum15wLhBWoQOIRHDhtIXtAltbc8lJS425HuXf0/K7dFfkp2LOtK/rh
zCPq+UGst4l/HLxetlo33uY5rdrRP4Juk20yfW7U35HFpCO7U0KNnjy+MqsHDT267ifb8hctrqi3
7F7/HX5Ra2J9ee86wC38zINcout2KMiIR49bOSGY1EdfZ2nBY0+ZUnOGFxPN29GT8xXi9DEJ7ZYO
fKH0EzmaGsQy7ndnelx8u6KlIpSCm5FIhCYwYQ7XA5Amgn7K9xMQLS0ttgOY9Oo49pK8ULD7j16S
ScYREgSdZS/MC6xF9bWzkcsY4d5636VBEdPbSpWkjQ2JJRSuruvx3jsw0rby+KuTtHKHDqKE+jZ7
iX353nBUqOMqdgebLeMIgeP7gxQI7oHEccpnKDNhDVX++BSyTWpfOEpXgaNCdpV7Ew53XJXb1OXZ
dbQELOp/z2pR+vWYT8TQWyWVmmsy+oVltacBvdAkE8H/O4GQ+VbYzH882tJ1+eh6IDS8/qgINENi
WnbCKFQNgp/oGrR+hNStE9XhIerKWk1zFRrcoVFmMgx510pId7VvQnZfdwH8xH1b6N3JZQw8gGLw
zPJj7wQcQ8U4c8Y5nTQSccymI7fRd5GEab2/ABbHVaQFs2jLe3TRl2eB4odW1B/IbCciCoMLCBOf
qepKRAXJvr2DdkExiCnS0VZf11Fha3C+yEW5uewcAchKm3hpAU0Cc5PUYUfzhBI4Xk6gJlCSsKW7
jucCTitBw0w/p3nOY3jCbPaZrPxYNBpjmxGAXBVw/93VVD9Jd2ho/WoTbIRo4234mICy6IRd+H+X
78ihh9TPLB2FHqOVBgz/2xxEDtbqCX9QYmX1MHcAMfK/9GnAA+jTNNk9Q9bBNgAT3SK+SPERYmC3
+OCxhi1CInlAY80zQydOvt/bE3+l6p/j7bWX4vhSfj/zLwH7B7l2YFBE9H+hhU77yMWJ0gCVKiAC
3K//cwo+ekDSeuJzSQWpMT0SHTrGcMCtzBouzeo8sEcGsARXWVIpG4Nj44H1xPxaS9XORAL+RlKr
PkKXhX77Ww0Pv3K+4Pfw4ZLWRMqCwOZinbzjmOAZzdmriwjVqEyXgIrx+SL+sD9GJIjqRxu1h5YE
+jTYbR++RKJUwV5kgv0bTV1cdJHhXe55ZXCtyQFHCMCYn3W4TQw1fmqW74KDh532OmHbq/gyyTyo
lxNrejFFL02llyCocajwD4Yxxs0SZuSMmpI0UGjL+EaD5G0HvQ+xZEG0ByQQvQo3Db94NqI2Ac00
+oOO6q752AZp97nOXJm487yKI0jtX1cEDZMamLi7+eHRnSItHpdTl/mBFWoe/HDp3r5ROAh/YGbf
7yZk5N705DvYfB41Rmh1rfB2IT/f6jpdR/AxUovC2UY9jZK2YuCkA1m5Mj/ZwvdxP3DHlkPidPAt
fbZMrmsN+eGoW34nI4BoZTdH5KjYD0HUZq14wi7hcVqXNE3BzrNvl5tS6Q330fSJuPyQxPNrkMr0
vQMrTh0MMVtzfV38brS106aQGvJk8eaCqh/rxqkh1qbhh+2mBj1Z50jKxWOHugcYP9Vk/Z+j/eka
V1+dc+atQa5p2+HcQN1/nXtIbpzm2gSS4n1xxnqZMMTOXPXjc84My4j7o8pMtNnOQXoPZ8YSHe3Y
NfGJryyEWE1bnSKBBIWmY1jXAzKh02vU6/SKtVYHmc0x31W1vNUaI5TEVxHk+yY1Y1mmtShhU6vm
MlAVTEeeQbqrTgHB5FnCZctJnwtpmJnCj0x9rCsNAl56X7QsoXKj4HpKmCetELfSR9pHaJIGwFAs
K6MQOWlLRhW+5yZWli/oiuyGYokRui00aJ1M4NDwg/5WTkYx2plXylDzlaqFHF3hLeIDQKBKnWwd
L/vHRDFBXGHZIIlHf3ZYSAi3ggB9dMWruARJcVGRtSF2e7OWTNRBsgvqFblQIVt5H+zsREn/z1Ed
W5OifnDGYBTuW6HPjg0vdAVL4cuPrKWukZnFyo9UmFGt8I3aos8uNSIdKrP7i1eplZIKXH2pD4Cd
REFjYK9ngumbkMk1Mr7/DV8/qgTXSBFb1D5fw76UITVePt/3epelFJqaB6EKjs9E74cjs5UOYzqJ
8DigNvR7wkZaWqORupMYtAXZEabXZpGZR48j+4Fl+/mXAUi2lbj8g6/LZTDrS/A9T8IiS0MK5mGU
wseWJADG75fyQTWRQrYtb2QKXCUyoPt9qu0HzKAMOEQ7pCsMEHiZB+owWH3ykWSiCiFialumvWht
b6+nwm5bW/Pe0ri76J5NCrriC2VnfJQdQxB5n8nwejd35YF87i7QlEQGEtF53UgPu9YFtloZ/dAE
8CdcjrGc5Ox/y3THMYs9T5PwQO9o2DeGT2Uw13ogrjOprITW7EEwTNNvbV4GIFZ4YUffMBEcrEsh
hOhAmkPFAzQG2xwF0Mj617kKUxmZUbwgbusC7730l4ZsDVU0x6eZf1TmxBy8y3TFPGhADyc+onEJ
9R8VQGzf/yqCBhp9XY5N4+7JC77DklkTcZZs4Kym8AC8NRNY9K+7A6fRL5mOaEzPuUUA9bTE3EiN
2ip9cdd2AD61s6wS8sC4kimUYWKS/q5F129EfgngzgPyMG/H/iq8NZivkyIsGUa+j/7C3280r73v
ytwQxVA0lJQAHo6AeiiESE5UX2CfGTik8xK0mJgaIhriV0pCRIQUXQTeIXWzb2McGryD6i7O+Tqa
rg3jqpz1SnB3EmisGgesxe92r8FRROPoULtiuLs32NKkcYlDjEKuCRzA9t2fx8FviU3euqx/XSZn
KIF6AiWqn3evUFBf3Z4FKvfdGEWkxTnx9TfIbMR/MsaeWQMfWMZ+TRJLH9gcE3dJoazCQ9wlPBTn
dYPmnNU4XAYmZ0wyuyFAddV7AJ4ksMI+H6ks4oo4/+IIj8wFzIOCNVwq2vNiJYL8Nnj6JkTM8O36
P1A/QhLzRDfhiwX2XrhPiVpkIWSnns/EqPEzyTiMvJG4B+8g1cSWJG1+ZpTuhf/TsjMxDi/sEbtd
OQqUTez8CM09biIFbhJFDdGGGNIvF/HHVxhRK9kObNFwrBFPd0BePjhUImq2rJFcQKGul/jVtGv7
7Aj5DWM4y3HLlvxYFy2pcm2u/+LD/GGQvbaTx6MCoQjtx4TH1XO6sa0ZERDT9aN1kghbYa/V8ivN
wqElsKkxFAj9iRM8Rpu38QcrklcJ0nO55CKvVo0jREwCTY/eKaJ9M8a9vc5lI+uM8LAdrzm0/2T6
0GRwgvfbiauAb16FeuFWiR1WtuyiRe5WHAuHPIEL95AOrTFBFZDWUJjeCPRuLJZcg5EMV60D+/zz
GzV3y0z6nljGGVm2fB/JnmSzn3bK2ICS84eudclcuqKtEvClvRBcEtuP91jpcuqlyKXbQ95mgVeR
vvqiO0R2ocZ3YFF8HWZ7Snb8VQMk6vNhpO/eWd77fR94JiD1h0VxC4yFbbWy4MPC549OixoAYUUR
RcLoLH+11N1L7jJhPa3nVJB0iVwZKwFYL6bX3qyfOlVVezn0U8DBqjFJxOM6gUYUmZP/7Bl0oQK+
gFQ8kjZzpeM+OAcszy6OUx+pXe2jgCtFLG/8IXr7uD2HBqa4KD3ueSZWF9TyOIXdSNEWpuzb2m7s
KkfhA9PcAL4SNao7F1ZOxQ9jMIhSqaFSkd8gKyDgYgZjCF0RW38jcNG1dc0uauQra/qvKGTDMoL7
1bxLk6uSpNF+dxpG+a9gzvF1+dwiVW1Gl/hcGGwXErpyRjlyiTKT14aZxuiiX1cVzhOFHZ7MEUnB
ecG7rt2/oxTTZ98GHhIiHDUVuKBaZV9e+uD4nRT3/SWfwWYM0oxsaCFFIcp0BTOgg/x6yGs8InnR
Z1FA9riFpQPztBqQXqKAUdJQ3DN88SDX5cgP1eGfy0BaHIEBfC8Zk2D736gViipdKJQCvFyW0qu2
rGHN16ie235OA31SisRj0OlTWuxZY9BVGQB5GDjAHHZx01Yij6CwKYcvKbLHhbBJgqtMFaDu+btF
p0y1VET8ba/PuRjqKfTgQfSVCBsplnPT15yM7FXYqKyA51YAEY7sVwbytEgAtpey+x/CZHIvQtwf
UIulVVXNtxlSTo1T/WwtnS9raa30VDYpF/7DkJGGwpRjZ0F/HNN8bEQksZBM26/IYNsq5cK3JuED
g4zwUVwkefkfo75AZ61TKFE5DFbcyuzqXWfB2DezaWcW2RvZMjOHrttrqKEV+IGaU863VNHZVE2S
/OoSOBtkNRq+NmplqCe7iDsELcJSxe7dAnus+mXMJuSD1jni8dtdudciQ0SfpTi/NdQsIixxUMYM
DuaolIjfoxC6zLdEHRjSA5sbCoP960Ar64cS2XEoIHX6zU+/d7GpA4vU824CtyTJbiG27v2+1bdA
2mWz/vUT9PAqYMTUf571fenNDnKo9MuAMRWN0M46+Lf6N3SOmkh/qhQZ6NXSl6A7aH2rghbS/VP+
iW9xBYUVJF/b+4Ld5o2BearKY925Ez5jnXwzW/Xto7ZNETNSv4/WCSE8MQRCmqO0i3du14RQnn4G
wbobnKUhChJ1FB2ZMrtWUiYNWYfV988kpZBebBhYY3qTYHk0N2sboPxG0pxAJl8RXCS5dJs3LSZr
a3x6TM6P68K2hysJL4kJfqqnMhrWt4wxHb+7iftGl23T1YscBgEWh7QBJjPmeDyBnBfLAThgpfer
uAQCdrF/qYx5LSelc3PkMNDoW0k6g3Yqia3BuOChvoQGZ1jCmcuVPHWK2Fv5kR3y3OmkKQ3JG0TS
kVtXqXkXWPls0z5dB58w2W1wzyx/i+zXXfjSDQzr/EuwHW20pvQLXc0Q/fvGxPQzbmvdGPKCY4ba
yhWrSm6r32Q1b2HyAL2W65exrKSeprtCKJ/WjRmd2ktDG1AswgwDScW/8nA8aEqEJgs21JoFvOcd
DkAI71OmrsC+wXtslwLqKtpGxRuZh9RuqewN5IwVMUJUXdNB7OEubGY5m5nDhTJmFhFhcxr4cbz8
3+z5clK46jysooDi4l1e3Vjdg68e5ZiXdnOPtYy3GXJby6nR5gBhYjkkNJPpp7nJoKbZdjDgzzLc
faQ9zx0G9MeWc5avam8GKxR9+YzITsgkWM2VtQrJrAYWNwqAH8yeis04eGG6Kqk2PxUGZowVvy9l
rqyPmRJTMts80SFbjXKZEU86w0xHy6s+jCnOQMzwRGHjep6kHbCl7ThoYDOBxzmsBe7/5NQput/2
IPdCHgwiJZ9yN4O7mE5FHY2XxvAixEbT+5IL8rsKEUTclZyphp3UCVF5oF2+g0NuTybLNTwjyOl5
yiS01tkiEz2lwxG37S+s/mCbGyGJ6gIuzX7mxCIFFViIjNABAOYdtuprApr24boDxge597GZriiP
t30Wi32RXdQlIbuhfDpxkmx+nGvsekuM9zxpmgajuUYjNsN6ieuKXtE6+1+BDZ4seoHI4Ox9rJPy
UVSg1vws7s7lw9+YpZPsBufk8l/mCMgMiY6UPb1abROpLB7da6YQBEUMkWLOhuM/YCNc2BselnoL
BBP9JdGBQExUKjPBh2Xd9BZAoHGIMy+Ta26S/GSuSdCl0E5svam54a9lBqWRBxB35G2xmteAqN5O
qCD9MVzr9527T6Wnt4sbFyyLJUKmb/umZxC60UntFRhqlXl/Z91BOoleSaJhObfJAkwz/EtfsbWx
4dSxAMsMF4fkoefFEuy66IdZqq4TNysCLmXyJUJFFRafu1mivv81JohTTRusGH6nQyiInd6n3wpg
fkRYiufgB5XbyH4zqpn3Aqju+rj3cha++qR7LrpESgjdZlqIq2jz7CLTEWHk5P1cNBoF/DkBOs8A
ZtpjO/zdfjoKOkXtLMGMQONHA8WfQlHWq8qQBRmicf67/oqQopv3lml/Uqg7fBLlnOQmPte+dT3m
xlm0ZyzQbHsZvFX0gKIkjz3pbOZW1Ve9MWeC01Y70JR5hG6UWydhAp052IHhF7GCXaJKDftr1xeR
8rRPyvQ5AQ1MgYRBTFN4XfyKwCiqb4HRqPDgjA5/50usebkl8WeLdvnD1Irwolnmgl5HSuJaXatK
CLSHX5D9JBDHGs3OKB/zZGMolXmp1RASU8w63HfT8eGikSpCewUWw23XUrNwPqKuZxNfLjOQzTP5
W4+WIL8eAB7btXhEo4YarYwutAcXwtXKMOZ8WUQMXjUhDjP/gc+rxoAp/UvH8sFCFOvQ6GF8EzJI
nvO9oeDmwyfZBJAw2lS96XpDRSCfVRnSDcWnqMZTKAsB6p8zN+kCcEnGRWXuhj1gwCUO/DAnK+ju
/+HbjzjWL2Bf8jFt0bOs0ylP7aQngvBT8hGVKFlE2GK9LaQhGgFXVQEslQl+STMZjNhe9pqLaeAx
6K4gmMrIqMjzfYvBYPKR6omrU+J0PSFKbaLTvfsDf3PboOcH7OKjxrXlx38DNatupM9ujQyElpfc
X1LwsOgkxD6u1dvWmALHbsAgF4zMoh2eEOuD93Tzqka/Xpw1/+pwLDCGjhyfTSlAjTD4ovYMC/2L
xlzLZg4SFj3UQ7nob2OQUti2zyvSwHH8Hs2K6/5BQ5HOmlq6UvQuMSJkOnptmGVdO9Nj05+UxNRT
+qBZa7iBFMD4Q0YLKZ7pz+Sm/PsT7c0xtEMpJ3acB0dt19jOiM71nf3lsbnFxcBDIQdCIMNKx9sd
Iu9/A+w5BKmMwL+UI+rqjY6De5tmIq62uDuJksrVtVq7XWnLyGBKr+KttGgSXf/z+5OOK5krfhK3
wBZolobS3ch2NMHWTQ8WBcpedWLnD7fbAyszce0aerXx8F3+rhpsw6WVnL8rR4WI4HEC2xzyZvzv
5ifHzU3V++ppFwdP2gadc4nTqdnDbuwrSLWXc95U4UMSrBh4vhRG+SuJUF87iPdgjRUfMlizFyYc
4Gry+4huAffCkQTwrOZWXV1hfo5bdU4+0kgYGyTtnKwVFeDa9ky6iHAmT19OUu+ojHP5kgpIsUah
O0MvT51Ofo7pq976a5blkg9LPWIxGppbtkVXZqjcq2+11tOFOFynfqqjBPQ9CAEHXxj//L5dZudU
XYExScRqNsgBSe84bMUCcgfHSzQVYAQHMVlSoxSuhFXzNnLGzKwPK+lCjCm4dl0JOcVO2quUdqM8
AbOxPtMn5oZ4rGsRafFhddT6ehLJec6qFvUmVlq/3qcpG1Ni0ca3lQqzNf7qt4pmADwq4IUhHLss
LYPVxFY1XvuzK+Eb4b7/Ic2FaMKVjDqooiVz0IUGqNEOX8GrBW3h3ar9U3LISaenzMxwalOcmNA5
Cd8WbhPDsR/EZ5CbY286f0hfAAU9fxYLzKDPGIbbVST8RdcPnrvj3UFyleLEouN6kaAmnU3S1ndX
vrbV6PeZ8H+xv3O/onVi/yEr20DjlhXiPA84yPXZRXGJ126V3gY/8vmKLxdUpflGd51cpT/qlHFZ
a13aeWff6Mvf7LRXAHbf/C7fmJLvFSx1JouIS/6brfy/98eeU9xgkuau5mu2RRICHNVtuv5qC0bq
PJiL5twtU3bLvOrD1w8SB5pWebghxlF/Vi3tzlmwtsfekHgO2D/JQxqUVY8njZrSyEdj7T1rrEkj
u2icagECPwPEw3v3C57YI1Elkskdb97cY5CwOa8AD853QHk0AaEKM+5lcwzQgGPjTr0KXyY8tWMF
6VdMIQCuLrq9GOj/6nhpfG9qC5Wz847QlOQtK8JRPWv3iZFk2I42IOL+QpBVFiMSNiHTw9dQSAfD
umRawaZQ+/AYX40v7L6lLOIcnIARVpIyvBiJnHze63VmkL9MZBhIVf/x5x9lPVsN3zWbmIVJsr7t
EdYoXX+EkmiydPEcNZif0G7s5jH+qyMDp5VbHYM4LDtilgaXMF+JMfOpkv7anDLAzf72Ymi3Z7wa
hwKQlko8fETsA8jBJ9bvykCElmtqjiZIGUasxYNbA+I/BaVj5l61NY5mCMtEusBu7zvLamjPvCvB
1B0qItcPfYa8kYUxsIiiOpdkHrHTgIhgcAkaIa94SPwxlK8H6cdicgcQ0NO8734XvAIK3KabDT3s
zWnoZ73ga3n+Kakton7kNuPtjKpATl2G1U78NkppbZSuHqLd6WNeCQkpH8v3Xl2uqCwBraZXpnGw
jCZdeYf5MS/JLpSrOMgzyL3XkcsOiyvsY4355Ig/N/X4W8SqwPNiISLG0aRT56lv4JHX5m87ZEFx
ExsvkJvOcfxe2Ps7jqYRuspnQGBoefYKWxH9N/iJmHfNKo/XG4dsurRFtlmqjc498DJbM+TJ47HL
q7asXh+0d/vug+FvHtCQjuNq/FAlBRk9suxP9pAhh+JnbhFKdz/3hA7WJQ9ZJk2DGEqQ/nAtlxEc
eVJRSmLq7PboI4Lmn+8QtKPERJiOIv2bNNB/CrqzD5PeoGZiyZyJ47tjDoNMtTsgKP56ybZKMiUy
IIXoZeekX9DGrBIETOyJLtmZaMUEWlccVDmwVnFFdwoFT/UUyYLHaRy7mLU0rqyFDoR1YCMXoUXj
E7idNseM6j+/FuQVq03CO2jaRH5cOqON+UdmT6FKC9fhNvCi2EuBdpYjqahQNVOgs/+HrN5ilZqk
Blzz+RxIkLIhgjgRTlf4fXjO5cQEVjwITlNJmqjaailWI3YRRmWDslV9CxUuOu0lWcFhIilZnxLI
ttHT64nsAZsmBosl+uT+IPHgduAv13ZhFCDLNK+Y7LAmQ5mrs3b9dI6sPYESMZFfuK21YZ3TsZ1/
pXMGFyVv29DQbo5aI1eUFVFPbVWzGnCdMj5SmnbkEKF6Zx6CMLK7UahJOmeidPgxAlUAPRiR+wq4
DYkgq20ZSbJU71nHRRlPaLNgnRnXbx/WGfPc99fbA2HC+fBk1yIGMJ2UWcV21DUJmI4/xG9zfBIA
o4NpAjCMtx/DNiMlsVF3m0S1f+ZK0PVJQiHXXQSOKVT5re9GonZDJ5d1UOidU1yUTLZg8Y5QwC0L
EBsp7jcSshk043AFpKFkVvOgkKZk1O1fJlbsVsZhD4rLWMUvxA0W1i3v20gktBJRg3hlVeKkrX31
eW3WWVAKLjZ4kh3lKIY6AflBsG289aTWrl1ILp3Mm4KlHLDxZi1CcgV3q4ABEookPRtJPPKnvD2m
lR9g0fWDbPff9lOfPD5bt8Cx/RbpOaTO7xJssZcuvsX2Tz+9omnzmkRWpcfZgwgppEUndw5+wmB4
h01VQeO/s4SoECCGUGSFeH1uX7YixtyIESWrlGGZ6H6oDD1bbNf3Xe/rUUBONCrOWyIlRry4GzUU
7aTMcAocmcBjXdszILZhFdcKeqb4/lHB616LsnUA89GlAgrfjKGdVDHJSVCuEjCfUdfpgiQAmbyR
/K4XbElZlLgHm+6Jl5mXwPH/UAfNZ8JFfx/5mcqwKpLouWsuqlEHUjXNJYZf8fo11ZC/KDGZnShB
A5SrRwNJ2aWY7klLZUK2CBxUMbghNMoAtCtAHCW67tZU0Z4+uVLRLB1dgYw3c1G54OpNOMDKg1o/
Pw/f8lO4pkItoDTOnibPPMU1kw8CYokXqnKwSHVZKGYNvcXQtG/Bo8N7gcfmFKqH24kctbIpcVjz
Qh1MJonFkX/e5Eo7+mXdOo1dXc6IaH2zMFxQOqAelRmV5heNAKPNru6n0/t72lhlc74L2IbbpGQg
3KpB5gSFvv6tsGPraA3QemXGEGKOV3ZV0dTYNceqKruXqvhXycelnLsTTwNAUChxJfwAnIlP30JM
8IIMzuE0GwgaxI5k0UC+aYpyiswK5crBEWXmzv1GAAFqKNIEd/5REUAUxC4Re3bF6OyG+OdTbg5H
2cWjRL+nb9tloKGLQD7SFB3xYEWP4ay8Jbwy7q79R3BE25S9Ni9ti44Hxd26Uxo+SpUXU3eXxZ7c
QPpQCGRI0QvrGL3SNXZsQdItggklmDVhvwNSrcsbzxIE/3t28zAmlxj7q9jqkxxU7nnLHO2iZfXI
JhWdK1/w31F6TFEZRchjURgW+Sy9ulHQWhcFKHK2yRHDnCYqNbm2+4B2tXiRRLD1hUYILEZ9Uj+0
RWyg7AI4dAKBrgOEiiH/9PwBP0U31wCEHLlhtvHN7NQiqVmU2HAziLj+PXwjwEAHUotoRD5xwu3L
V1AkzADw3VkR3eU0ZlkoreD5bF4jl89eP9cC4oWV045rYabTVRMSBz++K4uAiSbCDuYPqOVM9XlN
23qSl83sNfIo7/a7MVpYk6zEQEp0CrLylalboVnmmNkDNgFfu9HCF55lNyNzKGRPVdUrmAjG3tlv
LOSegN3I7d0NtFrco25RKgU6z+U9f+X22+QzqEAfAJ9K4a5ssalvbylsQg5iS0d+Y025pFhwL2XR
bCMZNL6KuRUIgP+7A4Lw7sFP1JYmhDqgsyEF2C5Y4v9XH5fOo0/alKQQuTJXN5a1fYNPj2rz8lcF
CmMhRdXQ2+BGNwdGbDQmSPYxWHJIdlsdMvUeaNmwerWMvBYXHNAKJCdzqf+ZT0AYZVm+EFnMZgMF
UIcg+2FXxhrAmPjggpXxyakZ6+cWZDEe58nURf/voHSPHO9ZiG0H2o2Ea9CFKv/vCLAsypUPYkGY
Bt9GhXjRsDe3EMBAKsZJju2F1wu9WSbjSpqBYQwapADmn14tsXHQfVCO7fK3fLCFwTUFN3Sj+wjY
cfUgxZRB92HOu1EYlY3s1j4CVhM+HW9TB4IrQvS3b0MG3h4KEnXT8F2u9IW3TEFF/G+fptILx8/9
avZCv2uVq7ZMz+YiS0ryNpvoPrNOb3woOpQlSIWkvDYxyUKLuTCmKlBruBheSLLiyhpJe3QXHrGg
pg/tIiG+OIiyse9aNMqmInVkFiYfzBJ7D2U6n05WB0/HpvrK8FAXagsUkpqL1YVHJZDj1k6mKkQu
T2Lb5eVdhUchDXToiZHXxO2IH3RmXRIZ7eNvGdYyQEu7XZdDfZABUCsYHsWsZg76osp4tyxw0t0Q
1verUHSWLfu3bXaaHkQtrzJ5LYH3sCMUUAo5FucrpRFfDYa3coNWEqIvVItvajhD2SDyrwjKQTuF
N/7q7cJqHn9w0MNw1fk9JuPUep0+0wgVw63plxk9K1ag9aCFGjmfcEomcZNxBnPCKQ0izd2Apqn7
F7HP5XIHDlsBIeTEEr9ILZN/xBxKkT7Q2uuNRlgBSPk1hjjG/fMo0b1Nz1OdK2RZolqHxAoi20X4
56CKEimpaNYuCDwmUMZNxR8iztT2P4MvNRRoVketSHIRxISBpxnVJTHebdjNUypTQoXNkoNXcgAX
NsthMUNQqXsPjc6sE2a/rb4B7Z9ywl7zBajk503OwTX/DQGm8sp2MDQQ9p+diMM9IQGa+IOvyOut
Sxhnpei9mACXEY98FdBr5XQj4lOsKCtJ2aJEqBNBvUOKVJftIkXaqy1rxJiUOH82bSkQDUazBFM+
1jkXPWrWec82jrxqth1/W9tb41cHSm+L3MuNJKXkGivIIvwhvYSpiq/lU07UP/g2M5g395hdror8
HqZG6WihdoJB05SAzZtHzwsBdvG+ltNmgK4MoFWwltVUUdTGMbhTmNtio2rxttqGeINMfk9HYB6s
6DA3g6KlZ0XFWVQsj0cKj5HnWbEhLHOBzPNbwZWrvpxTwWJk1hm1t/M8rmHW6Fy2p/FRB6G9PJ5d
/qQFZaAi+xZjgzHReghX8zpddNtrmjepvr7bsnwNR7cZ/zlFA7g/ZrT+tcUiWdz+Jgt0AC7+04ot
/YdmZqkqR/cxbooJUSeZkgEW2ff7MECi52l+OyoYtcSTP1GNIPKs/oyclSgWgRotOPC5og9KafwL
k8ty0f00Q3kqMXzvB0fmSjtFqxj4ijGn4ag+i4VGlEIRtuiG6DPPuMrfIXO2Fmxve9Eal89WTp60
cLRCNgGbmUgrN2C6tJJlj/Ej/QDgc68bUfOEivUg0EssMW3QivgVWUpMqs9xJbnurR/4Pqyv4/XJ
SI0AINCi95FRvyNC5HsfQCjsW2HstAR7Nd6pqdZKFZzXGCgMZCzYR780/hRvRnYFAKKuBGTPSgRg
OAXfMIn56Dpeso3KRD2OxFkaW5hf1yrYoMGPI9zA1HqY5McrH/+Jeccy3xpJ0H8bPihOde9xxrD2
wxtmXw9Sro25kKLqT9KZ5Zt5+RjLJctOHICfSSHW52GaSlb7VmNmClEI0trCzGj6RD1dz9bS7QNN
Vt/VZchh0H7ZOJyM7/9+DInXIewlKyojS42Y4/rFqW1TxwmVPwIXQD0OqKcPFACOKfjUb8mYW3do
Eg339yXA/5ZecCEuFj8Bc7oScOjn0EI3bdDboqA8+V4u4MDeocdRj5vDw+V5ymoey1tt+yqgO+Qd
BWMW/M9sg0regYByWiGaDUWbNO/NxeFN0Y+qAcN1nT2uyWFeDo3/k1dvKA8FQCWMS+/qZcEr3Gw4
U8u9D4xGdtm/nvzJSxRODt5Pr0IfKMUQhy7XSg0xj66+o6TGvc+aAPUJKHc1cFGORclWyieWTlsk
KjQTQFWakFy9xeKR3924T7dZwzQu54T+VLmKeK6tVwvkh1SBrXIE53do68QVrGqZ/Opy427YGmkR
rOto53cTjDZK4SeqVTrup9SFlHRFP2jaxGNd7y6z+AhDG5UEU2nGN3DI3EmjFrkDvnReUFMUkp5j
kAxA68WD/QecySMjwlJUW0WlPGiFjrZii5oQW/k7avR96DyzpwA+VsJHsfXxmbZPbGM9nTOCwFQ4
aCeU3XTkisa6zLChBlZpy0Wj56RJIcmdS9qH/cerhvzNZKT845e515auBMj1spWb8hPHfyl3E28r
WtDk9emPC5c5lUBI1h/Dj5xqCWrFbZz+vaTgrj3E2SwzOdIOsYEJHtDSCjhAylxF/feZ86+Lyx+S
WGpHaJRApsoYbCQL54UcUkEVTyExix7iV9omBCZUaJQ/TQaA5AA7tPrIYWTsGxFjNAdwAG2IxduQ
y0Oc83L6Qfz8bQK+vA/5aMn4AmlHruikEqfy+PzYeh02UqFfrz5ObezExYrGzoJxK8EfpJsCz6zb
1fxiUaC5EPFTipRVNjh0PqyTpEKEXiAjozpHw8qJKnHygra/0cpnzCWhS+W7UIyJd8AiYcp3WfEI
/2yw5l/opOR69nP6V+evmEpDI7nNuWiXb7f8dlweh6I1mxgYsHCl/0Nn+p9tVRa8NinnCLSSfLkB
lc1oreIfgj4Kd0RWMAM+5ZU0vZd4JS56EgI/sMcRfS5zgu7wh8gtCfRjRxQWMRrXuT3mR5zzxP2s
/bcMjVqIfMMYc1sBgd9QQqozOio2m3cervqxhcWbxCPs/0bbgA44osgoyvSPpHja+3rnx7MvNMOQ
Dz9NXktwKtrVZwnItkKnv20fcglniAHrtM/HFlL/bJuSfvkuUKakqZisOhHIH7D7RabnXW89fbR8
/DqO1tHhqLczBDiA/NRe/qtVILjtwNkHN03LQtX4/Vv74s7Y7oZ/emQpOZWyjGH2KV4A2S/8lkcF
kUCPUnq6Tf8LaE1ydGyr8dCWftS/jat84s4jfX4JvJXgORO/2UF24YUTTHtsZemAdX6oqAJ0z9WL
1NHsoABW9Hr8B8KhOGi+c/txgUp3m6jd4M1+bOOBvMxlrUfqg5NYJMHQJOxB4RedvKB1Kmqf99vJ
MPWu8xbJuqjVAW9bUa1ru86ID6BzTdR7DI8t3Emcl881ItAZ0PE4dIiKQKwxUKbct+MAkn7W9hbg
cMuVitrvOX8+Jck7DSMhfszTRY3ZW43L990cnBslwHj3w84VM9oHvodl/orpCjHUHvJd26TC1BU2
Gp7IeiNnN5WTfnidpGrYtre+lOZV21pDKlrr+OzMqYRCxcF+KRNemyFLcTgId9jnb8H18z/SixFs
/V4XIy2AJt64D2WA5BZQVqfJGlpkMROuP95a877+j8ko8G1TYpJRYxTaVVGAHG+4J9w6vMeYaAQq
WP+TiV1+Zlt1vkGjqO79hJmw17n4WQDpedyiVHhzmyZ4+//Z5GIKrLg3iNaghQAO7aXmOo4o7Q8S
te9hiIJD8E7GX8roGGGvsGJoe90oRg8FTOBYth2hSSooffFckOShKBFFvZP3Ny4TyLD2LapyI/y9
hX3HtctWbgnkhtL+LGdiMFkqXSsjUmgEB2G37R8jFlu1xe/v4+DYxSRWIgKlo2WN/Mj9cbGr6dsu
YS2s7aVEAqLa5Gw4hztnnM0LXteH5YiYswSkKQsfB98LjAMYjxuSspC2z7ajK0YyzqXFY4qnyrYK
dbqnZF+b372F7hamnDN+7QC46H0ynKnmvyt1iPwI1ghM4h379hFhgEXdMB35VMkFL25ykKgVKlta
IaCReelo8TYC5SDCmIF75sqBbz1Y0icsCuCb19bLf3KbMWexpzaMoKQQI3Zs7mV23lpIs57jSPBY
Sp8y49/4cw1UkOYY1KauTCcvwKpo0gDXdFGhaHHuTPXURhORFBdEKmcWVUy87yngdDOkywPCR8T2
JdQPat1YHxtYlMA5amQ3106IxkUPeu0y5t6jbVmpHmYrXw3DXMOp0sZ10dEYTPEyaMlx7tQkHTtT
uuvI6wB5K7KOE8WhN/t/3oxYCxrxwHAkh8p136hsLPyoGlzNXYQwHSL3irIyeH9r6zmjLY/UmszH
OIit+gFtpC2Jtif56G6vcGQcJNMVPFxGNXVMhyL5012mj/v/SBPf2ZZ9HwqwPgLCrUNybG3U3w8N
lssbYDwFbGzg7e6nar9iwptsfzKEIH8+mspbUGP4ZU62zR8pT3Grhe/h9w3ePk1RN8gZG3LuoL8E
ONba5AUydvCfitz27b7TF3qpWS+smvzkTld+dr79avgRP4hZDVW02ubDWH2xIOFcn/gPBQjojm7n
Cvr9eZOfaFny4O86RNn0xgD7ig9FSvgIa7FNaCLhhoaLn8vn5gtgd8DsF/4l1tHP0QCvml37Z4V6
G51aEhcHvcum8ITtd7kYPuwz2qfMuC77gt0lFVaN/GFiRMoVkUCjbyRuf1zmK/i/AYRtENF8wmjD
6oXWKxOhrhQpSB2oLQB7yXI3gp9XJnJmOiIPV45N11W2XefUWQjTEuU1a24H4i2dC1stF2InausA
gR+GF0/W4qWeHs/oGvfgjut83EDPT4r5xxTCu1HStlux+megQgs4PmC5JVoJ8mj58KT3ZKZn+EPe
5GzlLscClwZDD7Z9KofGLZDK+oJD5onLcGxD6r82yI8aJReH6Sg9SML+Q+/LlBSb5cEFIVxS4y2X
0oplsnvKDDLxMsbBoNaoVf+uJyN1Z8jvLalX0MUjCC96Quf6dK5bSk8umIwIV3W57wCyqyAf7Lgd
vAyhnCC7RuKnHkYaVD3MD3yE+HSaWl47kZVVwUN7HFhalnnSXSf6BT91PYq+ZgFNK830KlnkpV6i
5aVDIfBTeBTwQpNvk/ssIWumkGAT5RQ+crWUx5c3UkKGqKCVOfTPzLVKSdRmMFG2jlBqqL3/oP0i
Ww0Z75T8/Zoix+5SHXZoXiK259BSECQ91RXWDn6dy75Z6fqjfrJTFHxW45VEEsKFjmpIcwRGEgw4
Q0DepJpi85ahXfXjj9SwA/onv1SJKoXMD0BiTfVNCbDpa1OUHOwzsnGzzZMGKydaHH2BoUfWD+4m
/Sf8Q3LzJ026PJX3S4iYE/jw08KnCK6R1JDEGmG6fRao/N4pOw4901v/9pUYNylj//kzbLrOOls7
KDbzLU/2dsJBRijRBoPKo4VHmltgK8PinTAUdIAwsqlylzBnUOQ0TGdyxsJ1BViED3kc54C0/NWI
0AYTabjhuPI1QwQNwb9bkPGxyWrgkbTsqoa2fJQgSmFU/2rIWnOOHnPIullHOkk68dO3gH+rNjyY
vfPRyEqariVuvPmKvgOhO6l2vF11h6QFO/3JSzKVIWB7qOmrS3BEyyFxC02KUsrzYwTOJdbieeCu
gD9wwOxYvb8LETmNexlH6P4gxqAdQAzqQ5p7EM3wpp5CxeXjg3TmkkAmydwBc/9TcUorCgvC7ItL
MJEcEwm7GSKGGf5I5170hwXERUwM9pIMLQjPztI+4qQs+03QBkH0Rptz3FtoIBxLItM+IR/pJsVT
k79LkejZUJh6BnU2DlkYITHStvv06Y6QueZMN3/UgimEgxL2sGUZ2TLHMpWvq4lBFU0u+IW2gW51
pcgtT3buNwRd2uI+bMCrHgu+nURc3av5y+m5ceIF2LgTQF7YCHm9c5Ie5EEZ2DBQ25ElOgFzGY8r
8ue23RkNYWthbs4QXehl9b4L3y3WKvojAJV6f67zEG5Z8knS24qDc1smbulrIbRekzTAmnAyOkHg
Hri1Yb8t3GNRYBjoUSRJf+ZYhpfBnV9rfroGLipF/6kTtUDktFtIU3+8btG43SXWinWKZrHdm9II
wO9DLcuAbkG6dbk0+BnG8p8dFUcKSFF9LCoYD0tHK+zDSvtwss1dkEHjQ40y9RRbv5HPXGE6D5m0
OSBl7ae5X3wTjvRht05+SB+Zxc4rVhejc9RwmItYeQ+z2v5TIODAw80DQO0Ss3cnCTqOqZglSNQL
3lB7lUaTsPJmyxMeX3VdqNEl6KJbtZE3B0oTsHiyuZsgaRHt0LNVYRZR71QMOzZDxWTenX0EmR5Q
9wtP+paNIeZtfZ6qaHhwcBQOb9R4P8TfDvwH14gRyhWHAYeLwI6bbsRMldCkjHdViVsrF2dngOWZ
xydaHKJ2/Tc1BhWMC0wjKGdxMoLk5y9bYOjm0f5tJm7y8AeBnkiN9Feb0KhM24+2/tTYlxdMxFOp
IcpKEjuVjIx5ugtDhT3twtbvHsl14tW6635O09uAI91vWUvXh/o/gKdjDxitIt0U4CsWif++Dmn0
LoPjavULnGJjPw22nJX1DgzpV755lpSIqMJE6PwJlfutDfsY22nxUKGwMiFsetlOHdButd6tvsVc
EZ1YWIyAvAtS9WLUa0RHgmME3fB1DrqL48NCrdVbgLjl53EBVh1OEq+d99JLd+9rE7MYD7ZD4Wg0
aEv0s9DpPDyzGTSwmfv73AwcM9Zp6Y4/bNhhx1MDjffIEdQ+PYUKQotDiCFV30z1PtDaaob9QyDV
sYU2a7O0GD+tlcGjIOvws8MAZZ8rnhYv1TPzI3h14MwWfl5ZXCGOuN/xMPCPZU6x3uhEoyrwm6cK
+7T+rBho45R6MS7Mgb1JMZGpXvoSi7kUDvrgsfWVGF77iR3QPSxupDK9uxDsVLAvs+lmXHHJxBMG
Nue4Bh4B/iCoU+od6wK/engnPUzbU9hiAtX34xW4hl3Xu7Vb41gvnaD+7l5/cC7Vf3bBRx8sxk5z
sPNFncOx2+q20V83y4pr2PBvU2Y4u6NnN/tP/gtgxjtAZ37qQFjrqvi778+ae620PFY5Gzg1T92m
N1S9hAaISEuAOPJOZGRytbFYiKJif31G5vLojF9ALxEHKUHKN9hRi4qp+ADoogkfCJIsgWTyQlOV
WB/FJqPwwzi8lHQuNn0r7A2dSgoVg4ALXbgR7gBfhJtjV2i5HustfL/NBmj1N7feWK9bk362y1GL
Ig047yZNkKaDg1vjmq3ngiilIEXka0iZIKtvaGsZ9vDPW83mHAx1yyOz+wcOwYmUd+9gxHad3QgE
EKfQVX4zt6BWaC1TviMpDx1Sbf8jIOQXTZiH5Qc6yvq5jidLR2IiphNGEn/oHTdwTUmghqkhnBVb
A9Kj/6JTUT32NwkaJ4BjyUYokv0tFU0goU4bn+Zj0hKwzGWg/rGZ1N4Wd1AqaSguS1ZZu7iWSWkl
8HSLja9gMnpzJ19yx7n2I9comrzJx9KppoYjJaAH/WmN/5g3TmLYqmgdCpna94rN3NuDmh/oj6NB
Azh3O+rYd34DljdRs4rbQEBu3H+Gxjv4YsiL0rPNNy7FFsVpett9fRXdPSP5kVWz3solTJyy8NBj
xYF08lt/r/O8xWDlGXEO/J5pxe8NYrBLxY6R6kZfeW8lVkLG5+JeEBpxQFp7UxPF5ihFBbxpxkea
cebhzCZQghNkLsQQ1BC1naacscXHcKgm8NSN5MJ6AFTV3txv+gqRGoMkIoRt4reYVP5j4NtQGnmu
AozQKVoBDMF8nyB2DAJoZ95s8+dFyz+GfR9/iZHkk9TLMJueUFi8RILwgGVSgPrVbJMaHtpNSb/j
eC70c3+Obl8AuMVQUn1Zd7s7VFgwa5WQGxTE3etA7DvDrZtAjEme2nbgaNhdb4qK7pU241hs9jmz
HBj28v/NkPFSt5dEjFifwPwuCt9GvxPb6BvfYS6c8G3lPBkSDMyDnP0DMAdVsfIAoixsNpOdz0Ga
ZQy7Y/YGeJJsy7MxK138OlJpvh2YUYC3aaOCPSuJO/QxqxQwHC6p17foHMfaV2KZycIoIim/cY8n
mVz7ln0NkeNQiLuLo2ePZR6AU/P5b0tsIQ8vXwkXpos7+nwBPGaHSMRWb6/+BSkNaaSg1KGX4IhD
vdzuX9qvbsy7RvEuBxeLMFaWwhLcH+UTDf0MENR3IiJTmStoeG4BZr+zeP1sE+ChFvnNFeFEmox9
SZsIOibgGHo8dqP1Xa+n5wO6Yzb6otGs+WKw/w60+mhU5yQSyo4lTeh6vPvXlb8iwgLhUDaG3JEH
qeMV4UjnypcLC7n9lLxhOGt27wKEeFxE50FswiPffNNlEcBEmgitZZYpWONyMvsDThiXYg6CQzt0
stL+NYC2rfagIwTDbxsbTLYBnTBFhp3nzp8OH82v8AqTqSQMkNqZFmuMa7WlrjLXdPFpxsztvSO6
uksniU6yLnkdt91fjLpcTYgxfIMpzm3vpEJE5ATvttX+KfKL52Fxdkw8fCo0msaMI0xW6DkPt0pA
sTRlDEHjmpYUCcQY231Mg1j3AMxLKo368+/oqNBZnVzfYCLtn4HxkYtMCMUQWfWWo7flR/vSRXRo
qfmTuuh/5qzlHWgoY7XibsKtHONeAXfJwwYbOfYUd+84AaVNoqxRwS0so6a1vnhTRNYNa/JORDbe
qa4rLXz9NWXS6Tieaodk9dOGCqYTQPfjZ2Ssp2EEUojptkYUfldWetvKpwNZObBZGcBuUyP5WDIh
bMWKrkWD7QrbEwnjcX6qYrY5uGqu+FYpaYFDBPcLWPCkqJVBMnt3ir2oU67dhRLK2eROuTgHKOhl
K9EBOjnaWbgNXm9HeWHfXNP2eo2K47y2mk64YRkrk5nTizDaop6nAWBRSwZHNM6VK4D6JlwNjEgW
5myKcG9WNpzKqZyWWWJ6WHCW4TLcne3cXchRuUN0H2ftBvHACGJo9SxDvYfIIjM7dxD22XO0ObM8
A7Jgjg2CF3TxGJOB7levQH0Oec5f4RuYiI8G4iUeDeNOA6L9TaaCkhoXhtwDs9iVZFQb9FfpdNg9
jq05UaRuooSzTkO7ERWBjrAixPuic8iINE+HwXNmbDZUGBEKljLXr0UfpRbD8jz17l4jQVj0DUM7
k3U9k+pbe8toWacFuIOV0v/1IQ67K76fHYLzluxTd5xiFyYzV5619nfbIOiR5AC/aXWcAf4QNycK
fwXdgwJtZzYXiNqoNn/2Bg+DaUY2Z6y1i0RuErOj9HokKTrwov5EaPr+4nag1zCc59wLNCUaNBf/
4YWJMlHhLalB64nrvASZ5MPt8oP/w/syw23UJq07nRcL59Z6EHNo1p5FTABmkxXo1AKuClqX4ZR5
Ppu7y6w7Y1s2U3U7BVbkRkeOpcaI2HiKYeoOGex0OJK/Ou3OG+kcPQenv5QwjDiYEBykNutLkFuj
lYmPm7+esgQc5YO5QPnf4Tg01Cc5qUvQfZX6LwIuYo7Iq2fUiZ40Gse6tYaozNu+t+UWlJzn6jmp
p2kiaJG7KJ+8WNY19WqvqCYctBDXVd1aRf70WJfOOzF0T+KPb3aV+dOsAvpdPHiNjrz+KZJx5XQU
JIkY51oadFBkQrbHIUsmrJX4Fb3wbcWAOQPRW9b2kUJ3WfYuBD2q43IUsK/lAv3lwFbTd8j9iTN7
5p7uuuoUniAShmgErQACwuR0PT3kz3dUbzbZ6mVlvdhHGN/tPAQsZiMDvG8zetltBZTHw7CiV1Lt
SD/zzPMP/2lsi0CUyDIhB0SrFQYuRdVnaF2ZMTD6RI7I2vJs15qgSkIaqCj7eYoSo12/h6FBOYUu
LuEEsMSrIuT6wuqrrGTnPpsEaMykN5bSWdYSFRUVqVo/OpWHlUEpYJtQvmuexOY9LmMm34lFIb3e
08QJrRlUhkkbpu6Vij4knu5GkdqW3sd4LcJ95ed7xuMiGTetIGAjYtR3Z8Esrjy4c7kPEolRW6/x
aEFrSuIbUQSDHxns2tk6KluRjtpe6hh7ZcNaGQ/1nTSJCNGyViRasq5nmuDNiSwXL/M1udw+OC0u
wTdN/+RU4+cScc/O8hwMlWWwrIsWHxlfNogPuLG66iuLXHWPwpW+J1GIEsbBNl2WEvmofGpBAdcI
nwqlcbI0IV5J+5ov+EYxsQWHaDPdLePQf/LfNuK9LWav6DxvUKS5xPydkTctcxRgKAaNs31hwYEF
GYYfrvHxhvyz9PmJW//+KYgmJZmbPS0J5WCu4ZJYWEthnGpeeJQtF/kqPkzTFwmupVWLnaLpfyEM
3JmAt3HRZM4vt8ZnZBxDUxcakficxZ7xT+N2Fu335gxquP07LjKicfkGokVec3LVIAOaX9y/sNwQ
QRSh7CiebQTH0/oLwnFA4NIggt8LUMTjdZbDj/QEhtsj0/ekwBuhWEPDFhvNdnmvttcEZru/f9BM
Ne452RxDUo+e2wiuwfwYf46WtSdAn4a2n756YKtjbp16IuAIT24u+zuyI+WAgphanyYIqjmsFL2/
SUYPrYP4lBQkcUzFPkPusCEAUzf6G1jY5faDqsvB6pPH/TodKSgT0QSTrVzP6/dc3yvAT20FDDHK
kB6zGeILuKFw9wVPPOBPaTBDEdWvxqmhdtvbFiNteyte9UCJ89foFvZ2yrwBJsGNcVhUIf7zOEyz
VfAK/LJiXCAWcmQQc1cDuQjhgdEG46QsCEtmhhSNFAESziJv0oC1JYocYJLuOLB4+5RfQVHymMGo
qeqKnRTh0MHeceDdQK+LnkuzTkkH4afpm7EvnYCyJMkf+wPayr4QBypeMp1og3MiEWe93WBOKKAA
Rfl15eBR3Y+Ul985PPdhkAZGDy7HRdHyKrrzp/5W+bVXj39ZTP4wXXxy/R+JtWkTPp5+BM1bwcXV
URtMAZ2ghRjVZslBUoxeuITCYVEkKWlMz87qlIoYvAhNpIMxxvHUiHARPY1QOjGMqdmvNK5xidzT
YTJNs8z1QBZanZHavP5gQBmPOrEqAV5u4U/u6grSc4rjw5DqNweAJ5mZTDbTbOE5uiFQnUuhBkl5
gpH7v17lr/T9Sib8NagREBJlhAxkqMHIW2PQZ75p2hSvxIbWxzpDWTZD8FDfKItXp5XV5+rU/YoL
zQ6dCnhlqBMyMNDfWQhH+UDFSHne5/KeGFlmDKALdQSZr/sNjldnS7WarzSnufJhAcldT959WOmh
BSN3odQKg0M7SFHLD4Ah/KK2CjYClvF7MgHZbMozGFZ0ypuaSoP5G7E55meNcH2LDAdALGyZIFLs
H62QfGcslubGCTWQAgEvr0IyaMbwrD249u5Psxg1i0m7GJXbiKHUcpBYk+JOHJSl0vL9pDfLFDh8
ZrJ2yhnhy3CvYwlZUITyIg5hDyEgScf17eAV+R8ZQlzrHMJUGt0PkLOCm7xygGbM+F3XXLNkBLc8
SwItgzjFA8EOdD3v5nXejmhRtpSghCYeVZ4mRs3n4Vzul7KzWUqmXs2DuORySk1qgRLUnTHb+Mzx
VW1OpCZOS+yz2bVyGDx/AADiKkRXh+zLboPWuaZxlxZZIzOl9k7dWtSqGL9IzsCN2H8JgcvLQ4Ov
P56i+Kx/His/uzGz9j/bo7p/fdSp71XKYQDMyQQQIpA/vvH4OQk0CeQ/UoBrv0ecm5kMijAH+53t
bSBRd38ps4nJmddYIPAqYWd4eo2zvoF0BXJd+/ipiqGSoVUpjS3oTm/NvXSgnwWlocKuHrPJejt5
TCH5vha4z68MjD7+umN8fq9mo+M/SJH+3lu0fMjjqVzKn3kYqgM/SmdVjci4YSvmx9O9MtELfxy6
erDWEPWSTHhBQdQ6OJlN67wqKbP5tQNfTdAXm4ipdiqSh5Dt9ONEk0WWAAV9q1Rrg/hYzF/9WUEv
uGj4saxS2JzzFpRZ3U+FvflQ1wixA0A/JPpAd24/MHidTkkuWwcfEVdaNwMeoRJND+v3tHwgnlBA
0jUigNqyLOvF7+HelMVOzWnCGJ6G8RI8rwxxTFxHeSb2MHxheQnd49l07ed9QCmej3pKkXz1Mm4I
IbQIAuXmvAmCwtfygxbqQiXYL+RzKo+TIdOhx30z/0JrX8apzs0RIegVkXrd9HuninCU297fgzkd
xckyc9bTHau7cWqSoKlGVPoRI1ao8zn4LPkGY9LOfI7pDJ/XcaPnLu15Y3xCmKVuJoEBrbbwR1W6
d3ZvSlhPJ7EmvVJSpr16B3C1tnBETUi/etYqX9SiXmJzLBh9xy+S0K2Xm/Fjrecj2CG3suYXZRGs
dbYfLUT6+wce8idtW249jT+s+gWUh+DcFI41+9Zds9L1pwEh0WZXmjJN6H6UfIy1vXoBTfZhQIoO
hnEC9J9OcLeMgc4+WivrZw8ko+rQjVKkTxYeynj8WR2kcFaMX7DDd/he4/ShUTDQG/h6ZDfO5aqI
P1h4CqJ8HuAjF9u5DTH2kRty799mPknmMydf7Ot+fqKxpMOXNiQ5D3yrz8zNcwXtkvEDWjaDM0sm
0IO7JCp3FjVLhTLff8tKTykZQywNumUtwafn7HYjSvAtLZjQbH7MPE/V34Ygx2NzJrIVyp36io3l
z5Wb1bI0hJ/3OVtXIgmMgPxrW3xXItWGHch9SMT1BpBbNDXYG9M1Zq/3yexyL/HghNDqnEMt/gbq
2cMMVIFyJsJPHmI/hSBI1vmfGuYH9tuNse4CKFKv5VjENJ7HYJNch3GAIj2IMhoAk7OYQowWBGE/
acd52fQDcp3WuoSrK+Qkc3a0ZnxuvxMCXM2o4QMGos/OaWjxOv4f9cdv3T4v/ahwVI/H4pkJzdjf
uzp3c7xDDPtR0fdbiiN14kPawxTmxW8etREJ1QzgT6hY1zACc5z1gS2S+TArKEeZPOdPznNcSGdm
wEDIORM6VUgWxiGgeMVkYNAcKKcxXqOrP62XyZQuqGX4zRMDeer6A/HSm1CmZFDlzX+ElPGXox0P
2DrBrGzeiV3V+IG3DCjQDHvb1vQXBiRoSc0i9yonRBXD6Xj1IUyOOrPPBT4nud6smN5AKh6/2Jrs
ll7KyQKyKPdV3dRDgRvwD9Kv1FCjOywTckIwXUZHcP0v+DFz39masvyO9sAUNUak3vF6Cgef9Be1
qu8Hnc53FOG0hpNpWLpDRa7Nm7fmtcHIBTzf7nZ8XUm7ro/JjqwAnkJS7lytqrEC/UmtF9ozJnoC
Y9Q13r01lhNp6r2B9YR5fgjeFwVhQsJEKkTkvKPmIRV4bSbeG+yEKvTv5+kweenqR8/ULGgQJoUi
fAYI1tT0qmOm5c5R/VQTsVQq+6ewyvJ/yh3f2VpGJS4l+8lQbXXHsMReNSi0K4tKtHhKg6mJRaNa
Jwxqh/BSg/xcpMhOBz+K5RkconyE/lygp06OKmDGAs6/MhEOGzt77JnuN6bakaEPYlvQbXhqR6N9
rCyWmOMjG7j53gZhM+g2Z8XfjsQeCM21bsBv/TnPBG28CTLnx+CtZnIjnEs3t/GYYjIsRqOe8Yla
TB/nmKOC+vo3wZNaCStG30Npz04U11yvJbdZGkt1/QWOC2BzYo4yJInCKmzezNFlVY3C9JjAqK8B
TQVzxAXksvEZNGLwcbf50YTz9teOIaOWTn0CCL7geN/KE7BvsHJvRvFZey1PcWBIkgRPqH31NYo1
pPzhhrK/bOd+qV6DpYXGXsn/vMC+B9JXBOhVM5HuKOxChgfk5MuSUJJmcKUf5Vke3lak0ZBalvH7
YxxM0EMVrHxeHBmF7i+XRMmfXtiRhSBBW7zcBYcBqmMvnHJG6KWqTk+W12tbqLjyvzjr4Q2+O/uP
ABbdyaeqT8KaukHDc1nHA7emMr0c+xJss1kZIXcPnh+GeVyRfhIrJwKpCkIXpfibRvm6hzif+ufc
yKlzQAIyBkamQWH2qIt7wIFpektjPN2Rhj14IM7keU7KUpdZa/b4JVIQKCQzSIKnEp5E8nVYQN4V
YkewLhuPrliX09V27RbiyzwMChSL2EVhhVtKw/Nzq14M9q+eNHRQk/lDVuAi7ClGZ/uadQlzSovj
/Mny0FMnXTfJQlOt3uiwxJbdoxKf185x2CLb8cD3L2WRidCRxomgHjDbxenfsb8gLuWwcd70pkdK
9fuUFYajtIBkCxIdwxPUgUItxAzk8089UvKDA4NZgeG3SLkm/+Hy5ZB6c2e0bwZtIIJ0pkQ3UYTL
a4Y4wJHvtx8ESZhv+aVGAcHLlnnQzHilZmWiTtNI3GnZ3/jYiXD/a9I3OJsB5BP6khExoJE4CNgl
rhCpI9TghIDmYS8GMYvIwUXtf5G+kar/ozy4i6svYetyO1p0yKuUBoViSN/d0SbKb1jd6VQWoGO3
It73cY1wKQg9JN4bPkaJBBVt5OG+ssTSzksvloCMwI1ovsXI4TWIsv0M3r8/KFGGCKwcckfKPPKB
9hgBhkmqePl9iERH/mgID9Eqvk9T/KZjwRUIYdCmeAQISMBQY7kSMGE0y/urENBc7q0gWfbIsORQ
DWA1tqlRQGmZPOzKNchmYMKOLNslT8RKlLkzj7g7l/96EZVQu5KAajU/nqGa/yy3xs84LF9lRnye
hBXCVPVaKcgulDUxZRvDgidfW+Vaxs3G29KmvaF47A31rwAz+tsETqEQSJIBgkfbhswGE8WmKlp3
T1LB2SeQfgIv+sclK2Gh5MG3DAvBcaeUxWfnAoRJJXoG5znFTEzmjhti7kA8g3yPyzFnqP5s73fr
/hAh+zFS7wr5lW6mcEiGSjKhLSb2jBomG0uE2fu7aAYuJcHiiuOLNhPZje4VuVYb1AojToRzFUff
b4hxVK4532bjA4gtaDz2nmawNYd/txJHpiVCNEwBH23BwSXX6dqrp3zDahDUENdnEuv9cxTy84vy
XNlBgblVwcvsEA7kiUC0EdrTT37s67RKVOIWassecdiJj53M3Y/pf4WSExK0QpQdB7js4rNPP39V
B8N7qryDplksm+ph81/VS9u92DVPoqaMxYKcipWcetqU8+11ZzIrZlOuN1f6+B7p1khctiJBiEBO
84xe53D1dhxWzi6XPEa3TlPcQ+WQQHovXHde9z2Hw43BYasIzFk1eJkYnorY/0+AhmKYbI1pbGA1
U+uYILzGr6zOaJn1S4fcJMBv2idvXM7qr4iIuSfU+Spg9EKnePBWoVlvi2IaU588zDO73kz/MoMZ
pabrk5AWFLvRS0nXltxeDkzO7PjrpQ++itJi6KEjf4wVbfv0PcG9jn4T74nqqFkAjSunTDPeYzCq
AOXUv3S7yqagUZQB9j9KXkUiy9VGBBaJK5hNZIQxYyybF1IAw0DQpX69CRnS43LBHe/YnwJWQZg0
x5FQmq5bP7LCQLOHW2Y/J1gSRWb1mmLbjptHvS7oTzPMbEGSGMnPaZg45W5Or8/9/Z7/XLwOvbZ1
ypDMDSLefAPWt2XxoJV7Y/MoO540amrAW7fT2V91MPcirpUGQzh/EPMhB/rGCoQC+BF/jAJaQwhZ
DZE2wkw0coZcYd9sJaktJZbTfu6p88PNaF6TtHS/YF3GlOiHG+lUItEXf1qUbDYhmRNovnBbZ/dB
QeMzomF8R4i25oDq6xFcBlvqz/qP6dtlgA2Lfa+eQAnraGhIkSYgnsxjFDz8DVWLevMN0zNbuEmg
Lg55VhWKr/KWQim5uMXXWMJb8haYEyEgXVS/SBh8Tqi0+9sghnwq+sCzhuq/mYFODUc4TE6E4LgT
9dLq0TL1ZUtvTspiTiglZyJc7JzUp3X6DXnMv+ZJxX9ccqdK7AH6erGsYqULrk9i+uHwZ/HFp5OA
9/8TwcbVi3KunqYUQAdF6ueEVhVytv5d5zx2ceWXYjXdyhrL4JK9FFz2ZzaJxC+R89knUxuUsmJQ
YO2eAu2Xu1s6ou9TUtnbO4SDa8v4qm2LSSBubgfNVnYxi9UV85iz1ZHCINmyW4j3ZiP0xKTCoYLg
sDFLlZ6jXb9sJe9GBXl2oE3MTtTBiJHxgr6RE16BGbQTgp5uewioGvdcLrAh//Kc/SLk08bu0ytZ
jy1NyPVX4hiqqGjd+0WyYNjgwoOkbBnRE4aXbB7uB3jUiVNOhlYfKZ4RuXdp1M5uPzRh+rVu05B2
5LJs7lFiesnD14EaDBPyAPCR7VWg/PnrYVzGHKdwqEvO6zH8/hEt1mNgfRH3U2whHCs4kjvd0qXu
cZhq+WxfyDwcccQGiOHCu8kV0EeZ/JcSbs61XuCK4iSlyWyH8Z1tr9GSmihG5bkFnjSKaFT4BBXq
FaNk2Abcqs2AF7CU8BCyxzZ1HtR5Ux0lKTL6i87TPG+CnaW+Pyy8t2ydft1AY03Pg6fkNthUNo0S
BMDLnxxdvxnZmc+OxjJbpmdIDFFaOFZoYweAEjGnwJ2GgHA2BWNpMWFyWj7Z5h5654DE1hN5f6gd
ZlVSiVawd1wBvXk7/UcFjhwz0u6SgOT6h1va7FfgaShzT2pyB8TvFfimmjZpI4SLnxnRir86OZj+
9mA0Uqk8Ux/kaTr/MRhT0/DhNJ13uccPgNOCgMCjRaqQ1rGQkYIyRe4g+1AlOpUNYfQGtY0NJPHh
aXWpky3PPGfyls3DOYrP76BQQsX5kDAd5dmmKBrAuRKX4Q5PAP+tWArUb75lmuQTMEBqDM2d5GxK
MR8tHRn+XN/3O3paHyBq4aHf05FJjieYvqUK3rcnmRSluhN7ktq1NZjn5ABapo0v+t0H3l34LLK6
smo81szRqcneeJmG1oz6w+O/4ZGmMpFWY47HcWenB7VfGk85+4TcmDv93ZYMb/n95BHxbXBOvRpp
AuQv22O0bqfyY0FBNON6n69NUAAAp23J3UM8XctI4kugh4mdaizezZhJKa4FdQ7s1W4KgaATaUrT
g1E9ZW8vuVaMsHfAHhGJ1yU1sZQqH3FUAsDHtqp6sNq0qzrCUZhDF8GHPyNycPFBr+PLpatm6I6E
nB7n7x9wwncg5JL4EO+ZZjn52NjMEBfa2iahBouP7nO5V/uooklpH4Un2HEap29bvQdHNu1Rbcag
TZXrkPEKjv5VxdTP7HUaPkLXBtQlenC/37d9EZUj4CMGwzvnu0GEjE4GMV4bhM2NLw5E4GBS8KnX
Yl0V9bjTpialsuAbl6msWcYvlwT/6cgX+miSB7UBmWDhv6WQVg7MuO9l8t4vL3y5QYjbm/b0BaOv
k9Y0skWd1nRItWhT8ZjkcAteRnhNX1Go17JKAcA5ZPlpQm8hJzz64+6+udRoi/UfWVjfhs5Vyvlg
2s9pT2HO3i0tZMbc2BpEyEW7NH95ATgLubeMI0wMY3EIYh2zIn7Z5Atj0h1OiXf8ZU1iURa8Z0tE
5/06GsevLQxgxZ/EwY9EsGjxgtWBM5H5ceIGHIb5eP+oRX/jN7WypTcsESkBzH65JR/Oz3kXspJN
fWvO8d6OGr7pn/WO9QBoVn5Qghs3QOs0fCarQs4plKxQVu2PYqI9PG8Ru8WQs/2PMHZ/EGCCa4Xs
cktA0prRqikJNZdD7XnkhIr5SQJmTJR86XKdPHMXZ6931q81Z0IbWK79WVbxKIOQmbO4K8SlLw7m
FdL7mD6+S//Kd4l/UFAd5XTRbMyt/MswPkr/kbg725Y+3RcWJKyDwOU/idSYMXz7UR201gdlPvII
A5qA2z4Z1vt7DqrM3ZmuwSKQAPN3b02S0U71p4WAVu8ZKH0PtkmsLstAH8w1myO3eQxgm+NfSOt6
7XT+uiJmPXqqPsEBvFcwVxcWBt2ZoLgKhUoTEugw3e1DjgX0hArkvphizmVo0btdrJm2mL82Dvwi
mxaBZsMAZ83dm4nbly0uSufyPcLAVVMzPePpfFB06q28yN/irPnx+vDOB9yVjGnV7wMsrY7Rwwk+
eUl5E3tpz/US6d+wqE0uTwgVL43LSRRS2gRVcb4va9Y+f+JoBrLSzWt/fUCqb86nywBl8DbzoVXV
pSFf+5a4A2llJwWfYeQKtPwt1KUrKx597quI/kyiFCdE5LtQBxiy30Goj9hygwQVMN0unrdybIIe
NowA9+d+u61DDY6AQxEECxrOdqV8asJfBOhAxck7EI+zj4HfzT4kHVr+srIBjNTvN/aEC/+OaW5p
SWG35gn9rb7KHdBufrbDX+vBRYZv5m9tKGbZGnpGV5/EsvJMtQbG5c1L90WZDGLeX+Mx0yV7d72x
tMzfdnJRzp5vVKLOhYDRBITGNzj6b7bhclGYTKjgcGOMcdw9NL26hojWJBjPBWL714HkoGApm2H2
k9U5V/CrGUCcnq6ACbCiuW2FQilG3AVJcaVjECqPHKbu+kJABiFY8UMmPdmFdWihZYTU45k1l2ZI
1QvlDfl2G+VV+Fhgli1rNtWWTr51H4P3rIrLlZj+XAMJmMjqFjd+TM2xyl19nzme4Zc2ytL2jm7Y
jlUByUdsDJxAYo2fGrEJhx6PEdJJ2HUOTFPzCY0mcXobqIVEuE1Mfo4DU0JhYeVov4YPbu85O+xr
g+/bjNkjz+kVc4MKCk954sAaIJsJ0Y8UM7YKUyslJfKra9WS0lalRXbRdDQa5bPZId3NddCtTH29
Ki8/o0aWQ8C1CqGS5Xhb8Ysoi78as/I9LkEB31TcOlAyPx8tSyGfeOjkLF3Pnf3iGPD5s3AQA0mG
iqichGgdhaHPfuJJAmqZzJgMSmlkAC3dT7In/Wxuqs+mDdznw1TeM52mYaHM4pHtLDeICIjZ4/S4
0/FJ9kjPNtCvUq9E8sxnLbHjUnxTRnz8qpElc0sfSjxa28/3oBmANPXFhojkUIYgykB1UGuLc2UH
FmNKtKZYok/L0+yLUy+Tcr5B9ft8HFssZEPecpdDDXgYa3BJfOcPhBiOwi0QwDCkbBOPLbrxDL0L
JRdG+z34GYES8/bc7jdYMTmt0U0q9QXP3i7A9UPI1rSlWZp1Q8wlAMPIHq2gIl1p14giHp6I09l5
hC0j/9n72VOs1pRgC8W53AQAbkpt27xo93AsU4Mg9Nb4ISn2zbRJ0sCrxBazw84RH7xfWRLcvvry
f1MMdeo8DUQWbrSHAJQ1c1pVnvsyKqT4rHSGw7zu/db6zIGZcZBOfIgHxQDk1M7YfaPDqcwk3jUB
NwENJwCYBoaKwh6p3kyHOhi0kgPQntsmQ5f5Pmq7r6DigGU5jNRL0mQBYB5MugTGFm27pSs4Qf+R
JbTgqcuvoxf1h7YrVcjlBDubMhAXmmP7oJ2v0l2UicF6IzUl2gwSgfgKDd1dSyLWsNcAA+hLUnRV
4rbjQLsyCfxiFVP5962pjLB1GQcR8p9zm2Y2qgfjs2ffLId1uYVVWD7WqqxWLhQEpxJNiiHKxCku
CPS5wGWosqvp/IiGv8jxm/UleRrZJbPnQhPHttRgCaZvTDAq6Po3D9DsA79M5TY2YM61wrTBtWCC
xX3ugE81rNB9RDqudaouF1YsHIrgYpd/Go3FmPXSW+fqUQLzXpW9aZRUOKlEOIX3BqHipOZJd6VP
vBJ50HYNjFYCrhNRYMFPBBjg1BgxF5texlOEJES4NHRDz6ihq4sZqLsljKAQmGB8gj6uL+oVqaCi
EL5pqz70BX4dVAeCmJ0OQxhITc8BrWIGnVYw/hBzauZ8EKcYDzYIQUkEUKo9Yd4s7IYLtj4CFDoE
35uwt6ffzGQY9e2qLOlnRg5OMOR00kLqAC+jQ4z35FpO/Rs52ZXIKorm9odfG9T75gZa+42kdlBC
jbsuOabbWLWlLekLQtit265Wnv9Be6rb4EHupAHnVY+TKSJcXlCPqaQEkLoyZfmHE99NnJKoOGU2
gVJfhRstx8YnRDETD5xCLat+4gVFs7X8DxBD/yluIeR3pJQLZG9bwaOA1aQjyn+We7RqWiuqhwCK
Vpcno1L6U0L05NfneXALEoModybbbUylEyvAmfXeKzipq/Xy7ctV2dROzk/pJL4oMJstJEbon3U8
omijhSN03EqXayu7YybTpTmQEys1214hv1bRy/Hp33Ahmz2QTNO0ghcJDbHCaa64DS4UAOJW47oJ
kgs5H21Ny8/yayYHpnqjTxKlZ1s8irSsPIvgXChSr6XmpfZzjC6Y+RlwzZezX1QvjVqINqUiVKCj
Npjg3XqOZ2Hom1cGvRZm8Hkz0Kx5JkZPiApx6SfCBfdIAAGh0P4k26TItR34V7JXjLh7I7Pl78bq
m1nNxIssWROiWxMHKZG7dPosklf19UpyiMcb6K9b4uSujsjuU+okKWfcvcddtwmFmbyANa2yfHvd
GCNcogZPgIsRyG7tmFJCMMU+3mc1/WDCWk/UfYXwaL8es4GN/0jsDXW4fvaxWIQnc5GOCMY+WlUk
gdnOJHAjpHjTtsa4VR5F/la97P713ty0BAI5qtKNjwDQfxm7HglL0l/E0MCy+l3zBoFZyPaaCxkT
twZ0EOZN7BaArbhk0YgOgg0ZyLKYR4KYom33Z/q/H9QwE0mj+hfVku++88sMBYHMd58S2+ypNsbk
F/N8sI9y6ODD1+TpfAMXL7OFmjX169xXjn2U4YjL/WBbU/OZ77FTMRwLGVIsvXmsBEDnZ917cH9E
QOKiLHfFsjnOYmzVQsagoaKa7TC0m3Ik6ZTsN+A7wL950NqPGnK4l3557pkgaeTihRwFe7hg0QbC
BU3+YjYrlMxi6pTRaug4vuH+IqcFvHAWoCraRPtzROuFcWZsI0aMC5TwN3TMCpp8afwFespRG7ck
Zhb/upgJtl3y5Tjl21EIGirmoSUY3Izhn5bD7pPib5P2OGSCLceVaLlsQpr08dUHA/dgkmOi33KM
uzpLZIq+JleN5tURiiPAsSMpkC4Z5jdRdIm1ZsX/De5y+tum3XrPR6+pmb+7U9h1v/Hu5KmveCIv
cb0wxBjVOSy/vMe+2fmlh5hCKlkdY/x34ggWyM/kvN7/m4wcoTKXT7yKHLYtI1ZcchOE17qsz2fQ
u6G7SC6Ea6zpgAAC0373r8SRx2yYLo66HmfezHfaBGUMOjq6G8VW266+rKdChmGCa1wFJqI9H3g5
fvTrUd7SlvUSJGwbo1j/Rz5gJJWUOuX8e144j4aMRol+jEmo0HnD3XDZrASQnDJhc6ClDxX6XVD9
hfhHDpb5JWqQ7iWFycNcM8azb4Jk3OfMXh7LGN2pbw9CWRc7EDSG1t8VYYA12BEwilkXwy4q3k5J
x2zpA8r3JPf0EBY1tlFxBIb7LhprC4Pc+wgoIDy42pgw7qP9xQ7BT+/tpr181e5asfCejSnSlyXh
YG+ltilxQBMbxGbikPYlyDRpL0DNpTeECuIh6Pd2NeQZq3Rd7zqgBsjoI0Yam/MASIYoEp5HIugK
Xx62BvF3hpHntD358gl/V9LEwWPRLql5oF4CG1/RQIumO3NgZupD+bZ7HKUSrm5zoF7vsqFI1AhC
UjeLhn3F+zcYkw5d1wkTCruIVp/NOsPGEjNPSHRYezJfZXttOSd07QBG1daORTsMbCaeztM/n5KA
rV6rhFHzu/zA6n5Tto2bXD0+Xt4kg+RZz/dMyAW9No6FM+dFKno2i1c6IIVpihh4ddVyI61Yp0Tr
fwsEFppKuqmEVjNcASmiGF2sslX3oWDH1tZiW1fkGawrVP8CKKAc+AJJ0bOOs/meKS4HOm6YotEG
dhFvVbFw5UJeSp1GL04lIqBTHRZxPKrIV//79nxQWpvQXiwi1YFdiUx3icmC0wwRbv6yZfq/T58b
dPDu3vZEoXtDJOw92eHFHJrnbLNDPkc13UToIhJuRPW9w5UxgTrYnRjVgl1BqkEd6cH3/hEw6ndA
iucA35YL+SLOCBW5gAZdEmpopBjdR5IXKoR+oTA+WoSGBTS9X9MaPRRAliRhyMfTugOPr0gwr0LC
F2mdQ1/ePOtaIcbloXxjVn118MFW8T1ylP46Ivk416wWItT96mEutb63J2sUQ+9IhkhIzwOw7QW+
lUa5htk0AXVn8c0uCd14iD5SvGlVyxhekE2I5+IhQKEky+2k+aCkIAcZJXizt/3nxcHmBr+Cwl7w
iubkFFSB2Rwhxc9aZmgfTJemTPqoEnjQZatyTYprpvhBe99puJvS27yIWI+762fc3CuOlqhDML4l
0gc2xaGwQEPMfuWDbVBHZs0wrAvv1nGXF6M0TcFlNDbQT+5CnMrGsIj6xlGKTI6NX0001jnpstDe
2hxGG7+i64TrXVXGqjowzjO1C15h+1ZnaJiJDqtnWkJls1Rx2jiz3wmH9Y8sxDZQxjpSCLmezQLj
Wp3WidqAbdRasJc1cAVBnYaZ+8yD83iLN+CEf5C7lTD6UOLLtjJKWfCPMMZ0HEA6C43zi8P9oc/H
HHMQoubYt/0jKUtaaIgNASoWuLtdo8HsJflbWzJMpWp9hNFtZOmYxiJCw1uQb844CKNTN8nLu+aV
DvCaPEstPKmjEE6r4i+dwCwWgkgksAJnK4pOcAmpmjY1tnKdkcp5mrUrNCtokyN9Fh44JNXxZQ8H
xZSBUdWEM5j/351mcK/BdqP7iHZPc/FngVBh0HqV/4YkltQst5ubpi9gSt2t1LJaIy7Qp0bDchMQ
BAplHWwOoCi26E0ywVp1HnfXrIe04LPARo61up4vk7Vw1QsZGariUrvGf7e3Q2e0OWR7ZpHEdhYq
MS6AYIswA9GT3RmRSk5nCzoV1x9JrGhEGdaW8v4mFbjGlGqzDOh5jTFRYL2ai/f/WnQ0BDGmhYGQ
Vz4KGWdUWht/xD/XTevr7f8NdVVPfTcwzE7RRg8/jkx8h9Cww0Xu1Z+KgvvCDwZUByso1DT4oUkV
CBGez2rUrmkhXN62n62FLqUtGsnyetOPclXdCmvOWSiTTvS/0kBDZz3xPK9/7iqPGeQ8PNSJFbs8
xR7hvQpAYJU4ZCmyEj0//MzhXZNuNXOV4cYXy60VPHwzFJp05TRPl2T6qFA1O3rsmKM20yIOjmiq
Xt/iYWHMW0TepsIPAdhpbZ9ICQ/NZehk7a/uql6QVRq+p0IZSuN53VmdhPQPE6irSKcQqLeMdViP
40HpMl7ZzK0b+n/INcTtq1pGSMoSuY0E8qao29itzOM4hAXkb0cEtXNk5zISa1UoYABbNvwUN0Qe
v05R75d5xcB0y6lDu2kocTyFzF/zIyjtbSSnS9bMk6odI3Kf9v5noVr4op6jm/Lwx1i7gjOeC1KO
FN81t5/dl3HNDGOMh7Boq9FoDKVP8v6W5DC6K+bOoIYrJ+W3C6Yn9rBanzsFgqNpyvjRGRZUT93O
dUvLbH3n1xuFi8FtzY0O2kZBSZtTAWDtzeGgRNotdvNOs5WcJ+3wSuR8JRW0aFiM9YHAUNkRODaQ
7B9qqq5F5Y97e5d/qtVVAoFt09S5iTVHAAOr7iOW/VRU4RHEaxC6X1RmHEm6cPN/O7kwMI7khqfI
jblOpJHHXE9F6fLqcO2mwksd7TXmx1YmXf4u2vjykQvYcFLGed3pqjuxQTSvSTAPaxgI1C+3qDiI
Stu1sXm9mFPc75QYPJ1c7hR2Xi27a43BubOpO6caG4h0HjvcWdP+ftGr6h20VeJIiPFp8X/wgIzP
oW8qYOY7hHXzHPoDamQQgJEfjYmsLZ+rWxF8yvHTBiutkHzevxNLN9VnEElcZlFV0yU8WgMoyeYz
XLyLXSUdd464BaeVTPqV6zuXYrhIlc1S66rqS5X3z3WD0xFiq//cpKi+6U+28V8nwhhvi5SXuuoi
o8wu2zhZvfI/PMs+6/ce6mA0KYtEOL5iyUI/MELh+Qlh9wKCGA/GGfkkNmvl2PBXkY7FwU7WWJp0
HYZ/jsu3/D4KabmOFFosRMbCAzigIlBkqwzNVhIOtsFOR0Rlx7lYgK7vnIld/PCpmawA3Cy25LE8
5S+AOp0nJsFmIW3BgfVQCN8274ZlTEdL6bnnU1Hupd49gq+BeUaSPWa8HyeDR+idyiTmQqb3kb0G
MrxBgBB+BEW4ryO+84p3SmBL/SZWEFIUiD1L6g8FP+QBBQivZjgR4earkL1WZZWMH64OI1pyl9+E
kT99Zz31u2nbnbS8gIgrCKO9TmPkq1Cmz6qeW+JE94x2u99x+1O3VTM5XD6EoYHRatSyLJV8HJte
AHrxpjzk8a5BeuJvKs0TLDEnWzOG6GHRNrrHIzca0UEJParDgD6j3B3LmgR9CnRFXzowhxZXP+8j
nDKKllM2FerFE7lvswHbPADrF6QciS/wUX1qeD9rdSdpw5A1PYOWjdDAKjbn4afrxhyvzQgZ7Vxa
VmO5Lot+1mwV60+UhaVEmJdZH/8hNz+nE4RmZTAIn/Z7gkfXftlfEK4KVN9bAEAg+WTQ6rlb//pf
e2SAVm9/+ilQeyy8qxVUPfaGv3Ez8hfWLb/essa8SDVdN8dwDGnAwrDo4xpr/FTNZay/VuUxgVGf
116+A+OXG+Qj177xKwV2QBM2QgCawIlym3nXvOxgQVO0qxkvsf1EJoN7Ncq4/hCddmBP79EKnc9T
4L9lBEaznvFMy893aXgkNaQMlahHKOz+ei/X/EQ95hkmd9oQmxdDbS2Ll0/hqvQqrqNXdgnjPmUU
3Cw4lgge0HW6BQdWCFyBtsyIg+QT4WcWZ1NO+sqQcsY1urJAvW+UE/oqMWCQ+xhtqbwSnvhxJPQo
auYSfm0gmBAR+oU7GyhY8b81u7yeveAIHKRbece9NWaduJSZJwwrwFEeeYWh/dd2BZCZHiewpPSa
/tnfLs5KZ3ob8b1nr1sJtMN/5Ryk7piyZaivj0oQkvlH8m7dxOuVChy1F1+QWamL3tiOx0M4jAvl
WhLJNyxE8S6wDYWWfFb+t1L6jjfpuGtiQl+7mr4u0E3MzU8mJah9+we7IqfiRfTuIs+XCQC+b7nl
t+XGgwwdRL7f34vCxKeZub8SnVGiBwqqTYC35WbIUJbBz690GkdrPSFVX+fCI5ILvKn5BQHLcPGv
If9WdLEhQ4F941gJQTOn67gGsOX+DnhTf6gbMjtq15zxQJEtesVtxGhHcj7nIUcGSCid7KVg84Qn
bohoQXtEYDdpmPk4NeSU00KIMPXwhXUbN0HtuCHSEMKKrQBFsM7QmMjGrSf/lcuPHAQcGIAE5a/C
N6QIUGaFVjNVy+/bOz9NatmjTNMeGn6XO0zmnz0F7lI62vzQIN4x2b8wJv7XFEgL0QCxqYL86QWP
d2tvq8hgOBLVDZ2S5Dek67wyj8z7R4vVRibxgt5BDNSMSCxbpDzxi5P1ojLX4uavmfoyEwOz0TdD
c/z8LdvNQIrDm+nope8m+rpes67F+fWljbJyzxmyLitvjmWydTuaz3jPP7hllbwLPjt8tCbygR/+
9o8C25tRP1oT1si8C5EcnQycozkyLCIfnB5yiMDT2qFyEw74WvMuwAu42Q1hBQwz78IGT+iw4DeR
qpZ1yMA0pkVgVbYOL+IpSH5wW7hoE91Qo/lh113Lhs/UBZZyxc4+GjcLpGTiY1/ppCHZiT8V+kv8
lRbF3YOKwVOjtGCYeBrDbGUp13wU4N27HSCc6OlEdWINSr6BInLef1+L1Evn2KeGFnNtIX3TieEl
4atFnQATXZtvQkMAHc15R+68qt7OoViG8rDx33aCdHRkyJHYIDeILWNGV0IcN2JJNmmPCBQD0oMi
RdWSgTooZxs4gYNi3Y68SX1eNbxsTidm2DlL/O0nEmyO6z/sMdKp3iN5Z9hqv5G8Azudy9azlb6U
H9xZdgspb6LLDMCpT2xNQ7srYpmToJU7Sf8X8BE97YIit37CVBmfI3of0x4AcJcUTHRPFwm9EZzn
iwjXo3KBMaw38mR0It8XDBHuXKL3XIrzSrL39rQ5tFI80voOTe0x6Vx6jiN4Ymj00YAFsU2kHjmt
zmF9H2/xtYzFBOgjmgxuVPEJswFBvvvf7hTb+KAmh6j3v7sKbongCu3JarzwX1QA9Q/yZN+oghkK
USrqw2wYZZGfnQr7cHgbX0b86ifaRtbkhOiRZH2yfascuaDQTkL+kdRC4u1yvyDYiB1wv7Wl7gav
6ojFc+YsIPOX+LaluikZZ9t+yNokrhm6FlIAG4lGgl3iGQFz1ZjjSBAJGbHHU0xSvgeY2aKRg/Ai
cvkaNLqyqiq7Ws5Alis/bA8ayGuzXJiU1VVleXdfZ+lCWXdY/HGPogGyZ6zrrPeuVaoYaon4SSQr
45EU0awRE/8+PjBboLXSG19l4rwi3a3Cnt/AwPWxhYSyYk0FHfzM6BNVmKNM5rTlPPL91/Mo2vaw
AgxrW/6Pxa+0MbCy2BreO8YyoAEV4TvZGG4PzPu6U7GctCzT3OYMK53EwQkeBqw3W09RNL6V323C
rX1ZPMUaUcYkg37mo9x9kgcvUxvjrclmj4hosXGFjimrsjalfrMEVmkYEY8USSgJN0zBeAVifk/o
C3VqQA2/AQ/0RJ9j9/5bNQqvte5huUEPmfDdburAsS9OtTxEQhOcdTZID+ISpN1O+6GuigmTIbQL
b/vggDj7Ynlwb5pI7jrhf1Bxy59NuI5R9zfJzcYG+Ax2IqXFiLJnJswpXST+qeEF7jWla2Ug+GH1
H39AehApWeHYGXf3pu6ypAb9a/D6p0V+tWEbUPQIFyA0mCivFrKOGwT45MWp50d1/KIq9JzRlXAJ
sSuCjO2vOIQQLxHgprVFljFpkn51PAiSID6TYeW5Nmc78d9x/LzsWGYrzstISchxdZcyoihFKd2I
aFl4lQmYlWr9D3wM/QtBBhxcnZkGARsR0dsauLvPLGwE5NgciwuD/XG7r1I9fEc1B5+hb/TNXCFT
1MTLkv6PZ9hd+qaoO4HXXANDUDogaS/Xusg71S6YuPfF2VdHS521flD7NBZxBitTpADCimK2LMpc
zbcMCJbs0DK6kWambqB65ypbMy7lgUUmdoWWP0+LeIdJ3RmXDPmMBWtqg4KQQNiBzblgq+IFtsnJ
iYY9v9XffKv35JXaabzgg0qhbkU757rNoQx5rA+2/3l9rWcSaECsm81HbMMPrz5UjVblKWJqJupi
2z8gzdpnoBvush87kmiMYvS2OJFqJoMy2BWXPjqxNP1LhBbbd73H7FIiDj+/K6h7jSnVaf8b1Mai
Uv96J1CGBrYNTIaZ1Cj1Ns8wOetYltpxrQ2k/8LaMiSwdyb6d3sUxftl1ik0xHjdGb8sln1o5Pea
apc4GnvOUYgaglw2Y4uY/KTgsDxedQfi711nnXjFJhwUyZ5UgVvjurceScvq43JBTeU7kOdnqV2R
bqjVOXzOBKnRIJJBk8fB7upInNcavxSwqm0Upbd1FNMDteDMEIWRZqNXM9CMeBvXurXfHRz/b+oQ
fSP0MVBbiPfmg26eV9pZOLEuK+GDwOcIKlQf78/VWznPeaDppAeESB039HBWG+ahreBAsVQZ2+Dw
BWAQPvL0w8mbwGgFEQnwcT+mN/WppfdViV1L0XiODYQr5d30lN31+7iX3YH0xqYthDLjedqaMerE
Ld3zP80VZjiC+CLceReE5aSdYAwjgVW6azsGJxuSBURp+DqPsF1iaQD52yyadufKZT64Ty5ncsac
Pn/8iRXsIrGcat9O0cia0rU8sE5VzXIYjVWfQmwhSIi9KKhMNG1b+D9Kp1V8SDliTqz4iNl+WHwM
f2eOMBtxHdn898uTOGWJpkwxKNcx/u0fflEpue9939y2TUZiIW5nM66EzLFSfiW49lH0IoyXdTC9
v31Yu+LiwIuxM6aTyG0weaODgYdYMAmQMdn8CuO8oAfmqngXnzOTGrVnEMkO1SX+DRDHWI9z1nB7
nGFuPX31LFOfBTuOw05DkWwAqfFFWeSZpPv8dl/4wHbBN6HERtgCn8R+fOnlieKbjTodhkain1lY
smnTfAYa1vUThQmHzbjOCvodtuL94WNy7fhczot73Phh2OXTl5g6fvDuSozv/rWAddiHSDfcuw0J
2yNI5UQX1dvm2BmisauLiO+ttNxSoKquwrLmVRndXL12/DtDv3vjazDt16yWFT3f4OCMBUydG053
lGYtCMCT5iYJcD7T15OkhfHiBc1twlTl2UiPv4FqPRijbMR1Q8JwFt/SOqbTmd6UJalnamR0U8hQ
PkpWl1XhCiVaXnq5tcFZg02tUwmNmoap8m37kENmnvwbEwKPQqYuxQpzGWKLbE46A8xWO4DZgLm4
GsX4hQXDhSf19CDKB0gcK7U5JcyYm7BQ735w6XfNSNWseCk8aokVBeaDUt0Kd7KcI9hSm11NDcBX
JUS5hk6AEJGxn08uh7mAAgrMZt6lj3dkTHqJn4WXQiryNoGflpXxPrOKYNkPljyuiy1mg8YOfVvx
pPHeLnZVr7yAIdmi41R2/RsTzkcyksVMKmEotiHAP701r4b4FP5RYDW+2V5jBgNsDoXaWq6NS9Bk
oT3jnk8NwcwPGxHW82s32g1SwAXPoA+mHUa6Ki922ugBUpc+qyFhlja4AYCZun1kdSoyLM7Wo6I4
9c7pWL/O1Q/6zPhb8rD/lfUHJFMj7W+9hvmpOZmy+KBZE+X/J/NFCsGQWh0QR7nojR3UGSBMpbjQ
uFfdiVV9CD1qix60p8+0h3FahL7x7ZL5EtPvPC9qJv+yC7/MjFZaf/WOtrHKuC+PMaAIRuf0XATD
CCRFp/Rgv/I/6hGRXUuRflAH9l7FH1KCU6bDVuPoRyFpq7PHFo3JBTvcknjtOhtGXb6Agv7AC9rc
+3niuq3DajHZgzZIl9jn8NAGlAkx4kcE9Dpj1+3Fy8ixRTY7+2UqWYv1z4Nt3gcb+VcrJoz1lUng
l/xsS9whQKoa4O0DMQS0k05iYl8DVjsGh+f8Z8fUJM/efkD9a/bnQR/eY8m0DpL950C5Jxcid7Nm
5AHl2fz6kB35EMmA6Fq49/V0vEI4vWFi+ELzZ1UjHJzqMEAshU3ocRZRavWHzUI+TEGN8wGc5XoG
6exuojcmNNN1Vfq6C0nNzZtEBlaP+drPC5kbite/sc+fqiz2oRibPqCwhG68yQUPOKQDgSl2HWhk
9Mr863HZVIeBVwfAJgZDgi8jyTCX6jNmOExSg5ZSKbeXYMD+v/KN46nuk3IpwfHKtOYJh9dsmmWj
NkUEYyDQDZMvfnJKDusTBCRh5djYAsUisT8G+N4mZYqZwNVP9Mk3iPfEh9/54JMHSLHtXSy8aD3T
g7XF3pXw7P4eijnHXa4l9+AnQ0ivtzdG9dQdYDid86o+VyUf1+nBvsWiLaCq9y9lxh6K+16ahqO1
SMJyAGbl+Fw5nLdlIwJ8gKuibuNWosKbSOqIZnyXqbK9uoby05G24Y6GLfvrV+dzyd3Mu8Jr4I4l
jWMBbRmEmmyEdicu/4fEHke4Zegp974rSKujncphHvhYbSmO0D95oOJOjEYyh3MTLPQuPD7sYc7g
gv8ZrdJP+N/oJY8JeYxiP7PV1oJUPx2ZmxvqTIApwlsR4+W5383uC9SLpYBWwmnIN+rRpZaAklWj
Vjm7SZK0nbC1cZ68C71kX8kXrG00J7w/tS0auVnuHAq9B9lIaYR7rE/8vylljmIW8EjWy3K+oJUk
mXGHOfioUOkRK/RyO6EkXFqZS3LcOsn2zm9zfdG+V0iRxydffs5wOnni657usPawmGe+YdheTf4Q
LvXaekqkEYZyxDQLj17tcoHRkZ5lgcIBFOxa9KaZuFXypKRgqYKGx5K9n0a+qQAp7JYlhzVbp2GV
sTnfz/3NBEXm8Fw1wu+/OEb2+CFlcjJhjsl3vlQfNUQQh01lPRGRRPLeNABxSKh3odSBMPZu+yF3
l8AOrSLDb62mFMEn6ELu+j3SYitAz9kkn5B2RxO4lhN2I8XG62rLKsg70fUw9RGYbvpYDxgP807B
hEdBVpNm00NBR9hNsxHXLXprQHIhWHMi5CC90RyDA2fUTgMH4wE3RHXnOkApcopYz5XLA+zIgLaV
GyUA/zEVzdcuRnNC+gqHk+8/pEMrdwMa+ibSVlObOUNAFVYS725iTzxbLTTMyacpdyxqIXLQjzfm
28T5MHqagv4lmfkC2c4PbfxLTD20zIoAX+30+YoooMLPmU0NMLhSGUXYzebesm8j5m2BhRQOxzqL
KMj0bexwyACbSE4NZ9/1nsQ/RiI498JrPxOjGkLIUR1adqa21efcirQHdKFDlewxpPO/1k1WZOWx
92+bbv1u+NgDZj2zVHUotY7wDjgXzz3sz6ox8Qsj+Dswf1/e/mF5S2FaD5/cKYAnrgmGbfQqZSPi
Awy2JgdcB/LFHNCDrWW5yG9JaNLuOyZgMUrvxKIv1PH/eGEwGRQ3gFFuHzNuLIlyUtV96WFTZhRi
K7fWddg0cVKBwtbHBgO5OtMNyv+o0IT0BDWIVeyKusbWRpRMTuqLZHjnRUo05z3OdzwuICZRyVYA
4zoYV/0iC0FGUX1n3iYtBabxvtUE5HyTT5SvuHGSVBdxLBKzFAHCMBClIFLKu/HhXPw3WiDili9x
NaK4NcDtZovPG3bJIk+a3tq5IgpwVZm/HNKX/IQkRlcZxwNLFazwl0moBBbzospcRYsssL+faGLl
SW01OcdSwnolXHyr9KaTsl+HhjlbZsKnKAgmI2xevQLPgFZILTsHqtyOHMc4Jwhnek0Ri5XSffSK
1/PAcBwvG/+i0QU7sHR/9tguQClqfMYkLusSAIrPgjY844fU9AEJ7YhDBuI2BHpKTYVuZYbsi+VP
PPoArPIVFhfE7xTGT2xLD2kKjlotrXi9fR1g8iRcoJJOn+lZxBsvC+YXsHZdmK5kNQR1hAUoi4fN
iuAz/XDEXoYWjVHHR/AI8zAgSd6sYGi2z0HjaDjESFpBHtDwfdSVsu+hW0ZDruDpRJ9DNqfaTlkv
Cx8cAttFfBFS3MVKINmBdiIhkEGzVXcHZjnQ/hCQAbDU1eZTEn9wfsVA3r8n+jE8V+KMrg1oXSZ2
4Emvn/x/0NuEjQUi2bHuPAB5lL9c03xsLbuZzmC+Tu1Df21MMGHC6Y3oXHM1v+eT4YC5zi9ksosg
Iu7TUS+nHlekoixFDI6MCTSUICKvi2dzIViD5zbRL5uPHGDZLXEe4b2hkttWW7Hzd3N7E18bL1fQ
QTcMlqw2UY3Wce5oJKpuiTbP8wIMRhoAm0vydLUCZu4sMQwxtVS31PaJwem4HRiFO3Ek+t6Dk6uz
chzjkLN5k1200vFFKoSWi+H9SJNrxLXdTUmG7gqW5HXpIij/TBgXOC/3qIkcLp6TlxMhzmsvJUH7
7SzALLOho4vyeRGG+8rTlXHC85Hwd+wYuANExebFbzMOn5zj5XqVPBpitlDERemGkq9leIJtFEn6
5l+eG8jQA6eF643LT5x5nSCMOiyFfUo1ziWaDF5tw34hZcF4r+HdUtSkG4KouGwy7Cx9ZsmiiJVj
dO8aGk1DlRSPt0zTY8r13d54ryBhtB/Lx3aMKanf4x21s3Zu1abeMgUty5pTlMf2XWP3ASTN/CD7
EzVnZ11Fjle4NpkR/m2zrHb2hYp7YAeQTf4Dfe5yRfz2fkfk2jmxz5h/aJI/1Iwf75wtAiAByDoG
MUnxL7WFPNZeM7gEPJAcVxM30iCOgDRlWIb1HHBNL7C95OdJ6abP0R3tym3ysslyVHpkvM0d9hcP
DOwQq7DVxJ9/Fd0if7Q9ur2/34nq6jM+rh+eQjQGLJ0ewDQGdvqs1jHtcsG1Gh4S3nDaPuwSdiG2
QjUvNnNOx9TfFIxy25QsrJ8kdGK/T606FLAJ2YPFQurhZ+YqebgGSR+olVXU8publvQEkUmE6Mcs
hr09dLyIRE9vhk81QdscCe+ALZZLWSEH5bxDyrXwKEf5GjBKr4YcIbcYLrnmnGiZv4e8N8dVYR0U
IkgAzvNyH4xxlfAnkM/ekWOGon8n6GMMsNZltFYJiotZhTXJ/10zfgU1gLMg8Bs4HUJoZvO9yBnC
kifFORgOgrqH/EFzD/c9OSOCsN3nzXzkw5xgK3yi08TcRjYfVCR90N6tNCjj2oF4AdHkqae7UhU0
HFzn+/5SzVJhJkqEpqzEvEmSseHfftNEqTh/tFGlEWCe+nJ7qtAGJ8pyv5WrHDDNUqWCdyae9b1B
zCeMoqulDB7NQHqrPfBsv2TEqQkxqlw3IxSWOrpoKwvoAiHnAzVy/ZBigz7horqWCjICxkuU1NEm
BrALJJEvjdaJoS44CpQ1jETCgvrfk0dgt3JdZ8GcDHdw4pq4LyiQeVQyKgi7hAX6lmMD2mIF2CuC
DnKXilFlkfAQMB4Kdf+nbHRCNqmZe/zrYgnGEUrZyDVkxkJcbv29J7FUrbyhAerdQuAfm6QDntTU
JiFTLxelzfn9J0M8ZM+v43vmnfA3hnQHxOYtLL1bJjfrXlgjzHhKpRlz5OLVdnBlkYNgg23wnoGD
ekHo7/ws8HwOIqkVmB7gvyXHAE/899LuhKXsOXZ1Zj45VBAbvkPeOYZFUhEfF/gsUYRLD020CLIq
NNGk5nXrq7XgyO/FwvORD6URcWyUPNw29t0nWClP3JfSYmhbhC/Xkc1m5B6zG7xO6jMvVXOa7aQq
4/RvtDRetfoXe9fnYdXMbugU8yFqOWKCeX9reD9Ak0RMWUvukYbub9c5N8RaHpmz58gUnOKM/lId
76YuNfWQOfkSKE9uLcF98ulhKxF2JpsiAPIOlB7AC1BzpaBcvV5q39jYnnT4kqUxwpQX3cZrVO+0
zZZYPbEB/QsRuiL0FbcYoHdFPenIoPI8yTkLZ1J3vz+CFAeLkzfFv7IZW2KAOhbhgQx57fh7VuF1
WauQczGaRw27TJBrbBlsDyMXivy4ND2RX3naueyyFncwuTFh+Nn+BT5v8l4RSAsZrMlXpFIzFTzE
PbQCLpPKdYHIDLI8SJb9c0Xx3ZA1o+dq056B7NliyRl1/QfFX659qYYZZktYR/bLXYUC+YwNToJ5
jiVImql4IFdiP8NZs9VOn3n6JsmxgxN38hWgTzl5aiihSPrsutBB1+QiMPkMSl4K2rLjZv2oi9oM
XXA6c/1AgNIGoz9KaCWnzib1bgidShLzvkxO4OTdPYGWRIyxI6cOK24Bm9g31e/sr0En7ePgV5H3
mkTwj+jwPFdoxgWz1DkJTDupTpPB3t+8KD6dMl2MD8JRz+WFrXBq8Xtd7tyK+uYGAJ7YSoxYUYnG
zWEs1/RIzLa/BUVrU7lIrfBcvKAHlzN7AE+6+XnqX0xAGQKP/PDm2/Ok1LxRQRSadG3aEGC1e9dM
UIWjcxHHRNi9RTOBuqepTNPgQVQSHs8A+CCGiOJ63oyS+vtVTV83zyXI+/qdieIkE1t0/w6qknhK
aamPfSD5eWQVCpVcS0CXlISJPPC6krnGnlL3pOmuP6RVa33OOhvoqNje6QdjisFCvbLF3ufwVGTH
x2RuCtqCdMQXT5jiSEtCeV4wtfOchuqiwu9m2oTcqvvNejbiKY+W+06aygOvolEhZEiezboVnY0r
PsB3RfvxgNQ/LbxfPt2l9MC65927VUWSWQtNBWE9MO27fmbX+eQ78IGtaX4YA8OKoleUk7Iv4P+2
xWw/jfYliieAEQOMMpZCi4Bi7OEfYa7DBk6WZ67+zC4XkuBk41uqfsIweA4ONq71t2qB8IoO+WWG
M6pdvN8TkOtyNOm/JLZjzchpSbsm0DH52TnvdpDTZlg3M5RYfiI2qqvu0CcjbWMDAiPTqwk9qtud
K9sA60o316e4HyfREUGJbB3L4fnyuZXGXlXOy/RTxQDSCmkEi/CH4BPKIXDKPIfZ20M0UfOgMzJB
fNsxXE4ZAls2tTaQPXoanvDW2UimLS3Xf68t6yz4wSGwfN225UO3CmRRSK1Hs8L2RJX0eT3eNeLO
bFbcDJqpNyrz0N2azS0ty+CWtt80vVE2zhXTC6QXj7DFkVqkokmeZmfcnE58nf4xyLoo5CBKWzGb
0Fiy72Pl8vRSCOsEZM5NfZ9OpTyjTpck+p5fmkeJs7svvhaGIznOKpLtKN8jQqnWOeT7Fq+t8Fmf
X6H2TC6f5tllwklq1kn4cyliLWa5TRSHvjkdtqtGACgPaQP07aMC6hFkD0IEkYVUzvhNuUwEpNXH
C5s5NhCD6DMS6m6C00Q6Jps47mch5W0ztcjz7M3d97IpP6HCc+8dMudso3JemdYpicZcbXNpaj6i
qwDq5bppJUBQ84RO/4zjMNGwyJl8s8zrNoSNUJYTyA44Of5KlS45MvbBdqGGkTVOR4yTFQcG27cY
A2J2pXHjXPsXy4BYBqUbXfF7KLevFNJRrk4UH3XGg5yiKcjQCUO3WNaJ7a/HowHMWt0gNGauYdrD
FhW9Y+zSqsPbzaxvn14J48SKyfXKFocbLTWJnxNZm56Cx3zu6b79kzVYmQf17Bj6eCLQEfoSqeZS
9e4w+IK9pn5nzUKTMaNKel2CZnDd0JCYQpUWdCEyfOt8oUbW88j1g/c2VViR+9XT2MHt0tDW+0f0
l2ShZ1+75E8CAYO7ZTC8VXlMIUQOP+4J0qtwUZotFvVhLLzbEvNKIDDMM5SIat2DlzN7Far1OHhE
ugMeIDuBlzQax2sqGUF9zXeTGwj2FE5Ue5xHFlGN1fBc7q5+TVxUh3AygRxkDBUXm0hTrJ2X6t36
Ckj6he06lAjz63aWMMo0ee3HvVMBQzwlnxmpn2qCDK3Zg/w3qu2smcLHitonJHb4QpPUWj+A8OTy
S0mHQr9bsWewuPKZLlWLsjN/M6T3Z6ysx7xYNFqyF9MEWo23NvklLQEwMOrQj9vCLgW/j3C51vkp
LN4nvrSwMxVPpiCZhP09Lfp/uw+fSQiM6Go+RfPx+ZGl20QT0XROAhZk4msqzlOV0MG3hoit6sv4
s8UnpebWnggjQyzmEjKd2HKor4XmeL/cJKSZTSls6FFac4mPV1buPticcc8uk0C69rbNS3MvqVSa
WaVlu35qf+b/7ItMoL3feaACFolbXXXHXyBsV5taLsHunwiu3vI+IbaCfNnBGC43vvJ8zspkahaq
/3fQwZOi6KN6+Ttpr3T3kazkeEV9syO217zx4VzldjrZZOPKDHGTZ1p7Z3Dj+geLS6AiAc4eTvwN
iD3CXRrbv1eF0HtuzskBj3urBjuQygvBXhAbaaRtMsmlI9hJGASV2hcacCZtwisZpZWTvUq7pqpC
IXlhoSPIuzpFzT4JrhJDh3Hl5WnqPv/MfCZiIJpm6xDkokV4BfkxJLJ023U+dKgvmEt2MB7e8Ez3
ZVo+UL0UIz9wzpNzrAd6YOpFr4ac/cSFigmFsiT+O8NcQIOQ+yv8gWXy6JrGcPtfpcfxJC7Kqiht
R11rZHB5pHw7Fa/TVHXY0Xe6wF1TH8nB880jNvplCinsIzdwGK+LJz6tOEuvUM2CyQy+22PoXUzT
ysOjrPtUrfi7jIOCTqsfgZdckRCvdQ+K0jzZOzdh37Jo3h1gIz/dEOAYeIa6zfuYM70KgZwHkW8r
QvcDRCVuuUNAyhluKXzw2wNpRLlURbzy1gCMiqiNDl0mZMnU/z01xCEMT+LK6kpc8wSTICoI4XqT
EQhyOfoZFi7tI4NnHRPdWH/sAYuinjxd4DaWbL+fV2VAHJa/lmwKRXsjZMU5C7dp8aCxglmGWVUz
FQYaqvqy0exDCnsrwW7NpvaO8u9ZFNHApjoJx5w7hrZv+lObs7WPHbn51AKhgpmgGoz6vRu+7yGK
wkBknH26zYgGcUccr1lQk1Gbfi/AUoCAiDQGtqAEEoW4WSUop7DjJnLGlX0Jz6vU9Eu17Zm6ZoSR
2uoN0lCLAGet0gExT3li9R9eUQsZ63N/kPOOaWD0LU5HZRzcAin/lR9H/dn5uptwRx8IE8aIy0mj
KNg7rTC0phenQvmDu6z2czJQWslGK9GlVMQkgBi/g+dDrIpzpBUcck86d+8g4LTNQuU3J+8MKKGc
Kl9Y+nhljy3fiiNQNMWjrO47G9K330ia7lR5pTx8mh2CzVN98dMKUNDHZ9xlsDIYRMrNqqS9NDPP
joWp1E5U6whQOBH4q9mFMLXI+H1ospqpqR2n84pdaZ1actO27wDwM6g5LC0p3j/DUXecvbiK73Ke
sugsMfZeiVGwWzb4uAPUzfHeM4EMbrCwII6JCIu7YatAZADhkZByJ7clRb4oEvuo6StX8NYeIf6e
fzLXNUC5B4c4ejctzsHhBymZIoDDxEF2sxah92K+lN4HNkML2Z2w90fhO5UxY2robkDBNpf9K0a+
u8/L70zhIlUZdIHFJ2YWmjQrzTps/YfC1Zk3UCtW35jUmEk5mcDkmWY7FQLUTaDPTBGvvINyb7Ct
3ZiCKP+8sjvOqX/rWfAWnMi6KUAmHkw89NdrEB4rzvemgCOtimwSYofuRRz3zHxIjGRbnfq04yr/
d1NvDGfBfhbTU+88dByMepEOQjkzYWwnSfoTZc28AHZHN5oa5iCYiXA0EFQrgI3qRV14VbTFggIl
ZI1g6SpLxwVJn9LErbPE7+2icXqtpp+ZLucCG26zE1xMfOs0quBlWiHwFtJhTbtwoFJagANzG3M9
fjO/c6Sm1713iu4wdhVUTR8wsPtHPnIj+FbKFz3Qrgywza2yiEuPsYV7ow/kEMVa25QOVlDEndaS
GXcoxjU3MS2Cra11g09wwkjMT1b9NkPAD7lccapLt+msisXpzNNEW21Gs7Whmf6W4eY1hsvTCR5P
QpswHBiJNIcch5BaaUh2GDP+t4+WDmbO9C3pkUYxH3Ym0oi4YccbNfjnDHndQuDUGFxTgRC9PuWf
svjl2illS/hPh1g/uvSnqG6BFOau+NGCR/J1EPSfkCTaEmnaTfbDsv9CFy71iOjc6gNYu7Kso2yw
mzOxk+u5W2G4FgQla+d7Y1BMPtPIydUvNW8DIOyMDL0r2aQbo39QiRuYLKXvo8UQPU8Lawb3volr
3R19CjetK9zQEdxoQA+nkfIvzgWm+hXR2zAqyGaWeJcK9G4F0P93iuD/CIhFXZDu0++12Ui/8Lhp
I4+NAN/kI7HNkt8ETzmNVgkZ7CeD+4nstmy1IIAH2B3tDQSf4gF6KNMOYauEHGQ3uVkv5DclTPy0
uQhmh1lSmRKUf57Q5WTIa/valtSSC79fKutgiCc0LQ3NWRCtdzgE0B3E3CYOlkJkdH6roH0ty6/X
mLl5pVB4qUUYlFRHB1VGCiamICpHe0EXdwL+jaS6d6vN9GqGv75UGKf9mvXqmArWnitYR8Afi3iP
Mzti+uIe/TwLOiSYNivklqxExu8ogNWYofcNgho3bWyDdn2kWFXzAQvjLCMPnVtdjL/S/13OrLiV
JrkhGcx5zoo3xeCcHqclfMiQklgKYDfd+jGL5WCr46ZqQzhrDmIy+4A4LyaTtzgA5AFgYRVel0wC
sqCcwH+aM0DXFCMUKAbdWqNoDO4H1eLNEh401xA2lambv3FH+8mx1YP5M5Ouq4hd0Wx4x7RBf1hv
WiHPb0IUwcvhWgGnjK2wO83RlfHjXKoXGarU9fp+elxZczhJ40ofTBCN1gKGDn0Jht1HkxrrABhR
BB97g6NnSwvEj/CeOXM+5CZJQeMjDGaVzxMIJstH4nV+Mmzh7GdGaUf8IAqhWEL9EBTiLAQBVtS6
t78cNt+0tUTsOE14dSigMdoffW2zs7TWWjqi7VzvityuCGvZ0o38DWdPJVIwURyJfmz/X2v7sS6q
8brgNN2y+DteKTPOEAQLu4ij+90bJRfPzGDyK5VjqZRADzAcpQqBlscuMWwESH6rKovKWkmCf+oe
7IUXzLnxjkU0dW/h7dpRSA3nKyI9f4XqkfMNXhXWY93hnbV8e0gPxwD4ZdHfc3aAwLcKIp1QRai3
6UBM2qU80q0P4dZyGvlyUaBNePnNTywT7Kw1Wbffqk+TeD6hYNu+ojY4/dKx7lsAkqccWD9s3joO
Y12pGpmH6UCOD2W/7XkkOvN8CqDE6v+F40TmWusi9uc1Rj+ZdqsCmV16SZsxpBLFZRgPHUTCaNml
odIphrl/KcbStkmVXHGVWPCQNQ2+QsppWlMO5gC7yaJqmh58quy84u9xNjFys4xdoAMeFmjQRJhv
hRemF/nRMYDcvLiei4E+tHohqTUF5/yyoV9YwkonTvKV4Kd0VBfRSTNAp5bXtr7OGHf5zYMgXHt8
5S+BVIy2Brz+AnUlV2Yo8KUmugp/ZPUlwzOSmJkDTbntH37QF1qMdJPIycHauzdXD93kNaQ/OfBo
v9o6SiCoQ4kycxhBhbNCP5OkvKttUKdZ0BpwT3Rf6stOXd+VkwEUE1fTFxON9/ZJ7p+LE3YGxPSa
Q2N4cWIFKSLe8xz2Bo4t8VoCwD+0MNwHTxD6xJ2BZj93g/TY7/LgeLXDiil2mmIdhGv5m4Pr6Udr
TP4RgWgQIYDo8INXwdL5ZEJoQcwPsStIKbIPUXdyYqsiACz4TzgihyW8jOILGBik/jyUk4mHlHvP
/U4usTt6Rf6X/w9c6My2Z/y+BKVPiM6yWZcIBW8ysAamq6Mbj6jwmCfFLesSRMO48IwgkPcc0LGV
mb1/XcOF07rn1kfIPoW4/E6y8Lh6qdh9UWO8UHFqsigwR2CNAmK9TJ9WOraMBPiQdyM70lP7AK8m
ZQdW9U031cE/lt1GHJyeZGAC92ywRwJPK7o8oDCQ/mmMq7YC40hXFAhHCLP2dt+DER1ks+Z0qiIc
UkdQ+zafLpEiJlnQBXvp8bhsqpDxbNtoKw/J63402DepD7E5cdiTKxlyxUWLOvByCfT5yP+s7VyB
3gZ7is9bQNrFdRyfSZ/jeXIN8aW1+MEprSP60IDLVTDVLWRqa8UZuPdMedaz3VGNeSAMwYwAUWKo
jp+4CNBqPxLg1iPXPH6b6NVYffVEchDcM+WglRmsCuVrRtzlXCTN61RJv+7jZPatqWyz1DAAFIpB
hPIb/XnbLgkk1AP6SXP+WwCWEuV0BMnwTKsLmcPq/eAzrKlKCulrmbZWKogl4MnEm3LkAGHay88B
9eWnEuAImeo13CcSX32qnCUSCOrTnwJuVzoyG4RplnCWAp0mQddKyrq1i/5XwjHQRCn3uBzuK3KJ
ueLibsfws1ynazhaWMSPuR/Ek4s316ajeHeA6wcjOG16hRHzNPIwl7s9xLdxdyfcEWqhX8Ikyp7i
pfxKWWEPV3qLRvNZc1UuOZ4UTduwIUpaDitt3dd1HwOo+lKZTwMqoAoNmADjCnGQSG7VemXWw9d6
Vxb4KSGj4s/kfiaNr0V08J9MMJ3RenfwsJijpeiwpDOYdL5VpYHj5fmN9brVetc/m7DfkalSbQ0F
oh2Zs+08CrfDvZD4D+3P56scyISYvzgjfN8XxqfBsjIx8jkcOChYjfTqHE0Y+ed2SSDhA2JSnAqI
QHPggH7/nZ1SC9dYYB79+dGY8a51HhlspWZoCzUrL47sMOFp1tr7VxeF2SVUJeFIa+LYfsWv1Tae
v7sZ011hcErl6NQUQEU9QmYvuNGW1eb5Q+kCsaTRvgh+RJXn6ACIKT8rl66n1JaGb2t95TbS27Ow
GeMb6tQTsZYcdzigSdcjaav5g2SGRPbRmenw52W+EcW8XupWbBEMFPD3rgWamujSpJpjmRn25PUW
iaxiCtzcKT8a2Rh6Q24aMbeeNGCKPKtSRdCyju65aC2JcgyhHQJjK0a+6mftv8WG70mRHzjWVBxl
qd19DnkeTfBQyRFEGrgulqePNmjAyczcYo3VAUztGNAgk1BwaZvmMPQ3AJw1uitMl+shJvnMEvpX
hB1U+akGCj1RRD0f9C2ttPWbTqKRsJ6h+7fVcV3ZeAIOw2xRR/cDEe6JvGmWVJrgMSf7RXQrB8em
p69hDdpCOCRJzHA0/HnvaSbIEjDygcL/+Ez9dsgnlO3Hr34hmTuWxER+C9hpkBoYePDsXiSX8aTR
53907Ifq1AGIqvwN801Lll890IylNdY592KRcTgt2TRjH+yx2abiSEQrUAUURk2jqkjrj1vV53xu
mkwz8O5YzDedPpf2OK2U+rVSNmU05x0HWfOCoFfJZJxKSociaRq3p7+KqQF12w3hXEOlyZG7+jYY
jjud99gutLutyQvr/dT9NfheyiW5Pqv5nn3vs5LaVhqaGRz32FbtK501V84dip/Mz+McvGVe3LsY
3Ul1Z2TxAg44AAI1Fl0g06IxALlluuXiKr1CIGfYd0Q1mwDkWUj0PUVVDQ0+tzjJgOkM667L3f2w
yQ/p4UFm18VsIV0TMoOCyYhUeqrweV11EJG60dVlnBFnT/Cw/v/5hi2u1ItCJQ7TxPpbS73JMPjm
YTxMx1FyqTViLz1TQN4icySFTJc6LlxNsdXdr5cVrmisMvZJvGZeoSuR8xuqFNA1t71iSpAqcTbk
EHDX0Pq9o14elAYR5UWJvtywBBkbeiVqvzhyH2LE693YE1rfKxbGFgnYeJVQ4g4McgJbwVCNLMmc
B0j7FFIctj+IaJxMlBWVBblKaWe+vjGHb8WjOo5waI/Eo5japBvWUXziopZVvQfQXdUbMvW3TNb7
D1fHCszJlsu4lUgUfvEqF0EDv8zsDUg7LiDTCZFNRQCtu3lCjop6YWjWqKm3WhB3B1SfeFxkYuqg
Jnvr2hfNoHNXFaMA2Y7Z97rpAR/PWX8L82kJRc0dl9fvfOmKv1SLW01GHEI+WGnlfP101kwBlC/D
l6qfdzfKrwOikmHtH7tKaf7HS7HGyYtv/WYvtzdpqzO/IS8vKIqFUpwUvnsOMv7ej+bbM+SxKpmf
zN8C6HqikOlsDYEaCEwDfUdDnzjH9lQ+k7bWaMYaiY/LiCY0fJGLW8QeK9fUh1zp2vDmO0a3Zk4s
IehFZSZYiSBTEHrADHNAPogMNuEbb2sRggJTAwXOz0RW/T5/3FiBPwUlwjkgmCwVxtPHf/U0LEfE
xXu+KEfeDbIRDZyEiacvQnBbkFWDKbD9ZzWUqjqffJFYmUNdSQ02jZbJ4ep9nH/yeBsuJb1dtGDB
RMCFICfwAWx3QPPnefYyHude0y42xk178Q2WH0ixN124L2aLvlzXSK1YFCwnV/JeVErcMAoxgLwx
GlCOIY4pvhBBxXDaGYxunb8OwaDwWO1kGjkVrsKiLga/V0+n/WfeHObYS3WTaLkJytNCRVT6fHyb
sonVSgtcnUZ0lhnweAjCjbfvQuCZNSL0yM1rnhJxv+f5wzInvczXUL8wCjVCqXgNQEJcHXXmIqAW
gPugrf61P3Sd3DW0v0boqR04sq37n1lEGmMz5o6DZIOTrVRXugsrYhRAjXj7vxNpp1488eCmqjZ9
sdItpn89q87JH0sTphEx2vZmicFwF3tqT7f4cDEemLpcnTZW0kKJ5CZ2ulTX8BdZMa3vVAWztL+L
VHLRtEd1xfuU5iSehUP4oBSlYdbUDrbLg53lKnkMekRExyOZw84QCYVCk6KNzJqJqgjcBN8Y0vuS
N1jiYZQlfS2OELD96JcfnzHMPfwuUBlXtFVG0xTlEiDYpRh8E52Ycbv2x6wso8GrcpH4Yo1mvlMZ
kUNjWidX/Jn+JMLKipdHb8z3k32fxniJ3ehWNcrkXadhlocjXKC0pkYkt3K77m1HuYxCsZuTfve1
QBlaqBUE37we5QF9ocjtUaxZDmgeyofVYkmXQRdmhvM1isz7YMeZSjzOGGk26XemGOl5ZGtUOZin
4+ZncucD6fyxJKIyNx4fdwl0JwASiJ7Solmx6EcRvyWWFYzLxI7lm5OTM4MXiXHVbAOu0w1JJGBz
cIBfGb0tl452STxJj61HCqx6ednf5xZwKOYxBHlz1tcj2T1UPiocQ5G73obp7/pWzHMyqKHNzHdJ
erfonbVY/IMjFUnX7b7rD8cbKTPgfZADrmga1NLwE9AL25EXxctRN0gui4nciGiCRi8KJgjlyqLz
OISlYrltpYZqRQt04muho8b3skrebzHNOHRrflG3bE0iDqWpdeYkh9krdSYvjhtu364+Eha7PA4W
YVmFn5oaXgvZbtlQNtTJy+bBzS06QbPX2bjuDpcSkEhkNQvLsYhYisgowqzoLcGsoYyU+SYlRbO3
366A0+hZfkG6JFmdctJuNbwQXl7BFgyMH3Rz14cpxwdEhIIbwUP9DW/1gOlaseuz59/RvvnRQdZv
TKY99xYCSjBtfxeU/sacmiH8rEQPr+C0Z+YJI1nRAe+IXQK7kJaKnISC+xfPkp+HBGbft7/bpcjg
XxCMk2N8tLnaONt2oPUO4JoMtVid9wqExyzkBsaBHuMXGCWwVuwwEZ2qpJ2HXJLKhCkKNpgO2RHJ
H6JNmuLjZ0O9WZ/KG6z5mZGk74tGtuQIJq6qy3pMPBXnfeYdJvdhHLlW8VgRkAjpqXiFSXaLN03o
wg4KB2UNYcomdkAfjYMZqduWV8ofZXjKNxvJCwmB/RtieLSEZ1TAUrHHo5gUl/AqjPPrnApKLPl8
y91LS9GPmQObDqEO2OloNTrq/rVtq9R1hr1Lk16F/oFbRT8i/d1dEDzS0uytn4jGS9O/jwZWMks9
0736YaShE5BHwCSs6wRA6bATVnvhJuXmDDSRyVZe2iRNJETeeSThH6tITzNPWqSQbh5+vdv08C5M
wPIw3DIizQ/lRtyC9bCQmJl9SmQ2QJpjEEdFTrYUWm1pI9gPd4p/ejvAHhf4gwYvlSP7U0ZBPpWy
NHJhMT6/u06hk/oS2sstNNhx41B3c71/M89ErRAGEo8Af/PRCBa32nyjgpU34T+uwqUyorpHcCVV
jrprYOLwWHPzcKqlVxMoXhDKf3Vi2T1PF9vaHAvVeqkgCH0DB7j+E1KNKdhpeVvxWEx/nY7YZWWI
+dnPZx9tcRouiiVXJzxxt3+euH1T0IgvfZRDYAEePdZbOhWztxoc8o8EPcucDO0NTjOgkBdKGN//
yfCWDawYE0yq+LJSnQByCfjAa7xgvoSLm+SF2jpTXEbyLbJONVITQBqz1/kXBbeAIwEmSs5Fm702
eo8CK+oFhSf5yCOcZsE7OAxl3sNzUKeYVbDUgQ6MUSV64s+b4Hm3wKXP2hvEEN/WoEYXqNmxu4+P
qdNhawyvwtHKafqfg6eo8yVWO8CcTRi8YXKhCNZw3SXY6xkX4jn6tH1odFYMursM0cxB9qjJ4ZUe
BPDQKx417tnwJmqbEx9Op5gmMco/a5DugHqOWxD6A5+9ipDlMIXUjleu5xpQMAR6+oOw6qvQ0YFD
7S08eK/6BNWxL/VTI5vpcmhDibX2tL534B03L6QpyF/wk055yDRJvgk1qn4h8J+7g2zRZTKnqdxW
gNgpDo2jJ+LKMDyjSWK/VJzwJU+LvzfhE0CwwGy1JrXjMd4yAqCnHcONqcZ+7VhhQ7IlQDJ6bK/a
H2Pv6+2ggZ0AVbQYbZGrwSHyVPiWnt4io3FAlTFZQmN9XNFQSMozNq1BKV9B9XqwYHgtA9FruzP0
ETDXbhXloRZnTNx2faIqfPjCSQEPB4ciQvrlYrwcRxt9YzXDDDgRm8+ZFOYHA8fwQt0+Qt26YBNQ
PPu5xFDGPT9ol6R7vTlPg8JEeuf4xahaRFVnJHlF1FTONdNS/a5BLS0rOkPcaW84gPcbv45wvEGR
BRBoJjFPHCO+P06JaczlszMV+VpiDh+LEbqm1AE9WibfKwYG+ObmTbzcMuVXhkQeCqyn5MX/5jfQ
RxwycRwEIKVGfnUIjUuRo1UX4DdX61ymnkE98WPZVBG1m4Ey+uoYgka/dxmH+9IiKy/dMdklMrkv
1chocCAXYjgorkMn3f10OOvUkhaaCPJA2xLvxTB3yQtT45XUQyMGzcFD/kb5Q/h3oDI97G1yeKmR
53a7kubNEnGVve+5D6gT6CQS71ZCbYebCkcKXlWU9BEX5LNpX08bUEC+VpS5C25j2TZ/xl02/5Y0
nO0U1ub12phVQurhxfJllx6HVa/Rgj5KGN3eQ4g8+tH7fNvJ6vHhZ4we2BZW7I7HxmbYTmuCqL//
Is7eQysrk8q0HT1EsPypTbYPuE18zRhD8diEr7PFmsoQjAZicyt4uEpW0/Nzz0JhxOGs8LajzmQI
7qwWeky/kQa/px4Wv+e+IVJjA/Nsbo4kHAlJ+fYWjgVTukoqHXT7l9hEgoXmcua5DcORMNk2tB7g
Jfb2CSiiS5iUuSPdq3ipkf8qJcX98bzPFNUwEeg+47aJWblITch76uLyVOYDTk1agudeR5MgYI11
GN2+8PbI06Tv0TV8411il+9AJeX2GDaargYmwZe6qpReZNlAUUxeHOu1VSLkya7Qnn1PwkUGaL+V
ldaG+YZIP6qRIHAuUpzbfItjOAhlYpmMukc4nAotn38Xy8Ze5JxPEhlw1tCwJbEgry1409kk5Bwk
mcKE9Zvahno0uceX8GEZ/jnN6bEwzsxVxwjYjlXXuySUf8Lh4tqmmjxvk3medcoGGOsYkmo1816c
XQn0EeLae6WzKgmOe7mKA9QpxpwLvpiMKfWK2dKFu8ZyRsg8Ta9AnXftIqx9O5M7t4zCpV5R83uC
ImDEqfpTxvV+526xi3u/2y1eqmcm4QXRcK2SR+Z29aZull0II3tSiMWpvM9zvd87w8sBo0RceNwM
g7TYbSJnxmDOuyGQIhxJ3cqRFdGa6SYYc9VLN2jOMFK2flYOshhAaMZo61fzdJxxwrSUIfX6IFk0
9U0YOXdG0Q+lmVQgdDVNaq7MePQEEP44ISuqdCTDawfEFmb7n3KWFa6StaehbpU/Dfa7UwiS+mUX
yLps7nlq8c+IJ+vudPJux4tFby/wvSLj/X4zQB2MXZCqq7AkGxqur4kxdPqAuCO29qPfOBPAr/1q
Hd9NrUKahYwCulNYF3i9S27KWmgQef64VmDPtoNQU/wtoockc0qHU1rYnYd1XvOFZDyuJb0j6Tkp
JKV1BMhxsL1XRVSx3wWwrbC3tAuygAPFUP23cl1UXv1MD63Eppt/znzmf9oX4kKFNG6Yvvl4Ym83
kICJJN1jz2OVCLYek6ctmx+s7Z1Ma5Db41r2gjrw1iGkLh7B0CAShmH3RvtyWap+Kn4bLynAWXhn
5/6GrK0V6q9uRhJZu7H79hsN+GbehLFiIKhfhwhq97UV/I61V2Zgfl1DXRszZdgADasLzh+X6/wi
zg5kT3K4iGSzYazK1CB15aoAVFUXIssuwFgYZC2JSAH03Z12jkcD776gypfXwxm/J+hkLxe9smcA
gngLArYsBeZ5bh0qMntKqpltJUue26KNduqbsqUfuKg86OpW2VD+JopiuQbrcZimsq0p/26p6BVm
Z+zUf5h3I+e1BUC7KICMb4/GPbOGWq55KWdT+mySAg9kHFK4rhLR9nNmxcFKCsvLS7lXWKCE48wm
kL6dT6MHbsnVcEVN2kcRaELRxnADF+j6m3ofs0DRZb/8HpVWhK3UYj0ClYXtPJ/cNEQLyTV+7tvg
NuFWHUpZ2QYLc4v2Ie3DFsNPxh9J56Qld1vRpTvF21BguHd6QCX6M0ghh/isJKhKlsdsgkw0I+fR
QyUVS3FoVy1j4SsJ+O/6iXploMJ2AbooTtn0FRhHDTgwAF953TpU+cojK6s38bA2p5bXHIyRUlK2
NUyji+y1ZQJPIuJaEamsJF/q9KtpopiuO4hD8PD9tpa3/lptAHwNakMGFnqWXvZIrxuRLhZOsunU
N46BJqQej14xd5GdifVop40guY/KYHdz7hPpMTyEQFw27zqmyPn+TZjzVuwDew7Z+GUnAy84wiqL
lcu0JAtGHDs5SV++2pk753SrewvjakivJujCv9/3eaFIYpZhP7SoqKG+Ukk1vMrSZZJ9GPGGd8Cd
qkAx89cnI84/9D6NCbOgw3NsTz07sN/2B0y46Qa7kZJ9bphlceDYA2sJYwjoJCaGLOWI2e1nVZEf
vWliWKD+r2eq6ukphhdhRms5tfVGmK/MnGxgInJR5uwnT6a+ZniyIhuf6Uin4513Oeryph3A8Bxy
Q34qwSQhcAZSszo/L0+SrTfcWTqBGx+eHZZDRijW5f6ivkKACFnvRfto0jneKBC4rgGRacInab20
mBk+AOSRQt6gVEiDHrwtVM4Hi6Rw6ORJsWgJ10mOyrxx+L7QmX24CwLJfutrXkK7nUxF1d9xhDk1
rwYe1uiOvMVEQDMHVuvp1wfgJ6DPyzNrkLoJmxHnZ6NP+Yrv/PWYt/MDDGC9zzXxhi0TS6CgsEl4
bntnc+76WJ14Q3TphOkLfUn2b0H9MfNl/fxa/+Wvq3lHP4oi7Rdtt8amczhJ2BWK2nW6SJXidE4C
UptNUVeRswQzfOMrUUMY3p8KIzo12lw34jOdaXglGuKhOkfmKwEnGm0Rr1b9OrlOB/UtGi1wdpgG
15FYhgizSrF5c4cialKFl479FNxL5fnLZ6v7KhglrZPrey5M+2STToh7zqtdMkmigkoyhVpPAux2
Nn/i/nS0skoUqzNKGGrSJdk/0/6q+jppXlR76AMBOpmL99VHTjkXSZZ1/jmXNbSs+KUb6hht0SgT
cHxjDsSwFZFxXdKt7u3p9ZizQGWMyvam+dkWmvNQq/tx6NJe5/jsRvd3HNtgBQXE7eYBRzZdtQHL
M/QhsPxq6N2ZzczAI2BMwKEZNaQkkAu8ENvFG6WPnS3gCwg5elHMw4McSzPexu6n9czJJ5CH1ekY
modrrBv5lykICCiHfXUuQXBQ93nhA3LJxt7gaU/4PvF8QKZ9oVqfW5NTvWXpy/mpX4vmaUQsp2if
5wG12ciZi7rd0pGrjX/VJd2sPClPUfC7OCAHtuc2bwKOJ3Xq5XAIswlNzGak9n/9LYoYeT/fJI3b
VYSWo/rnK8C/wAiGkOceFj/ijc2SSGou0oNVykfsYGD5La6DVBv1VXzAohs/CxvCwW9+TqgqM6f2
e0fp+D1ezUKHZMs9B5UhaLmio18mvX+Gr5Z3u9zqkkLQxXhbzz9CCHaCQpTevQVyUEhsM1wFHZFg
jv8IutuQzRKTTbKfFLC8AOkZXFb75q0vKPvGz3TasiGd0He/bRSnXNllAKOx+LG6ZwNwoEQAXICD
IZRRRDxFP0s6R489Z0EvVZIIaRoehxXcmSrntW19z+qycKBH8LzVRGNY7dQeAzM4o0yEm7rPM5/1
T6e/L9MZ3jVDzzxbT5oZ5HXIGOiLjACIG7YayeNJC7wWckk+ZzYIBmK36FBZlDFOkkvAIb1uMO5p
hBN3UfFJ4dnhRxPlI2Bu8WQ6HyJBKueouLT3w5hx9k7/M9MC6926oxLxzZU+/5oYap8EjoNBtHX6
FSKuOjTgRbHx+yLmV8Wk3J0zBb4z0Kzjnz9ckTy311DaJr5si8MW9NIt2r5rM2+gOfFf+pLaREwW
mlskA3iJ+gpvA+AqRfBIZG6dLlb1AoR7IeNYUqwImm1shHZ3NyIY/h+MJ3Cw0TPw4KCVo6dKQ41a
VoTy+Bug0mzbW4rHG49sJTxHGOCiK9MDhSpgs9U9MfmSiZSQ+QHd8vUMI+iUuHRiz0MRKb4J4ymn
GUmD7/uTgnyocRoM/LWM8+SVN/8dpqCdFTGjdi7Bca/Lrw/QE9uaIpgGklR2AJU998dyKXbIv7x3
k7cKJI/E8dIwBA5V+lcI/YgVANsBS7vRLv0/mtnin73T6F5MxgYQ5ttQPLoh13XmQECiqnh4qBVB
KSCbORRogpqvEfrC5CsZ0iIlep+2xVxmuAyLKTAC8DpbOzVRMoEJP5j5JdQEM5iHCZyoFDbl/Zn3
brHd54xcPsd9wYM2YXnCbuVKOyIHCmj9mnHD7+WEjV/2UWvy+YHaDN4md9GAetafWdSOICqwo6Qk
c5L0PI5VpsNigp/VYrivDrUiwiZvOtLn7P7U9fc/jX0Xiexno9926XO79vtfrC+jZ4OHxbfvFCX7
JR+CNYByRV1rmB4fuMnYwl0/EGbH7KWtrjIChB7GIp6nI4jKz4j9DeouJ2psAscuNsuJ3w3zgiuS
n7SE6TCIY6PTSiS1Wo/Lzt+u2jfhE4+xaQruXkVjgVqK5gpHW1AXqyt73madpx17XPlaj53rTcha
UX8TvfbOJFhG0OwOf7Id5ooJstj8x2a6FTSwA6hnQtsbkB5yujemvrS+1Pl5D9wZVMMLDDnhPyHB
BSB8GqaazpNiMVqvFU9PNc+rPCH3TaLoyJM9nHZs5IBdf/GN52jJM05b35tCJDhiY5XJeYxoQxHA
qsuWk2QBQJtb/zLBSiq26vsnP7tTbhWatXDami1NgwcHALmBtMDBD5fio0pz3TZX2nIkXRIw3tht
M34+XOamm79JkZ1ngHtWdJVTY6gghLPlprBZkoE/h7FHeK6VQalWS8AyBysZ9Y169G62ri5oMudF
PePyq/j//V2U0V1iABDW91ceJZjV21Otf0gi48O4oWkbNtdBKxhLPRuShiXmW6l8ojGHnBA3/8Dg
32//VQJTrLJJUsvlR/nO4d78ulYBGrh8tFPVNgOiIcwwOC2wguXP1VyfNOs8sheOg+M5uKZmnkNf
v27mObxwmdEVt+OqHHTq7bRFNN2Rkzwyi++LCYfuR1FpHXa/R1HsDjI8/D/VxfLqHQhEDdok6kST
NBzmU6o6XQjIJ+XSK7uLFW8QZudpIz+pBx/00Etsi1QzbPEBaaUQT0VML1MPPnhdbW4/0A9tRjrO
mYBUrAZtfNQ6DL09nNG5k4v+WwMGZWr/H6+ucEfxqCX7Pf2T4eQZhRZtd4c7yZmZO2Wg/RB+JcfU
U21qKWDsIOpRsuKRamRxSSwR06VWYTlVK5N7cmjWAFRK057otUXm1t+SEEkChgKtoDtEta1fzNmR
Ij6Rmg3G3ypuCi/5Jfv0wppxMR1k36BI1velql/uUmeAvkkGIju8nPaX64QItsD9xqGiPD2h5RXK
Mjn78NO7mDSOjK9EIvfDN5c0U+PD1Mqh3zAzR4wIAMaFHGfy4dWrx+6MnG7pn4fgo2NpYJUrqrrF
qlgLrDWpduNqQ6/HetAOIBuHR8IKBb9kVb4PECVJ5m65irYFyYi3JMBDGhhXCQeAuMZen5p4YUS7
9Q+Q2RoG2YuL6ZYBKEKRQrSeZimSbM4kvhIvox30ow8QqGIa3I+cmuKtuXAE5uPxgxWaCzYWBCOa
ZLYIg1uDTjnQR9eAX+wrHmNw8AuTXG88Lw1Vj9nJaXSJ2KgX/z+m/XOL9Ec53KsF3n74EJdH0/9b
BwfdcxR9gzAgTmvwgano/1AYgx/br/HBPYgTTKNNCpm6QD5LGDDLW/FpXHTh5+c3iox6gW1AJtpu
RQfzQuQ8d6PR8JmY/tf180WGnHNLw2A59o9ETtcHN0jtBSh0RQDmuvor2jr+BENYP10pPG+UrAxP
vYPguMghZO6z0GoBFidsLUCu7YV098QT1gjbsaHrfDgOl922AmeSMJFsZMWukV6EHZDy0xyaDgVZ
RzUE/7a2C2stgMHoDiba/gZCEzUW0wP0F/1+OV59rEhwpRZSCkYaYwGYjT49LM7BOfEp6lK9eKIV
1ClBVbsvKUEMhUCbB1XLMpDrNLv8YBvX9ubYawXpZGloFYsQc1oiBKjo5r9aMgBlH+MwyuLqQ/Gq
yBxGj9oOHaulIYIgVmy2zHTywIOtB2r4+HsZLKMJ77b5KXFdOKgKu5kjkk3ETNDEIesGIYkkRBFj
DxJ8Wj/PLxVQ+8BVXrX8++lb9y12WimO3F/Kb/+Gbvpf6P0ifbrqjkUWjSiX5kInGxFK/XtKc0UT
LIX5tWt1LMCXTLrJ9/vHjcsJgeI+QWDIL+7VuUh3SJCsoYhOSUTZMEsZV1PHbJtCNzHFd1wYOrcY
8RNMN3z0mq8TxP0UroSV96/QQw0hNO888B6qnw7gHXRkkjplZ1KO8lbhD10ub6Ovlh+l9IaJEbP2
uIF5sH2Bq3btY+Upewz77k1FaZhY1zD8kfQBuZYjTqdoUl/oL49YNyfsbXLfgoNDpVhlWqBZNIZj
XCTqQIPzCimCi8z3s19HhwkpAuKHPhLFTN4jG+T7NBf2mGA7hNj37jSC1SZomKJvZ9+OE4/ROVOt
oILfErIgXaRIAbXAIbvf+P5IsNyVejnqCW4vjNAKcYdd0v3ShxZLD9ox9cmg6Q8mjygK+sPVVSdA
gn6XZ3sb9SLu/3kolfLPXj+hDqLWHBvrLDZJXqDiSHMC69wy3lyoXiM8fVl1RftQsnGuXrh+K9/f
yOVm3ocBY27U4BKkir7Q0nM1QmFCyJtk9QAXTCUXieX+lKEwuNH5SVAIJKA/MYYFe+zXb3CDJ8qN
XJZCVh9W1+tum/JSfRS6dwHb4H5L5GHCkx0LkKdBNvGO6vQ6vePU+3oa53NZGzS9fkD7MqHoq7hf
FOO+jZeXdl1A1dQ8kGKU19oyru1Yq6KSyNPdfiN6y73ErwJNiFKWAzXi1gR+wR6IvI2WDdSFKDaL
pdF2HGcpx1yJhYVtdMdLlnkb1+CkcEVm7WW2ykHo/E7bXhV7smJ7Ofxlea1+dZ/MEHe3EbuXjl5M
3jjR518O3JXLOZWIQ2xP4NIqh4kWOovzKkmkmZofSQ1GOAGapwwJRLflJvFIN1qLx5KijNweAtEp
/aqffpeQP80wdxwazyrk/8pbrydvIUTUojc5pw6zFlzDInZuf+gMZ4qe6rsBq/81nhX+g/RCJeL6
3Sw3wCTiE7ue3Zl68HcyMf0x9yXP0E5/HffUFzy1D78bN2rIuVP51toMP12kaoDmhMt+MYZh8ONC
MnxmwzYe9IaFWfQgZrJfqytHi+0e0MuiO7ZkP0u2hl56cwQ/IxXS/FasaDfj0jzbOVyjudH/NJHw
Pd7hKcNgDKyLGFLGjrY7oU5wI2MTkyl+A/JEoXxvy78RG1ySo0YHZ8/3T0VDyivxWanvgX2+aiRx
wdRpXL61/O9hFETbLbXW0rTUVVDyJ4jAcT3oG/C6kCtYuqyLFZNU9CMpOZPUQaZPVxtlzpCWW4bT
mHKT+q12BjLu/5rKHGDKXo64q8i6pSeoeF4Zg5xJ8+7k46HQQ3W/DliFNw+8GwfjGvgveKh7YuKr
iA0nCb1G7sGpUQSvWQmjebofc5Do3endgTD/If5PoccbC4GtcvNH0LKGVWOQoqPFp7xKsUxgZNt9
vQqzn53PIXf6QgeWngieeH0mETyBH60UUfKVvxitWihAhHMQnmf1tqfAF/CidB+ZMru/EchRWjwv
6Y/CtwP86hAiD2etIPfIGR7lu4ASW9CAYN8yyFlRpeLgEkmZZIk15s/Q8vQ0Y8VI4aDFoIk59GP0
yknyig62gkKpv15rsBa1luJddEEaPI5MLPGwiLV5aoq0k8d/1djvtjKTP9DnEC6FADPw8NNvinTk
LRT6pLQtMY1sDuQczNQ+8A/XAiH9ahVeKLV/2ScAdfoAD9jMOMppyeb31um5jbxypKSxZDEf8l8G
QzrWKWZMuFlvGmzLeunkGIFPoW8B7QFzUgUZotFSza2SJFZyh22Vrrr2uRO9BYM8qmFuBLVfkJ5J
LwNSIdx9l9dpx3CmYKQFXh9Mc0AKRwZZoQoQBJSlhpLT4q9WIA/f2mqQfKvgQpFtj+mNJPRBjO/2
KVQ+kXb1RGom6pmC2H4IdwnpkN7wFb6rYO+g5VHAtk30csgpzmdZmPaU0y6m2xKb9XzzbVn/vcGO
jN/1vWrjxTVsjp2d+ots74sHzjBviI9yn/vcsczXuokFREvFJzBVs92LHCV1DfHUiIfo68+06eQ0
NqF0eDxwOK85LVx0mzKbmj1ZGLsfL0TqMNqNAI0SCBVJmSZh+rsX52ytiCO51aHuaTGlZQppA9A6
3JqGK0WejvW4rco9ljbRDTyp/BKJjGBpbU+wcfhPCexBzzyEn+sf4bOVpxUCgx/am63/SzqikTsl
hHA3jIra+zgZ+XuT50h/CKUhGiTojpldkKiZ19jKmCoaKHR71JCnz/cxM+N9XbYe0cchHQVcWpUx
4LUuxd06JJcba60bhujQKMXX2ks9jKS1WXkfk7xiqrn0GL+RvcI3cRxCAecekrWjRPzEw08bh24m
Z4gdy2VcHKk4h45U/sBGeNqPvWmXP5D6N5f6PdQuqrZ2nGK8xuVUAvs0Hs1utkgz3qz0F255xqMn
Vya9fILH1lD8+Y2FN0ENWGu0TuYWXcWHs7+y1HZPcqvfIawY6EZZvFFwd6Xshm4Wk7MycooHn2WE
sX6pF8CbshR1KzdiyWAIrDfwQEXRuQmEoi9ghG1ypUqTcCmuvvh3AtwCDfWRQFQS3MUB9eU9UnzC
nMTrMz8Ib8aTfyNFjjpE937APZxwHQ5NYiWrQCcnePAJYYnHZvDCEXioVyROdAWkLImtCSVqLwz8
VDfez7AYYvFa7lEI41jtu7lvTYiF6/0V+kTtIuKn1iQWLgvtMIZll3B2pPJFhbR0I9JEH22z02cJ
Yy5IsPWPj3gaowwnaTHtFjHK3tb1+OTyDhk5c2umCFdRtE+P28YDDieHaw2Fpr/n1u6up1nCq0BE
I6znsc+6XMhASgjw1Gz/oboGuHmzU6y0epoYF2hlzdZNElij+kJMRJhMov6w5HfVLwNz+rwhrwfM
YageY1LDDnW0eV154OLYNlsrOhLbCMKbYBinssM7wfIePQop85Wbr4RrsN862EPQ4tDlKa+IzaZ2
BLHWEWi2MCmdXx04MJT35xAPWbeNjDCW31w1+lyIlfKlhNSTPbr4+8rZdyCfdEkyQBk7pRznZ2kC
PZuNJJbEHSk5jLKk0IF4SSqLfhU1b8q0Uv+AJ6PL0P6ALkWd/wnIiUM+HDSrgaubOc9AekyAlIH7
0iu6MEZkGrGqHSpe1b6KzVE24AQrowU3HevkP4JwFnxl77aFBFm8n7DSK34FLDKQyF7EQWYBT2zP
e5xXGaO0obNN8UbnrxGednOrS1D+4jBQufuWKgzatVj9GT4s4+mprgjLOG5cBY5hc3PxRsXGYKdZ
DgyxGqkGFCl47wPAAuxJBw3ZWXDXOIpzBC2BK8eAaKcWLMXUL1ITUBdI/dIIy265EQzJl43vec/A
0JervCOye0ouTDPzNw9GH6MnfybFOnBrtb+GNHW0fqtaq+ur53xp+/9fK6S5RTYYwRTKh9UmOku8
B5pJtIWCoQA/+FB90bgo5XhKs0seXzJOQlMeg7o7x+RrVZN3FGn8y+LGzzrsDGNAETg+Gq7w5Cc5
cPEr8hnwIQgpaVsn0FOYioGj/uZ0nmjC4MKG/0lDVmENYkP6HYCFxo/b+NMIagZXtUath/q4X1Wh
5LRYE5OKqovaadpUrvQkHKUrsX+ttjUvoJ8w5dPdbe+I3sOqrbEUC2G+5fChFEuXFF93El6x7PyF
Pp/UCUpPJGyipcP0HbGcuL3F+AQxV+W9ePcslflvspKO3DO1mLBjeoDLR1rhVZsUYadJcs3CPe40
J4GdEyMBvqIX8mi+3yBeJXJ/mTHIOHFDUV/8dAULMBZtZv/P4LzGxf8BJDpDQP3Fk2UOSYAKuXnn
kXui7VDPfIFLLg/DeRvJ1EiwiFx8TOxKSo4FBi17BsP9akWPk3rObiiU+YcExKs3bh7j5rvj0Yck
Y2HM+ePI/aeJrlIGmLMydJxipHH53nnLgpTU//I4Tk0J1/KmYRNoGu1xEq8I6bfEJTXb42AG16a1
b9KaW68ErOFyO2EcTT6Bm6sWJtjCUah4WVDmu2Z0OquXheik0n/KdKUY4EYvHNsrDMng7skGNb2h
+AntdJtnZqTyquPuwfMK08BxyvO3Q7txYYdjomPBTxG+kR8K2m9XQ+tQTw14KTYE8tbION/r5sQW
RnUFryr4gSABg+u6BrkSeebw6wY2Idi2JGC5R//+yW5sD3IiJrxzNozu2fkL24VhfSD1W0vd4bNw
MBYW+YMgYvMgH2NM27M3IRawjdA5y84IPuDalHhtVS6KSHjzOTYZyna83AL8sc9CLaDZLmHiK0If
DS5o/6e5UTrbjr1vhIMEC2DAJZSK5pJ7W57NAR45spIHZch3IUQ8hs61DL0PfVf8rods1SCDve/0
dFt5WQ75kxYyo/t5PjR5vwJxbnMa7gQQYkvE3eJzeJWFswsnCfIHUgpjdKesK9wd4IcC6tiQ083d
5r/qZItnrvksqBtGoalT3m79UdRnEoif7o6km39FL5Pe1maCW3DFVP458ZbxTjoVcl6AstiNLu7b
ndwPBFJ+FOtMVcMNE4OLwOrPy/yekrJ4/ih9Wlu0Vzg0lG7xblf+ol9K381S3NmBSNw3EL8Jiot+
d19rdYvXk88Ht8QH7giQY+7kSic5fFGecpT6m9Er8QMvrOdE+bsa8XULxDepxpncdnnxXoyA6K+k
DDVzjElJZMNvlJ/gcO82rX1dGGYc6G6TnU4/pDPhBjpvzahoCCZVS9nr9os04QKhpcyPH2EBchnm
PkXNGiZcyBX9O3uhhg47OAqnWnh+IebAMBynHLG+UAahD0aTjg08e4wDUjivKyhkWqFYirDsaDmI
5dNlCyxmOlCCsZ790ZtGvItl+sOtSr2mgUC35A4IfbJ9X2+/80Q4QYSNcEXNot9wiN1b+C8FJL6w
UJoaRjyaavKaMfltzntjQGp1aU9NdOAuaPZWrkriyShvjEFNWP1fzyLOesw+e/Dn37ZbeBtzOVL/
xc0zj6kXvvXNEuxi+tSxZG1y97qBwV8ZAe8ZzycZhzriIppubsF3c2kMWyOgmisZRJVUvFTpF1P/
3rpP/ggJKAvGzLOArxoQ6co7ADDaWZ2IeX/W1fbs/0+KZT6yZx+X3PjrVu7qAFeATw3TXgC5UZM0
B54PeTkzYM5IhxcWz4luGZVCOOxOSbB88WzjMn3j9MSyQw183IE2YsEYRinU/CA7o1kISxKJaUjV
PzOBn4pfAPocZ3FM+XXZBCdCKCzRFXJ6r4P3VPJg1XlVWRrddKZHp3mPncPm7cLtmR2K9CzpqlUF
sljk4wy34e/8NHRJYBvBFTnz+t4OFDOQWNopE1QbQ9R4ONKLOdXuNJDKWO9Y7D4UU4VU1GZe2U84
sDDqVtXwwL/ofRQqeKF138+EZTm8fAuBDUHnwMV6YWsqQhctZcJv+oXzw1R75zcnFGgXBvkDM0Gq
Orh6huZ90Zlr6n751PUyhVJ1/Cg+gCQ1ByEgBjx+UOcFyQ20UG7jLDA/jQ2f+9aZPURHtWqRBbRu
e4TXa/8tJa5nLjn3h+otsuMZTQ4iHdIsrl+qkRn07iAzfhurqWRM+FFNkOk40OxaIW3pq0TBkX4A
EbunSnJgaEYwM/bBz2/R8vAWsHoWAbAD8jgVANwyQBZu/Jd4qt+xucsQXYLR7phBYCUTqezyv+mv
197ntNfjpBA2zxkuG7hk/rNP6V8RXa29p4IsDMyW/ovDLQ9TYx9VTfgBpQHZm/uI9kgzRo9ttaTP
ZfJCDo5AaNQ+c7Sz2CpaNbg8kNB2jn4ltlmD8qsT76QLFcBYmxdv1ykwoNQFsgrfYUT7C28BLif/
L+A3eeoDvKmuP8Uh7q1E9HNQbUCw6krQNj92OqcSCjh6G+n+SDs7/jBPulB0wrN9fkL4dmsn6HbK
0enmMAtYw8g/F/ZYpze3aabwnKqM6eHy5J1dWJ59p8UF/NK3LFsLufwaBliUS5BQytOHWGZxOg2s
GJc7EF3EOnQT+F210Pt6W4RA/vY3CXVvdKSgmddaBF9ErNkePeD9GnlI7LfUbc8DViUpDQoaJZkt
Guu/NJA1OTgk98I+WJc0KDBJRlp981qYYTI8VJRXxUTBP8CbID+rEyOXNBJ+M2wsPTd0kOEJD7N0
iMIeIvoxAUSeh7GJKtyT1EVD5/Vqam3BMjZBxTgJDR3Cx/D/CF4qWzyOo7kkqK3GW8k6jzc8JCXM
Zmahs8xsF2cRfOjgixFidcSXe9ay4b9pryusouoql66N6+KdkMVLvvV1gCBCbOQiTy83fRbWYDwZ
PctoUWVTZRVOhlYrHnsPWCEw0J/1OmzSNGNM6tRH8rYBIETXKpPcgCvXRADeapnGct40QuLMLQEJ
Mc41NDxsFIXrwzae9YVv+nA+NMo/Mzrct02WZpl4CFnCNKQ8mFXBE6wIaHRLLsyHdZRdtdsR3W4+
ddWC4bqVSwBrQWxx4lRnsj3vU6mK1bNBtOnfPKDGfWZ0c25bZX0hl2I3yge5LJddIfpSAfCfLKb1
nXVOrJsNIdqXC4BJBM2vRthbG6yjxcc6VIEALAgyrvqLer1PICpOS3VL8h76u4vPs3LKeZk55hhd
Qcw9vuMvUXP23FXkBZjTcQYQNV1VhsWfWPhmPzw/6Dv5npWG98TJkwfyveso7a8e4uK7If/zwjAV
BEyd4T3fFHr9sM0EhotCWjIo2xP7o9+hD4zIw4r3KrjmC+BSX0zyo16zA6IcSQx569U6a62nhQcE
zxkLAqERT9dxQUC3o9ezXe+Br5XFvWKbfnQu+UTGNaj6IZgFpWkeQoHL6INoIKXU2XBpJ4FUZj5D
ue80hwgswKt46a0hHL4Rnq/KgpsUrgtgE1s2f31mDQ///cM3waHwhtjcrCYoGq+ZKnhu9UCxwcvY
n6Su1upmL1wwtOeTz+5iHwxoP7i2E8rB4c39jo/UQTPk/tvTsTIPmmI5uBNHXNUoeCMxsXrMQy69
+NI+k8TbvoAMw+UvQf2ArySuPk4PKB/ygdZfQBBQMgvWNWMqVA928tFgP6nPoaeHfpxOtUHUN6M2
dFqRi+oSOPv6RnihYrIvfSVORxu7Y+Xy/Hspasp5JQzRH7y8VibQ11yd5OPUey75AGCSOl7UoFs3
VuWkZ0Mlb6mcq4qI6HspnXW+W8ieoW+YiDViSVG1ykhbj+joNKFsMmmknCsaOtsa2KgeN52aPmeE
awZDSb+r/CQASc0nK8+Utt1+QPRyADXSBpMQtAMMCruufR7gIzS8uInUGn5vyQMQ2pS79r5PiRmU
25TClrlcM10bMNyNSq9QrMvCYUvskw4ETOIIeFWYs9oDZ4MTQcLQlTK+FaK9+zO8CPb035u3B/S4
AtNNl6h3DlH+cluQEYnu0nKz6UOMWRy0Ayo9xxzlSQIt/dE1UGlDUl38zS+xH+noOLpT9olj3eSI
DkM1yGUa/RWeuxUj9sHEQwx/XYCiCS/ChG1XvBIAhOtItmQ4iM8/a/sX94lg0KAngiBWtCipdzO3
gLvSD70VhW1CAEQUbgal8LU5lpTLDJlTZCKkVGEvqfLu7O6W6VmW8DW32CWGwc8yTnRO5r0tbRgh
JjSgcFiXIv9ZI2E8SNIp+MGNpT5q/m0mBf6DezCBByqOFMS5Ze8v4RGOV1C7BTU1s8sr3g1JlfiL
dWLnFKDx6zHD+VB/vRiaXzAfVSw4Y0QGRtl6OHjUpEX3pRUv3fSUY5q7Hm8hHP3eNsaRQzPrPgqP
cLx9CWQsbVjoF7TzcOAYAfpdpiX5JchG1P9qT8expgAaTtwydOYlQQGBOHTJ6ti6tcqhkvG909dE
qvGt6ZxrdeM/HeJk4rU/IlJckZpAetThW0ySNhBpx4+cdUi39bDKqCd/geRg8WwibdH2QHmCwMP2
CfeRclYaftZhct2CHKjNFk/ZgbGsC947vh2TvTrJ5ZF0WJkJsp8qwz2Aa68nSg/TWLyl+NEUBVoU
v2i63uMNeM0ttGiDzL513DgDI9W3tsmlxQcbiCvAiGXRuw5Pk3CB4pWBVC5BQyWEsmDxb1wYYMEh
hDeku23nYePHp8RgDbOYeOdotPTHKKXiuNr3IxLHhfhe5a8zdBGWNHc6qUxShM6StBKsX6f4ORDt
/nq8+RAziRFyMgPy6F43BKwBWwGiVrJo1WsrynHcm7s++6HHH3vmXuyjAmlFhR90bj4qhWiFI64z
pAJ1KXyzDXiHj3e8TFBldjPyJwFUEFdN5Ewhi5JZK+m6RPMQe9VMIO9C/QTJJndoFggcqf1M/71A
1obHXB/xHT0ZDSLuFM79u2Kub9S9L7/QKCpRKCSb/bpMKMpBp8+na3grySAQWus1FoRBtq7qAlX+
WXw1wrIxnBWQlPu8nDPwwwzq3XrKGazX/EP9T9VuxIIhdCsInA0PMe5Qkj+L4fssPkmpx3aUemyt
95AHVFAH3MJikim/l9E0/K3EtM1pxRkOVVA5rznG8IwDiTxwwdP12kL1pJOFu3upZQYQ8tXqXuIQ
agsNTScLpVrhr5TXRN1Ji23jjaE0B9UeMAuaapdEt44gAhxba+y99nqW+7aXZ39CgeAPALKJ7MTo
asucI6Oj25wWIu6+DzCZmavxK2X3anUN2xJbxZFRTfIU/YdVb0e8dbAfUUe1PF5M9qJVV4GXaFr8
UuQoS2fNCU7I8dOerSUv7JxZQkFAGepZ6hk4tSir5n0/WdV8P1EbYB7Ys20YCoIPg9vtSMx4QKM+
kO+OXizWn6WeXTkWRD3kdgp2U/NLLMRypzmvbh1s2U/i1TpxBWLVO8jeX83nfvyqK/dS5GCSq+EJ
F7sqY4GmsrTIbP7ik4B4gyPlXTai7yE/vuBDoVRqkkbMeNq/zWRg1caFghvoJv4GZpRea0FPZlXr
gI4/OdECtXvWloggE/3JNPCVXMaZ3mME04Z6gKATnIcZu/0z1yzqsmX5KdHBYtPCLYki6Y0Y7jSp
E/n61PUr8Msrc/JMThe7bU6Iy/zLgaTTfwLFb0pJ7Iow8lv4TQqdiiEeR4C3qB1FvoeiyO09drXr
3umolwLoMZ89K0F88J7mnHmee6J/datUb8gkkdUNeVeIWtp2tzphkrkCRrAi7xGKpe6325uAFEje
fTBMc4atR9yNPkXAWsDXaCNfzLBMfeF33nbTj1q4RUbqQVG3smTE3IpdMFwgJ2oKFQ66rmmB3OnK
bP5WI2Em68YWJS2UAw2pEHIFeRtc9UJGx9RxTZ0crXnYrdZRwuscFbZsKsJwgL0dsePc3W7635tj
TLOpto/calzG1r8esqQAEHTsjPUoqRwjNWkaifzHBDjSQlRTTO9pqXNN3XVwUp9kFSUjGUsZQ6UO
FZd9z78DjSp8vQ7ALLswxcAmyXTrneNcQBYySDGObDb3nGAUoqS/G+5nvwUN7stNdmCA4qD+yFYT
ATv8RZGuukK/O+G29eEtM8Bvr4rwM/eTsc3udl48QExOpqgNIscsizTlcfNlV1jZhkWRX0wDcbjK
fo+Vwv8sJbe1Hw/HOzR+JBTlGMnAzRPwqNV0ZTZIaQxzdgIxeHko3Mka077QtiSTQbKLSP3xRrJx
r4Gs411VzvR4PmqljNWq7ur3a/jhkL/jcmlk2cBbem10QCnU+evz+QWmOTQZHagK3WPijgGEDLGw
4Tl82VyyuanFTnP5542yYgpWJovMrk+itetywQ8HZlavnVyPDno+JBLPXQzjGmfvRco7p806z77e
q5akcKl13mOao9i+XebNJ2xiXDGlijkJhFAqvQSE+7QSMJ/oEXj51+8ihnVjLt3VP2qSOwecjcQ4
XLt9PCSEe0yvvuBeJ6MXAnDYpfs8i7ZcTzHoQJkLIiukE9OUFlroNt7uRNNWgKQR45kdVZJBQ9eM
IqTqXffkd9hNIX3vuri2ig2Bgcq7CHiMlD5SsSkpnOW735nwqpNbLXJtEJGbvgCooUzXpjESRH18
2Ko34m8UkSYBpROPjMUEVEoX+8VtNf/NM51yq8xAZV9H8tMrHpO8Rb5+tL0t38be4t4H37MoQO8b
ZBbflZXZ/Kae9PKU+XTyPV+H3FPrYrHGgea/fBvkusmEZa9tKHwYPBf8pkX4/PlX6PhhBPzrHCa4
eQ2Q3037MZHsejGUj5UhJbfSZFB9pLGTkj4BzRgNoxUHPszlqoiWPrpMAplwfFkyiv6K6AfClCFc
hxuHllAbuOBAnKu3qMHq54VrMEB9Bd5Q8rT/Yg+GpDgxagYVl2kdirPcgr0E1pro/wHnhAmWhBkw
XSM6Y5zd7X6iA9NldyuSVq6ob01UmU1pICUeGKDqrODYodrG9U2LHM0LuaanFMLrr0LAHP/VmEFa
gP+T0yNSa6cwsTWP91ziZ+hcFJgY9HR6oQodxIDwU/ztacMZEEVXqs9oSoy1wAr+FF4PnWpOK2xj
PORSjJ9j4CF0FubWwj7DS8DaIIH3eI0DjoB0ignPFKib9z9VAvLffV0gz4Id4E81hv0TD+7MIoOr
jU1Sk5afcIiy8IvOUPqFajuj0QQcISwp9UkYSrWlENNOKYHcHbMtjf+WN+O+RjKKxIHIwzFmSalg
QHZhovoBnKnCMnQhAsXJjaBdkaE0uWBAnz9cqCHHTOeUIvSvaQzXdiSErOlKn426yepFxjw8Ft08
UkAmKx+yDhy3g3Vitdu4Hp8jr2TyisQ2+f8bbW/oMZ/T3oOmBhTc99zK3IN/qsJQYlk9RphMhwKz
nMhBNgkiLwyxkiXK7QGZL1jChHHa6qITTgHV7HyqonfnvETXERvjT4NU/QUiZc4cSFYnlJ80PB33
i+sA0Mw4BXdkrph5bAwu+WNTBujgm6h2T5ErYb6GaDFgT6pDLJPcOporE2J63QjIsuOm2263Azyh
FXX8kITqVtODx+aKUGA7+/RG6c7uBmtv221B6pVXFuIyXXNWVrh65RC7FTKEucCyF94UuayOhwfE
mhRVT5KeTWBejxvaAz9XbBe4PsZn2VR54vZLwk/wWi2s2RtMKmmqQ7QbYf3s2CrH5ureiaEjyrpq
UY/Tsl1N/+yPc/WHmeVWOXUJtkg0etF3W+QmabjAPsKduPtWnUXWLIZnq+Aqt5wZ4uPsCTs60uQH
OenUdgfLr8Nkje/QwnpY8643ozTpaGAxuO2c7P+jP90NKGwxnRdm2eAJU1UjLADnH7vPIf8IAlhj
1zDjwL3jAWEG64Og1QALUJ1Lnm6/74Ut8lOexDovyGD3wd5ZOkJiKqj2dJ4nG8aNgmQLgjoOapEs
tjjoDNYxGbvjSe/tiHVxKEkoe7YsbUBZ/JWZUyt3RRzSsCKgeG1RYOrDGlXdLxlCZMFTIfz5BOBL
Wb5xXTadOt8PzLI1hSJQv36kMwOnafnbDgiQkhFqHrHnvJnZSlbSRnpEzg7lLUdpLVADBgpDvyQ9
VstoVqp1ijuus4m4raa4QObu+fUNv5h93DkHfuzxDs4Qnp0MbWCEv1H5ugI4bWKCvqGC3Due8boV
nJWD2Pl0QMVpHJOBxQ7wgKwwpm4fdsOVTl/ZDhciO6KGnLH3W9fAswbphWRV5I9LVrps2ukft+Z4
tzSgC0X57ic1P7YQ1S/82hNjZaRZl5ufJjXM3GTmijHgdnE8ZSdH5g0ewmyAyrEE49aHbUd4u6SQ
X1zlEeoQjTZOwBtVoZuCuXCVYG1C8go6UHmRbX4MutKy5HVSvsKJGw4dj7pfUtR5Zss9nwpr66+2
NyMGmHTPfOisxEZrr21IeanehwHXmDRmrYW+nyPEau6inoEdN4NyvprnrdfhLGJHaP6jCrqEb1WX
BCSCDOcI9XNOGXkgsYbMO59flL3f8925Pv7O5KuwoH/S8AlZCohwnMjgza8FTlevfYSunFv2FDFs
Nomsd8T4IKTYG/I8O7RHD21QX66POaMXqanlqxm02VaIKJjpKl4rQVutdZP0xEJMEvlP/Y6GpEdy
3Ez8JUWTM1QhfSQXZjwXs9R2NGT7aQWb6h+9cJBo3t9+DNTzqeOqrcsbFmr19LOStyYMcfPZw2r0
jCpXYr4PXgxsTdyVgzmdV6tMhofLFjf2nJrkync+KwPwmXHVbpdnSLV7Mb+UsElYPSU9Ejl1O4O2
n8SoBSWdZPlbi5Vi1JdnqaE/A88gFqWw7F6AICg0kk8RyZgfJcvKdLqCSGl0Bd7CTq3OwS9BCHK9
pJ9Rs43+bj4AOHy8x8v2xTmZTRXXxk1hnV3STdXHVeybKNyd5Q5ki2BrSq5dJ4JETm0A41f8/oBw
8B10nU3ic/PcNCaRAphYUisg1VDn9jDEj3L+UpLtn7vl34U9Io9JOY4vtNvg2d+azMVuVzea5Ogv
m3xcKeDdGuy7STYTt9OoAbUaMGtGzppw1CWQ2jXNlu7ZYOYcRrfnSoUZoFTVR7LUNXEqJ2P7uhVR
3GyRim6pvzMiuPn86ag1PtPU81AiQQaNdm8qhmiJi+GfmR20pImZ4K82sTkXlPIGhRFmZZ6ZsqRD
QWeOUJpAiY/FS545dYscLUJZE4ECnXzm7pK3dtzh/wNl3fzLn8c5sUyNnm8aYloAL3hBk2l2lumc
GLsOEeG4uyVavYLAD7DNtDPZ3+p5m70gSoGkihnW+S/h0kPDuB1ENb1dXoAIn/D4e+7bwEz/EDcY
E697/HdAtrgS14T3GEtrwpvDwJyt8tcXpTA8qFYFHady3cPQH1nL0RIqfgsW12gp8Tj+4fHRkSJM
gfPJZxENnTLvJ8njfpVmUFlIrswizRubfr2LobNM6cMEP+9mfcf2RxxLPaufN07YH59+vASbeW7n
QV/LdCCE57J9ySs/+tgB0kZzloDvO1DITeAkP6BPjrXxU9OqAzjWQWsjQTn9O67YCHNHaAAjpakM
9IxZI7FgR266MtVxrVkNUwn8iHtgmNOaU2rHH+arlYWvFoV8Q/BL5cpe3D/LoBNIyvmT02Jct6Lb
rTes+biMswC67vUVpkZXqEEJ0U5q/YzjCIsvQRf+0kOkyazqsdOEZnY/FakC8z9++6Ubx6fDBBz1
jebBo5uoEgZIHZYBC+CioFdki5/I8k0E6lphT8ZHHh52WPCFrT25P8oyMjhrnVHsT5ZxdgKz0Taf
wIc40CyTwaSw44MMrUCCmAfql8tXIZkIS6+ZcnsxxADB5t/8MigJstQwWf67lECEha+6kPjuT6Hw
Fc87gtI3nKKNL7/Wtp4BaE1nLc/j624bDuwNwrydi8J6w7aA2Tj3LXCKq+oWfpSwew/SdQ1fwk92
Zs1MsDtbV+1ik62KrJS1cBQDu83VXeGo83H+1Vt4ZsaEgSJxlM8bBocbc4cpMzTsAMfVBNKHo+DL
b6e5YJ3ZZn5Do4yjYOHSsxL4Tr7mT+eyLV5AbaZqJrlzC0dm2L7ttEQkraSF41QrXzQoAXIqHucV
3vfbzBLsVlRVGnlYzpjdBuF2pBw3Bd3dofpBTRxe/FCoLjeILgI1MCdrahkWQVntEX1xObL2j25W
LnpXIRBS6yoToXfsJO/lj12GcGhlRsbPYTobuIPHzU3r4yx6y8i6OdBpksD36wTWvNISU2P0cg+a
HBxDIsHnzo7GUWALcOnziS+P4hRnk3nOubJiEgAVLWj4Aqc5hahkdyPKkTkAvDxuRVfPvHfq0taq
kEmY3SVn/A3ivB40mAfiwokXgwdS9KonhfEuH+fEeOjTlO24lUNrzC0qrjbiO/gE5lCaMJBygx+C
bci8KR6HuqJuICaeAO6ZkyTfaiS+mxhJc37+72bTTuUNjfnfKGEYVMTJuX7qjjpLqo/M6EehMmg/
rRDulLvEg3e45gcH76doAflzOY7ttyipHvTAJI0wh9DTTqFvybgQN+BG1+5zuNHlR5FAzKxamYIk
O44KU1d0KnMsSouJbtOX2w0+wygXDxKLG18LBr8GQbfkLvPeADXWz36/0Ssw+P6/D7e7+hSJos3G
YUC/YIsG2n+9S0X+STLEk5Pa2imA6zr09xagGk1WKoIzVoClWI6sMlsO6m4x7VB+huphOYaEJQpd
M4RhheasB/AeYP190785TPsXjk0E+NppeH83GEvHFjwbPWKi1MALv3rFlkM+2Z2/0Iqh0Q/Ba+L2
vPgHTpsvyjDmmgto5FJ8Oz3ciUizbMegzw/Im8vZj75LTz673wdagnzLpLSNuxjQDqTtw3Jt6YaR
5Ougpxioy175FQdZ55LJhrPQ4UPOLmCyKjZGW85bbQdp+qR0TK/tVVcUoBezpxowwjjAci+8iq8Z
B7gNXcZ0Lyj/KOeWad1uEpmBF8qEFHCDWy+cO2HVNaiUva3zBrSMGpf/JpyIxy8tJtnNUSBlGPsI
A2rYpmqotVzd79QGv2sODqPVxsmmLwPnt2LGaHVzPE6OXYrg1amwEGdAK5nGt2j9JI63Z04FS3pp
jCgyL0M3Nzmz+2jijHUSTWEhQo6N/BdX09Ma2ck0dM2QRRJZnOYN1IPEaRw7P+jMI+BYvEUdCWfR
RA4S7pv8DJKIMkBeL1HUwpCjqxg7Ed/5YjvGYV6LZyPI0BNuEpIlDqkpR1aQyn/JO1dwk6tnVl5z
+4wdka+YqW4ro/1bHNhqUaZ6cI+1+JGbCqxAiv+u7O6gmMt4T88D5AdlGE7AWTSuH/a1GuYn1zJm
yX8GkPc82ZDqCEN/oLolRWn0wFtibdgciDBIJdJ5aKB4pIuxuPyO4saO9llM6OIFYx4GTrbD1aJc
TwC1wD0yXxoFPTQY1ZnO73HercpRvMtI5RTMisxrFXXuIH/cyV7yDysQoBZ+ZflZ5fG40JZIHDjt
tnnmh8Li6fyXYgDmtqwrFt49mer/UegQwVLOYudeFuwnE+1hpVbjsyRGaJADJ0ReqVdKc7bkZijK
6RsFThR++oNu89B9AxTvvQqcb2FEObgHJ9kLLyj3YHRIR22rB3/JtwzPDAGa31dB6ShGG6tlzxVv
mF5Viawz8mBs0MzcUsFzD+vEbZ+VIQn3kE3CwP4j19M5hrwSnWeH47xlIPzYvWW4xPc/AOOS2cxc
qGOGq26KY42lnSyUENtVpsqtNSCNQ9vnQK6cO8dH5FQeZguu9PklESWb9snDx6gjS2nhbP/67Y4Z
ZPgXAzXIbIWELL2NlpEfzheN2uBAOW9/Q7XzlnoacxdAey9zQwy9nIeRyKgZ1uuuPG751snRDQKc
lAEslSUe72QYj3Rlx7te7HPAxBlLmOn01g8eAF98xvahbHSZ1QD0XqQpv8kPyku472ay+bOK2LGu
U4tjGIdFPbymohcS97mehxtHgPQurLVJS72jNqG2d9+i0CxnwuDDX1B+NwhshNbJ+RpydSXV9KB2
3dfOyAP58SZKciMLNOuQOULgE3rE4Qki6IY8WiKnesxCyGzi1CqCK9scNOuAUztoGR4aWX+iyEnk
VDIQB5a34waU90oKeXTpRiag1k15e/cske2SOK937yY2BAhFnOQkwmBXVtcBRDYwulNHMe5Mvvye
J1QAqcKVpC/frh+YvA//0wrZ+InO9nPWljSOKICsuJHYt0wUv6XYYPij2Lm3JPg7VQfIfaRTArst
NQdqBkmYgp9NbS7bOxkUaEBGL/IkQjfWVcDjmm5BWUuLiW+N+hLaJZWDu0K8+hRpH4XDTfKpPfNh
IDc1Atmh3QcQqJ2OfM+W4mwcR0ezJPLxKXkxkfz14I7eSesVhnIIRk8DyNui0Ssn1p4eVsb/AVWk
E30fUxHxSQiHVPxX86IIdr9Dqe+e5LgqBuc1z1EPuvSpo9dR6TL3VHT2jJmxCnbnduH6My9Cyp/4
b6qY2sfqXRRViam1FrfbqSHqiuRHyBoQPJeCvIxSN8ajSXv7UWK6m9v6878Mq393TKrySXGF49Ps
oMLdws82/3jW76RW2UX1M9prsGa0OgpDCkZ05wI9i190imy4J7TCtBC5jZF2i10QFggLdvPB/Tx7
WZJWVQ/dePwvcKWEfy0qWYtAKCJvzWSMswM5kTy8fHuv0Mi29HyjA1Q9OyTvRXXlxqkdYKqISesQ
jzldUrnfe/T2B7O0zwhI1q2F8i3jpvcelDa2NzBpi5Z+5A+NGCR5MdY8LgOXfeXMYL9SxJ1gChKO
y1bCL26MY4DiHBJIBZq/zCDU1njB6YIL5mEelEo3/Q0y+6Plk8v1h/pB0bcy5g82h0afkJuKhhxs
5ucvrmDpa5KEaVtynCyawfBtOEJqPSWKIYzFhLvigFS6aqlpJrNu8HqEuc48rml6gEPBs6CsR8CV
cNTQ12qEcvnslZ02YQGv0yI8FdxkZVhYiO7QZz6FI5BCwplxSVMT/2lL4wBhZuY6nq2XS8EkPR2V
TNGYPR+fh21T8hQJC4098tfTs2RMgP4yudSrfjCK17laBnrWPT4y7MgcQEPVXU46TmBej6OMZ4gu
R6GNLcRpgTBrqDLUed42rh2QFKGEwc2QMDPeuVdJfayukJIM1Np104uyiZdZclKGTzpfjUIFC51n
NTped2YXztTpqtZaoFKW0Yq3W31dzkiO+U4+TLYIqI7JqOEOWiHDM73NcqSufUCtR4VCcyBXukIK
4JOoGZ4pL3qzl9iVGE5SJufMY+mSQBfgO9sXp/JO9O4ZjLTV6vlCNXC7xMEEt3OmstlzJRlHlSse
ABpRaih7H/y/YNQ9kVgyCdL4jK4hvtQWV47XS+uYqlWTqt+nPW3G3PybXLDIQ2Nb1xGaS4d5H6p2
vSNEXCCkojpCgwlRE1S2Lfzo3UazyLLWcOEcG8nRpT72sRkFp8G/P4eWp8p8kIvasHhAOscECWyi
pDyIYwZX6nxblBmOtHWl3gTfexn5QO/UUsmQuGqvg/Jbs73VJsp/n+fqz3w1BtJWhDPhWpxBG2sn
HvKokst2DXn4WUp73o+wuiYn7Wt7WSqZBjSZfyzvl+ZAHNf4kIbwKD4utL/ykcYck1qyN/htuJeL
oQxvIXXSi05SPJqU92DqdtsM2DNrDqUTyngqQmlK7fOSIO8jTVyJCpTF7qcemaX3kuW0+8Hhn6tA
B5E0NbXY4MAXXYU+P0SRV0SlFdxXSuccP9m5zyhKmrxK0uyUGjiKaXroma12VH0P4AManYb8HV5M
7i6R97XS5SbiovH/VlSTQOgI7D3cMpmzpAIZ5XaHoJsHXRghDVvMtQjTrPjy/XzyB+sUACU30/ph
bOnt0dFZ34tjuCb0IDBgdnJXd7seYlAVyexpHUxeKli7R3Il3USKeBvFTpKde1tojB/MrG91VIVP
qkV3m4Ved3fS5HsgbUMXkB2qmyyXv3AIur+5L21fx6nONCjHkPXoP8r8mqITutK6hkvV/rC02dh+
JMKp33jfRwtK7XRB1pLQJIPU3xP1n0NYSAAxglB6RpSCUdaSeH2VV2//Mn8vaqjFRry8VJLoViLD
StPrbMQ6JLqbnl0Bowk0iZVqn31UmTSz6TjrzWU18Hilte6HZvOu+bD1NLzjd4wuDSAKu5AHn1kG
bHZRthFauai4VBtu3AWBnRWRmqTpVpO/hRIDQdogVkp0iEtW86TAzWE2EvQOQyIVHzzTrwG1Wd+s
4FrSUpj1+3AfIkVneErj5D/fKJvLfnsecMon+MD1HFbBTR7qkoGQTDXmetZB16XGBCmGMIhK2uar
kIWgldBosKGEsUDo2dNmmzFZQC/VoswomnCa1I7HdDLn7kw1iAen5F4TZQGJyFXaVURojuOxU/o6
ygEPwl9amUzpXBtCJvF78WPP+pZAjYswmkVDTmXUF3x+zb1rjgMkwhPogZ3bBjqTU7xazQAoXd8d
7RPPhWRP+MYPhnXuchULzO7kV6o14/lpNTq1tcEjnH09ZwJrhvfyT8YPInQ91SG77AJ8cTk5M+BN
2N3w7jFQr8MSqRD8fuVFsklkzTDovQOYFyTC3jDUT+cJ+igcYXvt0mtxW9buIKbTPH5VCk2IJqRb
ecV4LtmpzlWzw0zgX79SyPHmKjygwtA1toy+1smHXvYpKAXB6gYfvi+12gurqEVyszh7Dpg5AbbC
mZeHJQ4D1FxwNNd4P8BWYN438NkBh6xq3cV8GDBDdYMhDsOWDIUz2diOOUomb6bJEQTfyQ7f+kS1
jPhqsVUBHi9Fpl3Nz+acbDcbsECL0TXBRbR720rCbv3AIKgiuBEXf6kCRjKYremjc0oAorXCWBBh
umgy+DwyULbACeqRDV0GohSPzTggUui/pAR5vBqA5UjZXkfnLiYRx7qb0lQXxcS5VeWvkj+0BFvN
Gx2v3rjS88XwMdghypUKK/G9HSqgPjR9EN5KWpDRhgpFpVHkBdUeNPtjeFdMu6g5qdzLVoBdY8j3
rrpSJPV/kwxThG71Ue0QRvjABNNhpOvZD1QEehkwkPdItvxV7fZwpge6q7g8ps4RmtJOPa4kR9Xc
lxFynaVQK31IEnWP8QkS8JCx2SKa0NUK95JAJamZQKmXCtznOYrz1PYNHwxEILIPuwmEf0f2nmF8
DbHynOmgvNWCrdsRoGJQvPF3abJjcb1bixw1gKjgxw2JI/qRsnKDj8USTUyOUj9x6dYHaoB/REKM
6nIBvr3+Aqh9+3QIewy932zdEZpsYVh8NupjKOH5f0CO2isQraskoBXbiCf9gcE3UJngjpsovF8Y
l8Qet0NS7yLZywBqxaNT8qOgbd7xGMCyj5595nU1eD1G8ac+Q7fH/2a426KuNuqbRIOOJer+6Yr/
ajIgIXmyhaLjN122kMDOVqlucqSZXGJqcmSPEwvX7vol8vbE9t+qL/FvyDSz5KcaC3ANOUFd11M2
TPRNCCl6m4B/+J0rSecGfbXZyjZUpLDpqBBB68SSjdbBvtQiS5ET0gZGNeHnURWYEIxjv2X2IWx+
fd1ERCmI+ym4mh6uz3ir4Ih0tfGmYIA/qU/ggGXwVE+KsXhMmlJHr/C9fVo7hR44hLwS65KFvkOe
A9aWN3Wx7ibeF26Z6UMMhMQowoqZ8ojuVbSmPTK20QYUiu56dtfzQ1+zo8gtQx2gdetwk4apjNX3
iJsI2Q4VPyVvwzADJT+Oy0/FHFpBvNpKdX0oelYoEPhIG2cAz6J12P+ZP3qvzObUkei/b/a0gCQd
78yLnu4FCs2COOPaDq51Rbf3sL3tTXgMpnRUFvStnHBL53J2NtmARI5QkXjBZalTxdWCujwphK8x
VzLNCphUtm3eX0jd6cFR6lFmn2LWRo35pl9kqrN7HIUbHLnwG3LnC5kgh+sLwYnEAHrpNo6Ww/eF
nEf4V7ui99YRYhKHDNsl53cVMvmH7a87BMrS37YsfBzr4o2nP22zccWpDnNKamaZwH3VaqAbZzQr
ogHPSZPelovBWk2Pwdg0pCmHp4DWqg20RDvCFY1UH1gKB7gsMmY9lHyPCeaPUB6Bvof8YSwr+S0x
+hAMkpiGthnX4kevpKg45LcweyfNCM76MVmjsjJxJzKMuTFOrfab/MrZK39xYuiXIH4b4EVjabAS
ZGw39ZekXuonrJCj6VMXkxXdfMB/+wcdrd6bZWWcnAKfJGDyHLAUu9whRdFObQbxCLtHOL2XE0l3
3UvcktaQjyJH3/CF1FbARv/vJiwXwfbCBcaPuVsQ5SylbBTNQc6dT9DsWohROorxis9m8x3TCgIe
uewUp+YXu4hIZ46NeNZ7w1nOpE9kQKUWBmRYgXGkMFzOKVFvXPK5E21eVDxiIjZwFv8afnRMJRcu
/GTco6NH0Ab5nG4A45mNj0yKh2vcgwi6loxXqBDjUBm6v4/dfDrD0vbxm0O2MCKNPjDC7INdJPcT
SxyStufrL/QTMs4IXny5FakKNfDm6JYVYLKyCvN4q7+axc9Qr71r4nmOzGn2ESToOWNhbEtWhefj
1WT5pcYeh0HR8CwX7XxwdPVld75Lov2vgNtF7QN2Og86MjBUFB7JQ/Q2qj0ltY8WXUiLTWjQrLTN
UPoiM9+SJ+TvsOr9iIIVxZIfVAum9HbEOzXYAv3FQHomqz/+czvIzzf5oQl74WONierLtJxhvHrY
6n2i8JBL18PtUeA3ab4ZOAwaACWLzgRw37m4We0A7rynwfZvW3Toqpy3htrxdF/5vYtVLu2polnM
LEQyaycFmpuMAHCcCvsJ2fFML55/1xmP2GfWavIral6vb6ZXITbS7JSjIQl/5km56fuGgxRX071O
jGnLWEJ7vub2tapvTsVOgd2gcJx9gbQx8zGAAn4rW3dETo7aOwE2blmMvgGfIIwE8zl/Nlm9AOcy
/kCLsJZWV3QVaY9E0hOVQ5Sjrw991tqYnWRTyGGcWR5+2SpwHKDxU3KmNRx0oERLcltEmUKsanfB
cttRWdnx004P3qnbaX0ELp1hJFd3lgcqE2HD0A5yk9q3gz3c7O0fUN7/6sP/MZeC/y5UOJXv98LZ
1qFbgbc25lXYwpQejKjnBESHYK9Ym9nZaPIQgoLoT7xb1O8m9+x+9J/PvOgEkPnXN0W7m9pvRcxE
m9dKur3NJ0PTupiCK6geGND4289PClJxeE2NKNmRMntlc674iCmJewCeTNvJ5eEcqAIvIEIHYq8X
Q/Ly8gWSL8VLk0urKCrbOOr8+QnfEIyygms9qNzgKlduo8oYOLbX12MeLVek6z8t5gR+k9ZNZJ79
sdpCMpIRVFkIPMWx1RuzfXbVHnm/qOvX27Q8kIdmXO43mXDLzhhBstQLe61FqCtlaDTFEQ1GKS7y
LbV6K/2+7w9gowSVVQh4t+QTt0cp4oHnC0BM6kbxsF4YsdVT/GsvE94ax/uaKMb0y2CE3a8cKgt1
f49x1S15rUAguxbBLtOAoAPxpgufW/ezlzGEoUTq36hsS/NWocuM5jPW6yBwW1NG1GvwQYQ5AkWA
B2q4r+0KD9bUbjNvyTjzP29jaFiPvG6wARvugX970pqH3ojkBW9r4i28qaDV3HLsmkdR6drJ+RJL
gwCsxG/s4nq0JRxJnhReaMCmoz1Jiu0G1cIBWp1Uy+KMGJaYHwHZsJ3W4Bn4K9QVy9PTyrV8wUmd
Q1TNEj1hXHZFblNPKvpYy41JlIh4jxIlvrvIiGdKBV0Sv4JoHGWL2DqpvZUkRmiHIaTZ5r4O54rw
FXK3w/YMnF1X7ROI1iLhxJWFSwZnjebejudOGNlfPrbxMmy9F/X6vDhmCyZy221IktJp8SHopefc
AwUxWG4DXuqVZuXHFiPF+y+yHjAteXNhv3Z7Xn3kPHO89c99bol/haMF4HAtAkicjf9D8WD1Xs/9
nb1wXFFmZP/Br1feR8OPT3+kdlcBtMgqHGW4iIsjtV9F9CtrtyPgFFd/bnLdoKIcmCb2hUqPE010
RdomUFLSVLlDju63uehSDASOg4BglNsXZUNVSFH5nsMHWfcCx+433XFcyBMMTIgE6hI386rNbzig
zQl2LM/LkZGIu8czbdXCR2pjuBRpAlE9b2PbIQ/GaBPPhoY1D0df0j/LydU094yt27PjFU1UkUBH
8japzDVYRE74QNXBk5BC+yj1taqkUddSUvV06L3qy7ACWXXN68LteA9gCRRUV/5XchjO5UUpAv1U
10+CrW40jWTkU0xuz4XG7NwXfvpR6rwajvbGfpvy2be3so6WLM2r1yqzK4o/z1I4MdTsEDkHkEDb
mGaeNATOcAV2McXmtbAFw1QEx8Zu9te0nNP5LWcA2Z/FPkmawz9PEPl2lkw9F507lG1sX4kV6MCo
ab+310z804tNFB1pEi8t1eGGBZpmFwUu3O1dakkmSjt0hhnPMdQdAvY/hAxGbKYLAWejFCCc3k6J
4hci/2V1AydEQzc/rMxKU9fiB+BTkJAUaugZjuMeklz05GDmGGg6vOMnHsNGegJsaxTZNNqMFPFt
qxKYO+RZp1oC8KPAg8+GGwfhsIpTF1lOsoNgMa9IhGjyZojuf6fRIFRoLGLRjtrInjK7WPdqFxNd
ZGiW9bszK7zFuuQ18hBJhldpWWrvba9xFlXhrGoaMUW6e9EzokQ6X0/nBsmdBpPS6pF8mL58I7JC
qvkYTgHDLAfOhhldA6diJlKZlNZlVOXGVjKOW4ribAItKL8HYzV8/9JhIgQXjaaJYxWObRMLQjr/
LtSmvYyoUiRvIGo6oscBQjVjcJ6DIv3iNJBgMRenQJ1J1scOLuv6bJUPEDbP7VSkcqdSt5Cp3/8L
jyImd7Ria1u7ITUu71csdXNx7b+zXJ+s2lubi2cSKrVgJBj3eGTpy2kMx7TGvV4XslwsLaOJKKRj
ts3wLANrZdz/veGIP/f9Jcwd0C1yCrkGTIxAR9t5hHI/y9bVXHvr1akVoFjwai+BTtt6vX5EoJCX
HXvYgEpJfK5IHfuV1AnCim6K14hvPnhBwAFmzbuxMkOGinVyQ1fGBLNNmdRiZrW1hnQ2R1LGQ3RS
N6/wFSBEM3wASOBcswzDZQB9/1612PPfW9toCH4aR3uQQXW7wjTlciDWoNMGNZ75J313PQwKlsUM
jM6c01vVUR9ZAHqlT1OiSrhvhQngI2hP1cOWnRzyDgzNlKRw5bTMNH8V/VVAyNfl7eGwEQcMRnrI
JfKAs1QpdZZuig3rWNgvu9aNRykUeim8O7uHLenuFH4z+D7FpaBkxGaZLJl5H7BUeeqQUIXHwH49
XOW6XAtW2IuMoTjlZKugkv1E0QhIXTBeoHMQS/kzieYK7TUvgUGZQSA6kGYMgWjZAJA7lkjg4F5U
5X3H5yvCGUpR3n2Y02/sSfZ/ckD9MvFiXZGQtNGSqIyUq0vZ8o8c6IERWefkLMWAMovFcyQ4OHHa
5U7SiZI2ne6XNiToRIzCzIkId1VIP0AXfy+fcDKDSU/FzCdZKGVYXPHMs+Vo/XXGNsv4GcpP6E6y
gDYP29g/2yJbfzlClc7ivks2wAhT/6Z+QJ7D778=
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
