//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2023.1 (lin64) Build 3865809 Sun May  7 15:04:56 MDT 2023
//Date        : Wed Nov 25 14:42:32 2026
//Host        : pc-klas1-14.esat.kuleuven.be running 64-bit Rocky Linux 9.9 (Blue Onyx)
//Command     : generate_target tb_ecdsa_project_wrapper.bd
//Design      : tb_ecdsa_project_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module tb_ecdsa_project_wrapper
   (clk,
    leds,
    mem_addr,
    mem_clk,
    mem_din,
    mem_dout,
    mem_en,
    mem_rst,
    mem_we,
    resetn,
    s_axi_csrs_araddr,
    s_axi_csrs_arready,
    s_axi_csrs_arvalid,
    s_axi_csrs_awaddr,
    s_axi_csrs_awready,
    s_axi_csrs_awvalid,
    s_axi_csrs_bready,
    s_axi_csrs_bresp,
    s_axi_csrs_bvalid,
    s_axi_csrs_rdata,
    s_axi_csrs_rready,
    s_axi_csrs_rresp,
    s_axi_csrs_rvalid,
    s_axi_csrs_wdata,
    s_axi_csrs_wready,
    s_axi_csrs_wstrb,
    s_axi_csrs_wvalid);
  input clk;
  output [3:0]leds;
  input [13:0]mem_addr;
  input mem_clk;
  input [1023:0]mem_din;
  output [1023:0]mem_dout;
  input mem_en;
  input mem_rst;
  input [127:0]mem_we;
  input resetn;
  input [11:0]s_axi_csrs_araddr;
  output s_axi_csrs_arready;
  input s_axi_csrs_arvalid;
  input [11:0]s_axi_csrs_awaddr;
  output s_axi_csrs_awready;
  input s_axi_csrs_awvalid;
  input s_axi_csrs_bready;
  output [1:0]s_axi_csrs_bresp;
  output s_axi_csrs_bvalid;
  output [31:0]s_axi_csrs_rdata;
  input s_axi_csrs_rready;
  output [1:0]s_axi_csrs_rresp;
  output s_axi_csrs_rvalid;
  input [31:0]s_axi_csrs_wdata;
  output s_axi_csrs_wready;
  input [3:0]s_axi_csrs_wstrb;
  input s_axi_csrs_wvalid;

  wire clk;
  wire [3:0]leds;
  wire [13:0]mem_addr;
  wire mem_clk;
  wire [1023:0]mem_din;
  wire [1023:0]mem_dout;
  wire mem_en;
  wire mem_rst;
  wire [127:0]mem_we;
  wire resetn;
  wire [11:0]s_axi_csrs_araddr;
  wire s_axi_csrs_arready;
  wire s_axi_csrs_arvalid;
  wire [11:0]s_axi_csrs_awaddr;
  wire s_axi_csrs_awready;
  wire s_axi_csrs_awvalid;
  wire s_axi_csrs_bready;
  wire [1:0]s_axi_csrs_bresp;
  wire s_axi_csrs_bvalid;
  wire [31:0]s_axi_csrs_rdata;
  wire s_axi_csrs_rready;
  wire [1:0]s_axi_csrs_rresp;
  wire s_axi_csrs_rvalid;
  wire [31:0]s_axi_csrs_wdata;
  wire s_axi_csrs_wready;
  wire [3:0]s_axi_csrs_wstrb;
  wire s_axi_csrs_wvalid;

  tb_ecdsa_project tb_ecdsa_project_i
       (.clk(clk),
        .leds(leds),
        .mem_addr(mem_addr),
        .mem_clk(mem_clk),
        .mem_din(mem_din),
        .mem_dout(mem_dout),
        .mem_en(mem_en),
        .mem_rst(mem_rst),
        .mem_we(mem_we),
        .resetn(resetn),
        .s_axi_csrs_araddr(s_axi_csrs_araddr),
        .s_axi_csrs_arready(s_axi_csrs_arready),
        .s_axi_csrs_arvalid(s_axi_csrs_arvalid),
        .s_axi_csrs_awaddr(s_axi_csrs_awaddr),
        .s_axi_csrs_awready(s_axi_csrs_awready),
        .s_axi_csrs_awvalid(s_axi_csrs_awvalid),
        .s_axi_csrs_bready(s_axi_csrs_bready),
        .s_axi_csrs_bresp(s_axi_csrs_bresp),
        .s_axi_csrs_bvalid(s_axi_csrs_bvalid),
        .s_axi_csrs_rdata(s_axi_csrs_rdata),
        .s_axi_csrs_rready(s_axi_csrs_rready),
        .s_axi_csrs_rresp(s_axi_csrs_rresp),
        .s_axi_csrs_rvalid(s_axi_csrs_rvalid),
        .s_axi_csrs_wdata(s_axi_csrs_wdata),
        .s_axi_csrs_wready(s_axi_csrs_wready),
        .s_axi_csrs_wstrb(s_axi_csrs_wstrb),
        .s_axi_csrs_wvalid(s_axi_csrs_wvalid));
endmodule
