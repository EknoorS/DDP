// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2023.1 (lin64) Build 3865809 Sun May  7 15:04:56 MDT 2023
// Date        : Wed Nov 25 15:00:05 2026
// Host        : pc-klas1-14.esat.kuleuven.be running 64-bit Rocky Linux 9.9 (Blue Onyx)
// Command     : write_verilog -force -mode synth_stub
//               /users/students/r1083141/DDP/DDP/hw_session_package/package/hw_project/project_hw/project_hw.gen/sources_1/bd/ecdsa_project/ip/ecdsa_project_ecdsa_0_0/ecdsa_project_ecdsa_0_0_stub.v
// Design      : ecdsa_project_ecdsa_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* X_CORE_INFO = "ecdsa,Vivado 2023.1" *)
module ecdsa_project_ecdsa_0_0(clk, resetn, leds, rin0, rin1, rin2, rin3, rin4, rin5, 
  rin6, rin7, rout0, rout1, rout2, rout3, rout4, rout5, rout6, rout7, dma_rx_data, dma_tx_data, 
  dma_rx_address, dma_tx_address, dma_rx_start, dma_tx_start, dma_done, dma_idle, dma_error)
/* synthesis syn_black_box black_box_pad_pin="resetn,leds[3:0],rin0[31:0],rin1[31:0],rin2[31:0],rin3[31:0],rin4[31:0],rin5[31:0],rin6[31:0],rin7[31:0],rout0[31:0],rout1[31:0],rout2[31:0],rout3[31:0],rout4[31:0],rout5[31:0],rout6[31:0],rout7[31:0],dma_rx_data[1023:0],dma_tx_data[1023:0],dma_rx_address[31:0],dma_tx_address[31:0],dma_rx_start,dma_tx_start,dma_done,dma_idle,dma_error" */
/* synthesis syn_force_seq_prim="clk" */;
  input clk /* synthesis syn_isclock = 1 */;
  input resetn;
  output [3:0]leds;
  input [31:0]rin0;
  input [31:0]rin1;
  input [31:0]rin2;
  input [31:0]rin3;
  input [31:0]rin4;
  input [31:0]rin5;
  input [31:0]rin6;
  input [31:0]rin7;
  output [31:0]rout0;
  output [31:0]rout1;
  output [31:0]rout2;
  output [31:0]rout3;
  output [31:0]rout4;
  output [31:0]rout5;
  output [31:0]rout6;
  output [31:0]rout7;
  input [1023:0]dma_rx_data;
  output [1023:0]dma_tx_data;
  output [31:0]dma_rx_address;
  output [31:0]dma_tx_address;
  output dma_rx_start;
  output dma_tx_start;
  input dma_done;
  input dma_idle;
  input dma_error;
endmodule
