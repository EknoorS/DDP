// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2023.1 (lin64) Build 3865809 Sun May  7 15:04:56 MDT 2023
// Date        : Wed Nov 25 15:00:42 2026
// Host        : pc-klas1-14.esat.kuleuven.be running 64-bit Rocky Linux 9.9 (Blue Onyx)
// Command     : write_verilog -force -mode funcsim
//               /users/students/r1083141/DDP/DDP/hw_session_package/package/hw_project/project_hw/project_hw.gen/sources_1/bd/ecdsa_project/ip/ecdsa_project_auto_pc_1/ecdsa_project_auto_pc_1_sim_netlist.v
// Design      : ecdsa_project_auto_pc_1
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "ecdsa_project_auto_pc_1,axi_protocol_converter_v2_1_28_axi_protocol_converter,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* X_CORE_INFO = "axi_protocol_converter_v2_1_28_axi_protocol_converter,Vivado 2023.1" *) 
(* NotValidForBitStream *)
module ecdsa_project_auto_pc_1
   (aclk,
    aresetn,
    s_axi_awaddr,
    s_axi_awlen,
    s_axi_awsize,
    s_axi_awburst,
    s_axi_awlock,
    s_axi_awcache,
    s_axi_awprot,
    s_axi_awregion,
    s_axi_awqos,
    s_axi_awvalid,
    s_axi_awready,
    s_axi_wdata,
    s_axi_wstrb,
    s_axi_wlast,
    s_axi_wvalid,
    s_axi_wready,
    s_axi_bresp,
    s_axi_bvalid,
    s_axi_bready,
    s_axi_araddr,
    s_axi_arlen,
    s_axi_arsize,
    s_axi_arburst,
    s_axi_arlock,
    s_axi_arcache,
    s_axi_arprot,
    s_axi_arregion,
    s_axi_arqos,
    s_axi_arvalid,
    s_axi_arready,
    s_axi_rdata,
    s_axi_rresp,
    s_axi_rlast,
    s_axi_rvalid,
    s_axi_rready,
    m_axi_awaddr,
    m_axi_awlen,
    m_axi_awsize,
    m_axi_awburst,
    m_axi_awlock,
    m_axi_awcache,
    m_axi_awprot,
    m_axi_awqos,
    m_axi_awvalid,
    m_axi_awready,
    m_axi_wdata,
    m_axi_wstrb,
    m_axi_wlast,
    m_axi_wvalid,
    m_axi_wready,
    m_axi_bresp,
    m_axi_bvalid,
    m_axi_bready,
    m_axi_araddr,
    m_axi_arlen,
    m_axi_arsize,
    m_axi_arburst,
    m_axi_arlock,
    m_axi_arcache,
    m_axi_arprot,
    m_axi_arqos,
    m_axi_arvalid,
    m_axi_arready,
    m_axi_rdata,
    m_axi_rresp,
    m_axi_rlast,
    m_axi_rvalid,
    m_axi_rready);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN ecdsa_project_processing_system7_0_0_FCLK_CLK0, ASSOCIATED_BUSIF S_AXI:M_AXI, ASSOCIATED_RESET ARESETN, INSERT_VIP 0" *) input aclk;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 RST RST" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME RST, POLARITY ACTIVE_LOW, INSERT_VIP 0, TYPE INTERCONNECT" *) input aresetn;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI AWADDR" *) input [31:0]s_axi_awaddr;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI AWLEN" *) input [7:0]s_axi_awlen;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI AWSIZE" *) input [2:0]s_axi_awsize;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI AWBURST" *) input [1:0]s_axi_awburst;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI AWLOCK" *) input [0:0]s_axi_awlock;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI AWCACHE" *) input [3:0]s_axi_awcache;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI AWPROT" *) input [2:0]s_axi_awprot;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI AWREGION" *) input [3:0]s_axi_awregion;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI AWQOS" *) input [3:0]s_axi_awqos;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI AWVALID" *) input s_axi_awvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI AWREADY" *) output s_axi_awready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI WDATA" *) input [63:0]s_axi_wdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI WSTRB" *) input [7:0]s_axi_wstrb;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI WLAST" *) input s_axi_wlast;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI WVALID" *) input s_axi_wvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI WREADY" *) output s_axi_wready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI BRESP" *) output [1:0]s_axi_bresp;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI BVALID" *) output s_axi_bvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI BREADY" *) input s_axi_bready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI ARADDR" *) input [31:0]s_axi_araddr;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI ARLEN" *) input [7:0]s_axi_arlen;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI ARSIZE" *) input [2:0]s_axi_arsize;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI ARBURST" *) input [1:0]s_axi_arburst;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI ARLOCK" *) input [0:0]s_axi_arlock;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI ARCACHE" *) input [3:0]s_axi_arcache;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI ARPROT" *) input [2:0]s_axi_arprot;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI ARREGION" *) input [3:0]s_axi_arregion;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI ARQOS" *) input [3:0]s_axi_arqos;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI ARVALID" *) input s_axi_arvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI ARREADY" *) output s_axi_arready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI RDATA" *) output [63:0]s_axi_rdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI RRESP" *) output [1:0]s_axi_rresp;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI RLAST" *) output s_axi_rlast;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI RVALID" *) output s_axi_rvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI RREADY" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME S_AXI, DATA_WIDTH 64, PROTOCOL AXI4, FREQ_HZ 100000000, ID_WIDTH 0, ADDR_WIDTH 32, AWUSER_WIDTH 0, ARUSER_WIDTH 0, WUSER_WIDTH 0, RUSER_WIDTH 0, BUSER_WIDTH 0, READ_WRITE_MODE READ_WRITE, HAS_BURST 1, HAS_LOCK 1, HAS_PROT 1, HAS_CACHE 1, HAS_QOS 1, HAS_REGION 1, HAS_WSTRB 1, HAS_BRESP 1, HAS_RRESP 1, SUPPORTS_NARROW_BURST 0, NUM_READ_OUTSTANDING 8, NUM_WRITE_OUTSTANDING 8, MAX_BURST_LENGTH 256, PHASE 0.0, CLK_DOMAIN ecdsa_project_processing_system7_0_0_FCLK_CLK0, NUM_READ_THREADS 1, NUM_WRITE_THREADS 1, RUSER_BITS_PER_BYTE 0, WUSER_BITS_PER_BYTE 0, INSERT_VIP 0" *) input s_axi_rready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI AWADDR" *) output [31:0]m_axi_awaddr;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI AWLEN" *) output [3:0]m_axi_awlen;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI AWSIZE" *) output [2:0]m_axi_awsize;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI AWBURST" *) output [1:0]m_axi_awburst;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI AWLOCK" *) output [1:0]m_axi_awlock;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI AWCACHE" *) output [3:0]m_axi_awcache;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI AWPROT" *) output [2:0]m_axi_awprot;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI AWQOS" *) output [3:0]m_axi_awqos;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI AWVALID" *) output m_axi_awvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI AWREADY" *) input m_axi_awready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI WDATA" *) output [63:0]m_axi_wdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI WSTRB" *) output [7:0]m_axi_wstrb;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI WLAST" *) output m_axi_wlast;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI WVALID" *) output m_axi_wvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI WREADY" *) input m_axi_wready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI BRESP" *) input [1:0]m_axi_bresp;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI BVALID" *) input m_axi_bvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI BREADY" *) output m_axi_bready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI ARADDR" *) output [31:0]m_axi_araddr;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI ARLEN" *) output [3:0]m_axi_arlen;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI ARSIZE" *) output [2:0]m_axi_arsize;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI ARBURST" *) output [1:0]m_axi_arburst;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI ARLOCK" *) output [1:0]m_axi_arlock;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI ARCACHE" *) output [3:0]m_axi_arcache;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI ARPROT" *) output [2:0]m_axi_arprot;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI ARQOS" *) output [3:0]m_axi_arqos;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI ARVALID" *) output m_axi_arvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI ARREADY" *) input m_axi_arready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI RDATA" *) input [63:0]m_axi_rdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI RRESP" *) input [1:0]m_axi_rresp;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI RLAST" *) input m_axi_rlast;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI RVALID" *) input m_axi_rvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 M_AXI RREADY" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME M_AXI, DATA_WIDTH 64, PROTOCOL AXI3, FREQ_HZ 100000000, ID_WIDTH 0, ADDR_WIDTH 32, AWUSER_WIDTH 0, ARUSER_WIDTH 0, WUSER_WIDTH 0, RUSER_WIDTH 0, BUSER_WIDTH 0, READ_WRITE_MODE READ_WRITE, HAS_BURST 1, HAS_LOCK 0, HAS_PROT 0, HAS_CACHE 0, HAS_QOS 0, HAS_REGION 0, HAS_WSTRB 0, HAS_BRESP 0, HAS_RRESP 1, SUPPORTS_NARROW_BURST 0, NUM_READ_OUTSTANDING 8, NUM_WRITE_OUTSTANDING 8, MAX_BURST_LENGTH 16, PHASE 0.0, CLK_DOMAIN ecdsa_project_processing_system7_0_0_FCLK_CLK0, NUM_READ_THREADS 1, NUM_WRITE_THREADS 1, RUSER_BITS_PER_BYTE 0, WUSER_BITS_PER_BYTE 0, INSERT_VIP 0" *) output m_axi_rready;

  wire \<const0> ;
  wire aclk;
  wire aresetn;
  wire [31:0]m_axi_araddr;
  wire [1:0]m_axi_arburst;
  wire [3:0]m_axi_arcache;
  wire [3:0]m_axi_arlen;
  wire [0:0]\^m_axi_arlock ;
  wire [2:0]m_axi_arprot;
  wire [3:0]m_axi_arqos;
  wire m_axi_arready;
  wire [2:0]m_axi_arsize;
  wire m_axi_arvalid;
  wire [31:0]m_axi_awaddr;
  wire [1:0]m_axi_awburst;
  wire [3:0]m_axi_awcache;
  wire [3:0]m_axi_awlen;
  wire [0:0]\^m_axi_awlock ;
  wire [2:0]m_axi_awprot;
  wire [3:0]m_axi_awqos;
  wire m_axi_awready;
  wire [2:0]m_axi_awsize;
  wire m_axi_awvalid;
  wire m_axi_bready;
  wire [1:0]m_axi_bresp;
  wire m_axi_bvalid;
  wire [63:0]m_axi_rdata;
  wire m_axi_rlast;
  wire m_axi_rready;
  wire [1:0]m_axi_rresp;
  wire m_axi_rvalid;
  wire [63:0]m_axi_wdata;
  wire m_axi_wlast;
  wire m_axi_wready;
  wire [7:0]m_axi_wstrb;
  wire m_axi_wvalid;
  wire [31:0]s_axi_araddr;
  wire [1:0]s_axi_arburst;
  wire [3:0]s_axi_arcache;
  wire [7:0]s_axi_arlen;
  wire [0:0]s_axi_arlock;
  wire [2:0]s_axi_arprot;
  wire [3:0]s_axi_arqos;
  wire s_axi_arready;
  wire [2:0]s_axi_arsize;
  wire s_axi_arvalid;
  wire [31:0]s_axi_awaddr;
  wire [1:0]s_axi_awburst;
  wire [3:0]s_axi_awcache;
  wire [7:0]s_axi_awlen;
  wire [0:0]s_axi_awlock;
  wire [2:0]s_axi_awprot;
  wire [3:0]s_axi_awqos;
  wire s_axi_awready;
  wire [2:0]s_axi_awsize;
  wire s_axi_awvalid;
  wire s_axi_bready;
  wire [1:0]s_axi_bresp;
  wire s_axi_bvalid;
  wire [63:0]s_axi_rdata;
  wire s_axi_rlast;
  wire s_axi_rready;
  wire [1:0]s_axi_rresp;
  wire s_axi_rvalid;
  wire [63:0]s_axi_wdata;
  wire s_axi_wready;
  wire [7:0]s_axi_wstrb;
  wire s_axi_wvalid;
  wire [0:0]NLW_inst_m_axi_arid_UNCONNECTED;
  wire [1:1]NLW_inst_m_axi_arlock_UNCONNECTED;
  wire [3:0]NLW_inst_m_axi_arregion_UNCONNECTED;
  wire [0:0]NLW_inst_m_axi_aruser_UNCONNECTED;
  wire [0:0]NLW_inst_m_axi_awid_UNCONNECTED;
  wire [1:1]NLW_inst_m_axi_awlock_UNCONNECTED;
  wire [3:0]NLW_inst_m_axi_awregion_UNCONNECTED;
  wire [0:0]NLW_inst_m_axi_awuser_UNCONNECTED;
  wire [0:0]NLW_inst_m_axi_wid_UNCONNECTED;
  wire [0:0]NLW_inst_m_axi_wuser_UNCONNECTED;
  wire [0:0]NLW_inst_s_axi_bid_UNCONNECTED;
  wire [0:0]NLW_inst_s_axi_buser_UNCONNECTED;
  wire [0:0]NLW_inst_s_axi_rid_UNCONNECTED;
  wire [0:0]NLW_inst_s_axi_ruser_UNCONNECTED;

  assign m_axi_arlock[1] = \<const0> ;
  assign m_axi_arlock[0] = \^m_axi_arlock [0];
  assign m_axi_awlock[1] = \<const0> ;
  assign m_axi_awlock[0] = \^m_axi_awlock [0];
  GND GND
       (.G(\<const0> ));
  (* C_AXI_ADDR_WIDTH = "32" *) 
  (* C_AXI_ARUSER_WIDTH = "1" *) 
  (* C_AXI_AWUSER_WIDTH = "1" *) 
  (* C_AXI_BUSER_WIDTH = "1" *) 
  (* C_AXI_DATA_WIDTH = "64" *) 
  (* C_AXI_ID_WIDTH = "1" *) 
  (* C_AXI_RUSER_WIDTH = "1" *) 
  (* C_AXI_SUPPORTS_READ = "1" *) 
  (* C_AXI_SUPPORTS_USER_SIGNALS = "0" *) 
  (* C_AXI_SUPPORTS_WRITE = "1" *) 
  (* C_AXI_WUSER_WIDTH = "1" *) 
  (* C_FAMILY = "zynq" *) 
  (* C_IGNORE_ID = "1" *) 
  (* C_M_AXI_PROTOCOL = "1" *) 
  (* C_S_AXI_PROTOCOL = "0" *) 
  (* C_TRANSLATION_MODE = "0" *) 
  (* P_AXI3 = "1" *) 
  (* P_AXI4 = "0" *) 
  (* P_AXILITE = "2" *) 
  (* P_AXILITE_SIZE = "3'b011" *) 
  (* P_CONVERSION = "2" *) 
  (* P_DECERR = "2'b11" *) 
  (* P_INCR = "2'b01" *) 
  (* P_PROTECTION = "1" *) 
  (* P_SLVERR = "2'b10" *) 
  (* downgradeipidentifiedwarnings = "yes" *) 
  ecdsa_project_auto_pc_1_axi_protocol_converter_v2_1_28_axi_protocol_converter inst
       (.aclk(aclk),
        .aresetn(aresetn),
        .m_axi_araddr(m_axi_araddr),
        .m_axi_arburst(m_axi_arburst),
        .m_axi_arcache(m_axi_arcache),
        .m_axi_arid(NLW_inst_m_axi_arid_UNCONNECTED[0]),
        .m_axi_arlen(m_axi_arlen),
        .m_axi_arlock({NLW_inst_m_axi_arlock_UNCONNECTED[1],\^m_axi_arlock }),
        .m_axi_arprot(m_axi_arprot),
        .m_axi_arqos(m_axi_arqos),
        .m_axi_arready(m_axi_arready),
        .m_axi_arregion(NLW_inst_m_axi_arregion_UNCONNECTED[3:0]),
        .m_axi_arsize(m_axi_arsize),
        .m_axi_aruser(NLW_inst_m_axi_aruser_UNCONNECTED[0]),
        .m_axi_arvalid(m_axi_arvalid),
        .m_axi_awaddr(m_axi_awaddr),
        .m_axi_awburst(m_axi_awburst),
        .m_axi_awcache(m_axi_awcache),
        .m_axi_awid(NLW_inst_m_axi_awid_UNCONNECTED[0]),
        .m_axi_awlen(m_axi_awlen),
        .m_axi_awlock({NLW_inst_m_axi_awlock_UNCONNECTED[1],\^m_axi_awlock }),
        .m_axi_awprot(m_axi_awprot),
        .m_axi_awqos(m_axi_awqos),
        .m_axi_awready(m_axi_awready),
        .m_axi_awregion(NLW_inst_m_axi_awregion_UNCONNECTED[3:0]),
        .m_axi_awsize(m_axi_awsize),
        .m_axi_awuser(NLW_inst_m_axi_awuser_UNCONNECTED[0]),
        .m_axi_awvalid(m_axi_awvalid),
        .m_axi_bid(1'b0),
        .m_axi_bready(m_axi_bready),
        .m_axi_bresp(m_axi_bresp),
        .m_axi_buser(1'b0),
        .m_axi_bvalid(m_axi_bvalid),
        .m_axi_rdata(m_axi_rdata),
        .m_axi_rid(1'b0),
        .m_axi_rlast(m_axi_rlast),
        .m_axi_rready(m_axi_rready),
        .m_axi_rresp(m_axi_rresp),
        .m_axi_ruser(1'b0),
        .m_axi_rvalid(m_axi_rvalid),
        .m_axi_wdata(m_axi_wdata),
        .m_axi_wid(NLW_inst_m_axi_wid_UNCONNECTED[0]),
        .m_axi_wlast(m_axi_wlast),
        .m_axi_wready(m_axi_wready),
        .m_axi_wstrb(m_axi_wstrb),
        .m_axi_wuser(NLW_inst_m_axi_wuser_UNCONNECTED[0]),
        .m_axi_wvalid(m_axi_wvalid),
        .s_axi_araddr(s_axi_araddr),
        .s_axi_arburst(s_axi_arburst),
        .s_axi_arcache(s_axi_arcache),
        .s_axi_arid(1'b0),
        .s_axi_arlen({1'b0,1'b0,1'b0,1'b0,s_axi_arlen[3:0]}),
        .s_axi_arlock(s_axi_arlock),
        .s_axi_arprot(s_axi_arprot),
        .s_axi_arqos(s_axi_arqos),
        .s_axi_arready(s_axi_arready),
        .s_axi_arregion({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arsize(s_axi_arsize),
        .s_axi_aruser(1'b0),
        .s_axi_arvalid(s_axi_arvalid),
        .s_axi_awaddr(s_axi_awaddr),
        .s_axi_awburst(s_axi_awburst),
        .s_axi_awcache(s_axi_awcache),
        .s_axi_awid(1'b0),
        .s_axi_awlen({1'b0,1'b0,1'b0,1'b0,s_axi_awlen[3:0]}),
        .s_axi_awlock(s_axi_awlock),
        .s_axi_awprot(s_axi_awprot),
        .s_axi_awqos(s_axi_awqos),
        .s_axi_awready(s_axi_awready),
        .s_axi_awregion({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awsize(s_axi_awsize),
        .s_axi_awuser(1'b0),
        .s_axi_awvalid(s_axi_awvalid),
        .s_axi_bid(NLW_inst_s_axi_bid_UNCONNECTED[0]),
        .s_axi_bready(s_axi_bready),
        .s_axi_bresp(s_axi_bresp),
        .s_axi_buser(NLW_inst_s_axi_buser_UNCONNECTED[0]),
        .s_axi_bvalid(s_axi_bvalid),
        .s_axi_rdata(s_axi_rdata),
        .s_axi_rid(NLW_inst_s_axi_rid_UNCONNECTED[0]),
        .s_axi_rlast(s_axi_rlast),
        .s_axi_rready(s_axi_rready),
        .s_axi_rresp(s_axi_rresp),
        .s_axi_ruser(NLW_inst_s_axi_ruser_UNCONNECTED[0]),
        .s_axi_rvalid(s_axi_rvalid),
        .s_axi_wdata(s_axi_wdata),
        .s_axi_wid(1'b0),
        .s_axi_wlast(1'b0),
        .s_axi_wready(s_axi_wready),
        .s_axi_wstrb(s_axi_wstrb),
        .s_axi_wuser(1'b0),
        .s_axi_wvalid(s_axi_wvalid));
endmodule

(* ORIG_REF_NAME = "axi_data_fifo_v2_1_27_axic_fifo" *) 
module ecdsa_project_auto_pc_1_axi_data_fifo_v2_1_27_axic_fifo
   (dout,
    empty,
    SR,
    aresetn_0,
    m_axi_awvalid,
    length_counter_1_reg_1_sp_1,
    empty_fwft_i_reg,
    m_axi_wvalid,
    S_AXI_AREADY_I_reg,
    \areset_d_reg[1] ,
    aclk,
    m_axi_awlen,
    rd_en,
    aresetn,
    m_axi_awvalid_0,
    command_ongoing,
    m_axi_awready,
    length_counter_1_reg,
    first_mi_word,
    s_axi_wvalid,
    m_axi_wready,
    E,
    s_axi_awvalid,
    Q);
  output [3:0]dout;
  output empty;
  output [0:0]SR;
  output aresetn_0;
  output m_axi_awvalid;
  output length_counter_1_reg_1_sp_1;
  output empty_fwft_i_reg;
  output m_axi_wvalid;
  output S_AXI_AREADY_I_reg;
  output \areset_d_reg[1] ;
  input aclk;
  input [3:0]m_axi_awlen;
  input rd_en;
  input aresetn;
  input m_axi_awvalid_0;
  input command_ongoing;
  input m_axi_awready;
  input [1:0]length_counter_1_reg;
  input first_mi_word;
  input s_axi_wvalid;
  input m_axi_wready;
  input [0:0]E;
  input s_axi_awvalid;
  input [1:0]Q;

  wire [0:0]E;
  wire [1:0]Q;
  wire [0:0]SR;
  wire S_AXI_AREADY_I_reg;
  wire aclk;
  wire \areset_d_reg[1] ;
  wire aresetn;
  wire aresetn_0;
  wire command_ongoing;
  wire [3:0]dout;
  wire empty;
  wire empty_fwft_i_reg;
  wire first_mi_word;
  wire [1:0]length_counter_1_reg;
  wire length_counter_1_reg_1_sn_1;
  wire [3:0]m_axi_awlen;
  wire m_axi_awready;
  wire m_axi_awvalid;
  wire m_axi_awvalid_0;
  wire m_axi_wready;
  wire m_axi_wvalid;
  wire rd_en;
  wire s_axi_awvalid;
  wire s_axi_wvalid;

  assign length_counter_1_reg_1_sp_1 = length_counter_1_reg_1_sn_1;
  ecdsa_project_auto_pc_1_axi_data_fifo_v2_1_27_fifo_gen inst
       (.E(E),
        .Q(Q),
        .SR(SR),
        .S_AXI_AREADY_I_reg(S_AXI_AREADY_I_reg),
        .aclk(aclk),
        .\areset_d_reg[1] (\areset_d_reg[1] ),
        .aresetn(aresetn),
        .aresetn_0(aresetn_0),
        .command_ongoing(command_ongoing),
        .dout(dout),
        .empty(empty),
        .empty_fwft_i_reg(empty_fwft_i_reg),
        .first_mi_word(first_mi_word),
        .length_counter_1_reg(length_counter_1_reg),
        .length_counter_1_reg_1_sp_1(length_counter_1_reg_1_sn_1),
        .m_axi_awlen(m_axi_awlen),
        .m_axi_awready(m_axi_awready),
        .m_axi_awvalid(m_axi_awvalid),
        .m_axi_awvalid_0(m_axi_awvalid_0),
        .m_axi_wready(m_axi_wready),
        .m_axi_wvalid(m_axi_wvalid),
        .rd_en(rd_en),
        .s_axi_awvalid(s_axi_awvalid),
        .s_axi_wvalid(s_axi_wvalid));
endmodule

(* ORIG_REF_NAME = "axi_data_fifo_v2_1_27_fifo_gen" *) 
module ecdsa_project_auto_pc_1_axi_data_fifo_v2_1_27_fifo_gen
   (dout,
    empty,
    SR,
    aresetn_0,
    m_axi_awvalid,
    length_counter_1_reg_1_sp_1,
    empty_fwft_i_reg,
    m_axi_wvalid,
    S_AXI_AREADY_I_reg,
    \areset_d_reg[1] ,
    aclk,
    m_axi_awlen,
    rd_en,
    aresetn,
    m_axi_awvalid_0,
    command_ongoing,
    m_axi_awready,
    length_counter_1_reg,
    first_mi_word,
    s_axi_wvalid,
    m_axi_wready,
    E,
    s_axi_awvalid,
    Q);
  output [3:0]dout;
  output empty;
  output [0:0]SR;
  output aresetn_0;
  output m_axi_awvalid;
  output length_counter_1_reg_1_sp_1;
  output empty_fwft_i_reg;
  output m_axi_wvalid;
  output S_AXI_AREADY_I_reg;
  output \areset_d_reg[1] ;
  input aclk;
  input [3:0]m_axi_awlen;
  input rd_en;
  input aresetn;
  input m_axi_awvalid_0;
  input command_ongoing;
  input m_axi_awready;
  input [1:0]length_counter_1_reg;
  input first_mi_word;
  input s_axi_wvalid;
  input m_axi_wready;
  input [0:0]E;
  input s_axi_awvalid;
  input [1:0]Q;

  wire [0:0]E;
  wire [1:0]Q;
  wire [0:0]SR;
  wire S_AXI_AREADY_I_i_3_n_0;
  wire S_AXI_AREADY_I_reg;
  wire aclk;
  wire \areset_d_reg[1] ;
  wire aresetn;
  wire aresetn_0;
  wire cmd_push;
  wire command_ongoing;
  wire command_ongoing_i_2_n_0;
  wire [3:0]dout;
  wire empty;
  wire empty_fwft_i_reg;
  wire first_mi_word;
  wire full;
  wire [1:0]length_counter_1_reg;
  wire length_counter_1_reg_1_sn_1;
  wire [3:0]m_axi_awlen;
  wire m_axi_awready;
  wire m_axi_awvalid;
  wire m_axi_awvalid_0;
  wire m_axi_wready;
  wire m_axi_wvalid;
  wire rd_en;
  wire s_axi_awvalid;
  wire s_axi_wvalid;
  wire NLW_fifo_gen_inst_almost_empty_UNCONNECTED;
  wire NLW_fifo_gen_inst_almost_full_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_ar_dbiterr_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_ar_overflow_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_ar_prog_empty_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_ar_prog_full_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_ar_sbiterr_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_ar_underflow_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_aw_dbiterr_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_aw_overflow_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_aw_prog_empty_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_aw_prog_full_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_aw_sbiterr_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_aw_underflow_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_b_dbiterr_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_b_overflow_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_b_prog_empty_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_b_prog_full_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_b_sbiterr_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_b_underflow_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_r_dbiterr_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_r_overflow_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_r_prog_empty_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_r_prog_full_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_r_sbiterr_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_r_underflow_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_w_dbiterr_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_w_overflow_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_w_prog_empty_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_w_prog_full_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_w_sbiterr_UNCONNECTED;
  wire NLW_fifo_gen_inst_axi_w_underflow_UNCONNECTED;
  wire NLW_fifo_gen_inst_axis_dbiterr_UNCONNECTED;
  wire NLW_fifo_gen_inst_axis_overflow_UNCONNECTED;
  wire NLW_fifo_gen_inst_axis_prog_empty_UNCONNECTED;
  wire NLW_fifo_gen_inst_axis_prog_full_UNCONNECTED;
  wire NLW_fifo_gen_inst_axis_sbiterr_UNCONNECTED;
  wire NLW_fifo_gen_inst_axis_underflow_UNCONNECTED;
  wire NLW_fifo_gen_inst_dbiterr_UNCONNECTED;
  wire NLW_fifo_gen_inst_m_axi_arvalid_UNCONNECTED;
  wire NLW_fifo_gen_inst_m_axi_awvalid_UNCONNECTED;
  wire NLW_fifo_gen_inst_m_axi_bready_UNCONNECTED;
  wire NLW_fifo_gen_inst_m_axi_rready_UNCONNECTED;
  wire NLW_fifo_gen_inst_m_axi_wlast_UNCONNECTED;
  wire NLW_fifo_gen_inst_m_axi_wvalid_UNCONNECTED;
  wire NLW_fifo_gen_inst_m_axis_tlast_UNCONNECTED;
  wire NLW_fifo_gen_inst_m_axis_tvalid_UNCONNECTED;
  wire NLW_fifo_gen_inst_overflow_UNCONNECTED;
  wire NLW_fifo_gen_inst_prog_empty_UNCONNECTED;
  wire NLW_fifo_gen_inst_prog_full_UNCONNECTED;
  wire NLW_fifo_gen_inst_rd_rst_busy_UNCONNECTED;
  wire NLW_fifo_gen_inst_s_axi_arready_UNCONNECTED;
  wire NLW_fifo_gen_inst_s_axi_awready_UNCONNECTED;
  wire NLW_fifo_gen_inst_s_axi_bvalid_UNCONNECTED;
  wire NLW_fifo_gen_inst_s_axi_rlast_UNCONNECTED;
  wire NLW_fifo_gen_inst_s_axi_rvalid_UNCONNECTED;
  wire NLW_fifo_gen_inst_s_axi_wready_UNCONNECTED;
  wire NLW_fifo_gen_inst_s_axis_tready_UNCONNECTED;
  wire NLW_fifo_gen_inst_sbiterr_UNCONNECTED;
  wire NLW_fifo_gen_inst_underflow_UNCONNECTED;
  wire NLW_fifo_gen_inst_valid_UNCONNECTED;
  wire NLW_fifo_gen_inst_wr_ack_UNCONNECTED;
  wire NLW_fifo_gen_inst_wr_rst_busy_UNCONNECTED;
  wire [4:0]NLW_fifo_gen_inst_axi_ar_data_count_UNCONNECTED;
  wire [4:0]NLW_fifo_gen_inst_axi_ar_rd_data_count_UNCONNECTED;
  wire [4:0]NLW_fifo_gen_inst_axi_ar_wr_data_count_UNCONNECTED;
  wire [4:0]NLW_fifo_gen_inst_axi_aw_data_count_UNCONNECTED;
  wire [4:0]NLW_fifo_gen_inst_axi_aw_rd_data_count_UNCONNECTED;
  wire [4:0]NLW_fifo_gen_inst_axi_aw_wr_data_count_UNCONNECTED;
  wire [4:0]NLW_fifo_gen_inst_axi_b_data_count_UNCONNECTED;
  wire [4:0]NLW_fifo_gen_inst_axi_b_rd_data_count_UNCONNECTED;
  wire [4:0]NLW_fifo_gen_inst_axi_b_wr_data_count_UNCONNECTED;
  wire [10:0]NLW_fifo_gen_inst_axi_r_data_count_UNCONNECTED;
  wire [10:0]NLW_fifo_gen_inst_axi_r_rd_data_count_UNCONNECTED;
  wire [10:0]NLW_fifo_gen_inst_axi_r_wr_data_count_UNCONNECTED;
  wire [10:0]NLW_fifo_gen_inst_axi_w_data_count_UNCONNECTED;
  wire [10:0]NLW_fifo_gen_inst_axi_w_rd_data_count_UNCONNECTED;
  wire [10:0]NLW_fifo_gen_inst_axi_w_wr_data_count_UNCONNECTED;
  wire [10:0]NLW_fifo_gen_inst_axis_data_count_UNCONNECTED;
  wire [10:0]NLW_fifo_gen_inst_axis_rd_data_count_UNCONNECTED;
  wire [10:0]NLW_fifo_gen_inst_axis_wr_data_count_UNCONNECTED;
  wire [5:0]NLW_fifo_gen_inst_data_count_UNCONNECTED;
  wire [4:4]NLW_fifo_gen_inst_dout_UNCONNECTED;
  wire [31:0]NLW_fifo_gen_inst_m_axi_araddr_UNCONNECTED;
  wire [1:0]NLW_fifo_gen_inst_m_axi_arburst_UNCONNECTED;
  wire [3:0]NLW_fifo_gen_inst_m_axi_arcache_UNCONNECTED;
  wire [3:0]NLW_fifo_gen_inst_m_axi_arid_UNCONNECTED;
  wire [7:0]NLW_fifo_gen_inst_m_axi_arlen_UNCONNECTED;
  wire [1:0]NLW_fifo_gen_inst_m_axi_arlock_UNCONNECTED;
  wire [2:0]NLW_fifo_gen_inst_m_axi_arprot_UNCONNECTED;
  wire [3:0]NLW_fifo_gen_inst_m_axi_arqos_UNCONNECTED;
  wire [3:0]NLW_fifo_gen_inst_m_axi_arregion_UNCONNECTED;
  wire [2:0]NLW_fifo_gen_inst_m_axi_arsize_UNCONNECTED;
  wire [0:0]NLW_fifo_gen_inst_m_axi_aruser_UNCONNECTED;
  wire [31:0]NLW_fifo_gen_inst_m_axi_awaddr_UNCONNECTED;
  wire [1:0]NLW_fifo_gen_inst_m_axi_awburst_UNCONNECTED;
  wire [3:0]NLW_fifo_gen_inst_m_axi_awcache_UNCONNECTED;
  wire [3:0]NLW_fifo_gen_inst_m_axi_awid_UNCONNECTED;
  wire [7:0]NLW_fifo_gen_inst_m_axi_awlen_UNCONNECTED;
  wire [1:0]NLW_fifo_gen_inst_m_axi_awlock_UNCONNECTED;
  wire [2:0]NLW_fifo_gen_inst_m_axi_awprot_UNCONNECTED;
  wire [3:0]NLW_fifo_gen_inst_m_axi_awqos_UNCONNECTED;
  wire [3:0]NLW_fifo_gen_inst_m_axi_awregion_UNCONNECTED;
  wire [2:0]NLW_fifo_gen_inst_m_axi_awsize_UNCONNECTED;
  wire [0:0]NLW_fifo_gen_inst_m_axi_awuser_UNCONNECTED;
  wire [63:0]NLW_fifo_gen_inst_m_axi_wdata_UNCONNECTED;
  wire [3:0]NLW_fifo_gen_inst_m_axi_wid_UNCONNECTED;
  wire [7:0]NLW_fifo_gen_inst_m_axi_wstrb_UNCONNECTED;
  wire [0:0]NLW_fifo_gen_inst_m_axi_wuser_UNCONNECTED;
  wire [63:0]NLW_fifo_gen_inst_m_axis_tdata_UNCONNECTED;
  wire [3:0]NLW_fifo_gen_inst_m_axis_tdest_UNCONNECTED;
  wire [7:0]NLW_fifo_gen_inst_m_axis_tid_UNCONNECTED;
  wire [3:0]NLW_fifo_gen_inst_m_axis_tkeep_UNCONNECTED;
  wire [3:0]NLW_fifo_gen_inst_m_axis_tstrb_UNCONNECTED;
  wire [3:0]NLW_fifo_gen_inst_m_axis_tuser_UNCONNECTED;
  wire [5:0]NLW_fifo_gen_inst_rd_data_count_UNCONNECTED;
  wire [3:0]NLW_fifo_gen_inst_s_axi_bid_UNCONNECTED;
  wire [1:0]NLW_fifo_gen_inst_s_axi_bresp_UNCONNECTED;
  wire [0:0]NLW_fifo_gen_inst_s_axi_buser_UNCONNECTED;
  wire [63:0]NLW_fifo_gen_inst_s_axi_rdata_UNCONNECTED;
  wire [3:0]NLW_fifo_gen_inst_s_axi_rid_UNCONNECTED;
  wire [1:0]NLW_fifo_gen_inst_s_axi_rresp_UNCONNECTED;
  wire [0:0]NLW_fifo_gen_inst_s_axi_ruser_UNCONNECTED;
  wire [5:0]NLW_fifo_gen_inst_wr_data_count_UNCONNECTED;

  assign length_counter_1_reg_1_sp_1 = length_counter_1_reg_1_sn_1;
  LUT1 #(
    .INIT(2'h1)) 
    S_AXI_AREADY_I_i_1
       (.I0(aresetn),
        .O(SR));
  LUT6 #(
    .INIT(64'h22722272FFFF2272)) 
    S_AXI_AREADY_I_i_2
       (.I0(E),
        .I1(s_axi_awvalid),
        .I2(m_axi_awready),
        .I3(S_AXI_AREADY_I_i_3_n_0),
        .I4(Q[1]),
        .I5(Q[0]),
        .O(S_AXI_AREADY_I_reg));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'h4F)) 
    S_AXI_AREADY_I_i_3
       (.I0(m_axi_awvalid_0),
        .I1(full),
        .I2(command_ongoing),
        .O(S_AXI_AREADY_I_i_3_n_0));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT5 #(
    .INIT(32'h00888A88)) 
    cmd_push_block_i_1
       (.I0(aresetn),
        .I1(m_axi_awvalid_0),
        .I2(full),
        .I3(command_ongoing),
        .I4(m_axi_awready),
        .O(aresetn_0));
  LUT6 #(
    .INIT(64'hF222FFFFD000D000)) 
    command_ongoing_i_1
       (.I0(Q[1]),
        .I1(Q[0]),
        .I2(E),
        .I3(s_axi_awvalid),
        .I4(command_ongoing_i_2_n_0),
        .I5(command_ongoing),
        .O(\areset_d_reg[1] ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT4 #(
    .INIT(16'h8808)) 
    command_ongoing_i_2
       (.I0(m_axi_awready),
        .I1(command_ongoing),
        .I2(full),
        .I3(m_axi_awvalid_0),
        .O(command_ongoing_i_2_n_0));
  (* C_ADD_NGC_CONSTRAINT = "0" *) 
  (* C_APPLICATION_TYPE_AXIS = "0" *) 
  (* C_APPLICATION_TYPE_RACH = "0" *) 
  (* C_APPLICATION_TYPE_RDCH = "0" *) 
  (* C_APPLICATION_TYPE_WACH = "0" *) 
  (* C_APPLICATION_TYPE_WDCH = "0" *) 
  (* C_APPLICATION_TYPE_WRCH = "0" *) 
  (* C_AXIS_TDATA_WIDTH = "64" *) 
  (* C_AXIS_TDEST_WIDTH = "4" *) 
  (* C_AXIS_TID_WIDTH = "8" *) 
  (* C_AXIS_TKEEP_WIDTH = "4" *) 
  (* C_AXIS_TSTRB_WIDTH = "4" *) 
  (* C_AXIS_TUSER_WIDTH = "4" *) 
  (* C_AXIS_TYPE = "0" *) 
  (* C_AXI_ADDR_WIDTH = "32" *) 
  (* C_AXI_ARUSER_WIDTH = "1" *) 
  (* C_AXI_AWUSER_WIDTH = "1" *) 
  (* C_AXI_BUSER_WIDTH = "1" *) 
  (* C_AXI_DATA_WIDTH = "64" *) 
  (* C_AXI_ID_WIDTH = "4" *) 
  (* C_AXI_LEN_WIDTH = "8" *) 
  (* C_AXI_LOCK_WIDTH = "2" *) 
  (* C_AXI_RUSER_WIDTH = "1" *) 
  (* C_AXI_TYPE = "0" *) 
  (* C_AXI_WUSER_WIDTH = "1" *) 
  (* C_COMMON_CLOCK = "1" *) 
  (* C_COUNT_TYPE = "0" *) 
  (* C_DATA_COUNT_WIDTH = "6" *) 
  (* C_DEFAULT_VALUE = "BlankString" *) 
  (* C_DIN_WIDTH = "5" *) 
  (* C_DIN_WIDTH_AXIS = "1" *) 
  (* C_DIN_WIDTH_RACH = "32" *) 
  (* C_DIN_WIDTH_RDCH = "64" *) 
  (* C_DIN_WIDTH_WACH = "32" *) 
  (* C_DIN_WIDTH_WDCH = "64" *) 
  (* C_DIN_WIDTH_WRCH = "2" *) 
  (* C_DOUT_RST_VAL = "0" *) 
  (* C_DOUT_WIDTH = "5" *) 
  (* C_ENABLE_RLOCS = "0" *) 
  (* C_ENABLE_RST_SYNC = "1" *) 
  (* C_EN_SAFETY_CKT = "0" *) 
  (* C_ERROR_INJECTION_TYPE = "0" *) 
  (* C_ERROR_INJECTION_TYPE_AXIS = "0" *) 
  (* C_ERROR_INJECTION_TYPE_RACH = "0" *) 
  (* C_ERROR_INJECTION_TYPE_RDCH = "0" *) 
  (* C_ERROR_INJECTION_TYPE_WACH = "0" *) 
  (* C_ERROR_INJECTION_TYPE_WDCH = "0" *) 
  (* C_ERROR_INJECTION_TYPE_WRCH = "0" *) 
  (* C_FAMILY = "zynq" *) 
  (* C_FULL_FLAGS_RST_VAL = "0" *) 
  (* C_HAS_ALMOST_EMPTY = "0" *) 
  (* C_HAS_ALMOST_FULL = "0" *) 
  (* C_HAS_AXIS_TDATA = "0" *) 
  (* C_HAS_AXIS_TDEST = "0" *) 
  (* C_HAS_AXIS_TID = "0" *) 
  (* C_HAS_AXIS_TKEEP = "0" *) 
  (* C_HAS_AXIS_TLAST = "0" *) 
  (* C_HAS_AXIS_TREADY = "1" *) 
  (* C_HAS_AXIS_TSTRB = "0" *) 
  (* C_HAS_AXIS_TUSER = "0" *) 
  (* C_HAS_AXI_ARUSER = "0" *) 
  (* C_HAS_AXI_AWUSER = "0" *) 
  (* C_HAS_AXI_BUSER = "0" *) 
  (* C_HAS_AXI_ID = "0" *) 
  (* C_HAS_AXI_RD_CHANNEL = "0" *) 
  (* C_HAS_AXI_RUSER = "0" *) 
  (* C_HAS_AXI_WR_CHANNEL = "0" *) 
  (* C_HAS_AXI_WUSER = "0" *) 
  (* C_HAS_BACKUP = "0" *) 
  (* C_HAS_DATA_COUNT = "0" *) 
  (* C_HAS_DATA_COUNTS_AXIS = "0" *) 
  (* C_HAS_DATA_COUNTS_RACH = "0" *) 
  (* C_HAS_DATA_COUNTS_RDCH = "0" *) 
  (* C_HAS_DATA_COUNTS_WACH = "0" *) 
  (* C_HAS_DATA_COUNTS_WDCH = "0" *) 
  (* C_HAS_DATA_COUNTS_WRCH = "0" *) 
  (* C_HAS_INT_CLK = "0" *) 
  (* C_HAS_MASTER_CE = "0" *) 
  (* C_HAS_MEMINIT_FILE = "0" *) 
  (* C_HAS_OVERFLOW = "0" *) 
  (* C_HAS_PROG_FLAGS_AXIS = "0" *) 
  (* C_HAS_PROG_FLAGS_RACH = "0" *) 
  (* C_HAS_PROG_FLAGS_RDCH = "0" *) 
  (* C_HAS_PROG_FLAGS_WACH = "0" *) 
  (* C_HAS_PROG_FLAGS_WDCH = "0" *) 
  (* C_HAS_PROG_FLAGS_WRCH = "0" *) 
  (* C_HAS_RD_DATA_COUNT = "0" *) 
  (* C_HAS_RD_RST = "0" *) 
  (* C_HAS_RST = "1" *) 
  (* C_HAS_SLAVE_CE = "0" *) 
  (* C_HAS_SRST = "0" *) 
  (* C_HAS_UNDERFLOW = "0" *) 
  (* C_HAS_VALID = "0" *) 
  (* C_HAS_WR_ACK = "0" *) 
  (* C_HAS_WR_DATA_COUNT = "0" *) 
  (* C_HAS_WR_RST = "0" *) 
  (* C_IMPLEMENTATION_TYPE = "0" *) 
  (* C_IMPLEMENTATION_TYPE_AXIS = "1" *) 
  (* C_IMPLEMENTATION_TYPE_RACH = "1" *) 
  (* C_IMPLEMENTATION_TYPE_RDCH = "1" *) 
  (* C_IMPLEMENTATION_TYPE_WACH = "1" *) 
  (* C_IMPLEMENTATION_TYPE_WDCH = "1" *) 
  (* C_IMPLEMENTATION_TYPE_WRCH = "1" *) 
  (* C_INIT_WR_PNTR_VAL = "0" *) 
  (* C_INTERFACE_TYPE = "0" *) 
  (* C_MEMORY_TYPE = "2" *) 
  (* C_MIF_FILE_NAME = "BlankString" *) 
  (* C_MSGON_VAL = "1" *) 
  (* C_OPTIMIZATION_MODE = "0" *) 
  (* C_OVERFLOW_LOW = "0" *) 
  (* C_POWER_SAVING_MODE = "0" *) 
  (* C_PRELOAD_LATENCY = "0" *) 
  (* C_PRELOAD_REGS = "1" *) 
  (* C_PRIM_FIFO_TYPE = "512x36" *) 
  (* C_PRIM_FIFO_TYPE_AXIS = "512x36" *) 
  (* C_PRIM_FIFO_TYPE_RACH = "512x36" *) 
  (* C_PRIM_FIFO_TYPE_RDCH = "512x36" *) 
  (* C_PRIM_FIFO_TYPE_WACH = "512x36" *) 
  (* C_PRIM_FIFO_TYPE_WDCH = "512x36" *) 
  (* C_PRIM_FIFO_TYPE_WRCH = "512x36" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL = "4" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_AXIS = "1022" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_RACH = "1022" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_RDCH = "1022" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_WACH = "1022" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_WDCH = "1022" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_WRCH = "1022" *) 
  (* C_PROG_EMPTY_THRESH_NEGATE_VAL = "5" *) 
  (* C_PROG_EMPTY_TYPE = "0" *) 
  (* C_PROG_EMPTY_TYPE_AXIS = "0" *) 
  (* C_PROG_EMPTY_TYPE_RACH = "0" *) 
  (* C_PROG_EMPTY_TYPE_RDCH = "0" *) 
  (* C_PROG_EMPTY_TYPE_WACH = "0" *) 
  (* C_PROG_EMPTY_TYPE_WDCH = "0" *) 
  (* C_PROG_EMPTY_TYPE_WRCH = "0" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL = "31" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_AXIS = "1023" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_RACH = "1023" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_RDCH = "1023" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_WACH = "1023" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_WDCH = "1023" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_WRCH = "1023" *) 
  (* C_PROG_FULL_THRESH_NEGATE_VAL = "30" *) 
  (* C_PROG_FULL_TYPE = "0" *) 
  (* C_PROG_FULL_TYPE_AXIS = "0" *) 
  (* C_PROG_FULL_TYPE_RACH = "0" *) 
  (* C_PROG_FULL_TYPE_RDCH = "0" *) 
  (* C_PROG_FULL_TYPE_WACH = "0" *) 
  (* C_PROG_FULL_TYPE_WDCH = "0" *) 
  (* C_PROG_FULL_TYPE_WRCH = "0" *) 
  (* C_RACH_TYPE = "0" *) 
  (* C_RDCH_TYPE = "0" *) 
  (* C_RD_DATA_COUNT_WIDTH = "6" *) 
  (* C_RD_DEPTH = "32" *) 
  (* C_RD_FREQ = "1" *) 
  (* C_RD_PNTR_WIDTH = "5" *) 
  (* C_REG_SLICE_MODE_AXIS = "0" *) 
  (* C_REG_SLICE_MODE_RACH = "0" *) 
  (* C_REG_SLICE_MODE_RDCH = "0" *) 
  (* C_REG_SLICE_MODE_WACH = "0" *) 
  (* C_REG_SLICE_MODE_WDCH = "0" *) 
  (* C_REG_SLICE_MODE_WRCH = "0" *) 
  (* C_SELECT_XPM = "0" *) 
  (* C_SYNCHRONIZER_STAGE = "3" *) 
  (* C_UNDERFLOW_LOW = "0" *) 
  (* C_USE_COMMON_OVERFLOW = "0" *) 
  (* C_USE_COMMON_UNDERFLOW = "0" *) 
  (* C_USE_DEFAULT_SETTINGS = "0" *) 
  (* C_USE_DOUT_RST = "0" *) 
  (* C_USE_ECC = "0" *) 
  (* C_USE_ECC_AXIS = "0" *) 
  (* C_USE_ECC_RACH = "0" *) 
  (* C_USE_ECC_RDCH = "0" *) 
  (* C_USE_ECC_WACH = "0" *) 
  (* C_USE_ECC_WDCH = "0" *) 
  (* C_USE_ECC_WRCH = "0" *) 
  (* C_USE_EMBEDDED_REG = "0" *) 
  (* C_USE_FIFO16_FLAGS = "0" *) 
  (* C_USE_FWFT_DATA_COUNT = "1" *) 
  (* C_USE_PIPELINE_REG = "0" *) 
  (* C_VALID_LOW = "0" *) 
  (* C_WACH_TYPE = "0" *) 
  (* C_WDCH_TYPE = "0" *) 
  (* C_WRCH_TYPE = "0" *) 
  (* C_WR_ACK_LOW = "0" *) 
  (* C_WR_DATA_COUNT_WIDTH = "6" *) 
  (* C_WR_DEPTH = "32" *) 
  (* C_WR_DEPTH_AXIS = "1024" *) 
  (* C_WR_DEPTH_RACH = "16" *) 
  (* C_WR_DEPTH_RDCH = "1024" *) 
  (* C_WR_DEPTH_WACH = "16" *) 
  (* C_WR_DEPTH_WDCH = "1024" *) 
  (* C_WR_DEPTH_WRCH = "16" *) 
  (* C_WR_FREQ = "1" *) 
  (* C_WR_PNTR_WIDTH = "5" *) 
  (* C_WR_PNTR_WIDTH_AXIS = "10" *) 
  (* C_WR_PNTR_WIDTH_RACH = "4" *) 
  (* C_WR_PNTR_WIDTH_RDCH = "10" *) 
  (* C_WR_PNTR_WIDTH_WACH = "4" *) 
  (* C_WR_PNTR_WIDTH_WDCH = "10" *) 
  (* C_WR_PNTR_WIDTH_WRCH = "4" *) 
  (* C_WR_RESPONSE_LATENCY = "1" *) 
  (* KEEP_HIERARCHY = "soft" *) 
  (* is_du_within_envelope = "true" *) 
  ecdsa_project_auto_pc_1_fifo_generator_v13_2_8 fifo_gen_inst
       (.almost_empty(NLW_fifo_gen_inst_almost_empty_UNCONNECTED),
        .almost_full(NLW_fifo_gen_inst_almost_full_UNCONNECTED),
        .axi_ar_data_count(NLW_fifo_gen_inst_axi_ar_data_count_UNCONNECTED[4:0]),
        .axi_ar_dbiterr(NLW_fifo_gen_inst_axi_ar_dbiterr_UNCONNECTED),
        .axi_ar_injectdbiterr(1'b0),
        .axi_ar_injectsbiterr(1'b0),
        .axi_ar_overflow(NLW_fifo_gen_inst_axi_ar_overflow_UNCONNECTED),
        .axi_ar_prog_empty(NLW_fifo_gen_inst_axi_ar_prog_empty_UNCONNECTED),
        .axi_ar_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_ar_prog_full(NLW_fifo_gen_inst_axi_ar_prog_full_UNCONNECTED),
        .axi_ar_prog_full_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_ar_rd_data_count(NLW_fifo_gen_inst_axi_ar_rd_data_count_UNCONNECTED[4:0]),
        .axi_ar_sbiterr(NLW_fifo_gen_inst_axi_ar_sbiterr_UNCONNECTED),
        .axi_ar_underflow(NLW_fifo_gen_inst_axi_ar_underflow_UNCONNECTED),
        .axi_ar_wr_data_count(NLW_fifo_gen_inst_axi_ar_wr_data_count_UNCONNECTED[4:0]),
        .axi_aw_data_count(NLW_fifo_gen_inst_axi_aw_data_count_UNCONNECTED[4:0]),
        .axi_aw_dbiterr(NLW_fifo_gen_inst_axi_aw_dbiterr_UNCONNECTED),
        .axi_aw_injectdbiterr(1'b0),
        .axi_aw_injectsbiterr(1'b0),
        .axi_aw_overflow(NLW_fifo_gen_inst_axi_aw_overflow_UNCONNECTED),
        .axi_aw_prog_empty(NLW_fifo_gen_inst_axi_aw_prog_empty_UNCONNECTED),
        .axi_aw_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_aw_prog_full(NLW_fifo_gen_inst_axi_aw_prog_full_UNCONNECTED),
        .axi_aw_prog_full_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_aw_rd_data_count(NLW_fifo_gen_inst_axi_aw_rd_data_count_UNCONNECTED[4:0]),
        .axi_aw_sbiterr(NLW_fifo_gen_inst_axi_aw_sbiterr_UNCONNECTED),
        .axi_aw_underflow(NLW_fifo_gen_inst_axi_aw_underflow_UNCONNECTED),
        .axi_aw_wr_data_count(NLW_fifo_gen_inst_axi_aw_wr_data_count_UNCONNECTED[4:0]),
        .axi_b_data_count(NLW_fifo_gen_inst_axi_b_data_count_UNCONNECTED[4:0]),
        .axi_b_dbiterr(NLW_fifo_gen_inst_axi_b_dbiterr_UNCONNECTED),
        .axi_b_injectdbiterr(1'b0),
        .axi_b_injectsbiterr(1'b0),
        .axi_b_overflow(NLW_fifo_gen_inst_axi_b_overflow_UNCONNECTED),
        .axi_b_prog_empty(NLW_fifo_gen_inst_axi_b_prog_empty_UNCONNECTED),
        .axi_b_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_b_prog_full(NLW_fifo_gen_inst_axi_b_prog_full_UNCONNECTED),
        .axi_b_prog_full_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_b_rd_data_count(NLW_fifo_gen_inst_axi_b_rd_data_count_UNCONNECTED[4:0]),
        .axi_b_sbiterr(NLW_fifo_gen_inst_axi_b_sbiterr_UNCONNECTED),
        .axi_b_underflow(NLW_fifo_gen_inst_axi_b_underflow_UNCONNECTED),
        .axi_b_wr_data_count(NLW_fifo_gen_inst_axi_b_wr_data_count_UNCONNECTED[4:0]),
        .axi_r_data_count(NLW_fifo_gen_inst_axi_r_data_count_UNCONNECTED[10:0]),
        .axi_r_dbiterr(NLW_fifo_gen_inst_axi_r_dbiterr_UNCONNECTED),
        .axi_r_injectdbiterr(1'b0),
        .axi_r_injectsbiterr(1'b0),
        .axi_r_overflow(NLW_fifo_gen_inst_axi_r_overflow_UNCONNECTED),
        .axi_r_prog_empty(NLW_fifo_gen_inst_axi_r_prog_empty_UNCONNECTED),
        .axi_r_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axi_r_prog_full(NLW_fifo_gen_inst_axi_r_prog_full_UNCONNECTED),
        .axi_r_prog_full_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axi_r_rd_data_count(NLW_fifo_gen_inst_axi_r_rd_data_count_UNCONNECTED[10:0]),
        .axi_r_sbiterr(NLW_fifo_gen_inst_axi_r_sbiterr_UNCONNECTED),
        .axi_r_underflow(NLW_fifo_gen_inst_axi_r_underflow_UNCONNECTED),
        .axi_r_wr_data_count(NLW_fifo_gen_inst_axi_r_wr_data_count_UNCONNECTED[10:0]),
        .axi_w_data_count(NLW_fifo_gen_inst_axi_w_data_count_UNCONNECTED[10:0]),
        .axi_w_dbiterr(NLW_fifo_gen_inst_axi_w_dbiterr_UNCONNECTED),
        .axi_w_injectdbiterr(1'b0),
        .axi_w_injectsbiterr(1'b0),
        .axi_w_overflow(NLW_fifo_gen_inst_axi_w_overflow_UNCONNECTED),
        .axi_w_prog_empty(NLW_fifo_gen_inst_axi_w_prog_empty_UNCONNECTED),
        .axi_w_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axi_w_prog_full(NLW_fifo_gen_inst_axi_w_prog_full_UNCONNECTED),
        .axi_w_prog_full_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axi_w_rd_data_count(NLW_fifo_gen_inst_axi_w_rd_data_count_UNCONNECTED[10:0]),
        .axi_w_sbiterr(NLW_fifo_gen_inst_axi_w_sbiterr_UNCONNECTED),
        .axi_w_underflow(NLW_fifo_gen_inst_axi_w_underflow_UNCONNECTED),
        .axi_w_wr_data_count(NLW_fifo_gen_inst_axi_w_wr_data_count_UNCONNECTED[10:0]),
        .axis_data_count(NLW_fifo_gen_inst_axis_data_count_UNCONNECTED[10:0]),
        .axis_dbiterr(NLW_fifo_gen_inst_axis_dbiterr_UNCONNECTED),
        .axis_injectdbiterr(1'b0),
        .axis_injectsbiterr(1'b0),
        .axis_overflow(NLW_fifo_gen_inst_axis_overflow_UNCONNECTED),
        .axis_prog_empty(NLW_fifo_gen_inst_axis_prog_empty_UNCONNECTED),
        .axis_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axis_prog_full(NLW_fifo_gen_inst_axis_prog_full_UNCONNECTED),
        .axis_prog_full_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axis_rd_data_count(NLW_fifo_gen_inst_axis_rd_data_count_UNCONNECTED[10:0]),
        .axis_sbiterr(NLW_fifo_gen_inst_axis_sbiterr_UNCONNECTED),
        .axis_underflow(NLW_fifo_gen_inst_axis_underflow_UNCONNECTED),
        .axis_wr_data_count(NLW_fifo_gen_inst_axis_wr_data_count_UNCONNECTED[10:0]),
        .backup(1'b0),
        .backup_marker(1'b0),
        .clk(aclk),
        .data_count(NLW_fifo_gen_inst_data_count_UNCONNECTED[5:0]),
        .dbiterr(NLW_fifo_gen_inst_dbiterr_UNCONNECTED),
        .din({1'b0,m_axi_awlen}),
        .dout({NLW_fifo_gen_inst_dout_UNCONNECTED[4],dout}),
        .empty(empty),
        .full(full),
        .injectdbiterr(1'b0),
        .injectsbiterr(1'b0),
        .int_clk(1'b0),
        .m_aclk(1'b0),
        .m_aclk_en(1'b0),
        .m_axi_araddr(NLW_fifo_gen_inst_m_axi_araddr_UNCONNECTED[31:0]),
        .m_axi_arburst(NLW_fifo_gen_inst_m_axi_arburst_UNCONNECTED[1:0]),
        .m_axi_arcache(NLW_fifo_gen_inst_m_axi_arcache_UNCONNECTED[3:0]),
        .m_axi_arid(NLW_fifo_gen_inst_m_axi_arid_UNCONNECTED[3:0]),
        .m_axi_arlen(NLW_fifo_gen_inst_m_axi_arlen_UNCONNECTED[7:0]),
        .m_axi_arlock(NLW_fifo_gen_inst_m_axi_arlock_UNCONNECTED[1:0]),
        .m_axi_arprot(NLW_fifo_gen_inst_m_axi_arprot_UNCONNECTED[2:0]),
        .m_axi_arqos(NLW_fifo_gen_inst_m_axi_arqos_UNCONNECTED[3:0]),
        .m_axi_arready(1'b0),
        .m_axi_arregion(NLW_fifo_gen_inst_m_axi_arregion_UNCONNECTED[3:0]),
        .m_axi_arsize(NLW_fifo_gen_inst_m_axi_arsize_UNCONNECTED[2:0]),
        .m_axi_aruser(NLW_fifo_gen_inst_m_axi_aruser_UNCONNECTED[0]),
        .m_axi_arvalid(NLW_fifo_gen_inst_m_axi_arvalid_UNCONNECTED),
        .m_axi_awaddr(NLW_fifo_gen_inst_m_axi_awaddr_UNCONNECTED[31:0]),
        .m_axi_awburst(NLW_fifo_gen_inst_m_axi_awburst_UNCONNECTED[1:0]),
        .m_axi_awcache(NLW_fifo_gen_inst_m_axi_awcache_UNCONNECTED[3:0]),
        .m_axi_awid(NLW_fifo_gen_inst_m_axi_awid_UNCONNECTED[3:0]),
        .m_axi_awlen(NLW_fifo_gen_inst_m_axi_awlen_UNCONNECTED[7:0]),
        .m_axi_awlock(NLW_fifo_gen_inst_m_axi_awlock_UNCONNECTED[1:0]),
        .m_axi_awprot(NLW_fifo_gen_inst_m_axi_awprot_UNCONNECTED[2:0]),
        .m_axi_awqos(NLW_fifo_gen_inst_m_axi_awqos_UNCONNECTED[3:0]),
        .m_axi_awready(1'b0),
        .m_axi_awregion(NLW_fifo_gen_inst_m_axi_awregion_UNCONNECTED[3:0]),
        .m_axi_awsize(NLW_fifo_gen_inst_m_axi_awsize_UNCONNECTED[2:0]),
        .m_axi_awuser(NLW_fifo_gen_inst_m_axi_awuser_UNCONNECTED[0]),
        .m_axi_awvalid(NLW_fifo_gen_inst_m_axi_awvalid_UNCONNECTED),
        .m_axi_bid({1'b0,1'b0,1'b0,1'b0}),
        .m_axi_bready(NLW_fifo_gen_inst_m_axi_bready_UNCONNECTED),
        .m_axi_bresp({1'b0,1'b0}),
        .m_axi_buser(1'b0),
        .m_axi_bvalid(1'b0),
        .m_axi_rdata({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .m_axi_rid({1'b0,1'b0,1'b0,1'b0}),
        .m_axi_rlast(1'b0),
        .m_axi_rready(NLW_fifo_gen_inst_m_axi_rready_UNCONNECTED),
        .m_axi_rresp({1'b0,1'b0}),
        .m_axi_ruser(1'b0),
        .m_axi_rvalid(1'b0),
        .m_axi_wdata(NLW_fifo_gen_inst_m_axi_wdata_UNCONNECTED[63:0]),
        .m_axi_wid(NLW_fifo_gen_inst_m_axi_wid_UNCONNECTED[3:0]),
        .m_axi_wlast(NLW_fifo_gen_inst_m_axi_wlast_UNCONNECTED),
        .m_axi_wready(1'b0),
        .m_axi_wstrb(NLW_fifo_gen_inst_m_axi_wstrb_UNCONNECTED[7:0]),
        .m_axi_wuser(NLW_fifo_gen_inst_m_axi_wuser_UNCONNECTED[0]),
        .m_axi_wvalid(NLW_fifo_gen_inst_m_axi_wvalid_UNCONNECTED),
        .m_axis_tdata(NLW_fifo_gen_inst_m_axis_tdata_UNCONNECTED[63:0]),
        .m_axis_tdest(NLW_fifo_gen_inst_m_axis_tdest_UNCONNECTED[3:0]),
        .m_axis_tid(NLW_fifo_gen_inst_m_axis_tid_UNCONNECTED[7:0]),
        .m_axis_tkeep(NLW_fifo_gen_inst_m_axis_tkeep_UNCONNECTED[3:0]),
        .m_axis_tlast(NLW_fifo_gen_inst_m_axis_tlast_UNCONNECTED),
        .m_axis_tready(1'b0),
        .m_axis_tstrb(NLW_fifo_gen_inst_m_axis_tstrb_UNCONNECTED[3:0]),
        .m_axis_tuser(NLW_fifo_gen_inst_m_axis_tuser_UNCONNECTED[3:0]),
        .m_axis_tvalid(NLW_fifo_gen_inst_m_axis_tvalid_UNCONNECTED),
        .overflow(NLW_fifo_gen_inst_overflow_UNCONNECTED),
        .prog_empty(NLW_fifo_gen_inst_prog_empty_UNCONNECTED),
        .prog_empty_thresh({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .prog_empty_thresh_assert({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .prog_empty_thresh_negate({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .prog_full(NLW_fifo_gen_inst_prog_full_UNCONNECTED),
        .prog_full_thresh({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .prog_full_thresh_assert({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .prog_full_thresh_negate({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .rd_clk(1'b0),
        .rd_data_count(NLW_fifo_gen_inst_rd_data_count_UNCONNECTED[5:0]),
        .rd_en(rd_en),
        .rd_rst(1'b0),
        .rd_rst_busy(NLW_fifo_gen_inst_rd_rst_busy_UNCONNECTED),
        .rst(SR),
        .s_aclk(1'b0),
        .s_aclk_en(1'b0),
        .s_aresetn(1'b0),
        .s_axi_araddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arburst({1'b0,1'b0}),
        .s_axi_arcache({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arid({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arlock({1'b0,1'b0}),
        .s_axi_arprot({1'b0,1'b0,1'b0}),
        .s_axi_arqos({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arready(NLW_fifo_gen_inst_s_axi_arready_UNCONNECTED),
        .s_axi_arregion({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arsize({1'b0,1'b0,1'b0}),
        .s_axi_aruser(1'b0),
        .s_axi_arvalid(1'b0),
        .s_axi_awaddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awburst({1'b0,1'b0}),
        .s_axi_awcache({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awid({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awlock({1'b0,1'b0}),
        .s_axi_awprot({1'b0,1'b0,1'b0}),
        .s_axi_awqos({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awready(NLW_fifo_gen_inst_s_axi_awready_UNCONNECTED),
        .s_axi_awregion({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awsize({1'b0,1'b0,1'b0}),
        .s_axi_awuser(1'b0),
        .s_axi_awvalid(1'b0),
        .s_axi_bid(NLW_fifo_gen_inst_s_axi_bid_UNCONNECTED[3:0]),
        .s_axi_bready(1'b0),
        .s_axi_bresp(NLW_fifo_gen_inst_s_axi_bresp_UNCONNECTED[1:0]),
        .s_axi_buser(NLW_fifo_gen_inst_s_axi_buser_UNCONNECTED[0]),
        .s_axi_bvalid(NLW_fifo_gen_inst_s_axi_bvalid_UNCONNECTED),
        .s_axi_rdata(NLW_fifo_gen_inst_s_axi_rdata_UNCONNECTED[63:0]),
        .s_axi_rid(NLW_fifo_gen_inst_s_axi_rid_UNCONNECTED[3:0]),
        .s_axi_rlast(NLW_fifo_gen_inst_s_axi_rlast_UNCONNECTED),
        .s_axi_rready(1'b0),
        .s_axi_rresp(NLW_fifo_gen_inst_s_axi_rresp_UNCONNECTED[1:0]),
        .s_axi_ruser(NLW_fifo_gen_inst_s_axi_ruser_UNCONNECTED[0]),
        .s_axi_rvalid(NLW_fifo_gen_inst_s_axi_rvalid_UNCONNECTED),
        .s_axi_wdata({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_wid({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_wlast(1'b0),
        .s_axi_wready(NLW_fifo_gen_inst_s_axi_wready_UNCONNECTED),
        .s_axi_wstrb({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_wuser(1'b0),
        .s_axi_wvalid(1'b0),
        .s_axis_tdata({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axis_tdest({1'b0,1'b0,1'b0,1'b0}),
        .s_axis_tid({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axis_tkeep({1'b0,1'b0,1'b0,1'b0}),
        .s_axis_tlast(1'b0),
        .s_axis_tready(NLW_fifo_gen_inst_s_axis_tready_UNCONNECTED),
        .s_axis_tstrb({1'b0,1'b0,1'b0,1'b0}),
        .s_axis_tuser({1'b0,1'b0,1'b0,1'b0}),
        .s_axis_tvalid(1'b0),
        .sbiterr(NLW_fifo_gen_inst_sbiterr_UNCONNECTED),
        .sleep(1'b0),
        .srst(1'b0),
        .underflow(NLW_fifo_gen_inst_underflow_UNCONNECTED),
        .valid(NLW_fifo_gen_inst_valid_UNCONNECTED),
        .wr_ack(NLW_fifo_gen_inst_wr_ack_UNCONNECTED),
        .wr_clk(1'b0),
        .wr_data_count(NLW_fifo_gen_inst_wr_data_count_UNCONNECTED[5:0]),
        .wr_en(cmd_push),
        .wr_rst(1'b0),
        .wr_rst_busy(NLW_fifo_gen_inst_wr_rst_busy_UNCONNECTED));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'h02)) 
    fifo_gen_inst_i_1
       (.I0(command_ongoing),
        .I1(full),
        .I2(m_axi_awvalid_0),
        .O(cmd_push));
  LUT6 #(
    .INIT(64'hE4E4CC664E4ECC66)) 
    \length_counter_1[1]_i_1 
       (.I0(empty_fwft_i_reg),
        .I1(length_counter_1_reg[1]),
        .I2(dout[1]),
        .I3(length_counter_1_reg[0]),
        .I4(first_mi_word),
        .I5(dout[0]),
        .O(length_counter_1_reg_1_sn_1));
  LUT3 #(
    .INIT(8'hA2)) 
    m_axi_awvalid_INST_0
       (.I0(command_ongoing),
        .I1(full),
        .I2(m_axi_awvalid_0),
        .O(m_axi_awvalid));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT2 #(
    .INIT(4'h2)) 
    m_axi_wvalid_INST_0
       (.I0(s_axi_wvalid),
        .I1(empty),
        .O(m_axi_wvalid));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'h40)) 
    s_axi_wready_INST_0
       (.I0(empty),
        .I1(s_axi_wvalid),
        .I2(m_axi_wready),
        .O(empty_fwft_i_reg));
endmodule

(* ORIG_REF_NAME = "axi_protocol_converter_v2_1_28_a_axi3_conv" *) 
module ecdsa_project_auto_pc_1_axi_protocol_converter_v2_1_28_a_axi3_conv
   (dout,
    empty,
    SR,
    m_axi_awlen,
    m_axi_awlock,
    E,
    m_axi_awvalid,
    length_counter_1_reg_1_sp_1,
    empty_fwft_i_reg,
    m_axi_wvalid,
    m_axi_awaddr,
    m_axi_awsize,
    m_axi_awburst,
    m_axi_awcache,
    m_axi_awprot,
    m_axi_awqos,
    aclk,
    rd_en,
    s_axi_awlock,
    aresetn,
    m_axi_awready,
    length_counter_1_reg,
    first_mi_word,
    s_axi_wvalid,
    m_axi_wready,
    s_axi_awvalid,
    s_axi_awaddr,
    s_axi_awlen,
    s_axi_awsize,
    s_axi_awburst,
    s_axi_awcache,
    s_axi_awprot,
    s_axi_awqos);
  output [3:0]dout;
  output empty;
  output [0:0]SR;
  output [3:0]m_axi_awlen;
  output [0:0]m_axi_awlock;
  output [0:0]E;
  output m_axi_awvalid;
  output length_counter_1_reg_1_sp_1;
  output empty_fwft_i_reg;
  output m_axi_wvalid;
  output [31:0]m_axi_awaddr;
  output [2:0]m_axi_awsize;
  output [1:0]m_axi_awburst;
  output [3:0]m_axi_awcache;
  output [2:0]m_axi_awprot;
  output [3:0]m_axi_awqos;
  input aclk;
  input rd_en;
  input [0:0]s_axi_awlock;
  input aresetn;
  input m_axi_awready;
  input [1:0]length_counter_1_reg;
  input first_mi_word;
  input s_axi_wvalid;
  input m_axi_wready;
  input s_axi_awvalid;
  input [31:0]s_axi_awaddr;
  input [3:0]s_axi_awlen;
  input [2:0]s_axi_awsize;
  input [1:0]s_axi_awburst;
  input [3:0]s_axi_awcache;
  input [2:0]s_axi_awprot;
  input [3:0]s_axi_awqos;

  wire [0:0]E;
  wire [0:0]SR;
  wire \USE_BURSTS.cmd_queue_n_11 ;
  wire \USE_BURSTS.cmd_queue_n_12 ;
  wire \USE_BURSTS.cmd_queue_n_6 ;
  wire aclk;
  wire [1:0]areset_d;
  wire aresetn;
  wire cmd_push_block_reg_n_0;
  wire command_ongoing;
  wire [3:0]dout;
  wire empty;
  wire empty_fwft_i_reg;
  wire first_mi_word;
  wire [1:0]length_counter_1_reg;
  wire length_counter_1_reg_1_sn_1;
  wire [31:0]m_axi_awaddr;
  wire [1:0]m_axi_awburst;
  wire [3:0]m_axi_awcache;
  wire [3:0]m_axi_awlen;
  wire [0:0]m_axi_awlock;
  wire [2:0]m_axi_awprot;
  wire [3:0]m_axi_awqos;
  wire m_axi_awready;
  wire [2:0]m_axi_awsize;
  wire m_axi_awvalid;
  wire m_axi_wready;
  wire m_axi_wvalid;
  wire rd_en;
  wire [31:0]s_axi_awaddr;
  wire [1:0]s_axi_awburst;
  wire [3:0]s_axi_awcache;
  wire [3:0]s_axi_awlen;
  wire [0:0]s_axi_awlock;
  wire [2:0]s_axi_awprot;
  wire [3:0]s_axi_awqos;
  wire [2:0]s_axi_awsize;
  wire s_axi_awvalid;
  wire s_axi_wvalid;

  assign length_counter_1_reg_1_sp_1 = length_counter_1_reg_1_sn_1;
  FDRE \S_AXI_AADDR_Q_reg[0] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[0]),
        .Q(m_axi_awaddr[0]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[10] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[10]),
        .Q(m_axi_awaddr[10]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[11] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[11]),
        .Q(m_axi_awaddr[11]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[12] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[12]),
        .Q(m_axi_awaddr[12]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[13] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[13]),
        .Q(m_axi_awaddr[13]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[14] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[14]),
        .Q(m_axi_awaddr[14]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[15] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[15]),
        .Q(m_axi_awaddr[15]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[16] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[16]),
        .Q(m_axi_awaddr[16]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[17] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[17]),
        .Q(m_axi_awaddr[17]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[18] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[18]),
        .Q(m_axi_awaddr[18]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[19] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[19]),
        .Q(m_axi_awaddr[19]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[1] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[1]),
        .Q(m_axi_awaddr[1]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[20] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[20]),
        .Q(m_axi_awaddr[20]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[21] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[21]),
        .Q(m_axi_awaddr[21]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[22] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[22]),
        .Q(m_axi_awaddr[22]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[23] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[23]),
        .Q(m_axi_awaddr[23]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[24] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[24]),
        .Q(m_axi_awaddr[24]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[25] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[25]),
        .Q(m_axi_awaddr[25]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[26] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[26]),
        .Q(m_axi_awaddr[26]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[27] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[27]),
        .Q(m_axi_awaddr[27]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[28] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[28]),
        .Q(m_axi_awaddr[28]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[29] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[29]),
        .Q(m_axi_awaddr[29]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[2] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[2]),
        .Q(m_axi_awaddr[2]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[30] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[30]),
        .Q(m_axi_awaddr[30]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[31] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[31]),
        .Q(m_axi_awaddr[31]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[3] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[3]),
        .Q(m_axi_awaddr[3]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[4] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[4]),
        .Q(m_axi_awaddr[4]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[5] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[5]),
        .Q(m_axi_awaddr[5]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[6] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[6]),
        .Q(m_axi_awaddr[6]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[7] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[7]),
        .Q(m_axi_awaddr[7]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[8] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[8]),
        .Q(m_axi_awaddr[8]),
        .R(SR));
  FDRE \S_AXI_AADDR_Q_reg[9] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awaddr[9]),
        .Q(m_axi_awaddr[9]),
        .R(SR));
  FDRE \S_AXI_ABURST_Q_reg[0] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awburst[0]),
        .Q(m_axi_awburst[0]),
        .R(SR));
  FDRE \S_AXI_ABURST_Q_reg[1] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awburst[1]),
        .Q(m_axi_awburst[1]),
        .R(SR));
  FDRE \S_AXI_ACACHE_Q_reg[0] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awcache[0]),
        .Q(m_axi_awcache[0]),
        .R(SR));
  FDRE \S_AXI_ACACHE_Q_reg[1] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awcache[1]),
        .Q(m_axi_awcache[1]),
        .R(SR));
  FDRE \S_AXI_ACACHE_Q_reg[2] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awcache[2]),
        .Q(m_axi_awcache[2]),
        .R(SR));
  FDRE \S_AXI_ACACHE_Q_reg[3] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awcache[3]),
        .Q(m_axi_awcache[3]),
        .R(SR));
  FDRE \S_AXI_ALEN_Q_reg[0] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awlen[0]),
        .Q(m_axi_awlen[0]),
        .R(SR));
  FDRE \S_AXI_ALEN_Q_reg[1] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awlen[1]),
        .Q(m_axi_awlen[1]),
        .R(SR));
  FDRE \S_AXI_ALEN_Q_reg[2] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awlen[2]),
        .Q(m_axi_awlen[2]),
        .R(SR));
  FDRE \S_AXI_ALEN_Q_reg[3] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awlen[3]),
        .Q(m_axi_awlen[3]),
        .R(SR));
  FDRE \S_AXI_ALOCK_Q_reg[0] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awlock),
        .Q(m_axi_awlock),
        .R(SR));
  FDRE \S_AXI_APROT_Q_reg[0] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awprot[0]),
        .Q(m_axi_awprot[0]),
        .R(SR));
  FDRE \S_AXI_APROT_Q_reg[1] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awprot[1]),
        .Q(m_axi_awprot[1]),
        .R(SR));
  FDRE \S_AXI_APROT_Q_reg[2] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awprot[2]),
        .Q(m_axi_awprot[2]),
        .R(SR));
  FDRE \S_AXI_AQOS_Q_reg[0] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awqos[0]),
        .Q(m_axi_awqos[0]),
        .R(SR));
  FDRE \S_AXI_AQOS_Q_reg[1] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awqos[1]),
        .Q(m_axi_awqos[1]),
        .R(SR));
  FDRE \S_AXI_AQOS_Q_reg[2] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awqos[2]),
        .Q(m_axi_awqos[2]),
        .R(SR));
  FDRE \S_AXI_AQOS_Q_reg[3] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awqos[3]),
        .Q(m_axi_awqos[3]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    S_AXI_AREADY_I_reg
       (.C(aclk),
        .CE(1'b1),
        .D(\USE_BURSTS.cmd_queue_n_11 ),
        .Q(E),
        .R(SR));
  FDRE \S_AXI_ASIZE_Q_reg[0] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awsize[0]),
        .Q(m_axi_awsize[0]),
        .R(SR));
  FDRE \S_AXI_ASIZE_Q_reg[1] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awsize[1]),
        .Q(m_axi_awsize[1]),
        .R(SR));
  FDRE \S_AXI_ASIZE_Q_reg[2] 
       (.C(aclk),
        .CE(E),
        .D(s_axi_awsize[2]),
        .Q(m_axi_awsize[2]),
        .R(SR));
  ecdsa_project_auto_pc_1_axi_data_fifo_v2_1_27_axic_fifo \USE_BURSTS.cmd_queue 
       (.E(E),
        .Q(areset_d),
        .SR(SR),
        .S_AXI_AREADY_I_reg(\USE_BURSTS.cmd_queue_n_11 ),
        .aclk(aclk),
        .\areset_d_reg[1] (\USE_BURSTS.cmd_queue_n_12 ),
        .aresetn(aresetn),
        .aresetn_0(\USE_BURSTS.cmd_queue_n_6 ),
        .command_ongoing(command_ongoing),
        .dout(dout),
        .empty(empty),
        .empty_fwft_i_reg(empty_fwft_i_reg),
        .first_mi_word(first_mi_word),
        .length_counter_1_reg(length_counter_1_reg),
        .length_counter_1_reg_1_sp_1(length_counter_1_reg_1_sn_1),
        .m_axi_awlen(m_axi_awlen),
        .m_axi_awready(m_axi_awready),
        .m_axi_awvalid(m_axi_awvalid),
        .m_axi_awvalid_0(cmd_push_block_reg_n_0),
        .m_axi_wready(m_axi_wready),
        .m_axi_wvalid(m_axi_wvalid),
        .rd_en(rd_en),
        .s_axi_awvalid(s_axi_awvalid),
        .s_axi_wvalid(s_axi_wvalid));
  FDRE #(
    .INIT(1'b0)) 
    \areset_d_reg[0] 
       (.C(aclk),
        .CE(1'b1),
        .D(SR),
        .Q(areset_d[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \areset_d_reg[1] 
       (.C(aclk),
        .CE(1'b1),
        .D(areset_d[0]),
        .Q(areset_d[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    cmd_push_block_reg
       (.C(aclk),
        .CE(1'b1),
        .D(\USE_BURSTS.cmd_queue_n_6 ),
        .Q(cmd_push_block_reg_n_0),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    command_ongoing_reg
       (.C(aclk),
        .CE(1'b1),
        .D(\USE_BURSTS.cmd_queue_n_12 ),
        .Q(command_ongoing),
        .R(SR));
endmodule

(* ORIG_REF_NAME = "axi_protocol_converter_v2_1_28_axi3_conv" *) 
module ecdsa_project_auto_pc_1_axi_protocol_converter_v2_1_28_axi3_conv
   (m_axi_awlen,
    m_axi_awaddr,
    E,
    m_axi_awsize,
    m_axi_awburst,
    m_axi_awlock,
    m_axi_awcache,
    m_axi_awprot,
    m_axi_awqos,
    m_axi_awvalid,
    empty_fwft_i_reg,
    m_axi_wvalid,
    m_axi_wlast,
    aresetn,
    m_axi_awready,
    aclk,
    s_axi_awaddr,
    s_axi_awlen,
    s_axi_awsize,
    s_axi_awburst,
    s_axi_awlock,
    s_axi_awcache,
    s_axi_awprot,
    s_axi_awqos,
    m_axi_wready,
    s_axi_wvalid,
    s_axi_awvalid);
  output [3:0]m_axi_awlen;
  output [31:0]m_axi_awaddr;
  output [0:0]E;
  output [2:0]m_axi_awsize;
  output [1:0]m_axi_awburst;
  output [0:0]m_axi_awlock;
  output [3:0]m_axi_awcache;
  output [2:0]m_axi_awprot;
  output [3:0]m_axi_awqos;
  output m_axi_awvalid;
  output empty_fwft_i_reg;
  output m_axi_wvalid;
  output m_axi_wlast;
  input aresetn;
  input m_axi_awready;
  input aclk;
  input [31:0]s_axi_awaddr;
  input [3:0]s_axi_awlen;
  input [2:0]s_axi_awsize;
  input [1:0]s_axi_awburst;
  input [0:0]s_axi_awlock;
  input [3:0]s_axi_awcache;
  input [2:0]s_axi_awprot;
  input [3:0]s_axi_awqos;
  input m_axi_wready;
  input s_axi_wvalid;
  input s_axi_awvalid;

  wire [0:0]E;
  wire \USE_BURSTS.cmd_queue/inst/empty ;
  wire [3:0]\USE_WRITE.wr_cmd_length ;
  wire \USE_WRITE.wr_cmd_ready ;
  wire \USE_WRITE.write_addr_inst_n_13 ;
  wire \USE_WRITE.write_addr_inst_n_5 ;
  wire aclk;
  wire aresetn;
  wire empty_fwft_i_reg;
  wire first_mi_word;
  wire [1:0]length_counter_1_reg;
  wire [31:0]m_axi_awaddr;
  wire [1:0]m_axi_awburst;
  wire [3:0]m_axi_awcache;
  wire [3:0]m_axi_awlen;
  wire [0:0]m_axi_awlock;
  wire [2:0]m_axi_awprot;
  wire [3:0]m_axi_awqos;
  wire m_axi_awready;
  wire [2:0]m_axi_awsize;
  wire m_axi_awvalid;
  wire m_axi_wlast;
  wire m_axi_wready;
  wire m_axi_wvalid;
  wire [31:0]s_axi_awaddr;
  wire [1:0]s_axi_awburst;
  wire [3:0]s_axi_awcache;
  wire [3:0]s_axi_awlen;
  wire [0:0]s_axi_awlock;
  wire [2:0]s_axi_awprot;
  wire [3:0]s_axi_awqos;
  wire [2:0]s_axi_awsize;
  wire s_axi_awvalid;
  wire s_axi_wvalid;

  ecdsa_project_auto_pc_1_axi_protocol_converter_v2_1_28_a_axi3_conv \USE_WRITE.write_addr_inst 
       (.E(E),
        .SR(\USE_WRITE.write_addr_inst_n_5 ),
        .aclk(aclk),
        .aresetn(aresetn),
        .dout(\USE_WRITE.wr_cmd_length ),
        .empty(\USE_BURSTS.cmd_queue/inst/empty ),
        .empty_fwft_i_reg(empty_fwft_i_reg),
        .first_mi_word(first_mi_word),
        .length_counter_1_reg(length_counter_1_reg),
        .length_counter_1_reg_1_sp_1(\USE_WRITE.write_addr_inst_n_13 ),
        .m_axi_awaddr(m_axi_awaddr),
        .m_axi_awburst(m_axi_awburst),
        .m_axi_awcache(m_axi_awcache),
        .m_axi_awlen(m_axi_awlen),
        .m_axi_awlock(m_axi_awlock),
        .m_axi_awprot(m_axi_awprot),
        .m_axi_awqos(m_axi_awqos),
        .m_axi_awready(m_axi_awready),
        .m_axi_awsize(m_axi_awsize),
        .m_axi_awvalid(m_axi_awvalid),
        .m_axi_wready(m_axi_wready),
        .m_axi_wvalid(m_axi_wvalid),
        .rd_en(\USE_WRITE.wr_cmd_ready ),
        .s_axi_awaddr(s_axi_awaddr),
        .s_axi_awburst(s_axi_awburst),
        .s_axi_awcache(s_axi_awcache),
        .s_axi_awlen(s_axi_awlen),
        .s_axi_awlock(s_axi_awlock),
        .s_axi_awprot(s_axi_awprot),
        .s_axi_awqos(s_axi_awqos),
        .s_axi_awsize(s_axi_awsize),
        .s_axi_awvalid(s_axi_awvalid),
        .s_axi_wvalid(s_axi_wvalid));
  ecdsa_project_auto_pc_1_axi_protocol_converter_v2_1_28_w_axi3_conv \USE_WRITE.write_data_inst 
       (.SR(\USE_WRITE.write_addr_inst_n_5 ),
        .aclk(aclk),
        .dout(\USE_WRITE.wr_cmd_length ),
        .empty(\USE_BURSTS.cmd_queue/inst/empty ),
        .first_mi_word(first_mi_word),
        .\length_counter_1_reg[1]_0 (length_counter_1_reg),
        .\length_counter_1_reg[1]_1 (\USE_WRITE.write_addr_inst_n_13 ),
        .\length_counter_1_reg[2]_0 (empty_fwft_i_reg),
        .m_axi_wlast(m_axi_wlast),
        .m_axi_wready(m_axi_wready),
        .rd_en(\USE_WRITE.wr_cmd_ready ),
        .s_axi_wvalid(s_axi_wvalid));
endmodule

(* C_AXI_ADDR_WIDTH = "32" *) (* C_AXI_ARUSER_WIDTH = "1" *) (* C_AXI_AWUSER_WIDTH = "1" *) 
(* C_AXI_BUSER_WIDTH = "1" *) (* C_AXI_DATA_WIDTH = "64" *) (* C_AXI_ID_WIDTH = "1" *) 
(* C_AXI_RUSER_WIDTH = "1" *) (* C_AXI_SUPPORTS_READ = "1" *) (* C_AXI_SUPPORTS_USER_SIGNALS = "0" *) 
(* C_AXI_SUPPORTS_WRITE = "1" *) (* C_AXI_WUSER_WIDTH = "1" *) (* C_FAMILY = "zynq" *) 
(* C_IGNORE_ID = "1" *) (* C_M_AXI_PROTOCOL = "1" *) (* C_S_AXI_PROTOCOL = "0" *) 
(* C_TRANSLATION_MODE = "0" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* ORIG_REF_NAME = "axi_protocol_converter_v2_1_28_axi_protocol_converter" *) 
(* P_AXI3 = "1" *) (* P_AXI4 = "0" *) (* P_AXILITE = "2" *) 
(* P_AXILITE_SIZE = "3'b011" *) (* P_CONVERSION = "2" *) (* P_DECERR = "2'b11" *) 
(* P_INCR = "2'b01" *) (* P_PROTECTION = "1" *) (* P_SLVERR = "2'b10" *) 
module ecdsa_project_auto_pc_1_axi_protocol_converter_v2_1_28_axi_protocol_converter
   (aclk,
    aresetn,
    s_axi_awid,
    s_axi_awaddr,
    s_axi_awlen,
    s_axi_awsize,
    s_axi_awburst,
    s_axi_awlock,
    s_axi_awcache,
    s_axi_awprot,
    s_axi_awregion,
    s_axi_awqos,
    s_axi_awuser,
    s_axi_awvalid,
    s_axi_awready,
    s_axi_wid,
    s_axi_wdata,
    s_axi_wstrb,
    s_axi_wlast,
    s_axi_wuser,
    s_axi_wvalid,
    s_axi_wready,
    s_axi_bid,
    s_axi_bresp,
    s_axi_buser,
    s_axi_bvalid,
    s_axi_bready,
    s_axi_arid,
    s_axi_araddr,
    s_axi_arlen,
    s_axi_arsize,
    s_axi_arburst,
    s_axi_arlock,
    s_axi_arcache,
    s_axi_arprot,
    s_axi_arregion,
    s_axi_arqos,
    s_axi_aruser,
    s_axi_arvalid,
    s_axi_arready,
    s_axi_rid,
    s_axi_rdata,
    s_axi_rresp,
    s_axi_rlast,
    s_axi_ruser,
    s_axi_rvalid,
    s_axi_rready,
    m_axi_awid,
    m_axi_awaddr,
    m_axi_awlen,
    m_axi_awsize,
    m_axi_awburst,
    m_axi_awlock,
    m_axi_awcache,
    m_axi_awprot,
    m_axi_awregion,
    m_axi_awqos,
    m_axi_awuser,
    m_axi_awvalid,
    m_axi_awready,
    m_axi_wid,
    m_axi_wdata,
    m_axi_wstrb,
    m_axi_wlast,
    m_axi_wuser,
    m_axi_wvalid,
    m_axi_wready,
    m_axi_bid,
    m_axi_bresp,
    m_axi_buser,
    m_axi_bvalid,
    m_axi_bready,
    m_axi_arid,
    m_axi_araddr,
    m_axi_arlen,
    m_axi_arsize,
    m_axi_arburst,
    m_axi_arlock,
    m_axi_arcache,
    m_axi_arprot,
    m_axi_arregion,
    m_axi_arqos,
    m_axi_aruser,
    m_axi_arvalid,
    m_axi_arready,
    m_axi_rid,
    m_axi_rdata,
    m_axi_rresp,
    m_axi_rlast,
    m_axi_ruser,
    m_axi_rvalid,
    m_axi_rready);
  input aclk;
  input aresetn;
  input [0:0]s_axi_awid;
  input [31:0]s_axi_awaddr;
  input [7:0]s_axi_awlen;
  input [2:0]s_axi_awsize;
  input [1:0]s_axi_awburst;
  input [0:0]s_axi_awlock;
  input [3:0]s_axi_awcache;
  input [2:0]s_axi_awprot;
  input [3:0]s_axi_awregion;
  input [3:0]s_axi_awqos;
  input [0:0]s_axi_awuser;
  input s_axi_awvalid;
  output s_axi_awready;
  input [0:0]s_axi_wid;
  input [63:0]s_axi_wdata;
  input [7:0]s_axi_wstrb;
  input s_axi_wlast;
  input [0:0]s_axi_wuser;
  input s_axi_wvalid;
  output s_axi_wready;
  output [0:0]s_axi_bid;
  output [1:0]s_axi_bresp;
  output [0:0]s_axi_buser;
  output s_axi_bvalid;
  input s_axi_bready;
  input [0:0]s_axi_arid;
  input [31:0]s_axi_araddr;
  input [7:0]s_axi_arlen;
  input [2:0]s_axi_arsize;
  input [1:0]s_axi_arburst;
  input [0:0]s_axi_arlock;
  input [3:0]s_axi_arcache;
  input [2:0]s_axi_arprot;
  input [3:0]s_axi_arregion;
  input [3:0]s_axi_arqos;
  input [0:0]s_axi_aruser;
  input s_axi_arvalid;
  output s_axi_arready;
  output [0:0]s_axi_rid;
  output [63:0]s_axi_rdata;
  output [1:0]s_axi_rresp;
  output s_axi_rlast;
  output [0:0]s_axi_ruser;
  output s_axi_rvalid;
  input s_axi_rready;
  output [0:0]m_axi_awid;
  output [31:0]m_axi_awaddr;
  output [3:0]m_axi_awlen;
  output [2:0]m_axi_awsize;
  output [1:0]m_axi_awburst;
  output [1:0]m_axi_awlock;
  output [3:0]m_axi_awcache;
  output [2:0]m_axi_awprot;
  output [3:0]m_axi_awregion;
  output [3:0]m_axi_awqos;
  output [0:0]m_axi_awuser;
  output m_axi_awvalid;
  input m_axi_awready;
  output [0:0]m_axi_wid;
  output [63:0]m_axi_wdata;
  output [7:0]m_axi_wstrb;
  output m_axi_wlast;
  output [0:0]m_axi_wuser;
  output m_axi_wvalid;
  input m_axi_wready;
  input [0:0]m_axi_bid;
  input [1:0]m_axi_bresp;
  input [0:0]m_axi_buser;
  input m_axi_bvalid;
  output m_axi_bready;
  output [0:0]m_axi_arid;
  output [31:0]m_axi_araddr;
  output [3:0]m_axi_arlen;
  output [2:0]m_axi_arsize;
  output [1:0]m_axi_arburst;
  output [1:0]m_axi_arlock;
  output [3:0]m_axi_arcache;
  output [2:0]m_axi_arprot;
  output [3:0]m_axi_arregion;
  output [3:0]m_axi_arqos;
  output [0:0]m_axi_aruser;
  output m_axi_arvalid;
  input m_axi_arready;
  input [0:0]m_axi_rid;
  input [63:0]m_axi_rdata;
  input [1:0]m_axi_rresp;
  input m_axi_rlast;
  input [0:0]m_axi_ruser;
  input m_axi_rvalid;
  output m_axi_rready;

  wire \<const0> ;
  wire aclk;
  wire aresetn;
  wire m_axi_arready;
  wire [31:0]m_axi_awaddr;
  wire [1:0]m_axi_awburst;
  wire [3:0]m_axi_awcache;
  wire [3:0]m_axi_awlen;
  wire [0:0]\^m_axi_awlock ;
  wire [2:0]m_axi_awprot;
  wire [3:0]m_axi_awqos;
  wire m_axi_awready;
  wire [2:0]m_axi_awsize;
  wire m_axi_awvalid;
  wire [1:0]m_axi_bresp;
  wire m_axi_bvalid;
  wire [63:0]m_axi_rdata;
  wire m_axi_rlast;
  wire [1:0]m_axi_rresp;
  wire m_axi_rvalid;
  wire m_axi_wlast;
  wire m_axi_wready;
  wire m_axi_wvalid;
  wire [31:0]s_axi_araddr;
  wire [1:0]s_axi_arburst;
  wire [3:0]s_axi_arcache;
  wire [7:0]s_axi_arlen;
  wire [0:0]s_axi_arlock;
  wire [2:0]s_axi_arprot;
  wire [3:0]s_axi_arqos;
  wire [2:0]s_axi_arsize;
  wire s_axi_arvalid;
  wire [31:0]s_axi_awaddr;
  wire [1:0]s_axi_awburst;
  wire [3:0]s_axi_awcache;
  wire [7:0]s_axi_awlen;
  wire [0:0]s_axi_awlock;
  wire [2:0]s_axi_awprot;
  wire [3:0]s_axi_awqos;
  wire s_axi_awready;
  wire [2:0]s_axi_awsize;
  wire s_axi_awvalid;
  wire s_axi_bready;
  wire s_axi_rready;
  wire [63:0]s_axi_wdata;
  wire s_axi_wready;
  wire [7:0]s_axi_wstrb;
  wire s_axi_wvalid;

  assign m_axi_araddr[31:0] = s_axi_araddr;
  assign m_axi_arburst[1:0] = s_axi_arburst;
  assign m_axi_arcache[3:0] = s_axi_arcache;
  assign m_axi_arid[0] = \<const0> ;
  assign m_axi_arlen[3:0] = s_axi_arlen[3:0];
  assign m_axi_arlock[1] = \<const0> ;
  assign m_axi_arlock[0] = s_axi_arlock;
  assign m_axi_arprot[2:0] = s_axi_arprot;
  assign m_axi_arqos[3:0] = s_axi_arqos;
  assign m_axi_arregion[3] = \<const0> ;
  assign m_axi_arregion[2] = \<const0> ;
  assign m_axi_arregion[1] = \<const0> ;
  assign m_axi_arregion[0] = \<const0> ;
  assign m_axi_arsize[2:0] = s_axi_arsize;
  assign m_axi_aruser[0] = \<const0> ;
  assign m_axi_arvalid = s_axi_arvalid;
  assign m_axi_awid[0] = \<const0> ;
  assign m_axi_awlock[1] = \<const0> ;
  assign m_axi_awlock[0] = \^m_axi_awlock [0];
  assign m_axi_awregion[3] = \<const0> ;
  assign m_axi_awregion[2] = \<const0> ;
  assign m_axi_awregion[1] = \<const0> ;
  assign m_axi_awregion[0] = \<const0> ;
  assign m_axi_awuser[0] = \<const0> ;
  assign m_axi_bready = s_axi_bready;
  assign m_axi_rready = s_axi_rready;
  assign m_axi_wdata[63:0] = s_axi_wdata;
  assign m_axi_wid[0] = \<const0> ;
  assign m_axi_wstrb[7:0] = s_axi_wstrb;
  assign m_axi_wuser[0] = \<const0> ;
  assign s_axi_arready = m_axi_arready;
  assign s_axi_bid[0] = \<const0> ;
  assign s_axi_bresp[1:0] = m_axi_bresp;
  assign s_axi_buser[0] = \<const0> ;
  assign s_axi_bvalid = m_axi_bvalid;
  assign s_axi_rdata[63:0] = m_axi_rdata;
  assign s_axi_rid[0] = \<const0> ;
  assign s_axi_rlast = m_axi_rlast;
  assign s_axi_rresp[1:0] = m_axi_rresp;
  assign s_axi_ruser[0] = \<const0> ;
  assign s_axi_rvalid = m_axi_rvalid;
  GND GND
       (.G(\<const0> ));
  ecdsa_project_auto_pc_1_axi_protocol_converter_v2_1_28_axi3_conv \gen_axi4_axi3.axi3_conv_inst 
       (.E(s_axi_awready),
        .aclk(aclk),
        .aresetn(aresetn),
        .empty_fwft_i_reg(s_axi_wready),
        .m_axi_awaddr(m_axi_awaddr),
        .m_axi_awburst(m_axi_awburst),
        .m_axi_awcache(m_axi_awcache),
        .m_axi_awlen(m_axi_awlen),
        .m_axi_awlock(\^m_axi_awlock ),
        .m_axi_awprot(m_axi_awprot),
        .m_axi_awqos(m_axi_awqos),
        .m_axi_awready(m_axi_awready),
        .m_axi_awsize(m_axi_awsize),
        .m_axi_awvalid(m_axi_awvalid),
        .m_axi_wlast(m_axi_wlast),
        .m_axi_wready(m_axi_wready),
        .m_axi_wvalid(m_axi_wvalid),
        .s_axi_awaddr(s_axi_awaddr),
        .s_axi_awburst(s_axi_awburst),
        .s_axi_awcache(s_axi_awcache),
        .s_axi_awlen(s_axi_awlen[3:0]),
        .s_axi_awlock(s_axi_awlock),
        .s_axi_awprot(s_axi_awprot),
        .s_axi_awqos(s_axi_awqos),
        .s_axi_awsize(s_axi_awsize),
        .s_axi_awvalid(s_axi_awvalid),
        .s_axi_wvalid(s_axi_wvalid));
endmodule

(* ORIG_REF_NAME = "axi_protocol_converter_v2_1_28_w_axi3_conv" *) 
module ecdsa_project_auto_pc_1_axi_protocol_converter_v2_1_28_w_axi3_conv
   (\length_counter_1_reg[1]_0 ,
    first_mi_word,
    rd_en,
    m_axi_wlast,
    SR,
    aclk,
    \length_counter_1_reg[1]_1 ,
    \length_counter_1_reg[2]_0 ,
    m_axi_wready,
    s_axi_wvalid,
    empty,
    dout);
  output [1:0]\length_counter_1_reg[1]_0 ;
  output first_mi_word;
  output rd_en;
  output m_axi_wlast;
  input [0:0]SR;
  input aclk;
  input \length_counter_1_reg[1]_1 ;
  input \length_counter_1_reg[2]_0 ;
  input m_axi_wready;
  input s_axi_wvalid;
  input empty;
  input [3:0]dout;

  wire [0:0]SR;
  wire aclk;
  wire [3:0]dout;
  wire empty;
  wire first_mi_word;
  wire first_mi_word_i_1_n_0;
  wire \length_counter_1[0]_i_1_n_0 ;
  wire \length_counter_1[2]_i_1_n_0 ;
  wire \length_counter_1[3]_i_1_n_0 ;
  wire \length_counter_1[4]_i_1_n_0 ;
  wire \length_counter_1[4]_i_2_n_0 ;
  wire \length_counter_1[5]_i_1_n_0 ;
  wire \length_counter_1[6]_i_1_n_0 ;
  wire \length_counter_1[7]_i_1_n_0 ;
  wire [7:2]length_counter_1_reg;
  wire [1:0]\length_counter_1_reg[1]_0 ;
  wire \length_counter_1_reg[1]_1 ;
  wire \length_counter_1_reg[2]_0 ;
  wire m_axi_wlast;
  wire m_axi_wlast_INST_0_i_1_n_0;
  wire m_axi_wlast_INST_0_i_2_n_0;
  wire m_axi_wlast_INST_0_i_3_n_0;
  wire m_axi_wready;
  wire rd_en;
  wire s_axi_wvalid;

  LUT6 #(
    .INIT(64'h0000CC000000CC04)) 
    fifo_gen_inst_i_2
       (.I0(length_counter_1_reg[7]),
        .I1(\length_counter_1_reg[2]_0 ),
        .I2(length_counter_1_reg[5]),
        .I3(first_mi_word),
        .I4(m_axi_wlast_INST_0_i_1_n_0),
        .I5(length_counter_1_reg[6]),
        .O(rd_en));
  LUT6 #(
    .INIT(64'h0F0FFFFF00010000)) 
    first_mi_word_i_1
       (.I0(length_counter_1_reg[7]),
        .I1(length_counter_1_reg[5]),
        .I2(m_axi_wlast_INST_0_i_1_n_0),
        .I3(length_counter_1_reg[6]),
        .I4(\length_counter_1_reg[2]_0 ),
        .I5(first_mi_word),
        .O(first_mi_word_i_1_n_0));
  FDSE #(
    .INIT(1'b0)) 
    first_mi_word_reg
       (.C(aclk),
        .CE(1'b1),
        .D(first_mi_word_i_1_n_0),
        .Q(first_mi_word),
        .S(SR));
  LUT6 #(
    .INIT(64'hF2FFFFFF07000000)) 
    \length_counter_1[0]_i_1 
       (.I0(first_mi_word),
        .I1(dout[0]),
        .I2(empty),
        .I3(s_axi_wvalid),
        .I4(m_axi_wready),
        .I5(\length_counter_1_reg[1]_0 [0]),
        .O(\length_counter_1[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT5 #(
    .INIT(32'hD8D272D2)) 
    \length_counter_1[2]_i_1 
       (.I0(\length_counter_1_reg[2]_0 ),
        .I1(m_axi_wlast_INST_0_i_3_n_0),
        .I2(length_counter_1_reg[2]),
        .I3(first_mi_word),
        .I4(dout[2]),
        .O(\length_counter_1[2]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT5 #(
    .INIT(32'hB8B474B4)) 
    \length_counter_1[3]_i_1 
       (.I0(\length_counter_1[4]_i_2_n_0 ),
        .I1(\length_counter_1_reg[2]_0 ),
        .I2(length_counter_1_reg[3]),
        .I3(first_mi_word),
        .I4(dout[3]),
        .O(\length_counter_1[3]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0A0A3A35AAAAAAAA)) 
    \length_counter_1[4]_i_1 
       (.I0(length_counter_1_reg[4]),
        .I1(dout[3]),
        .I2(first_mi_word),
        .I3(length_counter_1_reg[3]),
        .I4(\length_counter_1[4]_i_2_n_0 ),
        .I5(\length_counter_1_reg[2]_0 ),
        .O(\length_counter_1[4]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT4 #(
    .INIT(16'hFEAE)) 
    \length_counter_1[4]_i_2 
       (.I0(m_axi_wlast_INST_0_i_3_n_0),
        .I1(length_counter_1_reg[2]),
        .I2(first_mi_word),
        .I3(dout[2]),
        .O(\length_counter_1[4]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hF7FF0000FFF70808)) 
    \length_counter_1[5]_i_1 
       (.I0(m_axi_wready),
        .I1(s_axi_wvalid),
        .I2(empty),
        .I3(first_mi_word),
        .I4(length_counter_1_reg[5]),
        .I5(m_axi_wlast_INST_0_i_1_n_0),
        .O(\length_counter_1[5]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h3EFF0D00)) 
    \length_counter_1[6]_i_1 
       (.I0(length_counter_1_reg[5]),
        .I1(first_mi_word),
        .I2(m_axi_wlast_INST_0_i_1_n_0),
        .I3(\length_counter_1_reg[2]_0 ),
        .I4(length_counter_1_reg[6]),
        .O(\length_counter_1[6]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h3F3EFFFF30310000)) 
    \length_counter_1[7]_i_1 
       (.I0(length_counter_1_reg[6]),
        .I1(m_axi_wlast_INST_0_i_1_n_0),
        .I2(first_mi_word),
        .I3(length_counter_1_reg[5]),
        .I4(\length_counter_1_reg[2]_0 ),
        .I5(length_counter_1_reg[7]),
        .O(\length_counter_1[7]_i_1_n_0 ));
  FDRE \length_counter_1_reg[0] 
       (.C(aclk),
        .CE(1'b1),
        .D(\length_counter_1[0]_i_1_n_0 ),
        .Q(\length_counter_1_reg[1]_0 [0]),
        .R(SR));
  FDRE \length_counter_1_reg[1] 
       (.C(aclk),
        .CE(1'b1),
        .D(\length_counter_1_reg[1]_1 ),
        .Q(\length_counter_1_reg[1]_0 [1]),
        .R(SR));
  FDRE \length_counter_1_reg[2] 
       (.C(aclk),
        .CE(1'b1),
        .D(\length_counter_1[2]_i_1_n_0 ),
        .Q(length_counter_1_reg[2]),
        .R(SR));
  FDRE \length_counter_1_reg[3] 
       (.C(aclk),
        .CE(1'b1),
        .D(\length_counter_1[3]_i_1_n_0 ),
        .Q(length_counter_1_reg[3]),
        .R(SR));
  FDRE \length_counter_1_reg[4] 
       (.C(aclk),
        .CE(1'b1),
        .D(\length_counter_1[4]_i_1_n_0 ),
        .Q(length_counter_1_reg[4]),
        .R(SR));
  FDRE \length_counter_1_reg[5] 
       (.C(aclk),
        .CE(1'b1),
        .D(\length_counter_1[5]_i_1_n_0 ),
        .Q(length_counter_1_reg[5]),
        .R(SR));
  FDRE \length_counter_1_reg[6] 
       (.C(aclk),
        .CE(1'b1),
        .D(\length_counter_1[6]_i_1_n_0 ),
        .Q(length_counter_1_reg[6]),
        .R(SR));
  FDRE \length_counter_1_reg[7] 
       (.C(aclk),
        .CE(1'b1),
        .D(\length_counter_1[7]_i_1_n_0 ),
        .Q(length_counter_1_reg[7]),
        .R(SR));
  LUT5 #(
    .INIT(32'h00F000F1)) 
    m_axi_wlast_INST_0
       (.I0(length_counter_1_reg[7]),
        .I1(length_counter_1_reg[5]),
        .I2(first_mi_word),
        .I3(m_axi_wlast_INST_0_i_1_n_0),
        .I4(length_counter_1_reg[6]),
        .O(m_axi_wlast));
  LUT6 #(
    .INIT(64'hFFFFFFFEFCFCFFFE)) 
    m_axi_wlast_INST_0_i_1
       (.I0(length_counter_1_reg[4]),
        .I1(m_axi_wlast_INST_0_i_2_n_0),
        .I2(m_axi_wlast_INST_0_i_3_n_0),
        .I3(length_counter_1_reg[2]),
        .I4(first_mi_word),
        .I5(dout[2]),
        .O(m_axi_wlast_INST_0_i_1_n_0));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    m_axi_wlast_INST_0_i_2
       (.I0(dout[3]),
        .I1(first_mi_word),
        .I2(length_counter_1_reg[3]),
        .O(m_axi_wlast_INST_0_i_2_n_0));
  LUT5 #(
    .INIT(32'hFFFACCFA)) 
    m_axi_wlast_INST_0_i_3
       (.I0(\length_counter_1_reg[1]_0 [1]),
        .I1(dout[1]),
        .I2(\length_counter_1_reg[1]_0 [0]),
        .I3(first_mi_word),
        .I4(dout[0]),
        .O(m_axi_wlast_INST_0_i_3_n_0));
endmodule

(* DEF_VAL = "1'b0" *) (* DEST_SYNC_FF = "2" *) (* INIT_SYNC_FF = "0" *) 
(* INV_DEF_VAL = "1'b1" *) (* ORIG_REF_NAME = "xpm_cdc_async_rst" *) (* RST_ACTIVE_HIGH = "1" *) 
(* VERSION = "0" *) (* XPM_MODULE = "TRUE" *) (* is_du_within_envelope = "true" *) 
(* keep_hierarchy = "true" *) (* xpm_cdc = "ASYNC_RST" *) 
module ecdsa_project_auto_pc_1_xpm_cdc_async_rst
   (src_arst,
    dest_clk,
    dest_arst);
  input src_arst;
  input dest_clk;
  output dest_arst;

  (* RTL_KEEP = "true" *) (* async_reg = "true" *) (* xpm_cdc = "ASYNC_RST" *) wire [1:0]arststages_ff;
  wire dest_clk;
  wire src_arst;

  assign dest_arst = arststages_ff[1];
  (* ASYNC_REG *) 
  (* KEEP = "true" *) 
  (* XPM_CDC = "ASYNC_RST" *) 
  FDPE #(
    .INIT(1'b0)) 
    \arststages_ff_reg[0] 
       (.C(dest_clk),
        .CE(1'b1),
        .D(1'b0),
        .PRE(src_arst),
        .Q(arststages_ff[0]));
  (* ASYNC_REG *) 
  (* KEEP = "true" *) 
  (* XPM_CDC = "ASYNC_RST" *) 
  FDPE #(
    .INIT(1'b0)) 
    \arststages_ff_reg[1] 
       (.C(dest_clk),
        .CE(1'b1),
        .D(arststages_ff[0]),
        .PRE(src_arst),
        .Q(arststages_ff[1]));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2023.1"
`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
Qpp66Ic61NR0mkVmjG7vgOL0NB6CTFb3Lsi4qxXFnJ8tqqKShAriiJmn7uXBNCBvGZLnXCb4uZ8i
EqR6IQq34abN0LrooQu7rm3+Pw0iYYKzN1lcF+6EclZnFEeAIj7bGbLI9X3Ib88Mjvj0+p4IA3Fj
9ZGHNW+O+knchfmqAlY=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
aPxGoOnJHTAqFdFSzG9ru8Bw31YY71SqnXPbyZfA86PxaAjm6NpQtu/8fWeHlM19Jz2a+1ZDAj2o
VkuAl+PF18BGfMNo3Sar4bSJm8QwGYpdMiLM+06C76IY/redmJfNEXBnwDGx1NRihbIrHe17Fsp0
wci4ZT2n5HHVBuhowg8un8abF3TR6B1Ll1huon8bmUC1ZCG/4nJpwwhcE9pfhZYPxzBDs7qGqe8g
84QrDMzU6WhHqgMvR8Uor517l0pItAYj4pxMvaZhC0k3EgSYp/MQytJr+HF3vsw+o0eF1bHVU6Na
eXWSV3ijxUZXCyCMZ7YmEZa9JX5uKS5m5eiP0w==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
mWzZIcmTvZaO1EYxJJAY0jRMaMCjTyRzPU6SbUzrKHfep0pA4LS/MlSJytRY9FYloq8LonlEJmOa
YvTXus6Gximwd82NfOWOU+xAliGI4hqn0DLAX0dSg8OERUorJfPsNqrBuHvDufz9efGQs7Upr74j
TMlZiW0gSVGHMQSLqUU=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
lzrP+qu7wbNhDwJym0tPh2ytzSxetAAI7sMgVeTkF4E0aGc202oEP6AjkTk508CVci4/F5/oGOgY
jKPpZya27mqQoisM8ilYqvcw5pXx0/pQGRu7JZF08b+k4spPXeJ2wn8IDY3FWSHnOcvi4dOebH/q
+4u19fu74aqk1ECrIQzbVZpwcWeMDGDUSHDy4FPk9OjOswCxOQPuglJjXYv+hMg/7JiOUBTJX0uZ
Xmdtxy8L9z4EWzfRzOSHsJFjTkSLmdTFavs61PfZS4KYT25LV10DOvmL3fy7M6+bBXN5qE6rW0RO
W75E2gYB5D04Qa/SgER8JeFW1M0T8RacJUUV3w==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
FMe5G7+i5Dg2OTIM7CinNcesmx+3xFOKOCTYsoHWrp5MlbAPNqriPe41pqSx7Zo2+ype18VVw+tF
lEjRQQF5TsKrIoc8kQqO2Ck9JGAZjsyrFM5jTWzQZBawoJBB/EbM32rM+O963qqQdP9ruUzt4aM6
vf/tdyfOgxkUcl6+JJNYOQDIdBGzvk/dQUeNjJV2gWOsMrT/8aQJJMjp2XPW18IEhMSdUT+e8kM3
NlZcNyywDkNOLcIS8VKNtRSuC1gLTR2zXKL9eJomOGg66N8dfL808FNqNi+dtOqd2OhDKPCh9VYN
gJ7hSggqdHhUVsYY5qT37vUMUZG37ITEHavSug==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2022_10", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
IZp7wGosl6Ef78SQeUxKofUHVTZqkQHJJU3t0K53ysy/heNabWQpu3n2M8+eCIHOAio8FR6+AOlT
IAA4JAFJfJ70Sm8r1CV0vuXGNVDhIlFr8HhnDDJc8CLdz8yaFrENXgAR92A47cxMlNwaJCGipXa/
922mJ6b2pGDdjdTLUcKsU1DD92Kou08spouWrbB/PrcgiC0dc9Vh5gbveNqmUuOyH3mlBam3FvZl
pgofpiJBXCkR1i8+hAEtpYGjmSGUTUQ6uHMUKX0u24I2h77iOiDKYTNJT6jVuiYM/DRD2IfylgS4
u7QDnvP07bndi2AIocxrw7LHdjJ9XWVyHUaXIQ==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
mcmaj6yfbZVEKTiuHl5s5QU2BU2VRdOtz/pVopoNI21Pt4eUkknoHSgdfu7K976MpUo+bkHQ7sJi
/0kAsbTsCHtz7UWvsCk9A5SyLMykdZnWyjEbf0dHlFcgzZooebDG2zm4mibiRUIKwAMgFxTWk4RV
k5Ay3X64cOudFYqRbTCUmp1L8ijVoYJo0zi23fsL0jwpEG5FTTnJ1h5mK9rFtj4nIzmKqwwP+7JP
esKOwY5A74OZa9Q2+Oc/k4UmgeZgw5q/xkt1aAjxDyRRfCIJizymNuJw9sa/nQXTKX0zCMrY0MnQ
PN3c4p5wkiNcAHR4g0673PQsVxTSpFZkCNMkwQ==

`pragma protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`pragma protect key_block
mo2NT2/CRe5fYBwkxXV4DV2r4VY+mW8FieM9wY58cqg6XakgyeQ/Du2w01ie+Sko3Okr8ziahuNO
XBMXX0d4rR94Cwxf6q8vsbxZgbIlknsXsEuTwNfsw6ywD3/7leL6Kapx3fGSVuIHDMHjwpstoX+8
phs6lpM0VeRML4QJl7ITOuweBx9b+hHFRy5duNtva30fSyVWHLpzAsS+sS+gCcFxsDn+K9lQj/Kh
u11IaBweyu8d5W2ClTN46tdIzlVw6S962vDsk1+h6BQzF9y3z3BJfLpfR+9jdhy5wqng0ejlOpbT
G22gnlE/BqKGgLqVQKaeXfnp5NnReQcYXQTMossrLWwi2JUvDGuA6egmN+38JdoIzDHxNPxvAOZ/
mF9Qjn64t2tHB5iHybi3qFxlysWYSczGHStpTKrEoNAcQV/kMTe5coIDdy3mGIpwuduxq1OYPA9m
VKKE/GCL1MQzfgEx1Az+ts8Oo9hgM/A/cJ2envlpTKlt5itG9ciBZ41m

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
RXuoomA7HXqxfp6NbzOyYrUYOntlNDrjnrws4DzEIh4YC3p8BdX9/zrLD3AxALpTnAeHyk3lFxEI
uDCpL9/tP6yT5BmfL2N/oyWIQ7y53Env+IFaJMMaBIG9U1LBtkcnhV/FW9tkUePJ8EbKyE9tP/kp
RScK28UNuQEHp0OPznrb1v+AWO/DiSNPuA44x+Ig5nBALVW9qfA4+tvzfHYpcke67vIFYWLthZx9
NC9+R793F9ypEZMOjinKDbEk0gDUoqsmcmgF819P1JtLnGnuwtr1uER6OP17CsHbFowAmPsPPA55
QkDMyp68B+cHNNW23VXNPbIXLvPilhp/ypT+iw==

`pragma protect key_keyowner="Synplicity", key_keyname="SYNP15_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
6BvoQpuoVy9vIT9h44IRmW7Bo+8MCKJj5ZfOShjmujfjeFOwPLw2GCUNvV3ipB1eThHomI5yXGiO
fxOovfDeVP2hfGVaO1qz9Lz6NGhPt8K9Z+sH2rq47t68akOCSgmAoKJ/5BbwL/t0FtUVgTtq7Si+
HqZAUgbX8TCY6IRkFibfSSK6UarmhEpPrPOpvsevKx4OaMU1jfgaJvIMRd257kSQy5o7pyO0n7VX
LK6V93O0bi7Aa/TTt9W2MSK5pIDw9DmkTCLFjsS7gBYQYaFaba+LGfjQ782nQK2+KDz85b5qKPM1
h19t51h74j2WjWCadIgjRVfMYVvsErL0ehA3Xw==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-PREC-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
MMpJ8DorVcMATHbuGSlNSCGkzTOL3lRnFD2u4TUx1W94+tAqA8Ktjam9MqFHuJh/5PX5VUq6FgP7
1oYcR65DRc8C5iUj4h0vhHLi42ruJU++GUuIdS9gvoiQ246hdXMefRe5wcEOnqmxKzf7fyduaSpG
7SdN9PpubFzyeck9cLJj2CYMY1XoujEAxeBG5YKJtFkQkCeHZWr6R8PkNR2oyQGuZuMeJdgNh4Lg
5yYuOk0BGcB7bwSjic5zqk+8Veyp/ZGAVMgpH80juQjINIxDcLbvhqTIZX4gKUQjcJYcBhVuPgVt
Ms7dqARwL9nkpmZ/SuNzUmGdEIhVlblWNDRV3A==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 71856)
`pragma protect data_block
n21HvSenkbvY5X+JniXSIfU7DXSd/uitGy6wmYIarrCI/vDSXoiBqgnSshYvbR3pdJx05iTZsoBU
T1EQXsnGa71SeC+dRgxXlNTgPDXC0eZXgwVn+gpIXtuVleqq923Dc7f8D4jE3rt9NnmTs1EOJqy9
kGxQPj4dGew3nsSEF8WCi2m5mEYHFIclXbBdJJuGKW3E1U+i23u6khzLpudLfsD4Wc4lbGAYXyex
7KXNcHVjkbBFqbDn5dnMkWI5KOg/ejjAKBeFotH9Hr90UNHHw2/cKgr/RHcvxs0v77CbNJEVrhi9
B7ya1M0HSQTu0VNTC8UacUBT/XwnQNlSE5qfaEsFSFbFEhrE525ruv1iyd0UCtqtNXlgtVJab/CE
WX2Z1f8z9t4Xh9aCD4WRvA2hJJvmBxVRFuFSdBzm9QSaxmUiUy30I+PS2JoU3e8OQHo+2y8/WhCL
j35HmOFAgvYGAcIPfxm58gJ+sOUzN6X26guOwGvuImUvcLEAIDoT8Qh+GP3u1JShDnCUb4O1LXp8
wCUKcfYm2fbM/RmoKC6L2kkV3NV7wZjfZROfRKQ0V6Lkvd3zInUqAv2y/UFcx87k+qJGYSEYDkSp
Xa+0/0AtHp/9crc6ZkTgTSdw5C5aCmTrjk4mZ0FYKkAG6W6mwZMgnfVrGoDW902zolPfQPJohPIA
hF10HV4ll4NKqQ6Ru9Godf5/WhkhMclUFYHCVfP3m76QeHPDLFIjo7I9b/TPHKXVMli9qmUZ9XDk
IEzBNJmaq1nDV8Mbm1SlY2CNifuc7M26vB+eKNZ+IHdFBY+a8KxsinbaHbOiTHOQe++yBNt+kgX6
g/C1cK2wUyIsfMXi5TR8ooMfyi9bwuxUppvMZcZXYw65hP4QLgZSPws8eCmR8bO1BG9Jc+zo7agz
CZPvx+a5V7H6XHbrc8VEG942ilej4c7tkf/FIddYWi3M92rui0hiWi9dftN6+SOEAxc/J3ZmOcU1
i/eMcKwzqY8ACPxec9lCYIdknQkTfovWbO9jYfN1vcjI44PYpVOFwy4RznuHzl0Q8n6Ewk6k4dlk
mHHn+t3oScdi8CSaW0DSt/F1AIAnol0R95NWRek6qfl0NjcjLvITnAwtJuAKSUKZbgwCubt1gYuJ
38DNtFLeXG6KV91LAQNVfGHQo9G87vz+5id++dT/0MeAsFL+6CGzThjLYZygrVvIrACJdB2/Mpru
koylA0QxGibap94sOizWYDV3Q/V4VK7O+Pdm+RM2Fa7bgixXDmXNSUO/DhTJ5ioGGYijlOtKmgV9
QF7P1pVcgJDljfjktxh3Svdaf35syjXR4TmNnDRUIrNE0GbWh91RrtNc2lcSsA0bkMjwMsmhscpJ
Pz9hkZBviummnazIOyeV8BBNRVbzgZDnkGqgC+CkpWwdt3yisUcpYxWMe+BPf6tmh5KZ8EUh3s6r
/ZAv4b9WPIpMjVbv8XWIMXmj/zpKv+FWlJ15HqtOhYtB9VXXpCVNNNCIVYpvjJbHm+GzYXnR2WF4
NUOBd6DRpBbJE3xrnai+ATxIkH3TLTQ2o0vejGYr8fywWy7m/G+TKNQbiMGVaIRopIwNoy1ibdXb
S2vx3vFN/SNfi9ud9ClByBRzq2J49KcfLxqnISOHo6AAfX2+ywbSMgEs6gIFqFa7bwYNh+m/ZArg
LTqUWZcagqzYNGxcvQDms/8pFeooDvMAf9RZALZuvW6yYMEScg99jBmDSj8rr2OWk62iyDB7aEYg
4AC9LeqKcfBa+DNpR4U/YtEEM8/euoMLKyPfbwXitLURwFqC9X0wckojDr/YjXMF/DuQmeGScH2l
LlacxNLqz0lUlEaeO7DFXo8PZi7dPuwm/zRwIwb1rYmms57c5GgLUrypQekEC4l//YMp7d3HdAMH
jLgNNYBwtOX6UxLuksIInBNwGCMmacbRjKplsxWNgPpIA87O02Sg8KwsnGhC3WL83YZWN65+rqFS
N8gte69O3nCtki4sEnaeu105atfDbyn9Fh7f+h6UuC4bdXzEETy/JW2k0IbPfFpsOvw8xOSU9rib
Q0QiJdZKT9Z7zQuqiClPthOgzUGdvm5R+J1DmoxtAhD1KqjbmR33eVrct2WZXk7/HaT2uVqW7lOu
j+PusqJTeWzXBCbrvF0nFTS/Y8nm0Bn1s56I47raUcdlDE3Rf8Q+lChFD0fB4EH2eujmyy6TwsoP
BBuAK9gOgZujOiehTJdOpzfTa881mr/ARoPSodt+DLMNYFwM/YHy3c8STO0ktWaq5GEC4QfVtguI
YR6shdAuausAuJpufYWbtA9ByqaXATDsiwNytcr8mJwVYgpc4lfuIB4+UoARo6qv8OLfDEcRn5GW
XJM1q1qCHQ6yTZgr6uoq4gA18sc3e0YGGk+9BjWQ7WrRljF8jTgqjh6VfOrqpi3vM8iFydbimvBX
YfrxCkflU1bZ1yChKusHHL/NxnVw4ypbArfCWgyILRfPo7Ot9hZF49UTtTQdY9ReqO4bDei7G0Nf
XNFsBo03q+s2ur0LPgGvHzfg7phgLCdyf/r3TgmSIgFWCLr/iDYMg0UhpiScYXvV6ZHDCsCYEXaf
/OeWk3dcDjA7S93F+BfJZPsJmR5HK6mkh1J2hbn+izZkHw1lfh2Y/xwaZmWl7OmhZrw2udXpQ+sI
uKTPBmBZa69PDlVacfI9ztVTBw1yFCXnjJkN8tsyzZFBdoxfnV+d93PCm5ttbhf+DJ11G/L9IZfA
I6LRW8xTV1WZJXn/8z4rd2yCu14dvuzuYTLbfJkUmv1AEzW2Zzxx4+FNpyr2c9zxf84iWxw5vj8/
LXnqQsGHfWxp3Ls1S3N3+ULl10A2oCmtF+/hsuBkUNH4N8d8zNII0I4G1pxRmHPYoAfHt574NfqL
G2ZUxaDtjtmBi8v7KZ/frA7OUxAEDkijhoyZcQPRgcd2JKfGPWgHYlRzK//XW2qYaubKXUnh8gDv
EpEL/Y67COWx3s0HJOf/XwGLoWdvMhKbEdCS6ZTwB+e7H7Uk3AAyD2RPlQVF0ZJwJzQBgejAUtbd
G437/NWDJzaVS0RYvOJ62z4lNf3HmoxoHd/S05nPwvQzLji/wi54Q9+vPuisJtGzAwcoCw6IUDYe
x5gD8kmj/AF4cI4ScDk1wVCGjJMyQcv5MUP3BGI/2SOyWl7jhCK2nHb5BxBp7J26pZnnqGxL80rG
+yQ0Yead51z7hcd+oxbpjIAewro4PBOvLwy/tF2KgoBJXFnvlQYEdZAZY9zPEIeaskWAQVwyMNij
+r5TBroBPDO6uaOYOcOK6BkLFTIqri1a+W1AwvlF+RfEUfTLmQwi9Oxh6lhkYbBDhsAq2jVyeccv
2yqvDfDcDTk/rQk0B57xf2nXddgmX0GcDsPWqojfSxiTdbeGOoYDQrHCvT3JapgKef8uYg4UOiv+
dQGhhgHA7qf26l9l7yE2TET79Qacuxd0L2SGWWf1kCybLXF16bJ9xjzhhURQ2b9DtOpkNYo3RsiN
cRrNC3WMZA4Qr2Ha5FA/lqmTeCRsnbMpPWHnGI8vEb03F7yWhBDQwoJ095bG+RNSQd6QxeCSzxbi
720ww92XEGmLUZJgoLcJMx9k4A/1eHMnak8zyIzfx4fxkd8bsnpVUutI7rvTElN4/0X22SlRNSMW
fwPJD17xhTy2fmGI2neZEVxLu0lV+nPreVkioEc5DUwtbX8mL3iGjpG7lVax1Y5WykTRtZnHt3Ve
MhbNI8b1W0JCU0OttqH1M6f3IUUxIN6DJDlVv4DYhD+tT7wv3p5uAER6vutQrPvJSEmsokL/99qD
6cnWnV9youaZn3ApET1PWysmTEmjlNEYZCu4XueY1IOZklfJCjGUaLjGmi3brUs/hv6dWZzapb8y
a0qpsU4RTCwY1O+K9ExLkXGf8BfjJj2isLWZ4LxIuz2fbrQU4Mqimt2TcWbiVcdpDaYks6a9pnqz
kw8cZBF2I///3PFMTqZ1BeICsRlH4f9ZPOFkR3a0ZMOWhcz6bIrdKZ6Bxd6RypqUONkaFUmx0+gR
7T0nczxns+wANAHl/ZO3Rg/daUTNgzcd9qiSDeouWF9ciTKnBO3oQyySXSjraO34SoZfXPRPEdPn
UBDDCwKmp/V3+uaZHnuF9xZnYQgoj9/rbmq+oqG4VtiPciY9aKjEeoBJePxnwhiaVv17L9yZtdMc
4Cie0GIEyOfEIyHt1GpgHrFZ2QTKP/hXE+7c5DowpJvFPdcVY7r5HWvduWKdE7shhv+HnveMICgI
RSysueBVdEIXjIsgF+ktqSvRODcaGbKVBFYZYtOVA9WzBhvmLuRd9L4vpScreUg5YlMTuvGiH/qu
pcl7aWSx3jmSJpnOyHbiaHihEXlPpKbMtFBxZx/ZoszEpEvtkIYxdxRet1PvOJwgBsfSeftufI4P
yglpYeltBs5DOGKHkQJ6EyzySN/ZOQ+McfIiTTLv4AjMbkWaaH2zvLc4QrzHSqTiQ61oePTTbOLP
n06l95s+qgYGeFeoU8BICO6rjRWHSdp03yQyIh2dRgSFzP3+TSalxhFliMonLXJQ0YULAABjLbJP
2V+admCQg/0S8Qaxeon/SB+gonsTEvl13gA/emM+piMbuynAenN0mmGVdxdNtsTO26M3+vEU7r0U
zlbUrqVeHHiHriK1t88KAHlQaua/hzlvL2oxSLOxoS53MqRrZMNYvWhqoOgCf98iJHcjbZQ0tHBT
f5cAnN1y1H46OWXEPpwe5jcG6wlwmpRM2LGdro4GoyZKkQ59tFMLPXuR/v1a05mvMOcT1gIYqfca
SgA74sxNpfzKUTU3D8+GAFyvBzyTparhEBRWl3xBGXJrAJAdKpEsC7kOxePMEBlMlgpy5v+4T6S2
ygUxuwb3jBKJ2FKO5aXw+ZwUNEgThqB2vOFlWC5wjKBaorHqZg3GRcNZAGb+0hUGrwtIQy0I6cw/
wXHzBtfSpL1TiPJoRjjyqfBejBw5bCep542ylC45rmVcZdFZEiX19++e4zHka9Uf2IXxNe9+UxFA
UeCXITSyfzp4UJ9oAyhYFdAGborfSYcXNzBX43P/RK7ZfiB4H4eHKG0wDrNbdzHcDIyzpWzZasU8
zYCO+3sft53AQkIa94fKv1WtBSTaufQ6XgMApfRy4ht3RtpqEkLLvXc2Vx4h3DrCHXrdsA+p1dRX
quZf5hn2Barxl1w6nfvKWHf3/JSeb2GuLofWj0uy+LfCxjS1CwbPynUi7e+zVjAp9bunpurHF8U+
a/v00V9t6FeXxIH882InBf7hLZoE1AGA8Oy5mD210UZQ4tnCbJDxgFfr+9askV7pMaj7cH4ZA110
CRHcTRlA9z+e47jaZaTVDGBM69FLHly6swsTEMYDrEBXeYZQZt5KfQbbaWOjbay3BMuW1vgEHFQG
6E44VClX+njMJibQyHnDb6JmoLUJiyAWHZYspj/6zw88gI+pAC6+xjABNb+BjLaTvXW1khtjuB5T
fr/B3RnbbyqaCPZVhtQgQKQl4By66/3+ghNfy/IkJUv9+tgAIpXlaWgRATotZaM5rIZYouOLJyXz
xHxkRQ5994QOHayxOkbDVCZ7TH6JNc4xUCzYWCINb9bEb7ceqYqRxKzgMN6bQOzeOJkVaEgJPevz
NhPXZ/m8eZD402l7H6SSw4bRmc8agf3/mdmWemnFGI1nrShPC5JrdbkBnYZ0ADfw946VezaDsIHI
f8IPZN30YfUF5twDv+oAT45FWDyuoixXDs9r1jnD0eq+1ok1IeDfZ6GPE9NpojWe063zMIH1JprU
S8wtk5Hz4ItQ0skK1eyeAtyjUelk//5PRn7vDY8IHeVHBKrC5PfLvrMcrgcrbakuNsuXzdYGkmir
i2aHr3V/zSKLCca7Wv8Dy8ShQliSpIEgXqbrRwVZdfCaHfoEHaIxNR6scyixCeO/egIbi/1iybCx
QL+qxzitFKdkEny2wNvMH5bkpzzkex37LeSaFEoSHBWDgGjDZxpmPzXCa0wH/y7aTqyGQn/YAK37
s1Hfs+NUuxYaGL2hdWaDHxqXbE6AOW2E2ZHILBPsybzrBTXEMV2DYn906ws2W8M8yb6QRYy+LBSu
Mgi5vK7rkNX8Ie901luFBqIN8KFNtY1rWV6UVYpiMErVmlNfEcxqUwnCvYp8u4fA9pWlx9eq66yT
LfEZ+vxWncoeSNKsTCy+SyhUGmh5u9T/3yFEw3kG4wk9iCZ4zM9YsbFqMcc1p7q6CYIjHXYJnC25
8B9YQIIr+39kHrZadPuj3gaYg98mM8x45aDlu46ChGNq3CIMidoMv4aHA9rqd7LUTwKi46DX7MHu
P5LzBE9B33G4Or4HDzmkyyjrZjslmhFMOMWoPlqfthPVWudBXLL5NnIneolBLfXBkfBcNsjPfTgc
gAsN0RBNY5+4uXRD7Wvq9lrjYlSm1zKbUo0Ve7spQpYZp9vltW26MZLMh4cftRCJB6yTtEfNplSF
bGNv3UsF9I7KV8naAOCAs/DBPhMbR/sl4dTi6rcHAjMQz2Qu5m3ziB3Zo5bFCfDSPSCnD6FbYOz6
nyJvuY8mEDRwoZEvshxz2exyDgi/dcTrXL1jVMv4VG099KvEXs6JMfSCwlyBAj8CQiqCrffsqq6e
wOpXQ3WVuGgssi1EIso3KVarxnuj0o3hd1jMxeSZNxylVAtZLoNtGyN8SWXBN2KCAPsSXW2EwsA/
HVMqKSXJd8CzEfFHg7F2n1sdbXyzgIlHqMse2vpSXGU6x+XXD32iDsuZOtiTYnQ7jZw3frX5zpMl
FpCI7PDTi9GTih4n7SRK2BqFW5OxHviGmedCrJZEYokzVSCTVI8R4CTZ3zw5ooPdf0pZ6Mw+iKar
wuxF+qVmdWE+csebmUVckarezBN9GVGBUapGN+AJ2YPEeUdwetY2j54eb669PPvesEMW/N12Piz1
74qSth0Mz4rIecCGvluWj2Ccz6IHGTRXQmcekLp1e5pT/Ly3u7zxulXTmjJBTO3xtvx6bBcReoJu
/O66EDvdHbdYiYmAW7ezqQYtQ8Fl4LGrSBStC9UagZjqMwg96tBCv9Y5PuYJKo0ZOUhT4zxud1gb
ay5U/yhDQXs1m7CxaGHhMuYjhS956hFa9f5IVeA8nj6aOmD86CBBmfkdMaxnjBqvnHrziaYYy2AB
umzpnrETlmahqwvNvG6Onqo/uo2ZgT00938YQwnOcFDdz3PMV6/Bl7CCI6x4mk55v9WrxlbrqSVC
d2WrbOr5xzjtH+FVzX5M+0w9T5/MHV/beQ7WAryN9GNoRT+zUqdemx7gSiTHT9W4a1QPt1tu4Jyy
MspHFejxs96BqZ3NEQ1z4V9uqdFg0WJmHebMk2MGbA9/B6mqwBJ7gS9JxhGEqAUAjWEOTF+6LY8C
vwKTrb5XF6mRvCWoIxaZWDxiqHfwP+N1fn8Dggjftp52oim2MVTYQixq6ti9CzcePdE0GSVeWakI
Fqgovvxxd1DqJQMRXGQYM2lCzIEH9Ub15T9Li9r1fnoSqfrtEjJJXhy8U+9C+w+KCvRgxUUhhCSi
Ji4/4XuJyuYFQ1wSXxdSIA3sWFIB/EB4QQC7UtOwORPYLyNvl6lh83c+whP9W9ByRcFxbAtJg6/w
8zE0sQyBzHWgURU/HFqTX/6V2jiWpZteb2Kb31Noyzj4w71hQm/TFK/ZPDjniV9P7RkjAogfdQT1
nUEAuYnTe07wU1T8QM0Tj8ZjD8kPf1MsEbFifS55/oHzMEHJ8c3rdzJO6Ol594vd9ShibZvJaix2
NXXNX3R6pejLsRVQwprrdkoc8Tqnev8J+Z7fN0XWN0o/lB1P6ItSDEgM62zjwvDt8XFE7oijKqgq
/oFty2CJuz4JcSywIAGs3XoPsJFdPMzLX1ITAdb5PmJFWtngqsAVdYkTSWvf4MCf5jxNM9TSAZVp
nU0axIKFpPOvvS99lYTSF7GUr8h615SQn+ZFjRJfokKbROgPj68Q9vs/wd/03cfi4uCMatrkL+yM
2rbxDB+KYVNr/YK24hnnXga7eAGFq5b5F8pnH5wevWS2cpyon3rI3ZYvIztA4ulX7VzMSiriejns
Mnfa12mdzwyDA9UdSBr9owGg0fhbxESFxFhZfW9aDfSHaftbcwo+FzC0Gya/8UAPpzq3N4AEhy+5
XF8kyQWEW0s0hoNbbTdPcmTjyZF/UpsIXr2usAjXlEePc6pSgcw+WrK1fFQU/gB+00/Eml9SN2Xs
JmA0p635/K2s8Mar3SB9GSh8zPEZF+5lfYORzJJBo6JIVVygQJy5NPc2P2UK0vd8KbdQtWeLQKR8
mVDO/H8odTh8s+4ZXCik/TZlC49933mL2nyjOts/S+ceCex8TW20DpFShtr/lfqNAZW/Gfwxqt1b
r2YT4E1LKKpn0sAfjGzx1aVyZuX3CMaEHP4LvGbCw9L3yxI/PDd3x9txlxp5BHWEVzBkCF9AEvNF
wwobrLb5gX7NZUEEdWQYnSq+1O3NKiRrIBdzUA2w9mOsnFwsv2BbPP3QN8CGYtENoOccqiGCCyFx
FYrCVaHBsXDAWdkCmAe0VUp4sw/whGNaEX2aawQfW9xP4YffdpgDOBe3g+ybEPESEyRHhtd2r0fU
VdP4sFde0j5jZFQZXSHMDPuezPmCKRonZ+DQg7ZmeZQYWPfzrKrICr+Y2Ih16MFB3i++eNZbQqYI
eifhFRdxgHkfEXzf8QuzjUdmy8A3vTmqgRononHzfVqQkqQN4XqZghZ2QPBXaoH/AV08eLZQU1Dm
f1YOoypqKrdorPsa8zg3TBt/zfvkYpzWxeT9SZZ4LozI0w9hgAp+uS1slt85dTesmy8WoRXXfyt6
//A6RsaS69f6M5uxCDQqDrNijNO32AwNZeB/KlzqS25czLJKJlAwDBjJL57vAs3zZHR4jpVz8fvJ
LDngDyPD/3YRDHlhZE6SZOBW27XbzIJAhp4G/qanKpBtmDHDKPYFyBovju0egnxUEnEdqINggrWY
H7Knpqas3ZyavHBmNA7iknDsR+uRLAif6IOwTK7+ezXwk43IQSfMKG7c97O+2bi+UClLJINZ7hsT
zGeVANoiEwt5/nlmou/RizesMybnmrNKm//2yFMY7OBASHr1asFqa1p1X3pBNZ4tA25PRTyTVP22
UdZD8W4b+kVrWvicqjF+S2Ai6gCX4MMGt3pdKCcU746bpsURQ9sy8Et1J3uIgk4HKRv3mOcsIGpv
I1tb6BB3JdzkjogaL8ESeiWmvVi+getaUqplpgXlPXupVu3n68v16umEwYc5d2e9cbifrzwdZZs+
peO9ozIqjF5/8UfidLao4teJkmRhICGBYQ/zi4EmalQj+4jzntsbWJTaU5zC/fUIFrS2X2YpOwpo
RHJEzh9xBK797ngYm4Gia8mrgd5E6Z9ljlfRWXbLF0B5Dga9LWlS1bhuTwke8t5B5H1emX1GyTN1
/H8vTZ6RMlazacO9ZIthj4njRZGFrKr3iyo+xU5hYenjxAR3rjj3KBb4cVPA9dTVEdw3d2cD1697
yg/ZGwlTXj3Vc4/8PJ01pyI83bjCGouZUmQ6Sjz00jXZpgiHyR3V3XV8kmKeiYJ+Qi+GPYNzEeYB
NUxi4a4dw+PQf+hVJyXcKs12IJK7xME192Df0fz0os8RrO5eAoMMHP2ejZPiFJF55SaJMP5orqyT
epGdsGQ8bQ/gw3Ex2bZxrj3erfIsV6TsEgpRAqMHVhbe8s4L644TvjcrGEMuSi/9WTT1o7pw+QLs
DsST2FdWrKI1qugunVFTzFXn44XxGHxyZFXOxaBzL2A8oykxnfGq1ZWchPkgymenm4VUuDbrCWu1
V6UmUr0x42al0D6gnTP1K/IH1LhB8WhDXIMjLMBpIUksaltf3TJy5StDcn5qq71nQhFUfysUCHg0
pGa6Uvejh+5WWemyXfFfA2fC0O+uWApHg8YLfISMZjhRzNwg+9Nzv6AnISIdEa1BlK/DtUHKBVQi
1ytFDlCDGNBe5xXBr1pdrUye+Jryk6xu5DFBrO8tl88oWgIurRAVNUWZ4KPyAOSigyhA5Hy7ndo3
eHg7jvpYwqUIZZCVSvATmhz3PKshRgXjjPQgX1NhfVz4wfzWNKuOYzXkMgbnQAbz+EcvDomu8H1V
9HMvX3l6J1r7yqMeC+jUmjTq/hSsL+qplLzM7FeJfi57J/kGXWpw+v3lNDoW4tzvsOR/LPFZYKHH
TD+ku4oi9gaT73mtAixRRzBPyNLUSYdv/aBxLrHbOh7sTFiGsekSyfoP+rp7BSvHscFbC1k44zvK
yvj/Bfs3Lq0glxW1QZqxQ9x82yGVXVIF/V4PqV0XZ5AjMjniEvDSU4btZva30KmL3h+KW5dFWefA
xYLmDkXTCICKAf1f1O8+YEPnFD7GT3a++yhB3tBK0Ft6PhIBxcjKk6O90nWuShZI30uQIYSVZzes
P7S8mC5P6+Ifom+sGXnn7akyrwQmTTv+7apjWB6bkmyPtZND1H1vtddJxM4kxwG26rNiClrvOrP7
hKJIuD4n4UrHGBxPgnAHp3yglDRw4thDs1Qp9USUx5FyrT8Ih6/z7PGI7nyyUI0OWMosTJhNrS8+
Sf9PqnfUSPbkBk1k/pkMXah0x015Unlnk1JrB9EWVjjVG8t1+vIWMuc0ILizvjhC68J5UGNmp+ou
DdDnCi07SU6o/M2EnilqUlCg0gluKaWFUjbcwHpfTc3SNGXBGFrWswavswfGQGYPvnFZpOYhJXIL
/Kab/jaPF6MbH/9gzTrib2stTwf4NkwFmUMaZUzuj6ligCTIwxy84OcVTGy804LtdZSXhWYpT1QJ
JCOwNnemZA2F1slmYPn8dQYFsK7H1tK2/e9ZBRRBAqZsvE1TFDVtb9P184X1/WIMTnyFfpYLUg27
30eMHoX+09g7dB/1CTPrGn+gTQqUYD/zOaVokt8z3cgm5GyA9UYFgj5+jO7eB3Xg+TotlE114ui9
WqSdE6VFW7qE0EIElv8m0tzsIMojCjcl+REL2xC/bMWnbYou3LiPMV55f+Z1GiwzRiee1vaQIKvS
BNUnCQqa+e4UIBGksP4GKyqtLo+l74BSyy69uT0fmIgSicdaS44X0ZI/kAf9cBBm3A4PIkEIhkBg
bwA5CundDdvuz9Ee8bRd9nGD/CeRLk4ST2bOiQKunOjtottB4i/W12Kz2m8ltSCluLuNVbyuL8d8
DcQ4a/4Qf6r185BLdd/21yNKchlWA1yM25uHkJxFjUkkIH2dISZzfVdCjiv8FLmQ1zCqyUBU8yfx
Zal2NE7hNTyICZZdioLcQb03jIPXgEpEF5sDewwk6lwBCxigj5N9Kk6U4WVZQGfhGQzJ7KLsrrPs
aj107CbeQRPsmSbxpjyanGdpzx2oaLOnQfNGyBdRXhNW+qoZIAbwnaNvey7rroViOEBSwJk18UeH
A2LLTP6pyPO9RfCyqlwHhln9iE/gB0st75ulfYCVzc2CdjNREBciT8vlSn5zMky2vK/kC5a0H1SF
tlswJ1vDNmfffFXCXsOwmW+yQ652287NQ8Q/pFoj5uO23yKkFwB24ZwL5zH1AJ1T5dsBID0EnwqJ
rO62HsLGwXk0X2lCbUNG/s24xyajyTT1leIgbZwDb482jfgGSmv6rPqIAhpohKB2gJ8EibaoiliH
nO9o0ZbznfucXMx1BAkXNQdVtJUwN7LIpYtDDJo3ukpNZ23CRWMfocfHcMMhNsOyEG6qd14MwKxr
4bbe++a0YrOc3an/804ImnECJ5iHN4agRN5L5o4qMD0iVVn29kMxe257UxcguCT6uNbNjJWt6y6K
7lNXc93U7/lGowMfBc/jryl4m0nhZklhKYbw4XMWLdJKXGJQ6Pc13I8xPcpteVIxhpx8ztWyzotv
ZJ+BWzdOr4NzkYoduRrEYw4Z8k/S7B8s3vXxq0f/4g9IwyC9lWX5KOhzh/KDt/SUmjKWtcr3weNa
vwh16jfrdqAagDBsE+5nrAyJjloDp2qBJavRJNKshwzoSXZ3VzKS5zvRcbNJur68GpcttbSR9dle
A+Md5dObU2RWv9XS3aAlVm5Akx1+cA2/wHcoQcIlPSZCSck5Eo1vbKAxpA8oiqEx0lAZzOZ2iu3Q
459IE1Yx7HotsVhC2mgvqHhPgo4aoyz/HwjaNmf2WBSj/BbcGK6kBGpBjcZ1QHrpzjgb5s16MteL
G7iQNQfZqtUqwZA6p+1oF8fXuOzejIjmsBnRdZomjR26f8HAlFHNP9+Fv5M0KSFjyka3qc07IDyZ
oZRNZt1URW+feqM4LawNhFue88o5G6kcTDKkPupnnm2RC5Q7OP8v5Y6ptONArDfR+WybOwWOi7SZ
TYTb21BYbDKG5rVpSf0ypURrd27oaeIZUUTpIxr0RFckm5RKGPQ+eL1lX2zytKg3/9Q3i+0kQH+Q
IogrqUIDfLJtaVQhAp6Xm6huK0yroEZSt+4mBkX+o3CtVy+VKle5OakdfIhPaCAeSumD+7nowb34
nLMe/UQLESKouuMP5zvTthLqDSwtCb/gCPc+MlaxO9K0BfVyMvGSQ2yQQjni6mkx/zB9GdXqFiAj
14phnFh43mjtNrGfcHeVZNegzDZyMrdKTT/bKHVCe8WmLtLNwOO6WujaV4+eUy9GQAqVHxZPxeRQ
tihcInjoMvI6alXSbDUnhhk8VqnM20LDbmgLvViCYXPcb24A6Z1stwkS4U13qeVAsDEbLQdWHJpX
zcGiQiUCw0nY6YCt361fhc4n2OSwjVVoFWeHuLRYms3WeaBzs+DXmfUzsASe55heGgugXsLlVCq0
8sTTpHQHjOkNViL4rSEu5vPDRt7WqgzHUopj+VsGi9jY1ldiNAF90+0dP4QeyygDn15F3Ju1CN+u
BwlAyAp/jmCBJB/Rr/khcVY6Y540nZPA93xWhv52E2rX7YSgJboVuQ99p9YuG+71svNDEaSA+pmb
1LEBdCwhS44A8IXaD86L0XfXc8ygiKidPOUZv9L2B8KeQkUy9ysM5iY/TEj8ONPnWTLF3JeOVjvE
07IzYFpWy6+znZ2hqdC9/ZYM+VxE3ESrikfeUmqEwSmaoDmjw4pxvOEeMmzft8k3JfrAhjwCc7EG
Xac6B5cj+mcwkorspGZIe1mq2kHfTcUktjCKYFU9B/tsArIsf7Mj4LhHyaPpsacMvApG7qeolcbq
LumnA3kzIeZW/Im0bUo6G6n3g2xSXwSqUuj4FsguKHFeWy4SCilOFaz1bVawZLR39DE6rPkt8Mt9
HIz1wq+FoFa2T+E5CBJtnJdzf6+fKVgaV+4nhlTQ/5dQdxIyBvpLeQ87rDTOqt4mPhrv7G9LGVPR
O5NBP1VybOXpS9eATI8LixvsAOjL4kuVgdCBqANWgl3yVKZPIkxsnGJcPbDrTRFplsBBK23T1oJF
Fv9gt2gY5aHli/zigwfezbDDQkk79rix9Aalb83Is0ougFjdAUTXM3hJ7IPXo90Ym9AaKJJQdPK9
i7uHS3RcOCNHEDzDeryikjdKW/wA75c5LFsWfPQRelK391ERgihpxZNbf4Flz/DxxbYgoMZQLvEM
OpFqAYH8V2jULYwX/hiElmnn3RduuAx6pPRc2F+7vGbYphJfCaVE5GJW7dOjNAgSNJ0/NvzALkbo
tRLLbTs1HTkmRZtm02VgL8JaNncHcz/fzAgw9923wg8dE+wkv0AItUAk22busIbyVieP9G3Inffp
lUCc/h5msziSogsDL5uhLi+JCjQOq9t3whP2iexeFB1zThlmJovRMu6I736byroUnTETz7CleS9j
VRmMidvDKQo0UCwVuhKQ6pbKyQNUrFIoknT1X6DabcimVuFS5prFXz2R7U+w8wpm60f715HNBTu6
I7ldYqwqGNXW56tmZOxCKQP9aJ8Hwj52NE6ad/uVuQdaguB1XO0hm3vsxC4aOri9tCnSSjiJwE/y
0XJUO7ESbtzRUUYWql3+z/FXMsrtEf5R7mIrxHEOcCjlxiITv2rxIfvPjX/uCSIgUPWBu1o/Vr5U
0+Tp5UWb1jFepb/YebMTAVTwhqfcFkzo8f32MsMgpzeup8Hcou2DSp1kQbo46coHjPVqeP13N6J0
UnmnOwb50beZLJ1MHWALuYBgv3V1sYwFj7Xm4M9KKMT2HR/jIsOlaXhOk4OBFWjtpcnwqMgs6OI4
meWMeAa7nYCIXRNeCUsRHClhLb1OlAm04dTJGovRiYLOwXdy80TcAw2o+jxKytSfCYzc2UJt9ksU
JlGYuBIA06Ayn/ZZe4Gg10UlSfz6K3RoHu0InMatvlqQ9R91saGz9uuShQq9G9Ce5WlqaNAsnM5n
VwSRuXHeM+byc1d/br+UuNhl6YOAfNVCWtUshfhmXEUb3fhVkovlSqEx4xvfaNnuKpVpazvyUl1U
0rS2D0xV3AJrsOftIiD4zsAMQgrJUHyue2ES5ZYisYhexUHYgQo6BEWECBrZ8Sb84DcGKipgAAmT
Y5zJgHJDM28A33St6jf522zCUbKbJ3ppN79GDhmKEwjq+9nyBADXtrm7Wmbm3MVMKQOxZ1efJQmh
78knUC32mFATdqXDQkeM64HjWIBQgfSHqnRENfCZn0S4Nj6IgMgiwS2zsbX9tulxh5HB+qi6kTmB
Lzo+whUc13BFSqPBfeoFcyPaVIGizSU+VX7/S6zgesxchTKHuwdC91i81FJTj6muKbbs8PgRwgpQ
qjFiUfBVx80KrjGP7z51x6e7sZ2x1NzeDMaIsv6o3lBthDH/40SCIEITImtC3J7imAlYiYk9CMvl
Gz10qlclPK2E66OZ1GwfQ3ZojH/hewjuQ8jJ5TJKiTBiNRjbF0BDLuriLLpULyWb9walKBIn9dij
97UpQ3pD/UmDXrHbkw7n57q8AbE4e0DgPLAuONAOAEBMwMIo/Zc26yAZhVX4aTzj2glx7s6wGHSm
6OwF3dNd4MKFpi25hqn0usNP0f8/KqVQ5OEPeKlODBFamFV1l03TEyWF5WjLifU0GtfpeNN9Gac6
HxeM1ZH/bbktN9x/tIkUP97+yLWAYbFCAI/s+XCs2P7FzjUcPSJp43O+mAvEPLGO17C4nLgETqN4
uTvk0yueLbYvHudhg8rayJ2pqHNUfdsc7wxMJllihV7JM0eVlbRGR4LHLPlkYDtiG3DMVpEkPzhV
v9GIRDBm0shsVcl/EQkQqw27PJfC6tmDgiQ2nc0pnFWGETaRhf1YuAqzA/vAOIn3GAKDsdPixWLM
uVVYXGcMPuF/EHyb1sUiJxZjqlwOkEI8cyhEDcu02Iiu6NKcDtReenkuue5bWwdzZU9R3tktR/7l
UOk3XTYL2+jezo4uHgCTX6JypulykqyUaam6HFF4umYwvQiWIlxJJGE+c+glWxCzxJgKsdm6LoJ9
KDiH0cyvUNGPEMs8LlupXZISSCx6ZR3OEooCEyFMy9XP6dDjQYqRtl8f4Thymi/03Fjfbq2knYMJ
K2aHMBIsfaZ8BLrhaMvG6TjFzG17q2RFC0+HtbgdDTBc7xb4EiAs8g6JvjbLTwdDKQclWoMAlJ+N
kBphllZ1iRFj0P9aJ+EhJ1yvC5VFNOX9eK3os6ByfyfAi1bQtj8zv4WpFDqL/SM93YJTdOsp4Rib
m3bpzIYaey7etdyT8fAe2uFlq4RHbVrZWK0p0dktRIxhbK8hhitL7HcDvbQeyiaVcsMIcge/UPZ1
+s2SqO23o5vnNdcwGH/3Tw8cCMI9pbb3a0VhnTPWoK7ccDB15d7Z1AaRYR2+OA2COtw7WXLo47/R
8v9bZOwVnN2cFzWusnnMIbVAJlJsQ5BC5gngW7Kxl27g3Xi0oa8BbUUMJjNFbekKpmUaBGK8S+/a
MI1ZzYzGEb9xYB2/JPgg1PhyjhERqfTvxf/oMaAxXqNcL7IBGiGceK1pUpFi5Tj8ahmlCzedJwIY
T27j0/q6Q50fV2kDROgTNbsNqTt+jS6xL1wsn1CspSBgamqcTf+fRWKpT4XVHQP1FoKkwAB2TERa
Cq3vvNgl59u6wff00oLEVzSiiVsuaLCXYF80ocFsft8ip//8Vw/CT30+mGey0OBMKe82tttVMv+S
jjP5IrDkX47eIQeGI4p2Fzhg2FLAdrJha/g3/eSFF/s9ef0QgpnhSAhGxron0QIrBMZMXCqTVwke
8HJKWms8iGvXHukB5uazijg8LEU0vyH7j4kLmepMB7DHYArESayIYSGZIy2QmHUV7jHI8R0HoMds
koTj/izJTnq/3JPvrwgliFUs116CKKIjqR+PVnV52bsgG9flYUBAqmDVPTFBwmfQYJ6tqgjA1H6O
wko386NSUowVQryeGSdde1/Pua0a5O6spmDkmRMfxaae7PrBhLBS1mkb2t4HFquIIN7Zm6zCNc/j
6bIJaN8pX6Rt77eWu/911x66hDDT29fJeoyEg0GP8+IhiL8Io2KcAl5X00MwzEWEGHn/CyPJ6RUK
uSW0ZNSNq+U+YXNr2a/BlBYNGvFu9wXRDFfgMQPb/KbE3WKGCIFvS8NH6eXHMWdqZMm07qq3Lbm/
NlTWQoD0IdhkJC/kOMaEr8qzeNzi8ZUwl5Sn2Ygb0QKybLq9QajILpTMNAnGT1/lWw8ghCrpbbqY
NzNQQau7J2oniMS2QF+0XZ2IeI1QCm1aMEfQzZZcPllh6jKipwN0QE6JOr5IWqJ9Uw9l3R+ZSx9I
HflkVFqIUClvPLn9mxgC3833LeDxNEz/ls8RZcDA9GGcohYQIsajqNo1aRfjDccvg/SkhOCdTuri
pO5TJ98vXBsVbxwATUV7jRl+9Iz+7y5CBIsbAoIi1/V07yMtSBP3SFiIGVZcPaQl1AZBAUyxQi3Q
PjgqoXKJ0hy3RaBaNTq6LYaSeE7wNFJyhcm8blquWyFhvYsR6HI7ETe0Oe7S6asW103cEe4cPcic
wH7eSMrjK3O8MBue2FF1JbogRJCzxYAPM6XoVkQx6g0q+f4vgx8ruURj4pCx26QQVdLLlnn5/sPe
X4vgP8EtRQgTxc1jq75XBZr8nE2aR6V6xkOQA3vE1XHhILO4xIYXZg1muanY6u6VjcMFCnXfu7sY
Xz+ZMOp4L1+349AvKGOP2hWqTV8oz+Nv60+4JN1q1MDHdchFcAcSktUb/hUSyhr/1dpu/pzCIZia
QOCOfllW7itROOWgnM2Pb/CklHJbKA+YlLUlSKC9h29E6/WQ0EokDfIRkyesh+4w/pOCaUo+ifQ7
iiMop08KbsUEZsluiiMW09XntCXuuu7q/RJT3npJbIBiV0GtsfffRo9/qN19SH5JzTFzFZBZUvjn
1KpUNiSahkEv0M2D+5Ga3eqos2KIi9RNJF6BXHhNgbu3xtWpb6ORdvnKgxWq/wYzZbyXwqOv1y66
tiCtjVvsGDaMDNfJ7VUjlhlzPA/epduTOfnHZYQwjL7hsn75rIcwNuAn4M6avEFY5T5nSh5RsHEW
QEEIJ1BWfIJyVn/ZVJblejo5BfZpJnBzusPyoiYLYRjIC2nJqZSNSAlyvk7nux0bYGJbwPkUk3Dk
toZy5X7gWejLYoPOp2XUCFjTxBvNl029ZTs+Hz3/fXHJ8PifWZ+U6d5++oRwiRKgZU3K9dmDVyKV
pTv9rpVcqpIBsfyfeL/2WltLgOEUCY7+S11UkTvmaUPxDQVZXbMzKHiJ4R2s1wTrcbHmjv+/sKSr
q1h0wi8fhbIJZfLmwCIq0ukZyN1fXFPbDrrT0kRKVtSFTruvaFpgmYKlyc1bOzfSWPgVibGt4wV4
I55AHdDqgIqM6+jquuFDj5IXHsFrBYqPA5V4PDlIrrKs0f9BAe6TZObkB++qZ7uerFzSq1+wQY6K
IBHqxnUQ/jMstMO9q5JQbVHIyo5fZ7l8ZXUmr/x6BA8wFOunR4tHE5JaqOF4C+a10GigftCeTAJ7
MNJW276SiYr7p0nGwTnEK8fcRPm+0zng9bR6b/uk18tehktGkVVrc6tsuLT0eTy/Ilufc7GwDwOf
wVOOQrPdNrI7BPNAaA/tpnnk1hEnmEESVV5WXl5QOKjtHVQ6mblzye2+w4yaNRh84OmcEfm6/6Jv
XFmK/AakC0WnN4uTfHxwtK4fhrtxLnOTqPxfMjFXag8V35i27zS5JX5deHVL1SyXfaReIHspTXVo
8MkI08Tcvq8gZouL5CUCX1U1h1zkf6KC0QVKPkWEXlOSKlBYVHfIQ2CW+Lvh3gxLeVdZUX4ZmCd+
dAtF1IdR7jvk2Z9VGFkx4qh8s1zmkrMVgleEoA/UmVSIVfXCt0huHUI1extGc/o4kOub6IS8wspX
rLb7/wzoS896vlEOyn664vajMynbNaL1mrx/nKEz3rlTYRdBG9fZTGOtJXdvh1DFxiF6+xvKaF6B
ZQFPM0GFFoDXN6pi4UUfceLIQXBXAaJqrjCYExN/zo6kKGSD6mNAwEzh5kZom6h2sJg+6kwoacY5
vvDF888FLIoInaR7LQBD2V0OiLoh+q0dXi5qIL6MhofVyll+rylZ9GVZg6KeWPMtpHCjf6ZIeJ7e
ZIwsCB8HGnmHwHV6oNfSiuGMZVqnImO9iaa4hSDUnRn/PyYDnOTIiCPOJPy8dGyZ7c1yK/KB487H
XDkFTObrDUFoNS7Qs5G4MPlftVuHAr8X7xpqTUmEwn8tqRoqapUgu98UgM1lubmqmY7zF9A8kAKM
w6P/KZwY4dYQoqqRqKAOsHFNE4fyh6i40jCJlTakC91f/eSsjQ9/hLfqrStZOpZbO8kabWicWEIX
6hAcEvIWtkWmI5W1EiP7i3gq9X7YG9jDkAtL0HVXlT9DH5XePrVexWQk0KLHW18neoq4v3lzTtfS
w/K31DIUhyWyIFZEM1XhFgsg8Lzgjk3Fb3nMJVLjfP6dsZDZgfehx9dYJzLQteqG24Oi1tP9/rAv
DXpfLMrnp0PCq2I5XK+4D6ABoWG4U629pqkT+mSiJrdwFA0sjxyK8gWRLqrJizyX/CrQ98oRS7h9
zOYPmop9aoeatD/ag70XSpB/O6tCrzzMibYLhAhAbR+dJkab8tI1R0M2Q5GCAk6IhD3OXJafr9v3
vozVEwtgPp7wCO+1vfHNdXIp/7DPvmmmB6MaBK8Nf5MgaBi/TvnW1byLd86Df31gGz2t0u15HGb+
SFeZAOyz2q1Os0taBgskX6Oh8sHqg6WEhzTIN3C2XC9DSikSF51Tig7kbJyGx0wgwJLFfgpT5tCa
SnOUIUirhfkEDwEkcXm46sSxZC+tiZeDmFvPMXk3SBDZr59EVye2P1NeiH1XUXbFaZE4C1mfI34W
IrQKw3NupCvMUMXYpaxKFP7bMca/qoQ2zt8tKERWlqmAQupB9gWf7LPHzK1AWXzjuQNsDgkHxJzc
6bHt0zJfoWymkY+ugiq9fAuRl2XTfYyH5U2jo3yt03jUWXEugDAlaemFy1a/J1zVbz4n18HPYwaD
r4JZ5G03BEY2fgNVj+KNfzkOewGSU+trg2rw6Fmw1DNV0GiVM5iTsoTJDnSAsC8IZqYhB8FiLc/w
HvtXnlEkgLcTxn8dZ4N7Jj9ejZh3X/Jb7aOmvflFlphrSk27WdseckdU+Sr69l9BQ7b0Z9KTP+uW
9Qnnn6EvQ4CGPx5QP6jRyMYvgozKkJ/1Jc3ZK3/RrDJM/Ccu7nFDNA4MEfbj0s7qIGXfO9GZbxRH
HiQZgy4lshs8cC3IdBaTb/Hm+jL54Zy+3o2rtoCQlfCKbKjniZYefmkXRn+uJt3MLsLwtVwH4Hor
n4mgCfmNCAvhgm6h9MfIn6aoqHb6kkaGZvTTtf4irfYV9X62ok7cRm+vvwA4HmoVDHyJ9l69ZoLa
dtJVBRSg0La+GAC8A1AZL7M1GYe2C2iBxL6Qu9P1J8ZMYH4VrsxqDLfO0oEuQqYR1dS+qJD/R6T4
dXCFP2KCcoaxmtes+oYEKuJvtxNByyko3iu0uyQJ2VFYr9vUZYcpvFlxvbWwfC4wb5CRPbfUlIqV
DUf51vN5M7fwSUZYqadSFDf0VWHCSe73i56L/A+Tn6RFGEiLQBUF3vyDXUjK9Ot4IwhVpzF1ftdb
BzCLFxCIy9AmEy0HF4LGTEP+7t4hcm+SMCvQ0QJbW/1RQHbAFBJseIyFpdrRP8RioXI9neAvM6Es
oZ1DxabKy6J0SCQef8bR7KeTi5qVB0zn2+oj7j4ZRMdDf+r2j1zkPwQLxDFFL+z6AlTbIQCTKdwV
4iDIPKzRzfCG3J7T5FCjrtXaAbtTEsYcoumGI8uWhmNw7DHlTkZ/A3649v1EO5gfaiiaWg20Aosh
0ygMwnZTrXOF6gSQQJ8dsrS89IyeXuZlMTdakS8CWRisUzuWzvUJ0GNX5eWO7jNH3SPI+dFIDeyN
W6R1T3oDINVp5LaUdmLWk+mm72I/QinRtvtivtO1iK5zYlvp8qwjeSM9FfCN4oAAEG+csjY3VoPN
U3jCwtt8TJAPo7jNHkIba/dIOIfekODESnTdW2i8FX2mrV/OGGLdycDSIxTlWcEA011thF3WA1vp
QUDvtTVETQOb+/CE2bYKrSwN+FgDWpY4VKgGFMpuVQpGplE+uNEJ5edVQtdzwV7kVYEbehjw4kYY
HMkouolQt1JEjXJ/nPrISZfCO1s7+TOeAYhFGYWGCIALcI1qlabLnpuzwt/+QsDs4M/SOuukdRmE
c6NIK7jy0vKHYb3B/Cx3uP/e0y9dGkLq4TfIpcaoRT8R4Dj5oFonMtiZD1cdejWNKPb7drG6gyUK
Tz3vFQV9IxDKzOJpadGXgWpOhmOd7oxawQ1yeV1sk0/3Zh1zK5nosHmmbREpNAUP4MI0lJ634Aum
BSRBR38AQBzp0+gB3YfA2QhfSlhmkQgMos59rUbOmRL0dXFbrPiRCLPBU9UPh8m5Anv+rqrsnMjb
OQjG/pSarfUUJ9LtQIYgR1tt8MVCWeX+sB9dpIoF/ByPG1BQfrbn+Z85l57RRxl643uor52mvljo
bOpAu0UXtQDtGNgJVIoArHNfNwh5AB83Ov/Gj0omNwLqjrdUla3OgVORwyL25dCPvTQJWxpgCPy7
GpfXcRPInPRTYJmjIf0BJOBeFiF/PVIq+xUYbsQhNOovIV/2Ezd7b4rKOGtcAs8nm3dG87B/xFcD
+Jv7HyF4+4mEUctLho8C3WAa6yibk7ndCMP/+ROOBkpYAXjmIV4I9FNs0MQACTvVgjmnCLoxaKI9
bfyWuFbjE4TWTiQYBlELDHv++Uxh1y8if3b50Ore729xhcAo1iUZeKQDcmoTynsDzY/9LhADufDx
FgGI9OKyEmGrsIMEQ5+tF3Sxdc5OTQ4XmnDtyDmQslF5MkFwQtuUakJFmJFAldwv5YZHb3rW39Q+
6lVRyO0JW905b5jUa5cJdwa9Qohp9IRHv88OkKsW2MhDDxJuAZGjK7jPboYpq57wWI7YtO+r8VMe
lGldjSQAKnaQRmfXE7QsqY5pYbJImxWSa5ywhWiULzIKDobXXYgjJDtLYrZW8bxxUoczJAG+kqYV
E/XHgjAs0/jnTD94yY9E+axuBlmTlLYnKSr1c+EHJbI7Wxo0O3DEBRAi0GdWxK7uK899bQFvNbji
gLqKllOdMzAZZx0Le+XqxMspdN+pMxsySpEZfpgWikMzxIixcqnk+caFEkxKMMTGHWsg/qsiz6qD
n8NtwjLzpF6f6AfjzNGub2Mi9EfimzlASRTZst5px+kOHFO/z7G6aOpjzTOfa+1JgJtm7XnPk6Tk
aQ9sbBWAF7Hr0PjXPO6EBVQ0oRqVAmxGJiik13ZTtPo4bkupprXE7mJgz4UPnckP1hshVPVzRQB1
HA4JqN01+l5aornPowYMsFhhuX/KWajdLCNLcxJPkT4lyZsCfCBCsiOT0zAbhmarZYAvgLVog+A7
mjrn+7rIj6NfWLtgdD3lG7sMP0UtiWXw9jrs8inAq/wGgGIcXYqbzi3OJCV1r0ZahwhQz97xNAVy
BUDYRr//D+wUuRdZz+V4ly0FHOZExPcgYWkCG2x5PMcwfpB1bYHAbI8Vs4cqwANlgXogm77xu4I+
qjdBOB43cbRJf/eIBx0Q+Bwe2aDD09yfA3fnJVWQ6L3wlWJMpsg/nWcN/Kd6oaJj/UVRacksb9lW
kY/AlArTlwNxR+3PjEk+9OwQhoZ1d0v0UbrnS8YoePGceXvA4mDYvkN6tgwhouiONq72q8w6dZx8
q7jJIIoDLN76DwFJ0B7KhZd8Q0wQ+GF6WnqSk4H9D33x4Ig2dGs2GSCIYJgH3VZP78WoTfje4bqk
1MlbQ9fhy/UXmw+qet7nlI9vnsHgpcB8a4OlPyPrIPHEHD5C4QV40zokYeDfScSSPjNH6cp90IBD
LSHX3B15+jRvrOLrp6fSo12cLn658BW4VPq54ax2ywqmv3yvkYJElKu383h9lOteCzAeyY3sUJLp
M6FkjedmmhmBO6jk3035oQU800oiaA3MCHrMq/UrDTDjG90NJLgs25lirfVP790Y7UNnAGt2BL9X
uVKodZCVotFgxDJ7kCSdzemDxERLJMmpoAYPV0LRwMOIrzGp+TbqV7FLmBjzg0+UvqtZ0sGvXMCH
rZGN0mqKKyIvHJwOy3f0qs6G9ZPF2rrRS/GwA9rzYZrPHw6NDjoKegg/dCKqUpph7C9pYfqMg0zp
OfpA/RIgFoifDaJ0D/E6V5Ttpmrq4pScNrUjU8FKA/1qzLCLGrYBvGovo1LQWdVZNje9vN9AQzev
kzubDfpB611s7ijxbcupb6VxDJ+95n1WZ6Hl9EGHOQsrBg4YklfkQK9VWU9V5zboa3LpE+kjiRbQ
m8i0pVL7t+covxlMwHsK3XWJutjfkBvTsKyN+OyKZWIy3RwUW6wH4yKSWWmfVYNc0piASXyrhwq7
Mi0yM7ExGYNS++JpWZaz6QXI7vjAz7K7k/0XxZaajJ6LtUALR2d/1wBO/eEB4Q3oPzrELRzGiwrj
a14flnrY2cROK/rP7cAb9+UBfgjzCHBTy3LFn+n/SpqWogHrfbJnLF+WRjB9s23EGQ0uWrnaho3H
U7sXd89G4Bb6/IACHLvV+uJWp+ucrMR/m8PRwkdDAP7TayhQA3WWimgO2CYXvsJQPwDIjjW4JoaT
TLUqhjlvjzGTu2p6nTDWKed0clSsEQ1CbKUxEktlaun91MIRzc+mbaNClhOOLycMMq3svBSlE98H
yFRvHzsma0B9EkVz+xH/eunHtEswRzxgt4TtZDNGtwjcTkqiWiNecyvoSqC3kw9pDM5ob69NSdSA
BbjaEns2KHGcjxt+ZuYyfC4q8+RdaWV6Yp41mP3dvMqsWHR2ZOLU/JBfMrluc5zcVpNGNycMZYB3
grkjDSFp+8oIkVVimaOj0sNf6hflFEarMmbJdSlyHLeMJovqsQnohuLV+ADwbhMS2R/YG9r+HZVB
3vCPLjoWpuWSZisNNcCOLSUYw6ckc0IFhkEXRTIBvCHOZjYL4QyF3eBMKTvZwlTMTK0C9D66cbx8
6Co0E0hPRJk03CF4c2UJiirUm4bfYx+7yZp3VDWwAXB69tGgarr0DKv8a8TQS9o6HLSotRyppaTA
3NOI1ryXzhs70+IPOVV7G11RR6nnI7vAOC25DrEjElwwsPOxSvzrseOoNtCrLZrdPaVL0DONMprv
YfBN8HBHYJjH6iLdBtFnoJvjLEVy0u1UryqKu6R2K1d7XlQ+F3X134vSvtXgpOHF6yCZq57PDo4h
JUOjnarPIiAHwJl+tk+BxgFOIK9ZuE7cyUDBmU4fIR8e6Ij5GApRnvNgtg4hzZezz91xHjUZNPgW
Wv6DFObAriZI/JDmiHUUwLoxSEpS7kfHEBRpkFj3gx5nN+7J7PePyimDciPNpbLC4K8+4AwPuykg
f176QMvQ+3Rk0i0KlQcCrye189b0VPiE2eeZgYDl6zdiCUkeXXywgtIQfcU0N83Ls+qLlWjfEQow
/p3Wf9FAObgpGgfY2x9W5CqvDm6SSBdrPbHedst/a6Ixk0STo3xcWwBt5Ak5hI+XXJi51BXiR56o
xXpUw1WgZ7NkSL+u349iaCAHiJAt4t9GF0NLyavMK4d/Cyetp3w5mXcCBd9U3XfvgJXbE7p44cZk
EeDkwKT6knEIOrPDQWEr9Mn1Cw5eAqQF/RLZcJhK69rkGOCahWKdjDsJrjrKE3U8iv4qGCdFoFzs
5TAGRKpAvd/Hq4fcFk5U4uy03fjNRqLjd9oSqRo9+b/EGX7Fj6W5igmNrRloR0YKeokdOp7oWC0/
OsYlZg+fZsP1vDyBu66SX+uuLLmPHg67KJVgkFaAPWetpiR7tmBE8gYiyn9mI70DpGZ6/wXwgMvQ
ICw7hLyUZtBJ/P6mwmGqRCjjOUcnjVJzmfr4JCpCXG4vqW6zS88vwTu3iR4X1+CTAQtmgkzde6lt
QOmp8HunlBjc2sYSF2YOeIF7qinHE/JK9h8VQ3D4HCCR/go04BNkCH1dC+nLj55iwx3fAKnuvw8Y
dWAVNJezkpLk+sfY00kcvUkMFvUXmm7WvDoHXpZTiMHfH/x2hL/jIZYQBYsN8oBdnpFK15oe1Iox
TQ+VEnmU2Blk6LqWhH3dwqnvqU6deUZ10R+UroYxjcfAT0ycKR/BqeUqYSqm8U7xvCaf5TqMzNrV
R5VU7n0VOrdRTWzn8unpN7KB8DOkssH9PM3g5ZsXW8IyaE/Vp4Hit7vMPOdgsxj7puj0ETuEJ2MW
EhwXFYX0cqANIwEi8xj2QXJljSIIxvb9sAhGHOl/w8IZJvi5URF52W/cxHLg0kb750KNFMMXbsuO
9zNzKc4iNIooVqxbmJIggUmwWiVbhUsWsvZ7eVdHspIAl5H9EHCBfqc3YL6cxhzqxPRw60+T/Xh+
dABuZo9lpwdRGbS0LYbjURpSUIIam2msha52Ls5S7mmXCl5iJqV8VW3onqkF1i94WefhVdqWtV0c
8QxOMzfhT/ygnUDJdrpAaZAykJnsBgw2ZB5iWCEhoyyAr6pVJKLhwj0wRarHOM2Gvi29pSzcpne6
aRsuWIk0wWUGamtFnFwDpWsE0801e2eRiPxBjMrhQweWMS83HqyjMrKU4rInOVJcTVfUp4dtUpST
J5mK8pOpcIEuo3BhgYiC/R8f1xNM4hjPOLNPXr8tfJNcD9NAdG5UPqvS65oqwwYpZrDU2k88Hs0b
PlvxzdybYWG8vjHaabbdAd7kepDNO7YJzBzCQ4KHSNCkKwcfv8uFdrW/YjBOy0spjXcfRbOh/tt2
KgYYRjF1UPSQysepRTdaxSKYNmcCTZBVhGpmwVWlSNKMyO6MJ7qUODfmDE/r+w4uNayzRotKk6ls
DvUdoRBT6oOkaLPkLIevpSnavKOXHnSQ1nDxuIozzR1SXVBE8Ey+vfg19ONdLQBrV7QQRK6vCUaW
HqsQd1v9iXsMWcGz+yVT65a3f/yDaPIT7oYCC6V66giRGaSRpyI9/gNZMHuCtmXkhv2uh4RTiwB4
xX3MG95xpcMX9f6rJitMdvy2i6ZhSRPxGPE7m6QTkCTUX6MjCbTXpJmbEfncbHuemSTdCrLyptZ4
F8VJjQLFaju2EtLKoYQkO/qSlpPH8bwY2gIOnbMab2DPV4ynnl+GKyCIiZhDHrZY7MhWm1JvwCp3
VNHzAS9JaJ7niTrL+rrtJAg6l5/3R2WTtckj4UzZkQK1uXAABca32kCp4dLAuAmtRbAD0n8WwZGI
A55ocgwzl8foYAHyohmAYlbhZ0pH71njVA30wPTkgXDFJfKEIK5P29pc5DC3r5QmbItYS/ldalMM
aUzgT+GMjVujC7v7y6jPusSlYgonB8vsc+eHBSxRkqBGX/rjNJF9mY4IxDPkq/CELO7REKMgr5SR
ol6HyCgXbrpelKgpsqY5HQvHCY3KcupDICKQCb1rWbAVtHLIeSR7IUdARD6fMzwqhMKZo4PkIUqz
lrKQnOiHeabcra8TTOoiiRLQjTtwayrocg00JOkuF7arY1nokUlPjofqdWMr3ecaHpAqOZ8y1BmA
8uYgYE62scgjQQELTmhKxVlrscq7+8i1ruJXFdhMksctyBadxbzWzrmuOLqtWTDOwVbAX6VhHJ72
VDqi0Zl+tRiKm/A0Vf8YECEMboK3ws6E5S4g6GNhlVsI5QRSIiRAlNFzpoDUJs/doWN2Q0IiUX1I
B5trgqNSfKvn7cmAHRXZS0MkYRvQOw2u8P2v/esr82FBtYlRG7UoV2rjUIiLrndResD1J9RUU/DR
OSa9uT3MoF9pbXbXe6vxmGqgpIe1MU2Bkg3WySEvOaNicAcySX3emMU9GUfQt+MuR2ivRhuTCvTt
to6kkPYqCnzQ9V0LRfICx0VTLZYDYVb6Y93Z1A4nCt/xHullH3pg1C4m/29cVpybCxz9o2AVyFp/
wSpK/UJL8thZJFlZ75YZuR7N+2mUV5+dRIBCphASzGMmEOKb7eI273leGaI16HqLdCeK2Nny2h1b
5zo5T7gHHmIAeCCEcRfeKtJkTZ9Lod925PMdeRU+Di7vDlFDP4mCeQvxK42ZUoLJJLTaX+kGptn4
0+BetR1DkeSxupvoFGJZN7bCiK2jucFnuOkJ30CzSmvsy+JTPiGxHnUyVdW2qYCIkISIIRbtG9ST
vGjILElSxnPMT/MtaH5OkF0+GkbovWLGVomJMB0GD4wu00pPFo5HZ9S5DuVFbRepLha2d2enSVeH
tqQ9X+AaM7i08gGVUSrEEctEVqeHVDNECns1QxxTS1HMfM65MGNuQpKI9Ut0QoVt3iS/dyLA//J5
FrY1F/3g3c8sJyz/KnYIY96hZTiqCbjW1Julbhn3ZP78i2prCD0JQaTkbY6J7DIVPMtmCczr7TvR
HpAuEJchgNla8a3W2t6eVaNQG5Wg0pTZ04V+QOCHpI8b+PzQJ50QDE2ktRzQ6yHSVznvxkV22b6p
GF27ohZhdtM9HvzTrk8/XRq825Jq5bf8IATUL183kfA6WAY4QAa5oz1RdvUKxwJOnA3gBLryZnZw
7gj0/Hh1d9O9ewqWzm25gTg5Nn4R3Bv1bv+5Kg80+/JgiXh2be0qcbOo5kq/mbfzwD6jXsZJNNC8
fJs2TVK0/j80Be11g70QDbOESBx+i+TaK5S6LgICZVx4j6vc08l5TUpKhhBDGIn527Bjok2dtfUM
K12R9DrUHtFQU6aAr75hsbxrsaGU2or7rClXExPv0mC1twkcyhksuTFc6+b95HfoJKsd6BKzGbct
zASa6ElvT14VfIootyVUKMecGPw4LeXiSCOC90Ob1icE8jRtiuxxJlO5bXNTLdEUOwudbYEKf6rg
qs9rlK7ntnwVxnWyAQlUKw/LpZCuWRGrdaD5EEjp7o6YSw2wuIOqnTBwVmaxcQ8IkNQr0X1EYcBV
NgDjOlfh4/y0PSC/UZQZfmOvHmuyLIPzDmsyPKFUkteG0ZuZOJmeiZzTTZcJY2+q91FqtabtLosz
QACjM9Yr8x7gApcPV/pYipYXXkrU7OeFfjsL4TIRFUFKv1NiZ/eQcJad1F1cHIe9mdKFtRv9fBH9
BCQh4qhY5PLxY4yy7YCVxNGd1OZrvYL/yw7ueGmvIJJl/4ottxKqFTnUfKirrQ8vI6qwkMOdwgKr
eEn9j0sVoC0PYdw8xvBG2FejepYUV9HRhcP8Xe6Lsi+ihhMHPyVHhMUN60FyVQl75jtADytDyv1A
bC3UI1DFXTqHoJnqt8rgQWT9LvjwnGOlgS9QSyYCTI2rRUzjqZpLTleqco/fslXTlKXH+cqukyci
1TGDoDS3FEHJbIxBSONCu6IxVPh8JOYLBDMbrMcPdtTB7CvUkX02kpxip/yFpq7wYOmdyCw7FrF5
flFibPwRTwnrZGHDN8YoNIL0IapxFGlmNgmbq1lty/vEBNvDX0WLYAYC1B3bYg/exhKZpc2mmNqj
H1HDhi7H5KIQq5KHNUwXrxuOCoqnG3liooVb17Fi5YT9PgI7IMZ45hj3orjM7CO6cpAHVR37D+68
BeYN4fJ/ST2mTRp6H5Gw7WeuST5kBTifZLPFYls0FVfvbsYcdDbUk9lg7n45yPz64KutWIZTh1Ub
5wu9s3YqslGKd68lB9QLQSgjNvmHy5Kim2s1JBOmOMDFQ/PcmoyvK73eUSNSEbfYUSr68dUczPAH
FmGe6vpDPKwJKoZKpEb2LPiespEnezPpldV4ChmuaKcKMO0YWLAAEK8Ydlo1TmR5SPRqklzYApgv
6cQQQZj6VZVfkWE1LtmPrOwbkS5XWsRPmgU3o5qyPq2ZNlqJFC40ImoZYc9NGyIUzIsU9uZnztvn
eSVKMC+cGpb1EfznYsbe7OywMCVs/XhLhWIyn/bA8eNuHyu5iTPT5GYTWZrDLgw2xeVejzjutzid
iLcpNIr5CCQnCHB139CDn3sQiBR6CrF+ucSsHQHDDBUVGxBlCvug7llh+s6RmiJw0943+Ydqvsfs
WkXBdsGCfyeWAT1iNnVqBW9owOtgtphlVOX96VRvLxG4WRa6bljoSHGP3FUTiqLxE2suFDtC+4cZ
SqVfnGuBuXGQHbKT1tSbb0Ezj/gDGdkSKwJPZ4OPQOe1FtRzDo+WMvbKbXxIElfewrkC02DaUwgg
F8N3xxJjA2ek730KdFnB4zLPZe3uN4rS/hRHCvjwun3xyS15ievfzhdQ/Gp2lRmRl3WH8CW27nTU
UfBUIcOIpBH4eUlqGfhRCunkaFQMPAGT7zS/xk8qzKiFsnPOGWB5+PHwG8AOrlpQwBWCY2YFhubp
JwBR5qER6T6W1y9oVT8UEQrqTZxDpZqO5pDmSaX5pPnI7hAOP4JD4p2rUlHSmP4YhxJ2FKruhpvn
YLeist8eiwb4+MCg7OEqXQpGNPDtwbqCvX/+4ekEwMLDZ6fEdo4RL28+wpF3fd5DdHRU+z3ZjOtV
YOoOTEbcQuoubR6vumGPFu0XZu7An1VTCJ/VT1byQw5hm+lx7xJQNxy7Td91vBaWnpzCG4ayM4GS
ker9Lo2IURfFhDSUhGki4lRTUOGRoDe9qBrPZLqKbCIpEAcPj0kG6MKTb/ktxWGHlVKHe7UKaoKB
8PZS0WQ/xA1qPlmpKdGtXmMRpvkGqve0HoLkxsePv8DF3ALA1GMBRhe0W/LO713k/brjKtTMYsOy
uoZrQWpohp4D/KwzlNOM6Ssor4x7cub0IVFiyWNHjUvPkk1onQMlVhhuMHuP2x5OyJRg8TCIOKUo
tBpd9L8v6S3R0ruCX4VdsyxriHhEsYZ6Y0Pqq1cz8zwsKvwmbNH9Ic9NcSebVe0O+2U2u6lkzM0r
OFqpKWinEdJ9MnJMrkpkmWYzvIt62miSx77JMRmztYbHr8pSDbTCHpyd1wvUXlAIQJOToqyuIF2o
vIzBz+eS8neLyv3kub2xccVRGGudfeX0f2R7EWiQT1z9UbmO4PreeV6gV6hA6RM7yoykejlsB6dM
myY2BLR2gR/8L2s21NOG3fPnbNpC88tTX9tB2rBVOBwlSSE/j47mODoMqzLac87sSC47BbDsiBM6
Hn3oQwI2WsImu+NruGzO2HXVAiUMORhAUCMGQ/s7FGFY2usqwUVI4LmdbA+gK2I1sJjCZxrdi4iw
onM0zNKLug3R+LJ1nAuTz0mbPsEili4F3n3oyKOSRjg1UhHl0EuIN6RekSPf0QfmeIsKwRsMSok/
7mkHL/PoRXg6tdPow1LYd/ep7rHefd4CPE6puneIhqRPLnBzSTlH2qaOTRFRvuROoLNB5bFUFO0p
uGfkJ4EPmvYjcWYcvi5eomhDUtO1AwtppxmZ8gvyi6whhiElI2KM04/fpskzfblYkf7RbF92EXLw
3jwcxbmhMFQY3yI8OatIk7VbKyffRh38jQNIofHjc4hAUqoEAnrdXERizfkIczQksOFG3X7oguQy
2GBtyVAg4SOdo3j67JqhcRxsiZkaxxrpcU0N9BjAaUWiIvAyyas1JX6J9e0lozRztOj58yjTuI6k
SpnBd493PtEb/H+pXt0p8or8yDkai8V6vcoufcc6h/iSTuAMsLVqiTx0gLEvT/GRKF3u7hY2NZg8
ldp010XADa9/ZYubcPbIV7S3ZDVx9sYfyQ1DfitjjgLpah1N+NZ7J8XuqRp2Mj5aHFtlVHfLOtaL
EaISZfRafF85ba0ijOJY3NcHqKTjjo2bsaVUIGfi0GFnqTCaTG++c1NK7GDOLXTID2rPqE5xSftk
8AnUTSVW+971PYhSEzwCujjoQ6a2+QibmGfgjC5W4DMmF/gP2GjvHI+x2W1P7bdZVhpSyfUoiEhM
M52z0wNEQw/+zeJQsafpuWQCXz1f4rT4eDGf3jqRAjPvVYHFuBWczkIdpx52ZtYYL4gC6aMsXMRi
Uxf1VE4O6odDl5+/1vOyfgx8aziFGVNBqZpOM7WNAVVWs9QLgXzJWhvUVSyC0PiotRTLwZOXQw58
t1BLf4kw/QrIYb8RP30CXzxXxmUMLTayA5ygKw9IgixeLHpzjP+O595iWg7NkCcjbM/KdKUyZ+vM
7RgESh6/qIxKGvivCIOQUucn+xGmsSSlqGcPOZ2jLrsOLeLcRiwtqJEpv+n1fMx4z5OxzAQuW09o
VSqxosbMdRJQftcfcgBWpQ08UxhqdRRuW0bCZmyQJvMoM3l+GSwoFCbYAJUbB1P+ISo0JqxDU1tF
bVOMD7F9u9kvuZv6Bw8STBVp6WNXyp8HXvKzNlxZNNTwmB6RYh78ldTDmn+52/N8y/VGldURjEu8
ocYtaezd3pMYIfeTnAgSyhXCXkwNeOhhneLaMYIM4eYuZAWWbgLmM1eKnw6lNf+JCBYuf8+LM5au
yiyuCdFC61YiiaEeoDiN50ggSh9jLGNAwHPkp5XTYJJVQd+ztRv3qUWF0uhC2rGtcr9tiWUm8U20
Cil7QfNS03LyjTTP68hGWTX9y1aEjzQMVKJo0bQQs223tZWi7H7r3L8HxrW2pElPFMMpkRvLDkNr
N64xE4qSITfp0QCehASzrU/BMJ5ZXnKy2pESr+SXHvI4wzZSQWg6EMUejlr6LxQKB1O+t2WrS0g0
8XtXFaUm7LgeeFUhCPNv6oXhtGedYtYPhWPV605EDUf1WQr9jlhm0/rNoQfiS5Yp2UFhIJCscv5S
8Js9Pzu4rVWo7EdHLHF3mjBXSuvWhr7oisQ5WrHlQ7k8/jbGwULwy+A9Gmz28jVnr9ekiIZmqpV9
2XVTmjFyrlxbxeOoUzbw5gBVsNJLIvZUmJDpXngyVj7LKRE7RcktQJTVWM6/0yhOsHoqfHORzMJj
YgCW4wDEkkdHwE4KNd3SdB8TwGwf+tJXNk5DaoapHwiyp88SceCmAApGlZzN/1PlP7ACD2NRWSmL
07cZXpLx2ZRilSZ/9AH1ACnFhrNicDVxD79zoVsWZcCzjhXXYBZraKKe06Dk+vKmoiG86kUcl5ce
HsZ5EzKOP7bkR2ZyUQ/yIg8smfFDYMjS8/+FoLW05HQq0nXtReUsynzsBKcFWzBs7Kme6Uf1JdFv
BCz8ikAoA8XHmIGloC/y3CB9O7Rk+2npfixLpf6yT2y4hOaejTBT6EJ9K1Gr4Zm8IUFVNGTA2YIs
vqTkcTuQ8rwwEbjUIIsM8NXXpp9mbsBaDPv0og3sNHuVfGU8rtLV2+FKbY/6lkX5R+vqrhrtDdzO
pf7FVl4pPzntUTk6Aycgc9EcHP1gEuM1c4yBXEaUw14ZqKBIF+WLl7CmgJP6k6jotvt+kDqW0jCh
b8l6vfE74cYQWKBnpwxr5Kz74E+pegAgmRCogdPUQHV5aHqi/hYHsp3s4U/Y6SxLZo9lopzPihl5
NGpdHCwTW9bkOIA+agzqG17n1Zvqhzb8KpHMg2CGDdXWbvVm+4emRsnGNYixqFPx8yRp6PyP1BQ0
SvISMcNLF3Nv2v9PRvoAq9B8QfGUfLaEcBlGFnEzrLBToeozkFHvIZWa9frOa6RZ7LMsMwUSnxZ+
8nDGwyhb1dW2XlQV9089HTneEEfFOVhZLJI3nrIMz6Zd6UXGPKDx5RH9ZRtcAJu4+Ycx7Ik9mJJc
Rnfc4JkxKNdbnLDKepnLJwtXYRI3nlk6EE/AdkgxDSHXdD8UzVIMOxUhO6Qksuz2eDvLSOeRQMD0
3cbfwaJkYoEl0nwpA5jZzg29KyHoghAYabE2novy0KdZQZOWAHRtOW+tKH9eBpsHt+tGsRJ1eVW+
Bse2EHWfErvr3Kf3yEaCWMo60NIFGeDbnAxBFoFkpOEBTylZVWYbzkHGkprwS91iad0TaoL2BUUx
v0ptYvcm3bN8PO67gbqEA+8W06kBlCwZThemSRQukwyrPYeBIviRIBCzcMeomsrxLuBqpdKcUtxr
WzO9mTRq3JWknp0G8P4Diuzh4vfKw+5TrPkd/7gVRnyTUzfFW2rCzpyE+XF8BHuP7TKYuh8deoxz
HbeRUxglKXlIg0Rd/G4BeoDuTTIcuJrLrAEWM2NevXkySHc+FOfkdifBX+C2qji/Fn0fBkm09kiO
ksvGZJMjD165e3/vPdXubRmfxZW3wUxiS3jEIUF60d7MvliZbfqIGJw8KsxGnAAE4p1nxsCH/3AB
/SfVkLVMExsnPv3jP+AKVpjkxd45S89NO1GYZfZeMv1KipnaLrMq5Z4XaRPVHc77zLD0D3jTaJ6M
5CTJomgS5fEP3Zekk94KBBjv7MWLPyT472zduv8p3EGFYWq3Djej8czjFSp4FHiBCrwKkcJqhqSx
PufsXH/ae9Da2Dy/xrTve+9nf2nloDoLvTr++R3mvT9cDJe2vrNTohrFw0sC0EkBV2OdliSHMbXO
BBOib1iBZz2KfLutRzG4mipZOAEXQlwcQvu74yB6zmOLCoaMvvY9JTmAgQ+tdqeo0Ag4n6OGA5Yn
lJ5xp9BKk3CwP5lzoJ38IFbsO9RbmxbJi0FMlTePf/8OpjoagQfv1PKw9hgslN540gKM5kzfp7v0
l5KcJhJLfoCPhuACzQ36SNi5kIn45MXu+vbQBUqhgIz362S+yo4Fl1dsd5Cih2Nln7Hr56WXKsJD
HpNB3xBS7tzwpJN0qxWwKqHG4da427x40IOLEniFdq3q6vi+PLXIBnVXuqSuVLcMMMNlZTbPMUlI
Smqqv8/IFRZxl19+gZw3oMV9nlI2zaidSEF42nvVWVGi/lzFt6NYeCiB/begQTUKS6hSFMr0KbPH
OHixJeFl+y4qWoPObOjoXvLuRo/j9CaMaA2Tofrc6mya+xHteK+zrQ7FR9Er4jnYaKELqvIZxJpt
2HM2UB1jlTaUGbSsoHYOSZIS20wdDx49hpeZwmG31FvHZRXiAcJra1cTb/hBrpQMJi1IGiJ6I8ZN
huFRu0Xxp6ePYr9487Gwwe2Tn+4VoKvwRo8PrSONefiJhYPHu9CbZorDkbyxByIG4ekkmUJCL9ih
k2k/Bukzp28knFg/3GmSkk+tgbFv/4I192/JQQyxZv/1lWF6JeVEyuJO/mANZILDuhG1bco48TXy
3YgTaZoHosrJ4t9ZcQhjPdNka7zjMHIalGEH4hPvmWoqeDMFijEccia7wXr0IpcWGLRvA7r7OvmD
B27vgWEQkzpuy1nr29Vjh7rAVsw/Tjxoo+YuGv5MynnOvFcfWyBeLslu4PldZjA4D/F4stQTZw2x
WdWoE7IrPj90CW8/KUJVtRb/uzYaH2I485lVnhaDCDHsA0+sAHlm6TaC59yLVIABcGhsxgkWg2RJ
86FwUptsPRfpYeY95Fe+dM3ik4dk/VmFXVjuVf/IK1+n7qro0CENMqTcEb3TxOfqy1rpiFaNgznJ
kAMBQrYoY/9fmdKzY8ICEfcv90xPdxUzrdVmnyBfTKnNmeF/JQzSMsgqxKu6G8lYT710lahN18Qy
W5C1VG3E+3sZtpKAr2LD/0HCiLsZdgkdfsQ5J2NYM28O/PM5Xum5uLuUnAqHr2Alj+sLwKkU6nuS
16DR+CqrLmkqapNyIsUf6clazF/3nk6FLT2SUs/thfCQSIbpSrckohJIoEpgWvJ+QZYF74xBezg2
aSWK4uAkfd4Q0bvAgd3qtXovSCzKoSHe/eOBhAgf+ME4jsdV+S6rj9U9x4IwDyfKcgGgAiL3U31j
S4XSJgoxbbOPmaPBLRQm3tAWIi+S9f806lP+42AM1US0SnH7aDIHz4yRx7+f+KIU42f80i+O7EXn
5uYkr46ih15QSmCspcJKWJIm0ivhdzcRlmB4fNK0BNsmtGhuf4MO9ZREnxxiBaZ2fh8i6DFgMIY+
o2NWWSTZsfYRE+z/FTcGc2Q8OwLOCOCu9hUGNxl93U7oEBqqBO3kNRy/4FjsO8T9NIitsu4y9wdG
I8urIu0FLVaAtYyyn8jeQZKuVDsQsjLiYHWS3snG6tM2J0OT/vAHEulNIdjl3zazdenAu7c8C9jK
+UGSt6VhfC7lZCTSPAexVguvgis6c0u1noqBHpO6FXR8hITmwZ4qD+qz32VLW5+0G23X5G/LbiSU
yvambE+QkIN1a8baaqEkgH/EnTF9YJy5wO7JuGC0NetYzy2VLo6gbA9jYXa0D2qdqoJG5tFYNfUW
AM+FnPlaMcbpbqpSiphKx98jVH+ti4REHkCAZxuxhOXiFOZadQffSySg4vJrLt21YjkFlD5/q2ln
+s1oifdMKV90dloLsUSdIGczvi+PI3vmURP51oZtD6QGIFjT2qppWL83eya3XF9QyRkRPnD10UGt
pQaANon8ZEAwGzItUwTGuVNIKLGfwqGTLGroos1gRFXMCnzJA6rDwRc9iKWFDigdLFe/BGc58/TW
x3iIHlIj5oPqoEG+8feSoNrgVUCtkz0ieeJ1bRaA8P+UfTmzIzzxD+IcxZ5mT0SbDHg0skqFAUpZ
9LdGabAXc4KXI6BuROB11GkaglN52C+G7/MhjYcMXqP18SZA2uxOnEpUXApFSfH3ON8MS+QU3l/L
VuRZepuz7og70N3F2GpYgxbsOOOXpW5T0uT6CIBgXbZ8WP+7bcHCXSmKDOwlJ2kr/Z5+7cP9p+sQ
DLXir+Fscpeh0/Sr6nltnH6aHCppO0v1UHUqYJwmEliXd9I1cMLbM7qGa5fEkJxV0je58HOcTwvK
ZoP+j1Zu1VjW8ye/BWHkuPWxWbhZctSo9sjiwhFw9atw9a/xihmtgfPfILN+TinOJv0D82vmSkdl
0f/xpbwm8KyhvjD4W7c1d6EjehrJeznLJDYYn8RcfO9yZ6Te0zNXiOUoMORZKO32K8SidY+A98d9
OaFAM5YW74XI2MSc0bDOWMI3f1t49JpWdOhZgLFWKQIXIZPSWDVTTZPw6ojKfp+6y8+d0yT/cLFs
ZZimIrvt8p6dfuU47WXsu2NYMPPMNCTEqFX6I9GscNE6jVk+krHEW3nrv+Sb7a3Z/abVwHm5X3j/
he40opDES0S1pHfI7WE4RpL2bNb25F6NADrlSSw0GP9Av2SrZSmivKyo/rowb7G9gTJdM4Xl9Xtq
TDWFt/thuZsRHER/81T807vlGiklMx7tU4p2SWcMd+sCdUiGJv2ICtYk3IcpH/3nBlGPjMmERve1
8/fRm9pYg0g/IxIJl/l5/anrRV+lgquKhFpD7rTak8F01L6scIcLyPXhUvWOQqUAE1x8ECFXS17A
WCEQy+EItDf1k0VZjM230OMdTsSG/OGnv+gXoRVoczr3W5vDm65+frQcZVDWpiTxloYTleyYsYNd
SAnTqNcq00ZZpfV8yYoCP2TQSUpC+rnxaOThitEYrQoCZg9JMsaoQKOVsAiPVCPlQQW4ne0L31VL
FQAOiC2O/JEugIX/ljq5xGQ/9PcaxMdJDlw/OoVMR5cvc/ALieJPCL8m3bdDp+Un69LVt5UR1DR4
kDUXVF07iHHLSFm3XtKlKmGFCmKJWuJ7XxyEpmoFslXHShLTQwzJ+ECQAE2nC/z1/MD2pQ5qW4Nl
KjKt0nXLzBH9D7rwZvz6+1yDDZ7dbHi95bCX9+VOwzBknqu2/Y4SfLmNTPZ231YA0H0ShLBb4sy7
aa/Mf+5QHMbbb9T5q6tsPZGr4dYwtp6mnrtahqFbxXxrFmOWeySuwzYKKrMTQvMpcIp6ltvvlkiL
FUS7oYWyJpFoP5seYvlUt9tdgu7mX/ROPhK/W6dTHCl6l487j7OjAn/Evtv+9j5ipmFKJsWfPZEK
uUR/KO8VlpVgxzpapyQx+MZIgNiSk2ES8eZErMuac/4deQXftNB1GtbBbE4l6091rXaQJYE/kJ2q
CYvE6yVPomd6yGT5ahyKOdrJZrDZOOFaaaNSIVSda5wtAUqJQed3BlBQ08P9ZfkJqasCp/NgopVr
TMK3WaVIVKsaldGkpHmXJv/86C8Z1bWAUIyUEkJIbf4AKQxgodv9+aIt8vKK87MCw4TqV2+dQPUX
9SxObIIn0RyYOJ/BU8scEmagzDp4RFpGDFp1CG63YVDHIpBoZOgFcEbLHEDT5j/g+urY5UUYUGHc
LgRWYG/TEueugdNXQ+qVGLzAI57NIR/mLlbK31K+KT0UaGx+ao43LT9ozZZ8OQ+USEpoWZIAoZag
7nZp6ZHY2bv3w9wYQfI1AtP9XygQIn4MuOgUmywOT5hfVqmWrFbJHJxQtTH5rCFtFoAvm89a+4Cp
b2k84xcfMQSSMx3NBIkRrRt4wrupinjurUuMpiSAibKGaxYTStVOW9EJgofTocV9IFE+lU7LBvnP
cG7LA+5zXOtareOAbR9eC4m+TofVGxsRJ2BBirsc0vcfmOtBTrjgaLK3nGyKB08eWKGkNokYVVAX
FcOsi+5OrLFR/rSBshQvnXgwOn8lLBWwR3mhuXjjtnqpqIS49KU7yfWoeapGxqp+MViSY3n5owiP
7JIzty2fULkLxEz1+zjjNrayq0GqPUJiluLOcRxorTUgPPuoEH4fTzT9K/iuJccu4LJCbtDWq8An
o8HHrUBL3TsSWClMysF6skjKzT2nYU6g1L9jwQmnlKEaOgABbMKobTPuAGW7ktpGCNGBm+MtKUdH
Lf3gVZhYd7buTfJuIbfajZnF3LphD0xp6T1owgpAN4JQCtr/hEk4lFhLGgakAMgwwhVAJxO1gfbW
I/Vjr/Dr4I4fHVkSmtvbhsfR55FAiLNzxAmDVNnL1+BOyNQvHshP0mHxxer0RklaAVX/4zjAGlrS
FwSkqfXSEsasn+CrseHMlNZZ5fVAvQ5behh5qDQ0Srrv7sw5yMakeJKK0vcx7QXxSpbxnNTKhBJI
HSvQ/T9dNYfSUHSKQcRVFVvp3C86qyfnG92FsNkY9mx6VkPR5HXGcZibJ2AnZKPcZRn0fmmXU+9D
bkJcG6wYSGVS/eZLbchRoTm/su440KGt7KLgH1MCefXFTw7KqnrC+Zz+knYg2NeWfRdOPj1r5vtT
fX01whtUhAu+YRD5Y3PMNZdgzxz81kktuyvVA20EKCGjU8PUodtok86TxYd2x6tbBIHQbvQZ4AYV
BTpEUbzo5T4Dli1c5IWBoNGufsbyOlbOk3wnOu1Sn9sKdqHsEgUeoZ8ay1Xeqt2rujKMFReGmSFK
vza4ix6rXyT/dYTjRUHYlLA6GNeZVQvmfdggFvYo0zBJUnVOXeg2Soax4mlrT803v2egtVdOWFcP
qd9PZPKEAUp5OFw2O3gsUU116CSLJxvio/vFtJJ1MZWM4gtohg3EbbYwdxZ0syFZHk2X1FQnalJM
a7zTYo2AGi7SggU1GDGl9x65j+vcFrLbbNXBn1yNIKZJVL13BCEsBq5bETiTMzF5t4mVGXdXcP4U
vnXVJDHaJdlOcDOFAO/MSKQSwnp6ZiQx5WD17GAjIQorY1ClcByIWY3C4okmBTg3qbN4KOejOtpD
7fYNO+IVW5vlvwUIEzho4/XMgQ3Ye57sVGCljuoT5P2vfMJq5QMwVb28/mtwZvYoyKfWbbEP0bwL
O4WFTQegmmLuxbaC92FDKUDcielmLPImIdCwb4lZHsLx7UblUqSgh1IACv2ZAjlQQXwXALXFlxRX
BCNna2b4iPchAF9I85L/pqTmG0CBEW/UjQHpdIunuIcwIfsyCbXiQjMZsbYYj2LQaSxrnnHwzLf3
IP3OwzUCYe8B1l5Tax1Z8UjFkwGBmxwTzTnOPSOJUDE1vF2Qa0wxviWATc2Nk3k7bicu2i3yNFMI
bv28uqOgGmyq8W3pKUpDhreSDlVIg5bBobC/2/Y3ky+qdDD386FEyKiRjRB0LEUhHM5SZeSsNO6b
wCS3OnAWcNFt0rv2TgmMakKF+Lydia6Mt0Vjybo4w87k/fwZqOrh1b4HrRaX/QvTn8JIKGZ4wD1t
5m9CzzFjJefOtimXOu24slkMG9cg429asQST5r7cKexYxp/3r9L8nspyosvUlX3jD9KZIV6b13CJ
SRypsUZHKmGqz0PDvCpySBvk4eWfFElN2iei7ROsiF/ZH9rqa5yOFTKT9XP1Ejj7hLEP+CvfSRje
D6Jwo9S5tyuN9RV62NQDkEJc2kccwrW+m+PMkx8B4zDUGXHfUUTHWFahvMiHgrsse3NOSYW1Urmy
bV/m+A3C4/3bJicXIFEmNyAPSG378cBLhx8BUHnUogbdQK5DPDt1ZB3FINZciW5OwI98l4VxB2h+
t0vko34RVWXizGzAya81Hk5uV5jh2/am5jSGsvTfD8aUQ5yMmPCZjcEOhn/XLe8Agd00rcGeDZ+j
FOtIzMdyo83fyiYtBN7yltIc6SIWm5ZX7Tp79U8V3KY0RJ35vwbsgucu/2g2f4iMdk2citjAZKI3
587pp/knSLCLtzZ85j8RD6oU79Q6YJ/n9SpQk5uKk3z8Y2XjtsafQV9143g4k2/M1Q52Er+I6+/Y
NTTnC5XQV12uptet15UDrWznFRS9//EdkdSVFATGk6Kl6hrvfyezcVswD1GKQ4BYZL12USWKqNUK
xS+k9yBdzkzXvlQJiD4N+bgwc9qc0+FTX1bqRTlq6VwDwGw7ICi/5Ce7Yz/mk2YeLT+DmtPtnire
JRbPaNJ7Z1IavyyA550r4bZlkP00+uuHha1eg89ySEciH2/pM2TVa2m7tu1eskJ8wwopMoySdnEu
9X1HHyf7/qBBr+nG6Dc2jQ5T16xa2CId7ta1r6ytRxpivTc+a1ABJeIdce5kgfONyuPNrzx2ZRUz
MxHhGJuu4jvcIKRlc6rXAdxOprMZOg5/t/DoR6l88C72cPJpIGru1RSDp9a9yiJc7mXNz8SLKw6r
XfCV5LqzlxYjJpGRBOYH/XSK50fkESMAUS8JrXJxK1V/F362tDrYMIW4ITTjoDy96C8kD57n0NFT
TCUKpu+44TQ4NNWkOagSQIq/q1df5uYf6lFM1mFometdTQwgxdFec7eUM7Il5lQgaCtMF15uTBMz
Qzlqcm/mPO8ys9wZXD0b5iObjvPahtA4oeUf3Vk9Z2frCzVZJZqjPPPc0WrvgcAlVN1rllj3a2+m
Y2z440hoZHkTktzVBcJJxJ/pezvP4vzYtte8ozSFz0/keE4QovmsostGrQiFoajs6bA4VsOTYdMb
Gf/ZYZY5+tSvH6n4p7gEBQL1PFRd060xfOZ5V+72MpEKHIzU7mbJi/dr3sSmVpWhn2IpdWbuJhro
5TT3CcjcDWcbJbtYK4JvVctKXaTLCcAqaLaf9e76rgs+Qn6/JmYzCgcgBd5pMxUmgkTBzU5B9C2p
X8zi9DsBTm10wOOP8fCrt6VsvnCx4SizHKMuLbZM2wGue9FjAmCUcd5iUiEhDVymkq1ZKaGEccMt
1fFTVWuWbSJihcisEzYlgoDYgAWq+HpJFBRDLPalLfXyTvwWx640TA+lRymWN3RU1HUwesKrYMm0
D9fcNAkZxkk6PITMaCgahm8MQs0R2tUH9LZU8DgS4LadJd6BYjwJEApkIPEc4DBjoomcVa0/XHWj
1iVimDrnwDeKPNC8bC2Bsk2n65uSIlwPki2Uh3G0sxZ7jOsSzN8dkkQoggO5TztzrWT6mdzMR57U
JQGbEPKWcxRm44rdmtgP8oXEhuxbiE6kOAxB3rb3Hvb8CAKWkc+fQjjIXwLVDAHhfUAiF7qAf2wM
zYNCgBsSc7iBfRZQsXPxIxo1t1emkEezsIWIkJ0F1JIpDq/rdeqyVeCBW0Ak7/4PCPhCeU03XZpg
kYEE2zvW/YRy9e4HHIpulul16DI91t+lEeL6rzc26sAKOxMQV8L0HKxXOWnlqGqyhMLghPGj/spS
ewuYBF79vwy1wvc/ek55ukrD1pffbKkxigILj9KsgfTGIYYtHZIQK5CH//pNutlyy6v/5nRsyYlY
VJq71PBv0lRGurbMkk8Zw/WsMIobFxsAFn8JGGYzI6bIDSdB9AQ3XT/TZJIYTvCDfMuAEaTc5oHV
ycN+EmxXeGW/fq8KR5LUP/yH1tg9M+EA4uDYag1eUZ9H6DDANcx65fN7KM5/vVRQCXiOXJhjqG1k
owCS5osklHvvWX8o7ACOBGE9afgALJ5Oi9qSM9OeONCb3lcQNIiD5+rgvMdJVD7CMPe+7vHjH9Mk
E4tVlPgo6AisXhwUZ3pnAz1msyHuK6Fpyy9ggJingg+QLasqYEpmNeay16HmfZk57Qh23JHqMmPY
KtLTKmGKz3B3TXJvxXW69GDOMAGfewFdpytpCAFY8zK1IjkTJsDU2NvYlAvaDM6XOZ9YjnPfD0A2
r0sP6fm9oGZMvq155wn6zcn4aMPZ8LMA7W8Uty85/q+2Y/xZakM27I2PVD1z6c3seh43qcEG9X6h
dpkvUyFpgparddLLGBlPzGTCIpFWNmZ+iXL7pvPhrwBcsCRUpYXva7978OoVqrNGKse9T5hDFYa0
/GVZ/RrMbb2zOiwf+hAlV+BHSY9bmsy0+HGgkemNcEmctefZ3tre6KH5KTxuD5ToRR8KEG3liLHy
NgmrtyQKxkiWvEzsEddx0QMSMjAHZC+rAPHwDeOiMi7MqGZAW+DrB8+fMFPvihLFkLww5L9F0i5F
GoTK6Y3lmumysURCWAw7xZzKmrfvtsaB+DHrAycvMLuEYlGyVLqRFl68jTw/DyyfyUFN4gKu5vS4
hoZAhPT9oumorY1rtDpiBciRWSUAalaAN1uxLbIGqZFQPThK5F9FljnwpFdYoH4rqAzhE/BNw4VE
a1Y1/ig/6szb8u02PCyjvwsVgu/CEpHLkklPbTZhhPKWxe+cwk9LR7OiN1++VuETk33HYd07LDTY
iyoEayB79MGo5nAz0soZyjcSohC6ZFXa0lXjoQ8PxU2z/P9TTiua9Ra5pmbXXRU3DXPHDmw4rDTj
e2Xgv2Fcczee420lx3y8CRA9Dpg5ylt74MakeRMIXn4behUzf86W2JaUoYFeOmt9iM/JoTPXJol2
nTRzGbIUy2tMvPmrkkCJ9cuQgF8SdPjyivIURVl/yU7e0XahqOBTaROxswbH8ihA2ZKdfdXEa/Ep
hPJUdepVrM9weKrRjNPTjf/sLHPGhQ6aoxHyKtmQOMglN9p60iybS9Cj4z9RKalTg41ff95Jid7N
WXe8i3wJ2IsybRHRgyynffNvsqSRtUPggFYuUYdjcMzrhrgT+2e7Sn0NvjbJT8A66VmFVIeburAz
PZ6qQgKeYe7oX/6ETE5fmXKl3LSa3PfzvIvDXVZ/I3hLgWrbMGG4PFcUu4Aa0MvenvM5Th1Mu6ZI
RbQD3QSNdkAw7CP6w263Cu1zAwLzkitGlqrbWmCu5Mw1IH6S9zsCpBBab+uq7xWg37S9TWszso6f
dkfYWTMQT8K+if3EC7lmHtaU/oUSJryUsk2WGfRQzrlhPlouEk9qawSMAESj8q9cDP4V9qYgfkH7
Ckdn5nCr1u/r9WZeMpwAWMpChTalmTPdhGd2VZ7wcrNdubRk0AFsRKFbVjDF7pOu/swDL0v4BM2H
65BHr2JEDm9yfCeqqq3lGOAQPIo1ZWYJhHjrR0VbpPEzFnK8eMweXwtFy1ndxA0EwPuu667PHQ0Y
ANZzZL9jtTZ2bhkt262BCJ5llRlsbxXjxRa9jG+DJnO9z6SqVqramn+Ca99Aor0ZJs+48Alvw1Mw
0soJ+NwNuLO4JvVBZ5HYtVP+fJMgafRoLGglP1T4IZGSrAabWJ4LcxE1PjD43FMC6UU1jjqlntlw
0YL9hE9xiptaH1lQG47dyjIAz58F71idjFxgdwMAPe9Qq2P7cJNl9aV9y10tHmxnA3eMcaUIntkf
UU3VZ+NIEVJ5v74esXMd7vWUUCus3WHc5a+VL8BUWT5CKVZwK6ZiCChHHaot5UrgHvKrDdOtZXVn
XgahJRvA7LfqzpPpZQV2+Q/BOKpJzk6JVDNlAzsGrI8nVsDoOcVHORkrjCKeeZIU4l7e2FU2lrDP
PlnqN2IAUHQmoe5d1wQkRuMxTLj2P5SwjlIV0NpUWRiSxL11zu68Y2OAgXRF3SkBhCCKrvJJdtIW
m7kFJ/Y/gocBI/jk+UL/3qh9J4BliOJYVS6+RWvGqskqJ9g4AgBf61mlFc1lDMNvYcs4a9G7FhQP
wv/YKeuuTfz50q570CWtNK5RPF9qRtexPNqPNqsSi1LoQzJDIakat/Q1Y6ukXksYcQi1k8QDGNEE
NueHmWZrD/kCRErVl4FpPPiDnlSRUHwYvTxv8vd8Qbbzwy+WSHbrSdf5IapJGMQQeEE/n45iy3xe
bycNB7cuFQdjkW5B5VcTF6UIbPk6zKcPCNPUeo0oD0wEvAJ6415SalbuRTfM66b0uaPjDX5p6jdq
qKZNm4ssqFCk2LYXizOuNtEHzm7pcN6wggB7DU39RtsQr+FmmdZL4Eb9L207fGqn1RRjIIz0UTI2
740nPFM0TCVq7GaphBPDdDiDgDAbbtZzuDQGLk0p6Q72NiMLXH7fsb4SumwVORGBA4haBua4KCPo
FyUaxa45h40GaYkZJPHxSRY7RVGXk91bT20vmN7RRU6e3so9ldX3HxsYWIchiQ/Hf3XqkL1H0ARg
9cwDmYJopj/qAO3Co1pT1mGPIZ7ctv05U2gYd3L4mLE5rd5XzLdKumkepTntWPDaf0ZVhNEAMfsZ
olB1QAahDDSZhbJ741KmLgHxlvSkw1VSM3w3iBgldt/BdV9wWOUXziS4LgFjNv+4N6onSL1yxbRU
v+k2qbs3ZvXdJHS0YCGDUfqQdzUCXVqYdiCUSqL7cFF743DO+h7gkUODEciqZYqwYAcipljzIyNd
LI+ZQ3g0xht7fyLKOHbmY0ncR+EPjqiWZz84C5KMmzCz0vvPyDIG6dZ6uXrit7u9OEzJ98cXskon
p7Ztx7Vxaq2kwWualxoMGWKJTGeN8WdIPNJVscgG+TX9aflxGwyPbqgdidpL0uqhVZ0s/0giE1Hj
bwPcJbhQSsUR2ODXFl+LI2KNsviBvvzgCJ0TxL2crLufaKeT11oVL8hF38Al/WQpvDmOj97HrWgt
a4QbOPs9vthtu94a5hDHb3y6LjFTHwPxvlgecNiGv7tdpVk5lFLIuAESOrPiSuxqAbloVTxnv5lI
BvX7+2W2/XI8/RxX3CvjS0rVMlMln+zcFsoLdcpFELRv1FWy7QnnhF8+K5bGxsv2xBh4nUSAUMLv
m0N14+/cCqiM2TllEjJ9+d75/TO6djdbRpSICAzCHV9MXSzpl3Ifn3WHEXFnZBqGySCcMSZdOs/J
kPCRVIrgUxFa7mcFiuSKLjfSrmSc13PFELjB8GOJ6KMp1UHTgBseFJbKYW/qBGLIGoWrR2oCCfbw
samiT2PNEjxWatJfMIF9dICxP9p0tgOAgq8mfe05OG89fRy9+WKZsn2B+HveNJqAw/61EHStYh1a
NhtUcwvhvIjwWbCciuMH6GEq/5xe6HsqDHz+eo2TpZWI3GORyEiK9KfGGffLPCfTXYjt/k3gu9ll
1b3bf0x5xUar/thiISrCuUToAM3Yf2BpKWrR41NvfMZue5vhFS0iguv5C/JCXKovdzCoCGBKWlgC
0xcjZkI7uAvvTl+F3GoOipO9dt5TKygkyP+Y9gUD9eCW6k0f3YgtlEwM1bIFG5ge7KooLgxTdq+e
0K73pXdF3ZqezRQr5GW55ftkMRvufEkHgIVE9sud2vKgOqRjv+WgSaEylECorZB8HJZWRzxa882G
ha2VwHz5qMkh7bXfzcCovMA6FyCrkXvncwqb3pVJM81/wF7ZVowmfyph9T8W+tdXXTc1vk5rMyU1
Z69qy0TGzzrsGwWwZGTIEWigksSCY88nh9tpoovPJclGCKBIYaDTq7s+ZUtHdIzocLpv+TlhPEUE
ZGtrENUlu1lUXmnTnJct0Mff0aYfNym5T5rZ5XYIvresVxeZmRCCTe6SqssKVc2hEEIij4CLfN9g
ZBjawK+Rj/hdrInnPvmNX+ZESXCJyNS8R7ZPeAUBpkNMZesgTI1dPwofVGDtC2Opqbd/qv+8Sl4n
8JwvoYcImrvemqmGSaDwcrg42gDHvqR/9wHELvpfNKMPCXMnI5LaE+MtzcovNmwX2Lo/OVUtQA+h
07vR5WBdX69v7MNNmCca0EvbGMQs+e2jsdP+tIy9L54B9tQlyZIxFMoYRQYwgbdSt7GMRK+oRDbk
20ggmMkKrzN2TGZCVW6lDsIX8lX7pincCxq+MLEUDQHsF/2fStNFWQEgdrSq/WNzF7hribueSKUI
gW3cXFLQLmCEW0SEH/UJhO9jUNlWxRmvbIGxCcduyJ0dvjMc8Am9dtAKsu1NG+eooB/ukia8ADR4
t5nz9TFq0LjNf+4N4scODRIJ0M/pWjlfMKifiixx68tM+HL/jCMEItFEHLWP/QaiJ6HF7u9Ahpe2
h2qeLsahwQlbjtIIGW4F7ohwnLIowFguxmH8pBwbt3MuxyylnEZPIf+Hlz6mXpb8P2VfxF07KWy9
8vcI85Rza+mrZFCXBTx6WtOcnw4Y1SHoZPTJXEslloCasZzLsHPQst67SkGOac+O1sTTtR/bOyx2
wYC/XbPhCyrWTAZ6LJaZOP7PdLZcKj5AOeErecqn1mhZimZYf/b9cbFJoyzh1XMPCqDQ9+1rIO+M
QGNJQdImQm87GX/oIiFAocpYEZDn0Y8RWSVA6+ZIQSRhWJfvFIosF5+Wumo6BYtaC3sYy+OZqMu/
vaBCbOj6DnArYXgT67IS/dQmjaPB3a/zptKu0//c+r0Yt4QmKdokzWHZLtgCXMLUWk7+Jkqbl3xp
AhoU1Vf0ST3Do7VMCv/wEc2/N3jl+DnQWyTcEjrUwPx4soIkn+GLgvk0QLTAk+XtkDfH2e0924TH
QAO11r8MGSzqew1tDnv4ja/D3p5UbO7cdyJRtbKXbmKwlw5lNy9cHlXV6wXlKSODlb6r5LU4M5b2
c+99FrSpxBRvIAuhGi90ZJvRLWM9KorkHgDYvs3izKbb4JYDwkR3m/2FuMq3qa8vcqgLgqwoq89h
zPDzO95QODlgScvclvjYD56IzJSt4Ey8cSIpvQkK0qQdc8Krtjgj0ASMqzrKW03YaarIANoyG0Il
Coyd3McmVsVg+/QGmWlOjHlQzdlqqHy3EwE8H+kCpNvcRSlyJIMfdAax7edcdypnCqTHkupwZcrE
d4NBN2c74VQGBQTGd/cRFUCPApATk+IDHR1+//uRd14P38LRpzoKheVKEfwPwj82KaYMYty72UL4
e8zFaeinCBdBaBQ8Cbj8xbIsqCw5aqirTdxFflMGVYlifSvlwAAOCxCP+NZYM78gTVJevpkG725M
hpuT5XhPFBDxGk7R69QsdtGpEKpb6+4IpivcEw5X/ful4HR1tYfM+8Zg2eTBVStkLq7R+AnlK2f+
WIURPG8bREu6nbn7i6sfnhVPiaq4O58Mk4fqih3eI32DaEs9GPl52xn3SZrvYun7D7YTwYu7WUOn
QSpL5SOecxL2GHLtLRXDUqxgDXNu8FE44cdCmmoxj3SL5uFho6z8b+Kq4p/1QasLNI0wwFTeCXrW
WcBU1THAHSEame08tY2OHunesRICEhCwG05XN1Um73HWc1t3aqQyVIoJwUX5czl6rdmJaXiW+9FS
rsO3BK0EnsxvPu2x86/qNqWbIsffXww61/mCiUD24dHxJi4STv1i/lTgyj6IT8A6cefWm1AD5Kmb
bHvilinURTZQHr3KWkNibZFIDQdYvddV0zLC0KMaGaJddTpjVQkpRsor+W0rZZLVggrFKxtM+0jD
mJMgpxFkIpODZpl2IM8gIjbxpzFP7qK5DQRuwYUtj5NDO7lyr/th1Gy3Ww6XGxHGyhbXO9IZbTsN
4FDlrGs3CxdozwzBRMulOIRfO+/f3VI8IjmeqLZLMOC5VWgE/9bHeZGEk1/ZbQ1PJUagVVbGqiql
BXzCfll7+nTKVpvy/xgqmtYsSoCJGNu1HrlDVNd2Koq3YxKL3x4pcUaMs7hX56yRYsl8BOsVBDTZ
et6CH2tzR4XQJval2o09cYHD+q2x6459Ms41I4oq+kHbscw1MQ8J9EQXsk6/zo45GqaIKyjxVxWp
pPMntYfKYN4YJ347ccI1J6/QQX2YblpGMzPcCp7zadcU7SPlLnV+7yFxyAda5utAPKgpcg4IaYUL
wG3dvrKYt2iUPzOw4hQtqEoV/EzaqSdXfZ1PuVerjSB3HhN/dO/lrc1rUC7A4rdoD52d+HVFPbRS
kC5UCd+V8fFZRcuaQJZS2pR6W52kIe80039xJQ4lscMul3dDl88o4T2ko9NlYW6FLoVvHVEjPy3q
1i388AtpXj20Bx9i8rIMAKqLkdm1UgOWJqRFG4SbuzKnFnyqI24zk9MJopSqXessUpywsf/SaR1K
x+5W9mbR0y1mWkbiFt1sB4we6M+K1GNPq8NOtHMvpy9ls32O1X86NMh7KN5WPohgPU8CE8QDVm8W
9hNd9YUgTVOmNmIYQ+9UP46Xfl2IbyyAotPWdvlT2IMgVDunXYhbUD+eCI16GoT9riesTlj/ZdOR
74dwO0ac7dxGYC5eyKCR5286b/rlFI+b1nIubtLdv/RlC50ZZGM1ZBa6WYYL10zLNomRrHjUjk8y
V7bnpVHkhQiGy9tEjm4XscJK9yQg0kjekNT7wQMJreg2lSCv4t94VVzNXPO/KjpPqMJCQtu5cAVZ
qec0PRsJqJuj5TRtcG8MEW2ywo8BUSV+8YzKXdLQyhaAgDeWqxE8NCKhkBT4+MD/Pl6Kw/AMdhWK
GYXg8nKbdDi+5k/e2TIm9I1Ho6qnwfBIQVPbosBbT9oGBUDCW32v1IyDiQlqqlEmBa/4wdUndXhu
lUpqbBUGqwZCPAtlG3LeTBKmoYcREri2o8CARdaSVHHrBNBlfhuxXbtpjuUSisCleUCBSVmN8DjA
rCTGbQh8JgMu65eCmZ2NxWGyrtEDsZwvYmM0iPUEAPvOuXnv+L5deQ41eDGpLumMTOo4kpfFMrb9
8tiNTTOPRi24hLHUvg5qncQL2trPN8JyKSJ6osGB9NvcQkngU1XiWyAcMlrCwEZwIh26jgcWII+8
edTqKexJi7FxToARi3J3F/Uc2wGFVOh+8lyYeNit7mvLw1846pEsU5iXOjcGmGovH9QQcvQKPQ2J
3mVKFy01vi7g0FBc5tjt2Ih6GI9VtLIv3gsCWKwSjbBJhnKNRQURLZpvMqpvzP5CdsMMcQo1ssz5
obVesRV56RpOo5ScUcWG1LHOcToAB0WI+fQNvrmEvsuOBtWugoYIwxPOidbdcNciqT+o7emk7awe
x1gYMEux7ixenpCnfh+gt5NoU2N772MxJQSXFAmJnyBkE62zktc25n14cxl86WeKZd/+teHk2h1s
toXJdCTp3vQ1GwwHO6x48iY54qRWfIjYZSZKP+ncKyx81k39iP2QbLms7j/jmSVNdQDjEIBCMS/l
tBFwTMa2C/kJQGEitnM9tUBOE2tt55cfojxqYHzSYUgQ6oV9Xoo2RzeoSJF3+FNZU4IGRvk+niTx
fjLP4OaXpPW3yUrTMFlwL7Iuvv+WkE+mFj9iGSfW4W9ZASljzGB2MNsJFwaL7tdPmGJG9e9TJDx5
ECzFCCBLfxeSzMPx/5IZEA5am7wSIPjKD7UaeqYKnW4r1kWEjjKy2VFXEwUf+nu9AhhIbR/AiKwZ
gSn+1KfoUs6jR6LByy1LSCP+Vd9RvecV/aAGPh043TmyDkDqQdAIaN6trwQm55pWtEB4oEiDaX9G
iZA5ftBWIeR4UNF4VD5CJpdMKRLSsZxNsaDZGH5IMMbfkDiR5mT7VECPeAaA2NcZzcUNHokHVCcE
iHXBporAYBhi0bAxwI/q7EDXEjJvRe+4J2gVPWPay+fI/Y04g13IWpAsPF03zwIJVo9YQq0V9Hr6
9+kidWOjMMiDdEM0lYYejqVcWeMj7Xu0FBhlACO0Lll0OWNj1g7aKDsrmHJUeXkAtlrTFGQSoqsV
V/vYjgSH+YLQm3fpiJ6jEnfGdfoAN3Izt71fcliQQdp48uHdJGP2ARMdgzuYOlabEPth4ZAs4FE2
3Utr0u5kc2nEXbNJFpxWP7mA1OdL+OgVGk/OC0/duYjK+uBRwnX1vGLIjxPP4zDgThWb/rcPhT8j
lpc7sBtlygb0tkgiAIlIatOPPi1/sZ3hGW6hICd7cLSvrCuUTF6H48higq4SYxGgi7p0phP/eFzz
R6FW9oaulrjhznY92kYphnFOcSfL/CODSOPFCke42q1vFG0tXBrMKxqQhr1HmbJj09e/jxHxHL8j
Eqso4FsnAx/gJo95DLwismdCObTvhMQCndEXvpzE7b4Pq2OOP1LbQLs6WSL1fNp9VLPpusny3Dpn
T4o2hZpDFiPqxZPOiLf/4gCaL4SAV1niyCoDnFTNvbuHDzv0vWBSaZC9njUJTINBnTmlZctld/7A
9m+ywAptxXBHm2ECdOVU6W8nW0I6XBFtTi1yYN8nhzhjdkpv7/22n/cXWguihL1B2yyZGvurYITO
pMtTUhF3mBTpOl10sH3YpxPfZxgTtgAGJoV4byK8QG+fIz8vgSubncCpDC/Vi8P4EPuFh2O2qrVP
4yD+Hhj+s41MRVRo1u2UHiSbRurnKRg708AOVSRgGEr3Oin2O6ZAmAAg98WG7BUHskgDRiG06Rno
RBAvHGOOW4qd8avnywR8E0VN7OfWEbHP2wVZI5xYOVUUymVNXbRghfDfMpr1r1mEYRoKB7vFYQoZ
swTHdh3vIBn+U5+K1WDV8X0GTBGoKnQiz15wupP7P6jlpVMTVwHuB9xYFDxNNok4djj8hTXGgbw+
Z+YrHTlwDWsLmMFE5HXw0UjbXzeei5KzmIvAFydnp8zlQ7paCCeQbgkXRRs0GPx0lJdyYBeeQ0vJ
vYuZm45GsFOBcQgw1aCgSje59tH0fyT7hpE9PAjfbGJaVrhpDw4b4c1TZVGb1YvN7YtCs06e0sg5
/sb/Tx3kErJwk3NRwzzDe8caxvB+wC0iQ4WoCTWjMroOUBc88ieJQd1vcIpKRyQyQ/uF+z78lLmZ
7vZvX1zRgczkSNfVsyXfbBBMin7X/2vSjx96EpOYgwWJg5+ZL0QLcCFWQUNwMTXajMrdPmUWVyna
h3kdyu9ViV9HpA6QlmfAiiKTdOUHPy3hc98THI89dc+UsCrkpa/DiU3v03gxI4wspQ51uHqEmN+F
uiWCe9bCpMUajPu8wXtdKWGcfmVloadMllVIyWg4OYuLIw9CCT5OHzBN98XhYYHdC5PNbZAoMoWi
E9G7KInrQsrUJ+h0g0qRQj1O9q22abySKx5uQLpH+U4wsgPZSPQU0kQqdrzXQk88lmN5/kZ5NU6y
A42hFHeoRypb+7KzsWzm0gzqas3d6vAlyOusGwnlMr0uAe1+Q40VD+bAaQuDnKv65YhNBqvIQt+b
FHGqbq+2ZfUItZN46P5URk+TkQ2HJFfo9+GsPYn8KzCp1cIE+BLmhEVdGr/ojm1YeGYZw6NFyUJP
74Vxbe5mBrByy+U8lUw8zgPkL5eX1iX82ApSqbYH/Lw3L2mDAyozHCD/M4Z8WLEYYRkVBg3rA5Od
VdPOYM/H+qobXJkoDNeH5DoYL1a9lUaXVAKYbD9ZUYCrT+iWw8uxr/LRXSiXX1vtz0fZw8Eb5GLz
qDWfyvPqHX6wpHMfP7b8NhRWbiKVPjKmJDd6yugwavE7CKzSw1Gde6W7nIvsT4pb7Da8ywCjuINx
+vcp9KtfahQRsNZkl4EjvVIciE5MDp8uaEFQaCE8ONDimAQZp5vEhGXB68Zu4/NX2Qce1CaBhjpQ
6RG6pQKAj91PW3LidEnMdfhO+1ZCC1gQpEqGDEMna7yo0NRKb8kCYSGSMjaUjeuEkmgIUcoYL3op
FbObBKpv3Jh4Z/PyZBiGVm8wkdHJKgg9aWDph8mwK6fAuO+8H97t4gWRwfW+DDIX3MydL2VJ7tAy
INgTD0zhuPMXTMqRYp9vET50O4jwYsZI74OodV60655gPxXdy9FC9+tn+6Ic6WUGGrZxNMzpgLvx
EJ2kmG0NXZZ4Q+7OJZNrtD1G/VwQrzyPFfwDwOlMz2AdTuDnw9MMQFym4HCF+4nmZOVoZivmP9bw
CnsuMLGRhtA55XesWL1Vp/ymaJsHr0BN/+c/2Q1dl6WZLXcVBKRNJDaJEBCVVFiw0unCm2kJZE4J
Kqu9yRlq17+7PFrNIw7+z7+itRH2Ne8vZINxlpKl1wVFFgArsBguKmoSU4MMvA4zCEh89wLZFPa9
xUcALSPj6CGNxspSY29x5p7427CiwKlb2rRkse89YrM2tjY+HKZ9SWi1LueM8VOXYVpgxEvOsSGz
8yj+y4fgo4ltEzWHpKUivKO/yoQw99gBsf5bPMhCgX2TI3MP8knvn3sk11vEQtYwORkO1rpWAFtS
SKtspyAj4eR04ChBV1QcShFst3Lso8h2wB+Fs0jkPccQkzfo5hXTY8c4iT7/07/b1pRTBsVfv/8K
++zfKZR5gkevgflg+nCbBrmasoYtkwjzsdOgvA1/O11mDYDs/uIi7Ch0KyXXktHnPkH9D6cqHdFE
ksa7GgZFxe1JlebqsEwWO3NquhUCdcOXQnpOHyZrCkF/YzziMjzbpNd75GrQP1gS+d1EYyqN0W6O
bE4eq8dHsBQ+Cux5jK1d1rvpGJ2wTc1domRUEJ7LZYqg7I1uZa5AfajIQ0K9U0jHOM9LsZDzd047
Uu92SkzycCWHoAaV5TXbPSvRbcxQQKkELl/dikONqE2boz3wX3jEaynv35QYlVzuOryRZ5LC5+dW
ucdeFQqGggWpvq8wGjHSPkzQt8hFEstKbTtuj5uwcRT0we7SVO9ZWn30f9JFHHgfU+qXrxdxj1TH
gqx+y6A/CZ02dBToc6+tx/Kt1yyf44DK4hPKToo5Zd2IJzDcsonEqQm/VV3gqIriWs/eF0gsts6g
YrEyVWIuMhUTfAIJxH2bfcZHJu62330pEGaRO+kHPs6E5DTc7zbKV5gBidmqNrIb/oiuzRmPOt2G
PV8U98J5zrudAY9P4GWK1hid7PZxoFeWJpTLl9gaP4tVjCxKvB5b5YZMQbzQM0HDBctgrQ65zdWA
QZm2OyStQZtb6nJ4e/NP585eSsy38SEGLjYs0+ZWLCW2CznnKafdli41dbnTH7nV4EdEGlLoXyFu
n65f5Umvj5uYD4ywarg4MHOql+Lap5zrEEn7Ve5FN8MxsFqWTWHEG2sGE/ehVa1E1bJULAHvcZ0T
fRwXKkCjZlq3wCWVuqqSovdELCid3NTnLGtcKhbNQM0KIgwu7ZYQ0e9XkbdPcf+Q8w3FocJaltaR
TJpPIwLX7T8omiM1KaZqHpNcRzPiZuTEJUppyp69tKbAah6u6TW0EnPJQ5U3rHyITBhXoD22tNoE
8IB7dePn0arU/ivlZMKV3B8t8bjVBIsU0Ai+F3irxz3YKItbMf9LosUsmlAL94zqMOCJ9ThZku4r
iTdav86QJ89VL7OqNK9oJxOBgBiXQURlDqu8zUjILfJlanEx1lfk0pSa2ojq9hI+PApuYcyUWUOW
nak+W7TH9rjswKr2ry9Lg+810lIMwYv1ch4EHHZTzBUgx1UkvC4NmWjN3ftwvWqj+KRK65MARle2
o1RJn+oLWF4ziPni3Z/6lHjVaQZ+7whSIr2HTn98q4ZT/iBCZTh2S9/bszp+LoCbrHZcWKn08QRs
AWgaGE0GwOJoflPzyqOIO+/NAtUN2hlTz+Yia4kC/fU/Huj1HDez858awfW9V2DOvOMotS2tfoe9
XFweptZFZy3+aZQWFwUx/TSIfXt7oH5W+g7vn/adAjrn1j1m1OQ+4TBhpKcNr2y3PGTOTLSwkhkO
UnJCWdQ1BczUqIs4SmeDID9PIHxxTvGJMx+XG0GpNELqoWDHziA4/7h1WoVNpVaxp0iIkWxLZvK1
aVA17ioS1/fbp3Pj1nT1F7Iu/8OswVakzQpcLvUFKvgE2fCRFhUvaiZ2r9LO/YKahQRbaywSHA6u
EW9X4VNqQPqrYYRqtK75YVw6QjijJK12TfnGHWLI+SDEOpD7U3xrVQG8yO9AD44tV8hnfAy80RNv
BKoKVOizsJ680nEmZJLScHG/NvGPKWBSpWRhaaNiWC8G1KO5j2Oh5eihW3yvGrgSUAOKYx6Nijsi
zuAgVEVEQs4j/+w1jxYyQms0sBGdLRp7PHLGTIeO97S7Q3MD3y+mwpSFYAWOY97ragoNx42Lh1iu
1osFBKbKhXattTeueeb5eb3gnKLS0Xu0b8WyEzmAYGwyP+uC5kXAjmScUu1JQW3LI8u8fKyz0IPN
ZM84L5F1zCH/8KTGjkOKf+0it1QwZHiHR/YgctGms/c9i0wp/ANhdtIKeQIRcb/5clo+M7USivRJ
iw+kVHHNYSLhIeDYLN97rs6qDel3gnZ0BG2/ba70sEG2zbcaZyF4AeBd5AG/AOXMz1BJwWIMxJhs
fwBAhl2YAZJo2RbvJy9w+DBDFUnTbJZ+0Zj06Enum4cOn+Wj/qerlYS32GemC+QpzDg7+1AEXlFV
RGd9jIkie70lb1tBOhmkSmzKp0TYU3RH36qZNaNP48LT4IPYgHhTF42BSydZb2ZxBanErjIcct8N
ROOUWEpulmT/3ZfQhGvXY0wRE7+cfHLIZtwx/73pep22V1Tulst5+yI1rLB2X6nNszTVaapA6VGZ
W5ijSor3D9d+x9okpTMIcmjIzWOjjhrlUlV2a2PrZmb3bgjMNlQ9xFUjsGn+LMdwXlxqs1a8FxOV
jxusOgkjSEyCxdxGBzSpx12JQPh+Ycy40XJxM0vboHGKP+klbtz77kfgUKMVWj5tsClmuZ2P2dYS
HkvKOIvb+QfqRsIYl4oVo47LRY7ISt6zbhGQNpGEB8fTQzxJxNWtbHklIkkw+TedgKFRm6aALSmO
kgG2NUmNYCbsaR4ZeIzU55d2yEeF2jF4LQBw9lLxZEldtp1vhrOfnVBv4PG2t85LIwHJ1slq1Z1D
MoQG7eKg5a7/cBbOTDWa9kqrnXNMMEcjxv0pVTerDoOruzH89kw7e+VYFQ6UWwaUdUowDkRt38G5
PAYLnD6F1pVsbQ38h8Xd7TQ9qGIQW7A607FDodqte4ydC0FKj4qN42xmLI1HApCzJwWJD6tTEqRw
E7C5nfa+tion/FAS5SDKEL9L/c96Bfm+joo3+/Oat1RqxuN/qAVzWe0YJrMcup7OxYaZYG3EZdq+
X0KsKJiZ3HBuDIpqqfRYXWFKrlB3B3Wct4eAlSgAplQm5i3mFwusdsZD+rRaP6j895ku8KBXdhWD
F9FwTR/1C7FiSVLDdZD+A0cxUt1jNZB1EX9HXkKNLvKpPqly8T976goDgkDe+yN335ogoH461dV5
YL5WFegkDqAujXddLyQ1f5+kq3EHFu4O0N19HfJHB5RNvz4Yt4BLqvJTtTXobS0Jp/12rzNKSKZN
zkYOKOnSV1Ixj693YpA+OP0RJgfIIHzptPJfCOMqSm+v0CLjwLW0GRfurBsWfjP4nF+T9b31bf1F
fzcYPqzGHQOCkYrKKk7xivoWaPiOaKyQFhmUxbRP4fE7SfsrNlft0TqaFoSsHa0/CQUu1yz2U0N9
hvgdSUiYJLt0gT7Q7sp82VRjomBBGurEs7wuK/SAu+7+9evv4F222X80mm9NlRrEY6t4Sm4cs1Q3
MaLKXgjgLcPvvrRNxm2S1841YOb36ngKtHRyifapfd+A6/+/zy3b2SgEG9BF/GtvvHFPzmrdi0lh
ME0wAkM7rv44IdvIazPlRIc47cIv1HKMGGN+flV/2dDm0in5NZ0ug6TEqv2Vv/sleqOju5z0oq83
upLtJ2PJ5nnNEBcygAsGO/ZBj5kgAR2kmDyDDJgMB8eFUhDBOXPued7AHh9SP09o/eBGiXdJJ3Tf
w0FyEUCJefV7BnhCfMWgIXkii69WOCBodeniPX7vLnCqUGyyagTd/vp1TISBscy0+T9fYiYObEro
GKnjvEyEMTNhgWWoU7yiv7hyfYzC0HzRUIreELwzeGGB2qxAaAe8q8JgGzzJhgui4I/0dSpNacRz
iZ1wat10In25Jl1ZSAyKYOKSJEsiyJlIeWYuueqbqrD1267OlhqasoL3D6sk8T6SgTXxPRoaz8+f
RNSlpZQdR/l/i/1BWD/NeOhu82JN14Edn33EONgq3gUHXYrS2jaqZed2yYhAni5nlDPyfbA38rqm
87s/7ftt4jeKO7Y7MvjOO4E6Oi1/MhE7uZe53yvIb6OUTsmv8vPCQNSYGmLw1Xll8vOzEFkEOcBm
HWTEjqayl1qZ2AfV1+20jyPGpfpukGWmQhLj0JkPv/AQuiI7rLjAYJNHGJjMG+Ap6Ub307WhY3xA
6Y2XhQ2Mes6epX37Zm+oGIhbsBwM4RuzZNeVYGK5we7ZGolqXO8em9i5PXx1D1/2JbiPmXIKTOjs
bXH7xi/ctVm+Eo53yp7N+RwhLDXQVzWIspa35x9nP+QUtdPwJ/CRC/hAYpTBYHIJmng2NV3acr5P
tsA1vmXp9OrgifzISCqVFceJIUcRN+QKXIsYyVYTdCHJvDL5EvuG09hqYRpjA5fi5JYnylWgrAhq
bj9AkksryReZ91Wi7iJq+68AHVMguUNwZ9uHza9xpp5P1tQrlWqiBjotLQbDGC+20CxQncPjuAYK
Cz+V8OoMCyHOTxHvOpTaUAxA2BVmFBNSMNSY50cdZm+Y+rA9Df6miZn0wTDucn0ftzExZ8Jjvbsm
ExL6COjfJW8ul9DZlzDIFa1u0QOzrZcpMqXota8u6F84Z7I/c4H3zTV/A+1+zSw5U5anc+Pg5BW0
XhVuclGIngoXj3sMIxopEyv6b5/4eyDqcdLK/8ZeZzXXSErCJN9stL14xxLeud4Mm2DLWG9JUaxt
nXl/EWhzVk7Y8S7hcNnGWwoQOBqZBLQk3XvDtSXW9WzdzOSE61OOnBXGBFHX70pgFs3s6i0+MSj8
3z4SB4Lj0iGBE8ccHKlLsp/7kX7n29ABeLoZW8LBnBJVDHhGUcLWVwQKiSoFy4vZToSYHDqDW70w
34uIBDG5gNXPR9G4UAktM51+NIYiuhIs+f+t4CtKcn1xq7JHxL/2xntDxoWknQU9ZFNjHSNv7T2h
tRxZA1AcV/4Eh80DIcWVOPdoR3A6xIs4J5xWYSWxna6GZoc0u1YZZ4a+XBYPkvSUzc4+po5q7bID
39FWnGzPV11vyH8PN4URNT7c0i/iO0mxxqMhC9EA980ewdI+8Kml3sL/YuhTsQxcK3Bcs39acXrE
tMFY3bYnMOU8fhM81lB+DYzjRYckuZhmeXjkLGAIRq67wWq9lyW1b0soYbWSeMZqlZWEvqIv6pvW
US/7C9PJmQ0rvBz/ENq789R4XuEhoqPpAFCb9JUSjoKKMXszkP7P6WEN3NOs21JZO0uNOw1pDwuP
bAMv9hSZdvjzOSWw2R6ZADPOIa58Nd4oGcqPSaVpyrsNCmrBqGrVyfc2KsSND4rHMMwoSDpyhwZo
S92Myaj195tYr4rRa1LvFb/egOUhBVTADVavR+1tIlyMoohTR1OnxaVa78Jifir5gzkDrAZwmUhR
dHHJuO+DcG16Eoe/5QI13vbteQWHOi6HTK0gnaMKs3c1BfFvbqLOhzAQp94pF/3QzKhIk9lmoxNY
J19pJREBgD1+Nyw3iM4rhus7v24KEtTtkk0DBxkabYY1OR9dqWQmFnzQHOl0eFbxBCETG+C/eElT
kknBaQpNVHErVSGpHQWcSvu29DsbZb6MXCKCnM4tTaKjmEb0qedJNi0yWuithnCv+FBF9aaCzTQj
CHfn5HJZFZ8+bekstOctpi4MBQymWcDxX6wmk9JauWZ35VUp/679fV+OX3TTmpP5c0iqAcp6kz+O
4MvxO9R+PQjI9UVpocgrJuGowfuu2hWzekJsS2MEwDcXV/VUe7dQLcl1qEVUjospmBEasYIqhQzg
BXub7a4UsYt30PfdBcKBPyjMbeFKa61x/DTHurGiFj6YjxP869gsgz9k4NFJ6y+RUFPEv1dyENYK
hlgJGXJTo7ZeOGbl/gp5uCjQ0HE4OXUrfyqDrZrdoCRy9ohgzbF4keMvdO4PcZApqHO+fV5p2htn
CZDNu0L3nw8b38cyqKGie+XV4GdU4Toq/Fgqc4/5FaLLyaVjoTe75N/pnx5b+PiSxvv8bvJ2kB6U
Dt6kzgTKWIdGPJNzlLJ5RmobbHyJ1jBXFOJgqqJIDnpKV7l52qsQBa4YAV5GuvlNfgAjP4nJGKBZ
eKlC8uI3MLkWVWhfkiWo0kNAZAHy2a4IezNqTj86pk+r2rri+hKx9TiykQROOhnv/0YGfWROP/ih
oWIph7jmtFwEIacQkeRmyHXE1vypRROwOrCYZvG+ijg+aGy5vKi3f0JPlRwovyKlmMEA7nJ5S2ga
huVdrBua2/A6YHhrflBdrEloh/1+j9jr6NTZMCLayNngEIBmZQPODMe/5/w55MDJP0023fBC6eUp
A2BoghQm+gLXy7gXTiGdeLYYjUg0MlJsHbs2qtaV53dFfwgITAZB8GlUybBlnaTUrbaRN1+fjxG2
+QpG8q0Vs7MtIHasRy0Bk9nl57DSZIHnpfFzQZxnoNaws/yJKPA6n6tv8w5RrZHYiEvcjpOrEsPq
T6DPaA0niYAoZeuN6bESjEuBkQ9nQh5lUyhVAldD58XdzrH8/RDPM6P6asoKRtYj1nOR4TeIaEiG
jcRvUJ+fEfF0521FM2RecFacWEauTwX9EtSeU1wFv//12ymzBnzAxJV86FqhFhF9UNDEzhr7fXLt
+QQ1YWXoIKkd5tUBfPirnRdwoGyuVq+xFNm522h4BHgJDcHfDhF5Kyl9X1gOf7scQYWNCO3SewzL
ixWDQ+1QniC2cJKr3UHjzh1kXkqs9gLc8TPrRyXNocWJ0q4VFv1+Hxig1vwBCFHBqt/g/K+XMkVc
+yzoCJjaTIwq1a4tlZzXvu3DJT+9glLoWknXnf2Ruh+2UwmxlHpa3+u4OpAzLaBBu3eJjRYvtEDE
A4KXnCvnHcQpvoI9S2vQglMDcz81PF8QrW1FZigXNWRMCYKWOxYi8VIz+lgV3aoMTMKU4aeGQTWu
rnjyLJdSJBQ+8PrcYmq4SVpvFjvLl0gAijZ4vAvz/ztZ6QgMtmeSV+T8OHRTEHNUQQgslAVMm9Ov
dUQtZgGFP4JPDNvqkNhoMt5eKKNQmVfLQOsbcWyqgYnZq5CxK1F+ArnYWfwJYw6yf24lq3cv6iDa
yeEjctXJoOAHmQYepmrluPWlB6wLanBUnXzaiMbEmVX1ceGULSJqi6aCwvtjTFMRb5ezcVfSqKj7
/egaHYoVPYSHi/h85PgZ9cnWbP+LhNilnJ7yvVr8/dsT5sR76v2HOp6Mo6WSpF4RsrjRcmZ2SBeU
CrYKXw9MnckpyOqPSuV55SUWVY5MuhxXryi6HiDEHbuIJS/d9F4ArFCizXytB2w181tURoiREUtO
fXiU4W0EHy/2KlmpP9EbWiqTnggShKWMx4vJJaeJkKpwQ5RdxxlwIAky8eD9InOUAXAyxDlY4Vry
xEpfRaay+cRhsB1HIXaJPGirhudCTAHj3weUaUFXyThbi8ycMK4WZpqPBT9Wgf+eSNQ1y+4suRsO
AFJnXu7oLXuLry3nR3F7gaszu9bqbHGm6zE+57SGGx5xLIr9IZr5CDHyEcyBGpK5OfkDygdWve7H
DVw3pClaeP9Iz7fQID4o/zNWRjYq7YCQDnu3pfMgPBgoP62fWFgs9aeMh2W9Okzoyl4Tlp40Sb9i
GxWUPN8Hoxvj5ZS5NTbFOTIgncnjMmMd3/fzyJKZLU8JNknt1a0ttw9plPTdvPUeViEBq7Pvy1QE
AkGp3gzkfjnPEP0nQOracrihUJDyCrBtLipGYEpU0CEQa0BqyNv2wuKrmz6rKear1VtF+tzdX0yZ
T9e+UtG1NST67l9EcTumsYEM1nxK9Gd4717MN47dqaviKhxKd/PZNn7v/gG3offeoK8vIxDYUoFz
VMBIWbx/5WWH6izmruZzLztmKBkFQV+hj3jCV7UDVsYwa5tYITmFe8Nl5IiS4k/pfgMINuQE4Sx1
VcQyXMf4HCZ7iGjdFnchSrAiOc6836hkdByo3SRen3YWIz0v23sKXo6M3RNpL0vdxpoB9akuoGtz
zLSoOR4XVI4mKNPoj9REzNodu0dbTVZOvIY6uZClDtv4xVtl520I9Zewouuv4N9fPkt8QPFqnWl9
8fnUpKxv0Ke+vkKzpzpc389MfkIA/AWaBRmH4kK7sTE9uQHgUzbvr5b/cFFVRxYXqoUSHxPMWB/J
/WlH1gdGsPJN4LZRerH4MVKFvZMTanXBpu9IsJzdIi0ltqOPLrl+VTsKIBRjWfmoUkLglF7k5DVd
AQnRsCRpEGntpIcp8E8JzCUYINLrIfOIjABUEM9GaVfU7icxJOFORO7+rKExJgDQq1x1AWW9UXPF
dkhn8sRCGpezXI74DAgN9C+jYxdO2rBUd1c1XJ0GZcS2n9FHH9pxma5G+bhojX8Z7Bt4OUNNZGEY
Nupk05FxDpfQMGtdooyntAIIS+OZZyrkcltMuH+ATMiYWcAPsBU1WCIxl/cfP/ehSSrkx9UKGqJX
dzYO51j6Gm6hVdxC/JfnSI9KPpkI+lKuy4Io5YMOuLhMB4BhHz6ivwuXtLgiiYSJ3GpfGvgMymdZ
H1j4S0+cCUKchJT3vv6+2BJ31ETbNGTydHv+IIE8xdfPqGMQNCvJGWJMJB7nilfyULNr3DqW6XZA
ioDRfjYaHfVrjM61+x1oO820EO5PeHOOJw77unYziRxr1FubHFOKhYUTNR9MZ471lYuIKYeUbQQ3
1CFchFG843mp9/UnCyj3TqA8DWJBBRQciaIb9hraHRByd6KCV4K8rvDrMydkqmyeX5sam4ZORhuO
z6ESNNzRTr7xb8rEv7HPnTjQC9FmX7LkAXhi9EyvT3N6+i67GrkXanp9mqhYiqxV6/kbt46oKqsG
rl7d0vg88mDHS/FBIqhdUpm5AQH2GEWnWeE4Z11DABIwFo1SfnnK2zueZc7q+ruJBivjUF7/qUln
hq8QPw5I0B+IKvoaYJRjRmXi5zZDAmCAG0CIMyMg1T5KUaynGI/QABlq9MiNJ+8mK0Fja67E0DyR
W19cg/9hw8UD9nWYL51fWgH6GxHeWNoWMGxBsMYDxJovkRvRqdHBbx38ILyjsWlIslcIYs3pbWZr
dOmR7FuG4rYFue72VT7OCxXM7Lp0pMIKgU1d3ieltiD8dqXXQKQTnjFmRd0CfkJSiS1iDvxDnhoO
IOTHf1tGQg+B5SXGVPQvQSoqBu4iuq61gQ5A7eh390N3BvVnK7kkyw/dR3cxKI+1loTivV6ivaa+
L7ZGFPEQuq8HG0iKHHxhp4GurVCeOga5tS0fwbLOaUE+ruWJ6jVuy2j+oFEb6aSbMAyWR6/12ItY
HBLnjt5LNF23LP2MJG0F94xO9tDmv2QWgDy/ML1V0FhgbvWWyieIuetyyWw/p9KaVBbSJ5eY/d0x
/yupxGPeDKLzg0Guy/uXjDQ4aPlMsHIn7MTeqklki5af/qScPbwkcnfLshiR9/vN53ArfeZ+3G9X
SR7YuLDyAfcEK5GZqP6w1pSJYRnDtntEUxbG2LiAPmTEUhzQ5+M9YjtNJnakFw/Up1LYIp/g8kz1
Nz0j/LHsZ9pJfnRnzQ5/wPiOdoEc1aTDPGnh85DeiDgox7q9z6i3e0GQ1p79UWJDG5GxIkap4erY
5XpOOVMyRjbrlTlFgcSqy7hbfOK1XUW79V0Qc2dVMhH8nAhw1nwYo8JRMJQzblz6LJhGmBCaA1CI
nmDHlD36vxeiOYoJRq7Xc/sIxuboID9qW9WL+yjdfRrdHu+WU4q6rGzrZvjow98ncjmbVly+s8ZQ
3quscZupBpiYnUws5n4aOqx8s8j4KIox0WZj4gk5hW5cozxGV0WX/oQVlXnLLMDj5scnBKp+bCwM
Fic/Uba69CWDttGoaUPX7W0qCxu+NXvhKM2EhGhIX2DGKooBfcQUj4wtN+sR+EbQSBfShvtq8vqj
B4MHnewWCyaDpxexdwfim2IPPcQDYlbYueX3rG6YWwi+NB4uHAkMX+15QsGOb2jdp1b8SOTSahOz
RsSFXhupgVBo1T5+YJWiREjT9efbBvpjPsPgvjfkw0ts+lFG+hm5Ie5X96SPpFgVEJNOqKvWeUzW
ZEq1fF1gagego9YcqHpYMbMlzjQY3ir3E2rEJR94qHybObsw7XDvOCLwXILlkgMoPZFZz2awHwVZ
ZVheBbCZRYe8yYG8PbNzCq3jBZck1dSmKcFuVd2BomiOhQRsOazleaUR9cJCuDJL16aZf/0l2Fj6
8gTVRclD7lCgqHy0BBpKvOzADaeyA4wyf6ZqRh8VaVEGOQcWtrjPckOjfOrrjn2VwhDZZycI/FOp
loYLlzMbx27NO/sTHqExDaUho2PlUw88KJ4PfQRfDVVqJMX3Am4uN74Wf5fUn9f/vBK9JbEUF0M6
zVCxfgsXsIdzCEUCyX+A1tnEiEg6bHqkzkp8HlV51uWLloBx/BjW6eEojPfGLOnFvYtBjI37XgLZ
3ZohWm3dmPOAxTX31BJn4XmcgatVH+F4rn4Vw/S/3k538reNf0V6VHbYDPk4QWAEgIxOuz7rnfH0
5S4bbHnQLq9t6GAWa2KCxFTTw/bPyaeeftVwOBiMgcsdh8Ot/VhTDIgdwFgzxMTrTvFkzjzEZymk
Fwic2uECeWfpzxlVFvp7Ai3vIIMluXsyHjxdGxG2LcJdR0Qq+jHbFatSN+LT1py+9Fwv5mKTCgFO
2/0PSlCGa+aihhx/dVLEp9rwEN1AX8sdoqIA37gqYRLKAFhwKPmzbGs7leWIhVbd6xK7HCg5U/9P
6vlsCBg6rWFjsI9RhzGlAJ+m+BIsXoqUXtxsJEN76RhtZTaOaq5NGT+czjp4VPqUzKJADPWhYD3Y
gLO6Ilg4CVXv2FBUQB/hkcZrbrihUP7gbE9afdS8il90dyPgKgV5bPiRGNW3Fks0B7yWB83o+NNK
EfElIcLeLVs2lBcqEDCqkXOBGOYA+Ud0dnFRJ6Gpvty4JjvGb2RKdmKcDJnGWVJwPN88Dkvn4EA0
9c5VN7oJX7/7UYlwImcJpDJjqj3QU4QWOCHMAPz9Wtokvf8+1d54SvTNiX/kxjIGb5k33MKhPL4U
aRbNN/SARaOySjWCpFKT6VKcwyd+2Ttv9nnQY1HqpGgbzUJbHONeFZyVHA06lMSIGY6VktWzWbPE
oA4gJly4KeSYSNSH7T5b9YInpHwSa5Tx0kSNl74hDTyIEPR0kjd9rb+1ha5Y1DqhqFVZL6WtPIBH
S3k8cX773RvDmwCDnXo/TMRPxGicciwTQG7a1SGs8hlywp7ZKzCpyIpXqD7T0WYGKOpjACIsIOdq
DwgnTFI7nQ7Jxyw7FHUhFFkrU9OmOkxtmAkFDJMg82Nxs/nPOSkjxPM/9y/Fhkrzc8VWF7OazkrJ
vy6F27UllH6D6qJzlQAoLrfIPoypTzvqrAzy1/9C6etTx9gKXflK92wKwxBv//n2+vcLl1Ars7rA
jArkgz0TCB65GouN501yofWcbcsGg89x9DHt9ecyDZzySLwVIa9evUa27aGsWVb6N9b4YL1t1hG1
++uE8q02XTdRFfVAGZJ6EDORNWfKs2K8JL833uS0kpNKxUJ43XMG0XCbvTRA/h1YDESrW7443R9M
RbYKcEgYr3eRDRQzndWGDLph+s3EXUnni7F1FcnwE6DU6CIXyaxSUwYTcHJ0gTZrLNLXhnYv9uJa
ktaYQZlmTjtb6LFSfQXH9TmtuWP2E80I4JdsYMMC+2RTs6Asm95S88Zsn91SqwA/W1lr7Itle3Vi
abIWFpV6xAWBPVDSSrSh5DI6SAw1P0emEDN2sQa0st5qBcOJUMVxaH/QFIPkAfOAmgU914qoKglp
Wx7Ko6wRpGz3+9hOvYmH+ZN/O3GM2E1cN4o3ncAGz2T9zvguF6Uf4uOZuo4O0BKubZLDWSB/tGtc
VR+Sb2kFwuF+dFlWzFoEYHP8mGzG19kMuBvvakaZi/dL8EyAuFaIyqB2h+lgi+9+HMldcVz/IayM
RDJvXaa6OGan/dU7do43aseayd+sPHUgK55S9u9BFD47OrVe65NmxIbLEf9YYa84QCt+hlST+8Nv
qEjg3up4bbmkaaSXPoVaFPi2+EviApCZtcgZgTy/rToAlpwZhSdNIDFTPFd8d9UxUvH14P2FahWa
GvZRlGnhBy0oDFGCM74ssAN9AZ1M93HqgiMQC3BW9QX7P0rtwSsT0zshoiU4gnjKKpu/S/FONquq
lcS2QDLcGRg8t8fn6iH+ZR54YjCZSIQS+0Wnu3ZyD06oBAYXPmA4PJjmtmxuyHokFt/nK06li+1c
HYcP7J2tLrAfYPDBliOaLDRdxfwEgf0xr0JcKswkPPiPBVApt44REJCOTlvyodzrZccRJ84XGZWm
LcpORIPtC9p33CNNi5sUR7AzHS9JWXdz5dJnM1Gn3V3HdIqgb6mygsb1Cv1RoiXox6VJzbFae+qN
XzAHSZ9EwgECzSIaiaR2NCwuvHjA2not1mi42JJzFFF+CUPWNumZy9zJf7tJJuqaP09SQWHNkAVk
0GiLnJePq+h4xK1E4CuUGR+63NuGHvzPeGTofkuC2RcmhGc8YbRaVX4f6cMd4QMFFiNsZR88vQ+N
l2f9JomfZSIGziMzYt4S31V9q93pX9Bk5swr71coFFNp1zD08elVCtYInbHmd/eBV+yrPXTYahmZ
KGy6nsz2cWJNY5me2sWzolDvQlPqdrFrjjb07VZg32k44oznBXeUMhjE7pppDnQPKXqNFw/NWDPO
ALb4xVp0LPVmGGnyK1M9ozAufIihz9ny9ZssizoA/mx5zdlsm83ErankYF2IGOfsfxKRXE6Cv2Hj
fMtYu9Qh2pp5M9prSUgUqbOELbe0CluuTITf2zSdycxR2SOEYTlgjO6mz3I4Tp1TJyjWJ3gtUYlg
69iAcXQQgWA4FiCoz4enrP6MidTD1Rfffx62lJANOUs8VTRH/kJwVwj2HSRBso9aNSksM5Lz/nUI
hnmFcf5eNQGedmSFDv+DmgiljQS8Al8AGsTxgum3o910NFy7uCNuAUio9UdnLVho7UHdwXRDHaIH
Nur9ffQ9bzafKJrWohDvN54va59eMxfYfrmGVGFTVwrId44i7aJ7C2/x3gecAdhXoP6GxDstjtsl
424FPuj9wP2vl/tchfAq6QQZs2VBXVPpga5oGzvAezkh54iD8uGBj+hfk8Jtsn1i5BaSDs59ewyn
/3ddo6abiKtshUjGdQ2ukwgVL8exX/7Rh4I5UJlPdKqGQEllCVrLkKh7SRwRu+/pZi0M5uCuvS4B
SFIn1z6cc3P4e5nLRYCjU8BXnl+o3nGpfv3S/wE25ZpP6uclmcrgqhvkhSUsO+aeTldaDcWlveIE
/zrAuWf6tmbRJyBp6PTO+s7H6ZFQBp/tpmmKlFZSd8xW/drCBj/xPH+5S0+LGS8puMhL8v2AVxEL
v7PCHXSB8dBXF6gT7J7M+3R7aE6rMs2xm5c5H6vROKZkpp43ek1PVOiMA5sGYz1EuWngdnr/DCNq
wYlzqcOU7PsqiJ+j5nmZWeCe6DpxxpNTyZZkTSoVrfDQMVor3S7byAxquKNG7PqFMOh8U01yK/s1
ZAv5DPzHn6Wehh0c/Ripul5SmhC9i6P6gG4mt2dJmhuVComZ2puAhlGaKMOFG/06yNMJHkblOmu9
zsHLewO1eSQ6Ivuu6l+EzODSIsUyQtPWpgXorKHFoN7HrmQoENT8xchbIX7CHfAFmNDFWKhSeXYG
TfWZ93k8OFc0Trhfz24LQtAHPq6RBHAGRHRoQgatIOZVloXSg1l4UrLzM7BnJgA+PftotKlw5ax2
DZmKS3BJu6jYcWjdHM7KdWT8mrbPUmO7542pwYG+5LYlfTWARnTAyJTOEriB6KT7/FxIfYaI9EM5
xjz80mj5P/xC921TQQui1sg/EZVom9NHD74UD/N5LkbehwAM0FCa0qiK9geih/RW+ZSJd4gNtFYm
q1t95+9WYxBtLt7DWMVRnErcuzjXns0K+B2DfKrM1FboU47HmmxbVVi6FFX5mwvLbKeqfXUivGNs
BUPge9LVgPFSL3qQNFg7m7IOLvixyQVuE+5HxPh+HaRfLR3YJQgDyV1WmzsCpYYxf6v2bAW28EPR
HSfTjVuCCNvxXQgP1xgATvM+tg2QHyHGhYl6zT4Z38b/THVM8VBzb2ZfhkWXRI2gc6xorT80Yvcc
gYe4WAnA5HrLt/OKbkLHdErFMpcJind3PBeNPotfMJUlOeXeBtcBDNv7AGp2uAn4vipUWpbOjhh+
P/ii65I/CK0uv9hXc86ZwlBuzxK/ayKSJ+yEFQkVAqilH+xuJfy1KqGExeF0q0Mn5GiyPiWdNGGv
LxZHMKqFEo65SRt+T7ay/24UOiaT8eMWYBJVujvqBCvTNq2Cpe/Uev+NqnEczGgpCMmMhXMiTPf7
++r5rKWDzkY5X3g5fO/BvB4xIAAyCjtzcZFPbDPxEC6UpXxDoALtfkaMNeKHcVchJ6JfOZprFg7Z
utyEvSYCvd4vqKNeU7OJpnujtdMjB3QwvUWB7wko0HUvfstFJx0ErDuujN7jW5leRd61/aQvPlsH
ZgtqvCgoLYI/vhBnfhWkEI7SQpADxuDhU5hAjZ8bG8fOSmKsgmZyuLNcy1bQQEhbVoNxH/FWaemf
YIWrT/MgRBclEuBH/U9fKVZ9z986srtwjVV+YEj80Vyd7yYbq0G9m9AtGYhCASHHSZyerMAyulUL
2STToSWnq/FFYw2+FBvEkwiUKJwc0IO21Gx3I4RqENhPRZ1cTpIZG+SfCtjxmDfs4anB0Vo4D8V4
941gm9z0Nn1idZKan7mkZBVlr/SNmWnabA6+8f9dUiVfv7PbFNZe+wBQkoyKoaBh7pxRbqU6BGP6
qROPbIU6TqAr3TB8X9AOaCRRVyQHDSvJsab0qFMoSATyVPxdNvaQLpMAebLxTm+li+Cy1a3GC8Ze
eCdWIOQFNT65bXHuZdhObr9uYLTEP1SHZ672UM6idX/dwFnN9Zisoxtb/Twg3Hj6hlq7Yvdf6zkn
7iTmkLgdl3BAjjM1bVCZZ16vAA7c4kMnK+z9Xoaw7l0aF0mNUGllDJdjEmZFMt38VAZ9WFEPgsYu
iELI2rk/snWZ3fssY49ozwv31stC+4L1Kuu9qFHCP2umwqfqKW/Tm96fXIeLzgm0sDI3BBtfbQmZ
Idf4czWNnyWKE/zorulgEhrSXRADXzx7e8fhIR+9CwVoSpDdl5xviUoTRi+DZtwjo/hw/bfZduhz
M6DavVuno7yFFpRhRcOsKOh31iUZ4RiC2UUpNxAOrvf0v0d1ciq1sEzMET/zDnoIXIkOAyU1ac8z
tjXxt5clGOXBIf1eGvBSUmfXvyZ08NTLADDzqBYJmWpphfS+HsAjBloCL0aYNK4yA64IGkgD/ZON
0ge2n0wdVKAd8WfB9VVWXqwhVRsTkI9SWiny72ZCv20MmHhccwfe2HYG2+Gm6dz2gYkDu5P2FuaE
WDEZCTv6nLFx/45U+7DvQztQuAyv8GGKY2gJX98KlZ/PjTj/I3x8maxPKezfCgZ0c2sog7nxJyn5
R6t6Wcrutri3fRS8OW51BC/t0LdO1FRmmsDCEUtFuJ+K25zm9LUIQnn40bR7yNXtNk8i2sF8Kwpg
oDWW1M+7MAFWsbVW0+xQ1ui9+yPQthqpj9olH0/f+K3GaJn71piJ3ytgyinWv+oH8EEWsAJfOfCf
kbTPa40FMHLjcHFALfD+cmNMNsdzloKbv5rdN63vrRmALe04wWVdw2vIptCpngRSR2Iv73Yvjjol
jhOqe57KPwbSzCR1JCnOMDSN3Xxb6Eog5z+ldKs4fSbMT24/K047479Y+kjNPb0GLxF5UvRHqMam
jayGvpA5mVdjOvZ5nEXORmLlOW4H7LPTq4oXhCq+hAVYc4cr7GUZTVsU87rb7ASKV+aj47kCloXm
b8nBunsQ6/NrkUsesnIb/kkW5KpILpuKBrU5brudBirfVN7OBHZ0BCfKklNm+ZWUEx0jg6v/vqUS
By+ScH7nxNe2WnCsCcraMTrj0QofoMAETvOl5gT566ejNDxef/uc+p4DLIbbKGWmd7ZGojTUgWJG
Pitxm/bGzv9AZHmdw+E3GAXnH4Za6ztFSW1W+a4vJUVEHwGtXPZqoPglhOrdGV383L4TY0Y+AM5c
ChhbvZCFOQswA0Y1LtYwZDN3xBtwQNE6aanIUvNDOrkVz6l4kQUmVgvDxy2/hCBSQNhKVTsgRjxG
mZTAC+5ICbLk/ego4Sj0R4yfit08kMZoBkRLcVjDhg8TRTjymtXEpe1qnycnEl5KKb5wge4uzUgF
sCSsMj6phfgMbf+WSpdqMGRhYGU1tqaIvpERlD9sYwuzuZno2vLiotBzKwkBKrkPbS1RRU0T+3My
8j9TUGbSBwXn2kmzwckqI9axH7rWoMEu3ELoZaCzDHICQnA4ICV1RNlOMln00vCZ9VIHFrTf2Y60
gRm5t/vXLV0amiW9qpKAwZRlPpZimaTF7v5Iu+m2YU5dgL1pzAi45Tx8QV2opr+dCxx4PV8Nor6K
X3ujtUm0qofas23HI9C+uOeWyQ5ag47U3gKorsoSfg/c+uC+pwjA4mgHIHmr1cR/oBzCOZjSR2Qy
s6sOqIH8HEH4C4YfKUuQvBBGwLJ9zqeXP57GqQGk5yc9P0h1WIgVi8jYnT8Q+cJhEGkp5zcDdaMl
2/gc2TG3/vc48A1dbe1PbX2MFHnho+B1SvWj+awMZHDXa6qZnRf7lSmweEi4p4LmEUP5FTrjL3Qk
2PLLrafuyzIUhso/uexArT23vOIg0JBA3lGlxYwlbeo2/5zEre3HyMSHvCrpPyIqWFiOdnsZIaBS
/Ydo39NBBzmBZeFeJ5+3qfi4Ab1AKF8MYP6yY3seFQDpCOuICf7oQ5HGrERJUzZeiAworyMOOCwX
p1EVGJgzYIHekQdAs4R30lHwPGN3TLZz127GPPzpxe23SyQHbUDRtqpcupp9GeU/Sz37kjnSgJlT
Xyrp2b68lK97b0dUTi+j08L49jP2860Vt+3C2u0xRseWpr9iWKi05jbOkEulfnnP6+UqU6IpCe3B
mfM0wrNz223x2AYrJk07aBsjfoM/1UcgpMXm9stSwLEWRKwMrDXBsjQuSGfx/9l/KD+RWSXDKr3U
AoEZZ7Bfo3CX5hMVq/qIRXsW15WTWxtgGXrtDs0vQiLWJz8cWvoCitYpOdOCL/ot/Exa+6DIcSZx
ZKDo7DX/T3hjF3mRabwFs80DHBQX49ojrAX1TzI8FP/e5EaBoOVo+N8Ra0Unat61QIQJCkfw0H+Z
xWTIUbb6WlUoMuCDXw8l7HGGQwRHrcem/V3M8LBw+ThlKj6lE7dMCMA0t5J5haMRQLATxyJexrCu
zOV34gDFrz8hwQkkuxb7MN01byCoFEfeXiyuW+GPOuHqIPQFThtmPS6TAojw8JpXBEtSgrGtfIXP
cuwe6H7GcmIKDgFN3SKxL8ZYU9XrTPTntCjwWbDeLCapY1xKQ3ulnLra57SazCvVuQp0MYfGZ2Yi
Zu0TtheABE+SuvyVBU4HZnQvRk/LxtqVa6DH6sWHPNwTrjKtC5S7OAPKpGk8IlAj2Rl1iVAwnAhX
QoQZtRoreyxQH2vFSjDgdcXTVW56NrYSDRI6Fm8hxkeamH43QF7KcWjKU8oGLu1qde5HyzeCATOE
0emXb08390zsZvcxY2ecHt+QgrsnTKncgUNYLcL35VuStLxQH/y8EthZnEgSFXGdbu0MQKe8ts4O
2H6yvwiFhIsMiW3UkOHqV/y/ltLP5Pjid+73PgMWzPbYNwX7OP3B+xua1WWVX+aM6Veg+15CKl1v
F3dVhTTuncS/HB0/hy7+jhf2+EsGICx9AjoWWpl2hUJnExPoyubPG1MVV+rT0REOC/WnddpkBp8m
+2AdWRs/B65MGeZ/fh4uUwHwNiKRhtqPmrPVUVhNG2djTmbOTwIMozGi9AyZVHWJFx42Ntz1QgKw
YpLnphymG99kbMDpG4Ql8jamm9q7uNteZ5JS4f+HdhrNCTiU98uX/K8QrAfKnCeArpOTjhnpnQWV
w0nIApR7feh+pFYeOS4bvOxM51nvgNi5NQHZA0Lg4bWiH9Qx7w7CX5XgISvbJox/YmLT/Pbv+eJu
4EBdSG6jELIj7K9DPOSyBv7UfnMpzunGBtXWJ5V879KnN4Hk+t9wk9HbXCkVj8VXoswLYPGAtlOT
md62x04q8cX5Qk6361u2e9DjmJ6ZGsL13BzxukELTCLIBbaKG9jBhCXE9YbUWTbJoXVv41KF+l3m
Sh4HtG2Q7XcDVvDTj/9N3XhM+BnmE/Kyc1ys62zNsZjbAv9ecZajdpAUC0uZsJNN0TgjW+8PsvQr
qF2/gjA+kfB3Ep8/y917rA494QGXUe004eJ3xvcjzyvAowCW0z6yIB46Jn8yFaQ27q2woLOxwTgZ
VcT6DNphRhaz1QGMbW/Ypx8iHcH/kmqw3OztJIynj6ChcSKDhnqKC7Eyvo+iBe+7mXfEKYrXNOuu
O2Y6LYWE4g3M92i+kzto9cDN0yxbCLJ4mW3rAD7/M53CX72xGQzz93ces+8UD6sDyXHhNCi5Zsmi
Mxzvj8N+QBVYri0TiFmqn1LiAz7Dpl43LKpUaHAOLX8gIYdhfPF2OlmsGm2HuTWez+LTLQM9LUC/
CsM42iIIKb9V9XYn6OkZEAoi1Vu/xvBqv32RJTa14SS/91uwhzvAnKion1oI8xRSO0oQ5jY3ioIW
0SFNwkoBbBJdxptPS2j02hPBnF8VZS6Qdn25qqI5I5kxpm6KZ7h1SA2BSfGDuGagrjVFuKdR+eCB
+nVTeFu4u/1QJAYv6rBLon9w0oG4TH+4FBGRnCdAjKu/319zQPn/2BEwcR5BMBiGyM2RG/Iuhmlr
Z7AfXsCRrlyuJDPyKMPV7sGiW2QruM6ZP18OMQDr1ve+2SHxikQHeQb5VS6rjh4KZftURwIMvg7I
KGSeEsfSUOJdyqxWgEg1rexwZMKdrZUWZexMZSxvbd6l9Hbp8eVBJLCKVtLmLF/negho5Y2DZhvH
wnAgMoG2kAVcmcHU78nyV46yLzo8jRZSmiEnETlkXxMG4edluJgtOGXs2e4jK7WMyjJ/pUoTwb5g
n8NmmPspIE4iZSCndSPr0R60OsqbvkBL5d7Eo7PDDCV9vA/N0dVKklW7e8D1hTC3QwbNseIDg7j+
jd7KWuM9l7FdTLmJfbVsFn33qo5qV7yfhdlIpedFh/kihriam0Nb7TNO/iBk68KUfmCtAFJDwDez
yucIsAKoXTQHtxC88xl//Znrohd/x3VqONmAAzzCpBbGkk22PLHR3HxhhJ3asrpKW7Xq4TNtpm3i
rEDQRocpbLTTjRXolZ8h7OfKOJ20++jFsJI1pxvEqOGr3H2LclDEn3Euk0KUIYaHFJNDsKrfHNGg
5adlMGwyawWOmwIncVd1NmUcSAP5egV0kmV+WLnWSycBhC50PzJil+jR0qXpf7tf/yFSp8i3LZ4n
ZsLYuh1/RH/LjJw4Mpy4QzSfDSj6VBN8wGxKQCxlrzmnRsZSsXdAoeXJzaGZ9nchSPim97HY6ZWD
2/H8zU+Hd19STJkmruUFjMaxtiqbvnjPrNAxweDH+pmKqiuCaTybxs7PyIYGjA3xVV9mrB87gsjN
Ajxy0NBVPY4dE5hK9REJvNZftNP9CIslFT9Ou5M4piJI+JXMiFks0RfOZx/2rgqvm1IEdIBaoVPQ
q53JZ0F2EAQ/P6VDnHXjodF+mcpZcXZmAnBpEhcHPyWaxlhnOnZxWFI+4F81xXX7fL7I9xOeqMk0
N+tcoBpGJW3VS4DNieVNnMVpBzWc8HgyRazcgfJ1Z9NhY8L+3yefurD41/y8jjryzclOJbyqt9Bk
ARlpxxQFE/1HntL5xlrcgRj8snjXMwV09+JpKG9m28YAxJ6HZ4+0L2Jons/qhUx/PhUYGB9fDFNl
XCyS3wdknE9b+MkHStdU+vKt/3DGoZakN8gcbJfRk4q/iFMEoP8c/M/rlTp8RrdKqYOgLvZhTu9K
nZdKUhGsRk0E7/LR1Oi/+dSEJ7bcarxWk3aB4QQTp2jWHj2obD16kXaCxr9Ki4XPuEA8Ww+jIaLf
OsjZlKJt9ZB2KOoROno1557KQbsu3plwmtPpTA26xWOzONR2rsS3uBF2XEP+gwQfh9vTduk+fOtc
/MO+7BsXDvl/7eaF8xzH3/UNg0wSXLCGFeCni1V8uz/8AmvVBWpVIH6NR8R3ES65PZAmWNTDkEgT
U4ROu4OiFAPZOO1wQ/PpD/WdWUibG+lgUVIvcMNiC3VDJChi49VA8W2x3Ce1wI32/RoDVAAiPr+r
PpWtVKkKbo9Qjkny1fmCHP5sLDl2OySAYB6iLwaZj8qAa8l/dWTnpl6sfZnmqeWh2io5FF9ihuFn
OBvJjNLOD13weNnxXO7Rbm6Pfxcz6Tk+AGQMxCLDNlCo2eVnUwVmAfxbBNm1F2vH7FkJjEe74Tjj
tKBoImRwPO+/r+2x53zPiTexItgDWEZmmSogGAZ3Y4RE6OXnRPNbcVnFVJ3yKmW383RUgV/wYT0c
7BO1aBxFZzsTRWBZ69b4FZiDK6qlEwbOmWGOOqKY6UJxS3hzTSgsbrq3qnjNF0dkgDO+fZoCLxE5
IaFMoDiBB6cH4JevnfUdNA2AljpRP+7Iezq/FCO5v+Rr/8eT4PCY+7OmvvIWssfsPSHdCtMv9vmo
K/0CF+34P0FndbL03hISZz1ynqLdB5udEPdKyW0Jv97erxHL9INwl6ponDN5RZx9rlzQXIE6+sZJ
rEtGkEDT3IMrm/x2GSK+mY3s/W/EE4Oj9zXeU03TuX3UoM1sU+pY9b1nJQOPh1tsWYFt1VRLPu9o
g08TJwug2tRPLw7Tst1+dn1OFxS63MYnp9KbcgtccxZLKzujWkeqS5a9ilA0aYsof36uN6PvKFp3
IB61hs7ZHVzKHg5iwQp1hgme+0QK9PMHPrYGewchUAWk7XXG99Fdfe6wgfe5FirqJgFkff1tdn9W
Ea8reliUkbqO7WjqqshzoX2T3xLOhKDGdiQ17DUjO72hQ3AK8dN4nSP3PcAhvOwb7se7b3kBpMmz
Bwoqhn0cu9cYW/oexlNcb+buACVhhN2u4iNev7seZz4Th3QmQi/q72IwTTB6nQcaQWNSRgeU6jBV
HD+vQsdDuWqIbXsRbMyQzZki2WzG0TZ/cBWxraWeT0+Ca6gjro8JeYCWk1trSQLt9sRTtn/R8L5h
2cI7gz8UawUm6gIt+PDGoQl+gj/dL3/UNepUBBUr/nxV/IPi/kxSDJ8eVMSLFbLqfA+GbftMUSeB
+jS7TQ035q+qCuISu82qRlunWDxXxGsmqujcHopdpeEpGLkpkNtXzpHFlKbRVm51N5PAjdxQwz+C
/23oBtTMEMN5GtEzNBiS78bfdq0VKx/5xYB0VENDnBNPZ8HEHyh9Wd/JXmgIJVUzPSmvHzgpZOoL
xoz/QHQ+a+INq8Y1GqwE+SKC2onR/WC3sVvsvm5oRIf875/kiv0n96veWTJivKrpyLQgUac6vkqd
e/0Vbl1NmYHD2vryTvAqNgM0/k5jIhlAVqcnqf6x6tf87YrHfSyVdJhf5TwV3DcmQW2FHfl4GnGu
gLLCWC8P/OTAMShXbSiu5bvLZU6Xy5TlMFzCD1zUUArzYxuUtD+YE593FiXdLWlvtNLvMGaFKPds
axQhmmsd6vb8heM0vW0yc5tZSGyGmqCY4bnpJssyGDaXMcKeW9sv79rd5FR2Qo7jaF1hzE+zr/Wp
zBSJMFgGdllia759d9kiQRwzNhKjJ4NXTvIbLLImGghX0PiyVdWjRucc51rItDgwIoENGDNwIuEd
4W90KPzv4L42aqKn20KfKtL5/xH+t5eDr8AjeDdVwF+LvRcMbp5pkrM7ZyW1E82KvKakN80A9I5b
b13sQgjxnuSxKMF0Hi3FT43ApQkborcPAmG2LUtgEjTF7SmIIk4hRZgWGfevSj2FWxSOk6QiEXJt
f+lKo3UTKJQOsqRpVNArQeNhK9E0qs64nk2Ggwkx73dLMXZPg3HG+rBMWRjV6f0hDk/k1pqDCEXJ
7NOU7zdOnCphvtsL6Fzl2S41RxfXt0CXJ+3cerjTrKIXxbRWWEPnoUPZSeuV0IBfxabJb/MNqmT/
8vtYLWOAf/OqSRG8T9gpCPsz4w+tY68wKWDZDZHmyJhox6JGGj1Ayu63kMd8zxDTNYJ4uwlUZp6T
9+S0cyMfDFU6aRn55Y4pXeZrzYI7fm903cLX4KdoOs0IhJsjK8HIMQwjmiOu6oXfqqueqZ7e6BSF
xM4kclaIq/xXDT+eteOkq5NaxSv6P91oYv4V8TEIYJDfVREhIVAGXltsUZp+9XyksV7l9a+qTOkq
d6DVJ8DfrivJnbCAc88AD563Mep6CRor/MBpEG6N3pKA1hXehP8SwINh5dD+OBP3Jh4j98rvQhLI
/fpf63Wwkw2yjuakWdpfKOXrhkRg8jEDL34SQjuIHI7jBYESL02opE5EE+0iip3OPBX/TRTYuBqy
ZpMpg/cS5FjHcanafQPpPe982+HkhX0gdZhoW1ouXMGwhRJfPF3x5ZQOddKDE/MEuWS/eJ6IvYax
P6XxKaJWgm+q6Whnq1FnZCxKzFuiRVMz6ksCQqTSghl3wGP7qQEJfxIyU/aJjbWyfkuFigIV8mLF
fVoMX5qxbvhDnXgS4pFD5J518Bxr44vKxb/hdOgfNBaGWwEzufgWPgwMqGHAkYQauK4/AzFg35K9
C1TufEGNSIKR2xQU0SusdD2Q+ODi5bxlgoOU6KXyIUCnyTSmqOF0Amh1QQjUk64AIc6lLy56b3sj
dfZCrcXqzgotskQPFJw3tlfZGzXjSm+z25DyDp9tRL1kOTv519AQbBfRdCc0/CANkmPufvJh5DFT
87Yrq0XBcSPlF7Bfdc7X66nwoYXt+CBnrMXGQcDGzGqmmXR/zBvl/mwdinpPe7t9oWOTG4rTydoS
n2zuZJLrWIOML/v8WofOIoXAI5wm9c/T2+ws9Iekb/NEOzKAEypIZUnxLXFF6XQ9YPOcJhJY+WSQ
aMj4GAgAGSkc6iM+kMgQXc/wPJcdGjS744rlMzVLfSVxijlSnL5ZgPzciQUCKJKB4FgkTv/VbcVQ
SaI8s8ZLffDLKLQhp4rgtVGSBhi96CG3dMk4p8jFxOFsrDOkLz/WC/skFfi31qvBAYVpGsQ0tI1m
tA/2o4RblYkznJxzY6o1k9QHUzUrqF9putrMjgiKGP4c8qejnCf0C/PWW9ykdTHdT2MSfXK35ETx
51unFeRFA4r4E4qlSxpS6QkoZyTyfjXzdHh+EwRQtfxliQ643smyTaEGrOWSIs9Q+duBDK+N28GK
BctYoS8W2zgeXThx3vy/Ofdk/sGxHRVQfDtjP5dWV11+9cms6mZubWy9jaA+Cqf3emR46DA4e6tf
HcrlgaBLxIfj/PQf8ol+i6n3G3v7sqDyOKhgzWNfS6qOX+byopUJk8sQzhbvNy+htciCwkC37bZy
jRVHEij1NU0GSFfSbvImzI1zyNftiYZBILxn8ChtDE5qJYqnqMTxLOI3sbCYs/32tt0fs9uV4XlM
ZClRwGTyv9ZUGGaf+FynMFxe4n5pQPeMbLYU1ciIP9W8Z/4umVxLHOEv1Jd2YbvKdfN3txamrPo8
kU88EYF+XvaxRvyBdC2fHzddoLXzBEkU8+gtKmWkQ5kgU8z94Q/mNU7chJiRL1ZMt7pvAHaLjfnU
M+itkxd9bT0moD0eXC9qPbDEO0IR5fPHIrIhVMPuo1u3utR6gBSqxYjJ7N7YXwSu0ewmjpkA1EkZ
AnYe2KjQxoXaczfC8DoRsbsK49HhVsRV/P2YzktgRiUfQOnI6zIxSZDx9KXQ32h1jc7eE3rRnbJF
Xe480wHEJ71zdn7PQA0PBJ372nNe8hAYjGORmNxXx9UMl4RYRQlmy2/CRCkrrl4eBVPLIBMMNfR7
oHkOHMjdlz9xDFDWeX0k95Mz3Hszr3lVo0PYefAD9T+ucXv7yDlHUhgFmtAiMaf5kjj64m/8PB5e
Aob0U4kqnW7a918a8fI+787vZgIiPfY0dRn2zmghDpU0oC7oHhPLDtL7q3GxsZiYDIVBCG5Grsaq
Veyv3+qeoGR5bwxvKl1B5agwkQ8J9aOzUPJwWWRrMSIscX9NbO01mcGnyQNMiaQ+nERnEEWSr51O
LsuxODukE+5M9x557TWP9/VmqN5XFtXZYDErVKez6B2CHclpYUWPydxdhac0ZDX2OB3F0Hb9bVQ0
cH6VLcHXACpy447X92KIl1Psm3LEz5UF9r3HheJTPFKHB6WR4kwJIGmwNOTjtODMMgX9nAsEvexW
8R4+r/GXtCc4FZD0i1LYrYF6E0Ka8xOWRLPRjWbitrG/bUU0jMQbdlS2C+LTGEiNk5O8/JiKCOYN
tHQL+qRBaeYgK89Nm+3bPU5sUCUGHHe3EPyVtDLmU80FVis+O1pDQpY8r827qxTYD1NGo21v/vvM
NocTprqC4Bv1HOCOEZcmIGrrqVXrsQJCMZYcVe3G09o4JtcN0E3Q26FezFR5IBfXdL41gNO1HyzA
FLbKNcBTqOA6nVTSziAlBKGaAQ6SjT/eMPpclxtKUX7PFJ1vbaPfs1g36+/39/mUlwP0JbSkpaOt
kLTrZhgzkqlTpp9ghdcM0E5TeHyuGnofl1PN9peqGOi/lMEf+ZH80iAPZFO9g+9x1HiBUj0mcd0W
/wNwraK6uZogc+vHZwVZxCX+7W80oqmksebR52ADe//NjQKOHXFEhAZS9owMLJJ/Jk77k0d3Pm4J
8ZdKzILjgRWV8L21+aObFbVuDmIfr33rusqvIW7CJpS4Pji17Sz6lUcmOHBk/v/qpOTvsHtHWVLY
Hipd7hBAsXHaM8QBqRvLUnDIv+Su8g1dlzlb1K9zbtIC0c4ZJ+Ixto3tMP/DEeWyiAF9YsjP2w7w
JiGF+SFdj6HsXlSYtieQV7SvWp0uxjSI0SP6HhmOvGUTGioaffVfArMTCUe7/vSKMRSRKdBnHAA+
8ZIF3SrbHU9ZqU6cPhd78uDGRm1lyeJvdJrzo2YIygh+E85zxr3Vw6+ew+d8Fmfq6z5JXEjSJ6ci
ajBcRDSgJBWSXUqhbMmpkPedjV8G4kh7kMLmm7pvl1Y30EX631pQJXRr8t4l7rd3G02VNIyw4A9s
xc9dJE0I6WB+rds5j2P6o8uL+8ZWKnw1q0h2opwPWk9jodDsW0KXU7S91FCnQX3gtT/W8/I+1dpe
6NWoopELiMDbCt2bH5LdqJC3ENZ3DQL6j8jAmTAgPyymFlyWWAB1ylAOjriTh3EdLivFTV3FrixP
qi19MDKDWYUvc+hV7LWUh+pimpP+aRwNB5R61ItMEn6OafLIR3n4ga2fEt9sp2hEEKgTKQTROHwo
CfW33jIihIKT4+HqFk9RGUWwEeCBmvtyA/YhIKBaaoEnhcm38TirdxAgOlmW3G+Urw8bJdxgtS7d
/Uu453Q1t0bsDoXhSESMDL4qpKvyBMYuP6+JmHq9IbYHkfyoGbZUTJtHmH0bc9ljWJSsNwx0WhLP
YfxcMdA+Yo4m2yeK0Z4CcYYL3bUiaJ3+2Qfu8wQ6FDKQwyo2kt2To0EXkL2quugrSk1nTJBe2dxp
NO8Qn4nDTiGz6Z+LJ73gbUhpFNFIPPJGN/C5cQ6hfU4nd8i+8n/J75NQMe908l5AjquEBll0pnWz
fkLX8pDk0LuW3swauP7m/ORxrFeKfNQ2Rm5Lbfn2fErecL1QRrYf39ZV75+iJQeFuj2XPDrYRoIB
M7Ih2ODCg42SZF7Mjg4eomlSS4s2YME2G7pdF0GW01/GsetugI6rRJN42uy0Yh1+cQWrqqGf4bW3
uJ02HT+Oa3bnXGfe4qxShV152ePhiqRvhf67k82+yHGd6o4L2969JmhIbUWImwykfhnbaAt2s+Qo
NpHlgo7WRxOh73uedIJhAoc28EB5J0ESqMYK5s6l343vKXMqSiXmgpoO6Y8sgkstoJ0U/c39e+C8
df9a5aDgVatKi6I44KrDgfXdvFSxVtV9cF5Y4VCzrN4RVYY2AVclmTXIOIcPW9BBI9KYhsS3WcoV
fsFE4ybRfYvmFF+wT4+EFRDgVjtkb4s1xATLFn3H1idF10ThpG16QFaXDzZVlatLi4v6rclxP3p/
Q76onlewHFhdkCl2Yt1Rf1g9XaE+287inPE3KNacnNb8iXR5/PBBioGeu3wYxv8N1MvgdLufHK5t
s3niUOWFSGLHiq3iH5gJZIFxHRwgstsFsQxwYtifpfn9Cg96aa/T7aCsn9/oyIFX499r7oN8hv4b
GiE181/o152eYXIAtfyz/BYsxxwb9V4Uku5IudS2dzg3Z6M7WmBk2skLtlghCg4Fx7Hjz0pwGJjV
3upOSsYwULsbbxWM/KB2OiAtAdSFId9+3nX0spsOdkpwGaygz7IOiHIXEVchj8Rp7imuOJvD7BQU
JDIdww0Jgy9OjNyxVtCfR9SSW7YRmoKT6E5YEwyHCwInfVq0GIipFPt/M+fLamWSU6c59+3Ux1XB
frVUcudd4+cGLCRC4UAVVPnBRCtMUgDkYKxFcwDsfte4064CZNDO1sOpK12Q3aCeWxYH1cm7r1qy
QOOFyw0Jkz5RjY3e5Xqtj5c0IKdMqGqWtdhPZm6tI5SBjLH3gDqruRrtZC7G3ZZhnLFnZbksijF2
w2BqHJfq+vP2GLiWVlxEdy2fsgTCxadtSTOt2xYWFWLsPqHmh6Zv+0HV/LpQckeCW8uI9Hu7ho37
vBECP84gZjWeKc3vwu3m0N6uNadU3IsOQUJV0Iav4miYjRYN98BxaF7vds7XSHo9RhtKgHd8wu+8
lMhEL0nwPNtd4y5VWSi7DDu+wD5mVxxqWSt7D6pzIdBMr3OHd/lqzALPlj55HdLhR920/bKyDTv/
/FLxfGLl+PYWYYBWIFySYGVwZCH9Rok+U8fDawTqGqm4LYHWKG5su/pFh5cii95ozpoUFsnVN7bm
5kmRgGCneCFHUkD+ZpLuQAVPU94o9CCilVoIbTqa+jPcw3lePhQFvSYrbF9ZPHc4IHkz7JrmYxWB
4Hp6gwVsdREXK5tMjYMR30XFwiomsz0wPLl4CJNdzns72rc9oDmHedRNKC/WqluW88f+MNwFe+Hw
1vR+8YG8a57F1slmw4YlYIWHhGQsLVJdNb4+IwQz5DoXT4Lo7vCdUG/94y/Zl+06tIc8/EgS5yBe
tNghGPAK80zXEKpgi+8SxD5X+xC1wkCCK6KVwEE5v1rPOYltZvtur3YE3kiExBHKNltNoDiCHac5
91j7lt8AHwJ72hfj2Bw24lniAGvuffu03p3pOl3nLXQm0lH8yw37twhOVaapcJISaB+qrOA18Tut
4D4qj8+GvPFTlS6NG9KGdMn0n+Xj8O1AS8fC2BpP/EWz1cagG+a5SWcZYpEpLG2EKQz9DwB3blPM
4NFUOcshFXUQk7SvCF0i5juMB+XEQAj6jFytlXTMYLB+ebUSQmMRQnCqpf7MKSTU4gPGs4i52apc
lAnl+B2KGTZyQUH13jkXUjXBBYce7SUQsJBeJgnVrgWRZkv0JBVPKHhuRUDsRtIb75D4O5miYsBs
Tb4otbD4BjnXKcCn9emzIpgay4E2rjuoNirVM6UbCvPO1lgdEmbUpUCuI1DiMnPxcM1U8z9sMykh
qAkKQm0zRO1szI0Gsw1LqMpfgw9AVZCy5BUZaOoQCrFxB+xZz1x6Oe9grbS/DLJ7Bdvp5Deh8OvV
z3TEF87En1EUfvQB152PtTNow1ROirC9tHfVmhw7iWdOVoTBKLP1rsEAgUgsmFFbu6n7e+rSvUEK
3hyFnGU2BgA8HDCOHoQBSko0zDFGuNaX0eVdK6DkKqgvastaKKfwbp+zrk/0g30AmtSN436CemYm
7L0ash8qtEZ7a8CUoxPKl2I6Ss/AT8ldfQ2UWFjajIioezvW+YtHlhIQdUbJjf1arUcaGMAQcp9J
E65n/3sIpRDGwT/kDga0jSIPo+XCjlyDnBwYDsy6NQ7VGT8dIlouk99xzeqY10zGcBbZ/p0ucJVR
QKEHGEwkGjAwisVcB5jHiufZAhSekx4wxrAKUUJkyL2kSuH1bP4MG/skD4FDQFdOtcNezOVxwZLm
4mgIuStG/mjuxJM5b/O4pJuL61s5T8HduVc1wE2/xx9Krf2g1Rs7j3eEPpxABgafRLX/KQCcfq5m
EGhIZYSKW7usEaAEhB5GBcPsLnH4nifFvmRnb1qpuQZbRT2y4MGjzVTB3L+0wtLvfQ3IcXTTDsRj
tCRCC08yNfsee94GXtm4hK+fLbebbPbN0KPpAvCoDv0/DXYQ2WUa7WH6bUSii8IsnS9vol2xD6Do
rPRCNBDzoMC1T7LZxF0/WNbt81YVwWzrU2t276YWbnkhlzmyZFC7xrkl8Sk6Xj7oEk7nRBUGXde5
O8suIX1itm85JtOw7hTSruIjhsg6YcP41oUQgJVZjb9xRB664pt9bZbJpkZp/QZXph0Yu+i+dpG9
v05UtcLpNIoycct2LsSIZWp3NrrIcAKzUsEanLgXxtYr17ntwN3zaGB5g1sYNivzfUFmonE2tX9s
94CD5UXBOB6ahrm3KuEmOuEs6lxsmHmH2fFWEv01EN+ocLtUzma71uN5k+Vd+wGjYUMcJTG6VO7i
mLuxTNKYxEuyui1yLdQZadb1O38uBiXq1FkEMlB5TUBeAXxG25WIfv/ffAjMK0eH150wrkKRtFRw
Kgk/+uYcE4ItnI5jheQO50bYCI5Si8TXh1MZ3UTSaJ26smfS4u8jbaiEFBybR/bKqRO7Xm5aF4bI
evpNjy7Cjls9WC0KoIsOkHGAz1I+CeVlJAvCjEJqmcMuo/pNeMt4fHK/C9XMDZuprW3fgHGzIS7a
0kwOGPS1IelnPRlltdhq/mR6HccwviEQGP9NhpHydSDLEIBTKa4fF/rQd8//ho0DQIGHWqQ8QtMP
DhHvjMU/yGJmwjVk3Is6Gixipdw9p39wijTcjS0DkU8hj0y1gPPxxz0ESNLNd9GU/m9JyubxebmZ
/gDFJTRcgANlD7oHx5QMF7h2ZsK53RYguX2X3ZZZ5c5GKd6xUtRQCC4tNlw8XxHmigtTKb7r5oSD
bFnvHHRzoWZjsZ5Oc4VaR0O31RtzI1P6ayd80T95Yzm0LE1ouSOTgH/wGm2VL3Xt2ZDD7wtNTX7v
w4lRjQABmsaTOsShs9/Qk3YF0XnLZdx8Q8boNVypQO4ujBXfpnO3QI/zTBKg+fTkWh8hSCgkXTxa
F853sEE0LBpPnF12i+qbewixy/R+lRN1ITKrAHvYs8A2gTUVOOvUs+F5BhfMbJ1MzYSM+RWMoxX9
u0xUM6qufTg6eQarugSmx4XJ7VOF578mO3ETQz6yPdRAOrpH+TpWqyInQHleEaD0BqXVOVs1qD1o
S9XaKcyKMqHnnHxknkNpZyZH2aKngiGryZ7VO3CsCyppA//YICfwccU1ufuGpTS9J4gnKkktw1Wy
6jCSY6iiegHsog7EbCNuz3FT4smBnAP07d8zAs0EJCVbIlZpFJCMnlD2WPj7NEwJvwHX+Kf3TOWz
BtNgICNmXaWU+UDYGufqDtPfO0ccizNvuhoXHjaQe2yqneY/oVnAGMGkZPrJksmT9PRDopN6IL7D
uEcaObOqOx4otFyuQ09xCofweAcexGNOXV21jDLNFaETrk1YIjMEqfgJUciCSR3iPq28LbEKZ/vO
Gbk2m3Y2b9QXQvLr3/tJk7DH4yKnwUocRIHWbpy2ya45zdHcM5RDwa+i09pX83fXmWZveeB1K0HB
7/x5VwKMJnJ6CwFg9+E7GpVyx5KTKHX9mFZ2rVNL4EqJYtRFbU6ikzqtF1LW5K+atoQQsK8uigh4
MvwSp0Re1KVKCAp8eSUzlo8oh+BPI71k2qNzecihtkT2O7JHCiQqn9ZU5YhWEY+/RzD+I+u99fP6
8VMKnqRj4HO1/ibZAv9z3eIG3tDB8PeenBv3yGzpCaHTw4sftflmSG0fKIVH/exoQfL5Cc/VKJdu
PAV4bjqRwzZDASlu6Oun6HnHeGrLDtAwKmY5Rlv8gWK/3oRZswtNzOCiGm95/L3WNUdD+Q3JWKK5
OmmV2rXq4PIHctL+MRn0GUnZSFWLcTz3QPFCfCxNhADFYGIchPmS/3iS1PGU53V13EklFY1yiNqX
q1vHAOUpkK3T7fiikORwI3PIpT2LidqYEX/yWVTVrqyht5cvoRwXQpcEQdOwGFw0CsEtxN8DkHLg
JP2Sgbukscf3uAsOUfGzGArYxehZCZme/l5yZxw1ta5RCQs0NVn8ZGXVVs84Tqv5g2D3Qx2ihX1C
Pye4ofFpFo4VZT0HnKrZravMJjwZM0v4EhjhqgV4HdMxmNvHA/gnaztHtxFWp8KBpLOVIxZ5hWmx
RpFdHhHY0Ch6rFB0uO15aTIID9VytAAArkL1IaFQk0gh0sezR1TjDD2pc7bfy77MnW2H8XHYS8R8
nKKnHbNBgvm2sbxkOlDwZc6Tczk+195u+nojQYfhQQLc9UTVQlDdojDXh96DDN1CExvSyQ/oLiUF
GcxBLMdkbpRAMcdd4OLd7468hGS4bHupMKZw1VQc/z1YDQQsis+fVaBDQpn6drAhabCgRKqByWcF
37nMLIVKnPlmBSh3FLGoszOr2VsxWUTbYhuYn06RZnMSWq5ifJeAKFIsqf/CILACFsQy7C1ndRKs
2gI6jhQHro3742eQ91+B6LT/QTQvSE3r0o9yCg4KP2RDwySkHsttDXxJffqVH2XvL+q/2X1Gpeh6
GfGAH1IEbn6gm2kRudlpz1r99sDiTObze0TYxcmy59WWzuRAAdHQMrSLa9D1EVdCEYFg4nWMZaUr
ZBtPAATVT+ATsuZJlMJewMJTIVq65DeVbETR36F8eKDPVd0FISZqNdgOQDJ6wFNQ42BhtjPUITu2
fsuwAE9s8aFsmr+MmyvNakxHD1ZpSvaN0cb3uoGs5diOvRBkVGvdTl18SZSZd2VUpOFKcbDxwLN5
1aH5Nz+yUnuKeDXndw1FVmZztdpGfOjZyMo6q1K6yGdCIChFUi2UejogBsL5sZYGU6t+iFVt9Bb8
mQWNFcCLflTtMPq+dQcf95iZ+DIr4OzasPYmWVORrrqVcbydH7RxxA4I44SBWFtVfPk0VJRGxUBM
9r552v6VSWphm8jB7akG60mgANWv2t0Rkh4ghVjZYcnVlbFxGUIYal3Y9m7UI3mgyCpqcYBMUKqD
mofnsH2aKZZsAPYT44Bc8iC4woeDbGtl0lpKqHAqFIjfW+/jKLUcjfEdGrxRJ/Gqy+TIgZfryDrO
GQw2gEsW+E/5S4BDHSRLlC+7JjC9R86O5MvqeHDsv0gt4TyC0VB6+8zL16jGBs/ZqpzqIsWj3Yml
z80ESjlRBpT+oTFZxmzQFMa+2lrzDeLY4pdkFr9+tDUYFN2JRZ18Wi9B6X9yRrSP2Dj8wyRi69CE
9L2PmkOT/FeGLpTQzz/4vtba4KGhkwNOyaF4V9IsVk3osiJommv8xrOxW3rD4zctv/ZD6iqT78Dn
H6oxBGTjJ9y+ki8MQG0X5RRLnLx3R/HtJKh8610kYExQNhaIENrYQBdfp8ZA0AsPWw0gE/iyidyc
qRbIOYa55ASsJIWblxqw4QlOTuFVsmzkXU/J7gqm2zPUJFb59+cqUVSLs5vMEKqlvJZrBgcTXCYT
SAdqKV6a4pK5mDk0L+YKQYj4S1ybLdP/PEE3I12c1iT5Pchv//PhzcFcScBDdRZVTcBQT9NNRawl
uXeJtUl7IT1lZX8dZdPCzdFPTlaVLYPR9pfNMgSEaql6xLCpemOMUVhsN11IumOBX+ogBLKjY9Kp
FLMcZ7yMQgxu/3o11UlJtLhnlZMuqxWgaTY2BGw5obi3YuzTAI89yix9BQDgqzH0W1jGvrzfPgTC
K++wHIstaGnnc+reU3Kl2URaOawgll8eRNx3JqT2FOy+QG016kN/29pj5/WiKMTKq+ggKTD6skvL
S6/VSgdx56KYAl3kGD1ZumF45yhNnvcIKDz3LGPxS5XS8NMPJSzzhbbbVRO7XCVKbhL+ZVyvO4FD
dCnQnLBuvIg3H7vXdjJF0OdLuYcHrWsxGrjn/GkvKIk5b6t6l8H6i4cPd0TUTkCJs3VTn+HAgTrF
y6efnT5xzfP5Rc5e4LIqQYkMjv4gB9kWR/QRfgZqEf2rDn69DhZdCa72x0AF8BQzehlAtdWtnrZM
17h4fEDFzUkZlAAmaGqiWXTvqmNZ2oJTffZUYRhSAUqi3QCamQy7r7zvFD/zyjWm6dUfNBQrfWwx
5V8QgZqp9kcPbzrdGAflDXxSPVs57NfUmu2mWz3Lkg6F+vN9cAkcLjUO4ywjXRFS53z++7inwhkC
fnGmyUAQB2d7UkglLZSe0+JYxJhn90fqU6wPe9ecuAhTvMjMsbpq7Gd3HOlGrEW9c1ZcEUnAWvCj
LnRX2NZr5TNaB2WnEDWT6vJ+HluSjLlSckOcdeQLdqmkaZ7wKHPyPaRliWUgLW29om2oxuqDfUNe
cvbBV6KsYJZg7G6rje2Q3jqnrwdLJe1jvDpI2zwSx6b3LY8tL639qk5lcmTDmDNZjy9Z5VmfGPFl
xDuQjrGpE9iA9L7mKxsojLVwrEHe71WGQf5pYH9xxmwUXwO7JEyxsduemhjQuU6Wc8qs+eSb1MsF
ZKXlM8k64yVqAtUpfJamKAPD6kEkUW29U4yOoxxVeyZc9iD1X5rz2nbXE5GBCdU67GK1nTTkfit0
bJqUTDGoG81gCNRg79sVe5g0FnyuTeQVm/4BaFvySweXiPIWMquWPHiKjW5iQFQOeLvvPJ8GQxxJ
eQSjmJVqhbAlTqoaw1iXRQw9DbeUGebjz3d3/qIDl4KflN+MwujA07UW7jZie7BFKwCwhCMjkxjE
V7YCdb7aKitLdNImqanDtYsA/2j9RrV3PV1MWs1aaIckATxPSm75kWnPVWsmKJAc5QTbwTviWwt6
FQQdHcylIvV7ixJ7itfP9om534QzhLmJ0PiKoDBn2ICnGnNo5/ALLGRfq4pCwk1q9aAEAnwIgnHq
XBc8TBNxpcMHBUcOCowAh77p7A8RvjYUdMWSKEPWknNVVJIUkicG3Jp3eEkf6HphW8dZedmL5Q3d
AZ7Q9Ns1/1uFz/p0bO5Iv1WGR6kPfyl5fKqX/QrEBsA8dWYM+lwDhvjruuVVNrM8UjXq6yxp8vXu
CjTmv6eP3C3ATKDrHeTqwOHZ2dCPQK3P8HAz/RzLkXtK4i39z0BvNX+GfUSRmF5aWfQ9bFziu6d9
C7hz+7+IcYJzcrhdlYbbjm4uB4Xr206cnrXe7fcG0M95mOns0VHt1o+n5aSQFw2rMsNnBbjKQGrL
4A16tUViPaqvWNiIbLGXDfgr2yVQLuOWS23anVOx+4DELal9SHlXnZBnWqGxfbImwR8jZWPBvptk
S3pSeZcBko5v77r7rNwjJFQdITkJN2RehV/CsedVxtHw/QaxBQqGpfxVNgGqSo3BPJCrFrdJgktn
IT0Ok63cEsteojbdm279teAMfVdGBXAWh9oZX5MMv4qSJP+qwQqoqyGPQUKgh8k4TiHbqS+U8GzZ
A5hXi6jxH1nV+mHIsjAjtOI2X0RjLifLqnHRW6yKbO3a36v7Y1GXf+yEAAhcE0K/GpuUzMGWX5rP
++hmDtdCpsib4csYep0Bz7cgGAHJaCAGpDRAhZ1XMst/v5Q1qIhkhXtyyWTvjlO727DsnrQJyB7F
Dc4DoFG8hE3ecs+XW9N/ngROfcU+zeyVkXiIL2Vcedy/DaZ9B8lBYBw8y07MZtwbD4NyT6Ecajga
ALtj1D/ZTG71BOvtDehfozYZNnKGqLnve+auCRGdxhh5vz8NJbtY0XOUH26SRvCAKXyQjI6WMfoa
JuNS5ZoXXDAFFeBnbXI+MIh4jjpxupmeFKTBJRMM6nkeYxgdaePuLFcjgTh37tyAwc6guHP7hi4O
fL6yy2ee8DbPVo4pTlpzUyzujgZU0RzM+smZQ+8nlg0NWjMv/Y7+4Pp+GTe2+cBoSbAgJH+dOmN8
gQtCfHGNOE4G/HAef11GqG2KkuOqDrQCb8/z80CZhnUf0YYH4yJrQMjVe9hiv+DRfR9mnArzEz0j
IhOO+mXb4PKTj82z/UHwNo+0wb7WBgvEUDkfuaqQ1BidgkJhufALPtdFBakzmTErEbzZmYwJzt0B
N/zn9u1/Q8+oJ8G/lei7W1OjGRmPGGhrIttGwN9VdMm8GoH81kHI+cOrhGVRUX2y+OMEGEXFQHxB
A+zPQvxJZN1lcNjPnePQomlvVqxELfn4LdrRmRy8w5d/YJ+B8RdWcpEstS0jBxBrPA+Jtx0hwXGl
PDYA65pVTv2kApx6+gQdgYVdaz3zqsS6GP+0f11L9GcURVDnNOqfbzsv+tYmFJ8PgtkuSLjQdN9G
hPMGm60gw0bG0l5thboPyjX/4PBhdaLQ3HBafYAnjBtCYn9N/+0pKagzFVxHEHqEDpvGVPAhRSdw
NW2sN2LqtNIuf5qx5ufpEJqVRZ7WKtog/ws3KgoBuozPVv4ho/oHrkIRdXVkIs+Kf6tjS2Rm/I/c
PC5qSaiB1ON/vPwn3R9eXQMpJtN1B0QQwP5CHdSieIiCtbfyJ0nO3AR2lXG8Dh2BKU+EmxA/E3lf
DYFai8DkevUfXEZRUZ+SArlNV0K6h8ZjIPFmQPyY+f45Ls6o8LrkFFThxAx6v4yrIy9DBNKY9E+B
rPo/V3lFiZtOLGTE/k0rNPLzTcDD7h1FGFesRrGsVtGr469iQ3rIBJNJADyD1Jpgl0owboKSyxGe
yoNxhhdjm1aYOyt9lf7iel6DMgBn2sW1x8YuMjUhvkPZ+SE2X78OYyFyW4xw2wbZNA4ifq7kpvky
azbHRm+sNpS5deBXCxHP2UaKa4g2LqJfTiZRXXdCXOyBbNRpa396q5+5/ByAK8eCJqDHjPDZmQ56
mzJtJGZUDPWQCsKy5bslMc8TLkLeC0Eb5wktkyi07J3MH9pjP1ac6YVWHICtMc7oeJZHrxa3FrH0
JY7rU241V+rdxolNvpVminWKpp/t3mJ3DJwjJ9zBS7jqruviL2xereOxUk31+op3iBrGwhQUe+12
uAfueZiBBNJ027rrHutueUSfzbhK8/J1QkCkL6GKS7EOa6bXDfALBwFAvpIRga9rU+sAdFGTnnwt
Su7FN8TSlhkYg3YheAUR4hxVKouRgb04eEId2vxj66sh6lQ3K1ESWtomjafOST8DPPaHdTFu55mS
7OCQnjAco7rurvai5G0lygUACdJg+dI5ZtMb+pthUD/aac0vOKHdf5XAG+qlpa7z0Y+zteO/3wJd
nJiCF2v3TSIN/EQ/oIaYkitlFyvzwXx6GwDCTRZJUTR5Nox2RHx8NLJgyLiHiu3lR1jIb0mmi//W
BOZrRyNkPBmpxlswe96mkv2mjYzlKFsMLEGDlW+Qx4w/+NCcc+yIqELlAjg8COnul4U6NBZ9/qff
RxqORGsPxlpwphl9V3IF1K0Mn50n4la6nzn6zxNtHzpBWR6wY1thWmM81O73eIpazmna00qYrKct
32TG47zGN8PhPKTvCInnmGNOUftfvvfDXDA/xAfDLVT+OoRI1ohVE9EK88IOfIyX2sUmHzjwivn6
joseHkADbolIj5mZgRzXCpcJrfBkCJ3jhJETd1SBfUu5TqU0u2obxo0/X4wzjg8ZMCm+KTHQgIYd
yBGZzBxfwS6r1VHFyzLGhJpVo6nNSAdPmIg7vH8wBktwe8B3oAlvbpPvtJqAuwrgpjacrndg43O4
weSknUzFtLvURV0XX3K4pDjeKmN0UrMc2uB+SM5t2EMAHqMoUVV7Kha9WgAC88+ZE99N+2d7KK+2
2O/RdFus5FFx04fhJxLiX0nS2zzQnzomgZuOdzO6E7nyqyOY1UOLaNzG5WWOGdRDZCEts2UJNN6h
RoCx6rTOb5p+m7F8CpnIBeh+Jp4ltwm+3BppBmdEoK43ZajYo/8hG0QoJ7G1rXj/slra/WsJI6go
N5u+ONmQHiQX3KoDqzmpsibBemcfBYME2WauOsXkv/o/lLZZBvTqGCy9/RlsGK7H2bhx+TQkHPBx
pXp/S/vWHHNDGGXMiiPjfwnQOlNLHPKzbF3+tPgHs/ITdMc6luCMQO2CbFBLwI8RgpqOBjHUFEbY
RnJ4/a5OAt9roNk3ZELJVlY+OEYDJEE2Y6sHWFVYR6wgQzH9xTae1qdh8/ihP6A3uHvhqFevLpTC
N8R1s9QlJ42oav6iE2QzhiLZxuejTFYAgMmkjhU/m9UksRU/F21ALTiB9lvWa8n++/5nzZZF6rgB
GXV37fZXG9vhef13Me5eYmadAC9yiVqRUdJ1ijfRGVSmJ7sA8fO97AV4Gs5DUqoAaTGRG2oDD18U
D1XZQn+j0FhFbkA3XPsF7IGYmxIuyCVCX8LtGQaM8YkFAjTu2/xxtvCFr0S9GK6ITLn0s/L7pKQN
T4QAA1IoQKLb2wCTHwMuNpbK50L16S8z3QALWpwRrKarlYcBJTphDZpI+qjNcSZrJ0obSPahLWk8
wkW3v6LjHdRO4B+PGKy6t7cD5QQzOuSlbxqDP0DDNyTv9oFqnlgsQebMpaqEatDf7rtxvyhDapdx
4U4Pu/CazJoqZkTCm2dU1jEYJ45nJ7BiIIiM7yPmjI/94JRnrf1qWgyJyf+ZsdpxGI/OVTZNt4XZ
gYNHAdF/UxwR4RQ8J/0YRPOGhpw5g89sHeWQRExkFTlMU3pcu0fJV9O13d1t9HWhCJh/FmimkCxV
JzzQJPpUUiJ1WypSmCyJr1WsEQSK2lTlRf68eCFvtrs9DkNnR0IP8luI340kekdGho+QCjaf+5Ey
tJA3iXujo4PGZ9X2tGsfN0hlmUv0bxNRhMikKssxrZxDXLdEG47xVZH8Utb+cfeMIeLvYeFUWA8/
FfkROawM08X2q0gFa5v/SWOxbe1U2vOsSa1kJE7GUddKgdsbZvXLN+fd0aSJvvoUdWx+FIVsjo06
Pb5+2pM6BNx1f2Atx0E95vO2Bpx7Ci6nELbiZlEKEa1Bfa+gw97bSW1GhKofHka4DLzJuQmmdAF8
zoG3JXvN1flvVdSgh/pKnmQT8XYT2KeOKS0LGekHvcW8cYEbxK5LKncsxh9v4HBzWyvGlT27DFZi
fSrV7/KOM7HR/uKqWgtHkXy9fqphS1WVA01SfWUdgUWUi4igb43YiQrbHhqMOWel0LLukMseDesc
pQAv66Merx+VW0x0LYImMNrq4fO5sv0SBTRxuz9BIEwm6p6GE8HFWxc8YcX7P+2HPUj9Uho8tmd6
yoErpx+2VWCY6hZD4zUXPXCagon4TI5c1VaDxnnbzWxOeVoFelFyBYpY4otUMQdoBbXfCxcpkKof
SUNgdp9WPj1QyTYVxHPDepEYC81IDXAvLcxCa030604QfNcEjXNh3N7SMUK0lCO2weLPPFuJP235
ySOrRbLk70SZy8j6h1f8qXGjaQa1NnmAwsscx2uoqumUf6rGoZODWK55aDEjJr99+Qb3h/C4i3Tu
THo9YBkPdASkiaJZed4kOBLJeRHytjM2VNZwAXGzS2/BCtRDqLP3PH+EbPMcU2oK8ETCzhC4fVLo
UchoXQ/Y5kyrrpThkFKJkBsuxBRP1D1Yp/MkQYf+wlYrCKXVxHrIMt6Ehl15z6tNsGPYMUKsqMY5
G22XTLEFkwtM6FOJGRvjjswEvYcnpjz8xhjvaoSh5PAjZ8iw4xtC4hAR9fhhXZPdpaASLD7zdTzK
7bVg390C+UP3cPK6T+ZXh45r4yjGi8uhE+SySMBQM+95XVTr2m3G1Ul/soQpZ5RD/adpTJHiGQ5g
8+/bTXuctcVyu/pGVpkJadFE5zb+9tRB/8FOGGrElw/S/+f5AkmcqJz8Q3iALgomChK6m6/RN7Mw
HSlkY3JBm+50qrn+EzW1UYcydjfCjEKxEXdkq+chwWFKv16MDHM0Tb2utA9VcfZpjAvjg30iZ5Xv
AOTvKiLnRIJ3wBkO/ehJHlWv8+kVwRRq8oE5/K7TaPuWut/bVQb0rrSPLSdHuLJUCnRaINd23+Fm
MFFBaIfS50PTqwOHTdJLUH7bG7O+1GO52m0hPOMch0jjOQsSnckBk2xSqYvvdgVmiMRW99S+3TeX
Cv9cSTC0pAUmDpgvfmOOZjhIN661qVuU5CR8G9miWD5iz38V+sd2EXJ1PN18m12d2yC3aibclPAU
pbrmAQ2CQgMagogiOxfyqWfg2Ozj5kzN3XA20edIJsxmaSugH/atNKl5IWaV5dKaIc8A6fh16IEQ
54b32Stpt91/vjQXfS324dq96XfiKxzIMhu9ZnOffkeDItP46VDSVM6x6Jn6H/pWarfLGbM1eH6O
XKwlVCCSWpUYFLvGtSiv069mUvbYMlMCry25FhSciRZpiEflRwLzjI8gwI3LQ+erziRO9vpckDdE
NPkKPXwpSYpcWGmPBYQGpQYT9cxL2nkft/T+zCnDCxoJIRfEHEhhTK+s9d5vDsyVrNCjUBF5kEXb
M1zo+E7bE7SyX/f4cSRXsRr9K2me2aNcK82xCqRK2lGSuVt9ld9i5Lx0pn6UUEgfwivudSDXmxOi
2tvouDCOfk+crcQrNqGyemZOIRxa1kzTTsaPvP/GDSg2n6NGCUXo+su6t5ZXqwWbe7aoaTFn6o0f
SNmK/fwYY6DupfV1ODbKoMGl3q0cI8GdqiogIiLgA6RL1mtis87Gz48TIjUiyiGyynFH+82VAPMX
Cr5SV2IBjuk70yUYfP/X4eXhZcpMLF8QlkCV0tUKNJq8VHJH3TMvK1WPBFHnePstXyVM6rvJskpS
lE2lI0OmePlNHE4QrCf40IYx0H1+uQWFaehkBvbL8n0mSmpUgiaHF7mha8gSFgJR2qDvNY4f4Ntv
CER+P8i3/XyLJaTwG1rwBXu9uyNy3Eu4mip43G6fWasWNXDMXs5Al3zl8nQj+y3r/DkIXTuMa+ve
f5bhL43praTnwoYKxvSKfDb+bK/orpAjrxI69t+BQSP7vGvGbe1mMbSAt/Zg3PEsAOP/Y0NX5vw7
aDmgcri0ELEnInFpeQrv0U+GZnSZQzoE5rUEezNW3Ekqc4LnYy1/Nc77oK6QQK7rEuEOYGBSOpL8
4QZQZJ2mZ3n/VmzN0rUVmNsG5/CHs9QV1PDr1uQJhs6MgnAb32MCMtynG1MMchu+R7ZGhH6Ir4Fm
rh8L/iPbCHB//nSbQQ72bJ7CBzUBLui9QGuXSMRtvk0YrvnFT0P+HoFsMojFo57LTs1QhEqfQo+8
3Ya5FVWm/upHd9YOprj9PL0OhtZtQrBnoBbf4FUV1b5MFchIjFdwS5ijbBdU7QKePvkR5uFsPYi6
qkm50+2wvrZVpsM7S2xev4i7a/VMsonolJfR1qAhiR/PP0JedhyxUouTbcX3t5ZLxG6JMntQOiHM
m/se/L0XWaamtuv9Vh+YV2mvImuHsWA5/vKcRiRSGMfkx0rj2mQfi17jxxotKFpRqaCPyWL6cKTa
wjiVY0akpdmDPak0NWtyPFh1UqOKGSR9Fy1KkBmpCn8mjoTM+OYBiTWVXuqhndVFpYV3TaBE0VZS
pOtPzTGKatiPHjY3ThneAdDJN9a7nh1WpjiOhK7vlq6Gxvp+dRt++7pDhmrSNJ+6cK0e+QbdSUkg
3Wpbvl9QzCmFgL7EiE0KhhwLWPNKF4z+TIr260HKPjogmIYlYX4oGc6w7AqdJK7rofmKQVu8l9d1
Yqfq8+w1ujIMRveIg9xSwf1vv2hx0poQnVjzdJrbN7PMuh+2jb0yS6IUs5NtQEqg75/CbwfkzF7P
CeyGl2u8ZNN5GyQ9bI7CtGszpKVBaPdjOXI+RenWZSAPZgjZjRBSHH6VsxSUlC7DxmYD8zw4EqIr
ixCA9XK+GQrl0ySI0LNbykTOZ9DbSB6mAJJ7DMDoeruUG5Xsc/zMzRTc/SQzD+FXfXUykhnrLn5A
Pv4oy08XlwTQZlF6YTIkTYS2Efpl5dRA/7fXqh7h3PWam1HkIfEmWEGjWEX+arfll7+Wg3FylpST
cgzsPjkG2kvRvxRmR7Blg1uKW5Etoba++0AMHTBFKP5MCIxm7frg3+vvweU+WuHZbSHZ1EWit7/8
scpQSsZoF7+87FoI36MtxD8YWExz+3T05PPtCu7SolVE2UcWRMxsSO1wlFPZUMLPQJLGzmzGqWCW
y+nt0ZOo1+2aXHmCFD8F0WolE9a75cnbviuV0hAGLTuCJBg6oo5QHQ8AlmHZpRzo1mBCol7Es5P2
hTOYPTlUs5STO2fZxIEy1eirwlZnxv1f28CHgq8f2foRfV8v3oUvKN05v5jCkH5Fy5pFS14Zbg+U
c00BUndwbTJTT19talrzvwK143dY048rU5EDCqT5Zm6B5Af00VrqAIpa54gyDpMZ9rqGznk0J5am
xe0ffftvg+qDiOLDt440SGVg5iqMYThxsZ6Sl22z7psACrcSOpChG6qvqw8a4zkzpOd3xnBnnNFv
RqNQz3zUqUcj9NQdoiEHZbFT251JSZoFylf5J5ueLpYPcEahBZ8zQ1Mz0fo3KTnOk2hmWWaTyLBQ
StFB+3WIjbCOYoos7pbwj3ExsYOabhzGgmy4XcAsY8GZJLKVPf+d/PCiWRZ5iyPdnZeg1yhwMG6z
d5fk9NFsvXc02ogAlZPpu13D6N9cqOc6loEV8EaYBaLNgfRS1SMv2XZzgIVL9Hw/VmcADSoaV38P
ZGMWMljfUrAj/0pbGbD3/A3XYt/aRu4ZHf6wWV7O0u/rgZU7lIr8dyP95jxoNba52C6d7kGvHdsy
acEP+5JgmxsChW9+ydbKmhkjuUMLD6L2z/5/pa/o4/u7MHfKisz+GW7npvD3U072UNbLZ41aMc85
hz6dxPreNR8hpe+kGZART+Nj3PNa6OOVhYN25pgd6Bnyb4QdUdBB715Zqe9+CShc0j4m86FJ/SoR
UbaX2n7PwDyRJCxdSuvCkBGYlAEAApNhp1V/XvXOZQw6b+L5aNTOoWr4T0zPbX8Rfo2NEcRRTIXi
YIrIpqCLDoGk4hodSUmBoHnK7dC41REBos7/9QkPSBtP6/yqpSLsubM5Cy9FoU8eKBNw1IAZr9fD
2HJfEpweAXnLKO2MNq0EQ/pa6zb1Kz3yxuhFtYzS/QSIRLn+XUZxahZO6EPm6xGullvk6OYNjq3D
ZMN1pm7wC8777izibi0t3pxbNdWetOrwkojJ9cT2LK/czM7Rjwlui8B8AZ/Fw9npMy68ViiE4NgK
sGygEaWuGbcKcrGlI/M4h6miAYbfmVjA0hfhKDjGCP0ZHZuQZwEs7cGgWKgLWyjg3OZzyR4S03dr
vpDr4DPqENVmPO8cdO/gkX4t4N2NW9Eu7oY9DTs5+ALRtxs4ct62xJFGCXQVY6L3i5i14cluJLQl
w/gT1JFPgNk/2ntaMO7JNXhwGfvPX6OSmehaMnSxrKTa1oa8C7stc/NQKcoPwSb7ijA1WilwoZp0
yhDlGfQVngmO+rYH7IVKCSCWCsqgz5AmMgxQcZyvoOj+S/U8xe7Kgw0sCcySUnTC8BEHGRjRCGI1
L5ympcK7nQTafnhIRCp2mpNSRBLIg27Y3yPpkeg2fUZHQ3a19UjqpNnJOMVvVr+vakqf0cZtdN5T
99LFAsIp8XyeorGbXFGnigOQ+mBoLx2d/B+JuNDI/QGNl2DGI9FzusYAWzbB5fYQc2Hr/6hiONBW
doMRQkCVW7DxIbK2E6dw6aRpLBLQJeQ/xLMwXLimb/kfGFBvHHOyym/N9HSuIIrvHECWwtccKNXG
y2zs/v45RmmJp496H3BXVePoJpnPL77xy9TGV2ZoLyrchRYQPU+j2scOauljc8UNpBVdaGYfcMye
a7pv9mBz8miX8KM5H8hsUagQNNQyL+NRudzVhXB03dIf/2OWGyFFXNhW9R5gIJgdabFvR3ztfhpS
EiPwA+SZk0X6A/Go/9DUTkB2z37MYNQh6HGLavK3CGOhhA0iOgWOxBPq0ULB4HruYYjfqUJd0UmX
9AsBuH46HH9bl2wVxZCYQeV762cJ68p/EHq7adkS2ci4wOTDbDBDT1e/VMsNoRWHle8u9fX+kwHw
6SYuI5QCQo4AHCN2tNztglBnWigql9GEdu0TdH7abLkja3lBZHFQWv1UW5T+9f+B5LuaZ0KN97/q
eRoTxJPgf33kgITqETt5Rg7abHn0Y9ED3jUFD5YlfoT698YYiswoG7tHu9IBj2mN04uW0/dIZEkd
0f8nON+PAwf5+3HPz817pQktTT2wYPdnSE/Yt73MMiu6a2fPaluhEFXrUvygzyNQ8LpjVlDoMQae
bSHcJoTqcch8Iyr3mbM93VQAIjdaNpMUWvF3CxIWCTKsVmTrT9k1CkFBaTH4RFFEHfgW3YMUWgSF
6Xb5z58L8RHtcWWodPUg8eFeSgUjpKp72r3J+juNz55Uq1JnLWSoXfsS8uy2HwC7P5Vkza1FeTcC
ozcBKjHP9v/h+k6QFZwsE9aKXIaMBZrFnj4hycxZr05xAcwgFF27s7GomitURj02WZT08cP3xF+I
1SeuHZJzszQ1vqd2gSeWpho1q6MLll0ZnJ88GKMg+rPsb7NQtsTJxKL3uomm9CXhy+Ac9NwMBP3b
PUKMo0ojdYA+tbAbBpKIXfTsfcakhZ/0xrGYnvwJvJLINP4PDrj6cGoQYxjYS/+2f5WXNEJG2Uzk
+Ky9hbZEHdpK8vCtNy48VZ3vybuSuznO/gOmrEh0AcN+Gvl0KhtnH5P7Ag5K7IxVcNpBQHHCCtWV
Ke1Axp6//A90Xa5sRh5IYzVoOR7iwU90unREa1wVDWIUGHLVd5NSgOtWpYxVOXittPskOuLf3/RF
APV7jSx0BlJ5EKtBWT532kDZWJYU3sRJl9ePYWPPN4zk5yWsFqLo0QG+51DKI7d32p8406iR9L6p
ai4DW0sN+f3+49lbTq9gp/s+h2bga3pHKXaEAsdchOhvoaV9AK4KQBfRMbMP1Vn/EQ0Za8MVTEoZ
i4BnlPWtiMgu2Q4HUkv1ItdTLSOwt6ZtTVix8e8zYMpeHEoDi8tICE2BSWgMy1UbbePKAiCZ+QcP
d7INkY+COSkMcNYNiv2Or2np09zJSw36tIPoBa/7zyV3iwGP7zvMJ/3lzv1VlB0gR/SdTDIEtlX2
NOBuyr8ikmG1EzDotwZfSJ9v54JuhLoMbOPTrWZEWJZDdcHYQs99pU82zDUNbzoCtpopjiFfTvJg
B4o07/PVlQkce29cS/QiKJTUkY1nZxw21SMDyu74lrTjc5khCBfuspUl7qb0pkpM0GkBrXuzsB5q
/0dT7dxaaF1gwbCXrQdouqEAr6Kh15EDVAY6y/nElZlBIgLktb+PjKD7WXcsK8frH4RZsRBZjmTD
xQxjlkia1ZCbhM/uxW9qyF0ga44k7YGZQK+wLa7ySNNawgepB086lkUrn6OXdFPw3Xqe6eTWYS9K
7afEo0WCvSgQNYk87mpIg796mSuH7++HoArIbeVslaoPjJkTDG9YsTv9Ywrv/NGNCwCm7EsnjKkl
XXYcpiMRCVcVHVVRB2hUuA9Q2Cs6yZXh3Zi5UMYS5ne3X4zid2JHHnPKGWty6L7a/LfNjrRO20A0
3ZuPgKHpMi/+/Nw7of56UvinZzk107uYOpDoqvP4+arcqhMS1vbk+60D6k7rEWsaPiuEvty0WBIu
jP9bee4KNDJnkLV3PTvrBn0ADk/qaugzNc6TSURYyIoEiQI6l/BUTrawkEkzASNX8oD00WUlWUqW
Quuycm1yMryh74w5IzhUjMN7gLH6tGrZvm8EWEvSh58QQE0kAH39TwajXj1zk+yLl/aK7pEdW7iE
Xo9SbPH/9GVkO2nJSB1VFnltDhkeYOYOIxTHWTxOikUHlVqAo3BbbhpqqQz2yZNeOrdTnWBUjGK6
ZQuNicDpbD7xIA+Dh2705ERb2IfuZido7jGzNcEptQzJAF9fnIZOFcPshpfy/sSYd6xq+CVUJh3Q
u6jG48QFU6ElMMei/i7RPxh1Wl0te60JJdh8JOZRjMa76EOqJIjxyjvTY53LFxXz4+MUykWBhtLY
7JrGqgl+71T52XMqFQNuYCVDHj/zHNTsUj+sWycgViOM6luoH266LMnm9JQ07sRRpTCuba8/+RMp
sg8O6ePodmMdz+VjdQu9LAxLZHmgxbJNajYWrJm29c4BKgpPiB49ojBTjMmofE2CHi9orKNZRHDm
qi8K0ysGE/NYgixq/jJaEAP9nvtdXjXc1F7p3I0B5grSl5dAqUZJBOA2wfaG0ZUStxtwkW4ggcTU
c7UwEhsC1IbwZ2YF/TnUNh6SPuVX21u0DZlS9ZZnSktNlyH7V0vdhoubQl5wJGIvHlgbMBJTq3Np
PKUhpv4dSyXblBAaV856d3Z1nEkXs5P0zgJkhcXsXuUfqFYEC/j9GdBte3bqcyy4krtHRpyqxhPK
8QxwriVlK+y/p/puolS0PTwt8SnnJPtig80ANl41N2JAmdNGPxT09iRLinyY+Gc+SX/luPya6DBE
z0y6YMv3WaovJjXRNh4IPsCQZc9FkDD5j02Hz5JVlAFT8oS3gqGQm3BYUV39zEFZPnyKZHG/3UOp
X2ZLyy2ASZEUEVl36pWLl1WaHEmiessTQXrL9ESMmr62XD3KV/u3PhcExhhv44ReCiTnVEPCeHK6
CT6Bg6UeGtOyU+P0RJDj5qVI0t/reM6sOQ4aE6VG5zqSJdEXCsJgXxia3rkDSCuzRR+aoC3aXm5q
MfL8rYiLjTVuh6q2+1Kc2ZoMQiB5EdVFEZd6tjFehq5bvQ5Yi3LxCtZH2LYMaTCRwm+3kIiPK2od
fYSnWVFjYkaTilGEVmcjPuLHY7VB2Ok1dzB7wFHiXZSkfXRmpNss8onHIdhY9G7p2ak6UVbT9m7h
H0jm+I2ZVGIOesM5IbJYHkjzP23T5X6p31Sh14Cs9chlqmZH1pxli5KlL3fQRXyVSrbxdQglqKtW
4Ak2l8QaPB6jI1+KoHKDyIICq++BRiMQxS7+kjB2PZu+XG/hUVhchR7vpjUensojxIocWyDxzhCD
ai/n0Pbh4Y6RDHrtF7m5QfMppuC3V2knoB2X55N7GLShsyLhthg7IXri1sd2ieEmmtAE0E2zDdpN
syIXjKDKHyJh3zz4+XYLVFJVduFVVBOQO2AdzylbUnKHRLHimSi33dpIfYIaIFydz2MuuqtgC2qI
R2kkL5nJ9MUm3iOHvzRCaBLJh5BxgpTRrBmqD9YPMKgVcMLEs+iYS2o7cTP+K7ByD+CxaP7AOqJ5
ym3uW5+GakuU+h9wL5z+R80eRaWcDYwQJUiNG4AFB8fHP1l2s83HbKl4QFP3YY6Lqn2MK+RNNGMW
Vrsn0whztUrDwxiBhG1AoDDHLRLevGw44iVeKuX3JOxwwPEL
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
