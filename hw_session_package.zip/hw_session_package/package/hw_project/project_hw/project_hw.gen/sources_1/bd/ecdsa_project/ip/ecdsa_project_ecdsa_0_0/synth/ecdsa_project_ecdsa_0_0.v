// (c) Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// (c) Copyright 2022-2026 Advanced Micro Devices, Inc. All rights reserved.
// 
// This file contains confidential and proprietary information
// of AMD and is protected under U.S. and international copyright
// and other intellectual property laws.
// 
// DISCLAIMER
// This disclaimer is not a license and does not grant any
// rights to the materials distributed herewith. Except as
// otherwise provided in a valid license issued to you by
// AMD, and to the maximum extent permitted by applicable
// law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
// WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
// AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
// BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
// INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
// (2) AMD shall not be liable (whether in contract or tort,
// including negligence, or under any other theory of
// liability) for any loss or damage of any kind or nature
// related to, arising under or in connection with these
// materials, including for any direct, or any indirect,
// special, incidental, or consequential loss or damage
// (including loss of data, profits, goodwill, or any type of
// loss or damage suffered as a result of any action brought
// by a third party) even if such damage or loss was
// reasonably foreseeable or AMD had been advised of the
// possibility of the same.
// 
// CRITICAL APPLICATIONS
// AMD products are not designed or intended to be fail-
// safe, or for use in any application requiring fail-safe
// performance, such as life-support or safety devices or
// systems, Class III medical devices, nuclear facilities,
// applications related to the deployment of airbags, or any
// other applications that could lead to death, personal
// injury, or severe property or environmental damage
// (individually and collectively, "Critical
// Applications"). Customer assumes the sole risk and
// liability of any use of AMD products in Critical
// Applications, subject only to applicable laws and
// regulations governing limitations on product liability.
// 
// THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
// PART OF THIS FILE AT ALL TIMES.
// 
// DO NOT MODIFY THIS FILE.


// IP VLNV: xilinx.com:module_ref:ecdsa:1.0
// IP Revision: 1

(* X_CORE_INFO = "ecdsa,Vivado 2023.1" *)
(* CHECK_LICENSE_TYPE = "ecdsa_project_ecdsa_0_0,ecdsa,{}" *)
(* CORE_GENERATION_INFO = "ecdsa_project_ecdsa_0_0,ecdsa,{x_ipProduct=Vivado 2023.1,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=ecdsa,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED}" *)
(* IP_DEFINITION_SOURCE = "module_ref" *)
(* DowngradeIPIdentifiedWarnings = "yes" *)
module ecdsa_project_ecdsa_0_0 (
  clk,
  resetn,
  leds,
  rin0,
  rin1,
  rin2,
  rin3,
  rin4,
  rin5,
  rin6,
  rin7,
  rout0,
  rout1,
  rout2,
  rout3,
  rout4,
  rout5,
  rout6,
  rout7,
  dma_rx_data,
  dma_tx_data,
  dma_rx_address,
  dma_tx_address,
  dma_rx_start,
  dma_tx_start,
  dma_done,
  dma_idle,
  dma_error
);

(* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME clk, ASSOCIATED_RESET resetn, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN ecdsa_project_processing_system7_0_0_FCLK_CLK0, INSERT_VIP 0" *)
(* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 clk CLK" *)
input wire clk;
(* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME resetn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *)
(* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 resetn RST" *)
input wire resetn;
output wire [3 : 0] leds;
input wire [31 : 0] rin0;
input wire [31 : 0] rin1;
input wire [31 : 0] rin2;
input wire [31 : 0] rin3;
input wire [31 : 0] rin4;
input wire [31 : 0] rin5;
input wire [31 : 0] rin6;
input wire [31 : 0] rin7;
output wire [31 : 0] rout0;
output wire [31 : 0] rout1;
output wire [31 : 0] rout2;
output wire [31 : 0] rout3;
output wire [31 : 0] rout4;
output wire [31 : 0] rout5;
output wire [31 : 0] rout6;
output wire [31 : 0] rout7;
input wire [1023 : 0] dma_rx_data;
output wire [1023 : 0] dma_tx_data;
output wire [31 : 0] dma_rx_address;
output wire [31 : 0] dma_tx_address;
output wire dma_rx_start;
output wire dma_tx_start;
input wire dma_done;
input wire dma_idle;
input wire dma_error;

  ecdsa inst (
    .clk(clk),
    .resetn(resetn),
    .leds(leds),
    .rin0(rin0),
    .rin1(rin1),
    .rin2(rin2),
    .rin3(rin3),
    .rin4(rin4),
    .rin5(rin5),
    .rin6(rin6),
    .rin7(rin7),
    .rout0(rout0),
    .rout1(rout1),
    .rout2(rout2),
    .rout3(rout3),
    .rout4(rout4),
    .rout5(rout5),
    .rout6(rout6),
    .rout7(rout7),
    .dma_rx_data(dma_rx_data),
    .dma_tx_data(dma_tx_data),
    .dma_rx_address(dma_rx_address),
    .dma_tx_address(dma_tx_address),
    .dma_rx_start(dma_rx_start),
    .dma_tx_start(dma_tx_start),
    .dma_done(dma_done),
    .dma_idle(dma_idle),
    .dma_error(dma_error)
  );
endmodule
