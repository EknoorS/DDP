// (c) Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// (c) Copyright 2022-2026 Advanced Micro Devices, Inc. All rights reserved.
// 
// This file contains confidential and proprietary information
// of AMD and is protected under U.S. and international copyright
// and other intellectual property laws.
// 
// DISCLAIMER
// This disclaimer is not a license and does not grant any
// rights to the materials distributed herewith. Except as
// otherwise provided in a valid license issued to you by
// AMD, and to the maximum extent permitted by applicable
// law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
// WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
// AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
// BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
// INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
// (2) AMD shall not be liable (whether in contract or tort,
// including negligence, or under any other theory of
// liability) for any loss or damage of any kind or nature
// related to, arising under or in connection with these
// materials, including for any direct, or any indirect,
// special, incidental, or consequential loss or damage
// (including loss of data, profits, goodwill, or any type of
// loss or damage suffered as a result of any action brought
// by a third party) even if such damage or loss was
// reasonably foreseeable or AMD had been advised of the
// possibility of the same.
// 
// CRITICAL APPLICATIONS
// AMD products are not designed or intended to be fail-
// safe, or for use in any application requiring fail-safe
// performance, such as life-support or safety devices or
// systems, Class III medical devices, nuclear facilities,
// applications related to the deployment of airbags, or any
// other applications that could lead to death, personal
// injury, or severe property or environmental damage
// (individually and collectively, "Critical
// Applications"). Customer assumes the sole risk and
// liability of any use of AMD products in Critical
// Applications, subject only to applicable laws and
// regulations governing limitations on product liability.
// 
// THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
// PART OF THIS FILE AT ALL TIMES.
// 
// DO NOT MODIFY THIS FILE.


// IP VLNV: xilinx.com:module_ref:interfacer:1.0
// IP Revision: 1

(* X_CORE_INFO = "interfacer,Vivado 2023.1" *)
(* CHECK_LICENSE_TYPE = "ecdsa_project_interfacer_0_0,interfacer,{}" *)
(* CORE_GENERATION_INFO = "ecdsa_project_interfacer_0_0,interfacer,{x_ipProduct=Vivado 2023.1,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=interfacer,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED,C_SAXIL_ADDR_WIDTH=12,C_SAXIL_DATA_WIDTH=32,C_MAXI_ADDR_WIDTH=32,C_MAXI_DATA_WIDTH=1024}" *)
(* IP_DEFINITION_SOURCE = "module_ref" *)
(* DowngradeIPIdentifiedWarnings = "yes" *)
module ecdsa_project_interfacer_0_0 (
  aclk,
  aresetn,
  m_axi_dma_awvalid,
  m_axi_dma_awready,
  m_axi_dma_awaddr,
  m_axi_dma_awlen,
  m_axi_dma_awburst,
  m_axi_dma_wvalid,
  m_axi_dma_wready,
  m_axi_dma_wdata,
  m_axi_dma_wlast,
  m_axi_dma_bvalid,
  m_axi_dma_bready,
  m_axi_dma_arvalid,
  m_axi_dma_arready,
  m_axi_dma_araddr,
  m_axi_dma_arlen,
  m_axi_dma_arburst,
  m_axi_dma_rvalid,
  m_axi_dma_rready,
  m_axi_dma_rdata,
  m_axi_dma_rlast,
  s_axi_csrs_awvalid,
  s_axi_csrs_awready,
  s_axi_csrs_awaddr,
  s_axi_csrs_wvalid,
  s_axi_csrs_wready,
  s_axi_csrs_wdata,
  s_axi_csrs_wstrb,
  s_axi_csrs_bvalid,
  s_axi_csrs_bready,
  s_axi_csrs_bresp,
  s_axi_csrs_arvalid,
  s_axi_csrs_arready,
  s_axi_csrs_araddr,
  s_axi_csrs_rvalid,
  s_axi_csrs_rready,
  s_axi_csrs_rdata,
  s_axi_csrs_rresp,
  csr0_c2f,
  csr0_f2c,
  csr1_c2f,
  csr1_f2c,
  csr2_c2f,
  csr2_f2c,
  csr3_c2f,
  csr3_f2c,
  csr4_c2f,
  csr4_f2c,
  csr5_c2f,
  csr5_f2c,
  csr6_c2f,
  csr6_f2c,
  csr7_c2f,
  csr7_f2c,
  dma_c2f_start,
  dma_f2c_start,
  dma_c2f_data,
  dma_f2c_data,
  dma_c2f_addr,
  dma_f2c_addr,
  dma_done,
  dma_idle,
  dma_error
);

(* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF m_axi_dma:s_axi_csrs, ASSOCIATED_RESET aresetn, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN ecdsa_project_processing_system7_0_0_FCLK_CLK0, INSERT_VIP 0" *)
(* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 aclk CLK" *)
input wire aclk;
(* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *)
(* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 aresetn RST" *)
input wire aresetn;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma AWVALID" *)
output wire m_axi_dma_awvalid;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma AWREADY" *)
input wire m_axi_dma_awready;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma AWADDR" *)
output wire [31 : 0] m_axi_dma_awaddr;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma AWLEN" *)
output wire [7 : 0] m_axi_dma_awlen;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma AWBURST" *)
output wire [1 : 0] m_axi_dma_awburst;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma WVALID" *)
output wire m_axi_dma_wvalid;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma WREADY" *)
input wire m_axi_dma_wready;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma WDATA" *)
output wire [1023 : 0] m_axi_dma_wdata;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma WLAST" *)
output wire m_axi_dma_wlast;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma BVALID" *)
input wire m_axi_dma_bvalid;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma BREADY" *)
output wire m_axi_dma_bready;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma ARVALID" *)
output wire m_axi_dma_arvalid;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma ARREADY" *)
input wire m_axi_dma_arready;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma ARADDR" *)
output wire [31 : 0] m_axi_dma_araddr;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma ARLEN" *)
output wire [7 : 0] m_axi_dma_arlen;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma ARBURST" *)
output wire [1 : 0] m_axi_dma_arburst;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma RVALID" *)
input wire m_axi_dma_rvalid;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma RREADY" *)
output wire m_axi_dma_rready;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma RDATA" *)
input wire [1023 : 0] m_axi_dma_rdata;
(* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME m_axi_dma, DATA_WIDTH 1024, PROTOCOL AXI4, FREQ_HZ 100000000, ID_WIDTH 0, ADDR_WIDTH 32, AWUSER_WIDTH 0, ARUSER_WIDTH 0, WUSER_WIDTH 0, RUSER_WIDTH 0, BUSER_WIDTH 0, READ_WRITE_MODE READ_WRITE, HAS_BURST 1, HAS_LOCK 0, HAS_PROT 0, HAS_CACHE 0, HAS_QOS 0, HAS_REGION 0, HAS_WSTRB 0, HAS_BRESP 0, HAS_RRESP 0, SUPPORTS_NARROW_BURST 0, NUM_READ_OUTSTANDING 2, NUM_WRITE_OUTSTANDING 2, MAX_BURST_LENGTH 256, PHASE 0.0, CLK_DOMAIN ecdsa_project_processing_system7_0_0_FCLK_CLK0, NUM_READ\
_THREADS 1, NUM_WRITE_THREADS 1, RUSER_BITS_PER_BYTE 0, WUSER_BITS_PER_BYTE 0, INSERT_VIP 0" *)
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 m_axi_dma RLAST" *)
input wire m_axi_dma_rlast;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs AWVALID" *)
input wire s_axi_csrs_awvalid;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs AWREADY" *)
output wire s_axi_csrs_awready;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs AWADDR" *)
input wire [11 : 0] s_axi_csrs_awaddr;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs WVALID" *)
input wire s_axi_csrs_wvalid;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs WREADY" *)
output wire s_axi_csrs_wready;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs WDATA" *)
input wire [31 : 0] s_axi_csrs_wdata;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs WSTRB" *)
input wire [3 : 0] s_axi_csrs_wstrb;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs BVALID" *)
output wire s_axi_csrs_bvalid;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs BREADY" *)
input wire s_axi_csrs_bready;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs BRESP" *)
output wire [1 : 0] s_axi_csrs_bresp;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs ARVALID" *)
input wire s_axi_csrs_arvalid;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs ARREADY" *)
output wire s_axi_csrs_arready;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs ARADDR" *)
input wire [11 : 0] s_axi_csrs_araddr;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs RVALID" *)
output wire s_axi_csrs_rvalid;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs RREADY" *)
input wire s_axi_csrs_rready;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs RDATA" *)
output wire [31 : 0] s_axi_csrs_rdata;
(* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME s_axi_csrs, DATA_WIDTH 32, PROTOCOL AXI4LITE, FREQ_HZ 100000000, ID_WIDTH 0, ADDR_WIDTH 12, AWUSER_WIDTH 0, ARUSER_WIDTH 0, WUSER_WIDTH 0, RUSER_WIDTH 0, BUSER_WIDTH 0, READ_WRITE_MODE READ_WRITE, HAS_BURST 0, HAS_LOCK 0, HAS_PROT 0, HAS_CACHE 0, HAS_QOS 0, HAS_REGION 0, HAS_WSTRB 1, HAS_BRESP 1, HAS_RRESP 1, SUPPORTS_NARROW_BURST 0, NUM_READ_OUTSTANDING 1, NUM_WRITE_OUTSTANDING 1, MAX_BURST_LENGTH 1, PHASE 0.0, CLK_DOMAIN ecdsa_project_processing_system7_0_0_FCLK_CLK0, NUM_REA\
D_THREADS 4, NUM_WRITE_THREADS 4, RUSER_BITS_PER_BYTE 0, WUSER_BITS_PER_BYTE 0, INSERT_VIP 0" *)
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs RRESP" *)
output wire [1 : 0] s_axi_csrs_rresp;
output wire [31 : 0] csr0_c2f;
input wire [31 : 0] csr0_f2c;
output wire [31 : 0] csr1_c2f;
input wire [31 : 0] csr1_f2c;
output wire [31 : 0] csr2_c2f;
input wire [31 : 0] csr2_f2c;
output wire [31 : 0] csr3_c2f;
input wire [31 : 0] csr3_f2c;
output wire [31 : 0] csr4_c2f;
input wire [31 : 0] csr4_f2c;
output wire [31 : 0] csr5_c2f;
input wire [31 : 0] csr5_f2c;
output wire [31 : 0] csr6_c2f;
input wire [31 : 0] csr6_f2c;
output wire [31 : 0] csr7_c2f;
input wire [31 : 0] csr7_f2c;
input wire dma_c2f_start;
input wire dma_f2c_start;
output wire [1023 : 0] dma_c2f_data;
input wire [1023 : 0] dma_f2c_data;
input wire [31 : 0] dma_c2f_addr;
input wire [31 : 0] dma_f2c_addr;
output wire dma_done;
output wire dma_idle;
output wire dma_error;

  interfacer #(
    .C_SAXIL_ADDR_WIDTH(12),
    .C_SAXIL_DATA_WIDTH(32),
    .C_MAXI_ADDR_WIDTH(32),
    .C_MAXI_DATA_WIDTH(1024)
  ) inst (
    .aclk(aclk),
    .aresetn(aresetn),
    .m_axi_dma_awvalid(m_axi_dma_awvalid),
    .m_axi_dma_awready(m_axi_dma_awready),
    .m_axi_dma_awaddr(m_axi_dma_awaddr),
    .m_axi_dma_awlen(m_axi_dma_awlen),
    .m_axi_dma_awburst(m_axi_dma_awburst),
    .m_axi_dma_wvalid(m_axi_dma_wvalid),
    .m_axi_dma_wready(m_axi_dma_wready),
    .m_axi_dma_wdata(m_axi_dma_wdata),
    .m_axi_dma_wlast(m_axi_dma_wlast),
    .m_axi_dma_bvalid(m_axi_dma_bvalid),
    .m_axi_dma_bready(m_axi_dma_bready),
    .m_axi_dma_arvalid(m_axi_dma_arvalid),
    .m_axi_dma_arready(m_axi_dma_arready),
    .m_axi_dma_araddr(m_axi_dma_araddr),
    .m_axi_dma_arlen(m_axi_dma_arlen),
    .m_axi_dma_arburst(m_axi_dma_arburst),
    .m_axi_dma_rvalid(m_axi_dma_rvalid),
    .m_axi_dma_rready(m_axi_dma_rready),
    .m_axi_dma_rdata(m_axi_dma_rdata),
    .m_axi_dma_rlast(m_axi_dma_rlast),
    .s_axi_csrs_awvalid(s_axi_csrs_awvalid),
    .s_axi_csrs_awready(s_axi_csrs_awready),
    .s_axi_csrs_awaddr(s_axi_csrs_awaddr),
    .s_axi_csrs_wvalid(s_axi_csrs_wvalid),
    .s_axi_csrs_wready(s_axi_csrs_wready),
    .s_axi_csrs_wdata(s_axi_csrs_wdata),
    .s_axi_csrs_wstrb(s_axi_csrs_wstrb),
    .s_axi_csrs_bvalid(s_axi_csrs_bvalid),
    .s_axi_csrs_bready(s_axi_csrs_bready),
    .s_axi_csrs_bresp(s_axi_csrs_bresp),
    .s_axi_csrs_arvalid(s_axi_csrs_arvalid),
    .s_axi_csrs_arready(s_axi_csrs_arready),
    .s_axi_csrs_araddr(s_axi_csrs_araddr),
    .s_axi_csrs_rvalid(s_axi_csrs_rvalid),
    .s_axi_csrs_rready(s_axi_csrs_rready),
    .s_axi_csrs_rdata(s_axi_csrs_rdata),
    .s_axi_csrs_rresp(s_axi_csrs_rresp),
    .csr0_c2f(csr0_c2f),
    .csr0_f2c(csr0_f2c),
    .csr1_c2f(csr1_c2f),
    .csr1_f2c(csr1_f2c),
    .csr2_c2f(csr2_c2f),
    .csr2_f2c(csr2_f2c),
    .csr3_c2f(csr3_c2f),
    .csr3_f2c(csr3_f2c),
    .csr4_c2f(csr4_c2f),
    .csr4_f2c(csr4_f2c),
    .csr5_c2f(csr5_c2f),
    .csr5_f2c(csr5_f2c),
    .csr6_c2f(csr6_c2f),
    .csr6_f2c(csr6_f2c),
    .csr7_c2f(csr7_c2f),
    .csr7_f2c(csr7_f2c),
    .dma_c2f_start(dma_c2f_start),
    .dma_f2c_start(dma_f2c_start),
    .dma_c2f_data(dma_c2f_data),
    .dma_f2c_data(dma_f2c_data),
    .dma_c2f_addr(dma_c2f_addr),
    .dma_f2c_addr(dma_f2c_addr),
    .dma_done(dma_done),
    .dma_idle(dma_idle),
    .dma_error(dma_error)
  );
endmodule
