-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2023.1 (lin64) Build 3865809 Sun May  7 15:04:56 MDT 2023
-- Date        : Wed Nov 25 15:00:00 2026
-- Host        : pc-klas1-14.esat.kuleuven.be running 64-bit Rocky Linux 9.9 (Blue Onyx)
-- Command     : write_vhdl -force -mode funcsim
--               /users/students/r1083141/DDP/DDP/hw_session_package/package/hw_project/project_hw/project_hw.gen/sources_1/bd/ecdsa_project/ip/ecdsa_project_interfacer_0_0/ecdsa_project_interfacer_0_0_sim_netlist.vhdl
-- Design      : ecdsa_project_interfacer_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity ecdsa_project_interfacer_0_0_interfacer is
  port (
    s_axi_csrs_wready : out STD_LOGIC;
    s_axi_csrs_rdata : out STD_LOGIC_VECTOR ( 31 downto 0 );
    csr0_c2f : out STD_LOGIC_VECTOR ( 31 downto 0 );
    csr1_c2f : out STD_LOGIC_VECTOR ( 31 downto 0 );
    csr2_c2f : out STD_LOGIC_VECTOR ( 31 downto 0 );
    csr3_c2f : out STD_LOGIC_VECTOR ( 31 downto 0 );
    csr4_c2f : out STD_LOGIC_VECTOR ( 31 downto 0 );
    csr5_c2f : out STD_LOGIC_VECTOR ( 31 downto 0 );
    csr6_c2f : out STD_LOGIC_VECTOR ( 31 downto 0 );
    csr7_c2f : out STD_LOGIC_VECTOR ( 31 downto 0 );
    m_axi_dma_bready : out STD_LOGIC;
    m_axi_dma_wvalid : out STD_LOGIC;
    dma_idle : out STD_LOGIC;
    m_axi_dma_awvalid : out STD_LOGIC;
    dma_done : out STD_LOGIC;
    m_axi_dma_rready : out STD_LOGIC;
    m_axi_dma_arvalid : out STD_LOGIC;
    s_axi_csrs_awready : out STD_LOGIC;
    s_axi_csrs_bvalid : out STD_LOGIC;
    s_axi_csrs_rvalid : out STD_LOGIC;
    s_axi_csrs_arready : out STD_LOGIC;
    dma_error : out STD_LOGIC;
    dma_c2f_start : in STD_LOGIC;
    dma_f2c_start : in STD_LOGIC;
    s_axi_csrs_wvalid : in STD_LOGIC;
    s_axi_csrs_awvalid : in STD_LOGIC;
    aclk : in STD_LOGIC;
    csr3_f2c : in STD_LOGIC_VECTOR ( 31 downto 0 );
    csr2_f2c : in STD_LOGIC_VECTOR ( 31 downto 0 );
    s_axi_csrs_araddr : in STD_LOGIC_VECTOR ( 4 downto 0 );
    csr1_f2c : in STD_LOGIC_VECTOR ( 31 downto 0 );
    csr0_f2c : in STD_LOGIC_VECTOR ( 31 downto 0 );
    csr7_f2c : in STD_LOGIC_VECTOR ( 31 downto 0 );
    csr6_f2c : in STD_LOGIC_VECTOR ( 31 downto 0 );
    csr5_f2c : in STD_LOGIC_VECTOR ( 31 downto 0 );
    csr4_f2c : in STD_LOGIC_VECTOR ( 31 downto 0 );
    s_axi_csrs_arvalid : in STD_LOGIC;
    s_axi_csrs_awaddr : in STD_LOGIC_VECTOR ( 4 downto 0 );
    m_axi_dma_bvalid : in STD_LOGIC;
    m_axi_dma_rvalid : in STD_LOGIC;
    m_axi_dma_awready : in STD_LOGIC;
    m_axi_dma_wready : in STD_LOGIC;
    m_axi_dma_arready : in STD_LOGIC;
    dma_f2c_addr : in STD_LOGIC_VECTOR ( 6 downto 0 );
    dma_c2f_addr : in STD_LOGIC_VECTOR ( 6 downto 0 );
    s_axi_csrs_rready : in STD_LOGIC;
    s_axi_csrs_bready : in STD_LOGIC;
    s_axi_csrs_wdata : in STD_LOGIC_VECTOR ( 31 downto 0 );
    s_axi_csrs_wstrb : in STD_LOGIC_VECTOR ( 3 downto 0 );
    aresetn : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of ecdsa_project_interfacer_0_0_interfacer : entity is "interfacer";
end ecdsa_project_interfacer_0_0_interfacer;

architecture STRUCTURE of ecdsa_project_interfacer_0_0_interfacer is
  signal ar_hs : STD_LOGIC;
  signal aw_hs : STD_LOGIC;
  signal csr00 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \csr0[31]_i_1_n_0\ : STD_LOGIC;
  signal \csr0[31]_i_3_n_0\ : STD_LOGIC;
  signal \csr0[31]_i_4_n_0\ : STD_LOGIC;
  signal \^csr0_c2f\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal csr10 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \csr1[31]_i_1_n_0\ : STD_LOGIC;
  signal \^csr1_c2f\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal csr20 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \csr2[31]_i_1_n_0\ : STD_LOGIC;
  signal \^csr2_c2f\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal csr30 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \csr3[31]_i_1_n_0\ : STD_LOGIC;
  signal \^csr3_c2f\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal csr40 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \csr4[31]_i_1_n_0\ : STD_LOGIC;
  signal \csr4[31]_i_3_n_0\ : STD_LOGIC;
  signal \^csr4_c2f\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal csr50 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \csr5[31]_i_1_n_0\ : STD_LOGIC;
  signal \^csr5_c2f\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal csr60 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \csr6[31]_i_1_n_0\ : STD_LOGIC;
  signal \^csr6_c2f\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal csr70 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \csr7[31]_i_1_n_0\ : STD_LOGIC;
  signal \^csr7_c2f\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \^dma_error\ : STD_LOGIC;
  signal dma_error_set_i_1_n_0 : STD_LOGIC;
  signal dma_error_set_i_2_n_0 : STD_LOGIC;
  signal dma_error_set_i_5_n_0 : STD_LOGIC;
  signal dma_error_set_i_6_n_0 : STD_LOGIC;
  signal \^m_axi_dma_rready\ : STD_LOGIC;
  signal \next_state__0\ : STD_LOGIC_VECTOR ( 5 downto 1 );
  signal next_state_n_0 : STD_LOGIC;
  signal \rdata[0]_i_2_n_0\ : STD_LOGIC;
  signal \rdata[0]_i_3_n_0\ : STD_LOGIC;
  signal \rdata[10]_i_2_n_0\ : STD_LOGIC;
  signal \rdata[10]_i_3_n_0\ : STD_LOGIC;
  signal \rdata[11]_i_2_n_0\ : STD_LOGIC;
  signal \rdata[11]_i_3_n_0\ : STD_LOGIC;
  signal \rdata[12]_i_2_n_0\ : STD_LOGIC;
  signal \rdata[12]_i_3_n_0\ : STD_LOGIC;
  signal \rdata[13]_i_2_n_0\ : STD_LOGIC;
  signal \rdata[13]_i_3_n_0\ : STD_LOGIC;
  signal \rdata[14]_i_2_n_0\ : STD_LOGIC;
  signal \rdata[14]_i_3_n_0\ : STD_LOGIC;
  signal \rdata[15]_i_2_n_0\ : STD_LOGIC;
  signal \rdata[15]_i_3_n_0\ : STD_LOGIC;
  signal \rdata[16]_i_2_n_0\ : STD_LOGIC;
  signal \rdata[16]_i_3_n_0\ : STD_LOGIC;
  signal \rdata[17]_i_2_n_0\ : STD_LOGIC;
  signal \rdata[17]_i_3_n_0\ : STD_LOGIC;
  signal \rdata[18]_i_2_n_0\ : STD_LOGIC;
  signal \rdata[18]_i_3_n_0\ : STD_LOGIC;
  signal \rdata[19]_i_2_n_0\ : STD_LOGIC;
  signal \rdata[19]_i_3_n_0\ : STD_LOGIC;
  signal \rdata[1]_i_2_n_0\ : STD_LOGIC;
  signal \rdata[1]_i_3_n_0\ : STD_LOGIC;
  signal \rdata[20]_i_2_n_0\ : STD_LOGIC;
  signal \rdata[20]_i_3_n_0\ : STD_LOGIC;
  signal \rdata[21]_i_2_n_0\ : STD_LOGIC;
  signal \rdata[21]_i_3_n_0\ : STD_LOGIC;
  signal \rdata[22]_i_2_n_0\ : STD_LOGIC;
  signal \rdata[22]_i_3_n_0\ : STD_LOGIC;
  signal \rdata[23]_i_2_n_0\ : STD_LOGIC;
  signal \rdata[23]_i_3_n_0\ : STD_LOGIC;
  signal \rdata[24]_i_2_n_0\ : STD_LOGIC;
  signal \rdata[24]_i_3_n_0\ : STD_LOGIC;
  signal \rdata[25]_i_2_n_0\ : STD_LOGIC;
  signal \rdata[25]_i_3_n_0\ : STD_LOGIC;
  signal \rdata[26]_i_2_n_0\ : STD_LOGIC;
  signal \rdata[26]_i_3_n_0\ : STD_LOGIC;
  signal \rdata[27]_i_2_n_0\ : STD_LOGIC;
  signal \rdata[27]_i_3_n_0\ : STD_LOGIC;
  signal \rdata[28]_i_2_n_0\ : STD_LOGIC;
  signal \rdata[28]_i_3_n_0\ : STD_LOGIC;
  signal \rdata[29]_i_2_n_0\ : STD_LOGIC;
  signal \rdata[29]_i_3_n_0\ : STD_LOGIC;
  signal \rdata[2]_i_2_n_0\ : STD_LOGIC;
  signal \rdata[2]_i_3_n_0\ : STD_LOGIC;
  signal \rdata[30]_i_2_n_0\ : STD_LOGIC;
  signal \rdata[30]_i_3_n_0\ : STD_LOGIC;
  signal \rdata[31]_i_1_n_0\ : STD_LOGIC;
  signal \rdata[31]_i_4_n_0\ : STD_LOGIC;
  signal \rdata[31]_i_5_n_0\ : STD_LOGIC;
  signal \rdata[31]_i_6_n_0\ : STD_LOGIC;
  signal \rdata[3]_i_2_n_0\ : STD_LOGIC;
  signal \rdata[3]_i_3_n_0\ : STD_LOGIC;
  signal \rdata[4]_i_2_n_0\ : STD_LOGIC;
  signal \rdata[4]_i_3_n_0\ : STD_LOGIC;
  signal \rdata[5]_i_2_n_0\ : STD_LOGIC;
  signal \rdata[5]_i_3_n_0\ : STD_LOGIC;
  signal \rdata[6]_i_2_n_0\ : STD_LOGIC;
  signal \rdata[6]_i_3_n_0\ : STD_LOGIC;
  signal \rdata[7]_i_2_n_0\ : STD_LOGIC;
  signal \rdata[7]_i_3_n_0\ : STD_LOGIC;
  signal \rdata[8]_i_2_n_0\ : STD_LOGIC;
  signal \rdata[8]_i_3_n_0\ : STD_LOGIC;
  signal \rdata[9]_i_2_n_0\ : STD_LOGIC;
  signal \rdata[9]_i_3_n_0\ : STD_LOGIC;
  signal \rdata_reg[0]_i_1_n_0\ : STD_LOGIC;
  signal \rdata_reg[10]_i_1_n_0\ : STD_LOGIC;
  signal \rdata_reg[11]_i_1_n_0\ : STD_LOGIC;
  signal \rdata_reg[12]_i_1_n_0\ : STD_LOGIC;
  signal \rdata_reg[13]_i_1_n_0\ : STD_LOGIC;
  signal \rdata_reg[14]_i_1_n_0\ : STD_LOGIC;
  signal \rdata_reg[15]_i_1_n_0\ : STD_LOGIC;
  signal \rdata_reg[16]_i_1_n_0\ : STD_LOGIC;
  signal \rdata_reg[17]_i_1_n_0\ : STD_LOGIC;
  signal \rdata_reg[18]_i_1_n_0\ : STD_LOGIC;
  signal \rdata_reg[19]_i_1_n_0\ : STD_LOGIC;
  signal \rdata_reg[1]_i_1_n_0\ : STD_LOGIC;
  signal \rdata_reg[20]_i_1_n_0\ : STD_LOGIC;
  signal \rdata_reg[21]_i_1_n_0\ : STD_LOGIC;
  signal \rdata_reg[22]_i_1_n_0\ : STD_LOGIC;
  signal \rdata_reg[23]_i_1_n_0\ : STD_LOGIC;
  signal \rdata_reg[24]_i_1_n_0\ : STD_LOGIC;
  signal \rdata_reg[25]_i_1_n_0\ : STD_LOGIC;
  signal \rdata_reg[26]_i_1_n_0\ : STD_LOGIC;
  signal \rdata_reg[27]_i_1_n_0\ : STD_LOGIC;
  signal \rdata_reg[28]_i_1_n_0\ : STD_LOGIC;
  signal \rdata_reg[29]_i_1_n_0\ : STD_LOGIC;
  signal \rdata_reg[2]_i_1_n_0\ : STD_LOGIC;
  signal \rdata_reg[30]_i_1_n_0\ : STD_LOGIC;
  signal \rdata_reg[31]_i_3_n_0\ : STD_LOGIC;
  signal \rdata_reg[3]_i_1_n_0\ : STD_LOGIC;
  signal \rdata_reg[4]_i_1_n_0\ : STD_LOGIC;
  signal \rdata_reg[5]_i_1_n_0\ : STD_LOGIC;
  signal \rdata_reg[6]_i_1_n_0\ : STD_LOGIC;
  signal \rdata_reg[7]_i_1_n_0\ : STD_LOGIC;
  signal \rdata_reg[8]_i_1_n_0\ : STD_LOGIC;
  signal \rdata_reg[9]_i_1_n_0\ : STD_LOGIC;
  signal rnext : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal rstate : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal \^s_axi_csrs_wready\ : STD_LOGIC;
  signal state : STD_LOGIC_VECTOR ( 5 downto 0 );
  signal \state[0]_i_1_n_0\ : STD_LOGIC;
  signal \state[0]_i_2_n_0\ : STD_LOGIC;
  signal waddr : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal wnext : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal wrong_addr00_in : STD_LOGIC;
  signal \wrong_addr0__6\ : STD_LOGIC;
  signal wstate : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \wstate[1]_i_1_n_0\ : STD_LOGIC;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \csr0[0]_i_1\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \csr0[10]_i_1\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \csr0[11]_i_1\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \csr0[12]_i_1\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \csr0[13]_i_1\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \csr0[14]_i_1\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \csr0[15]_i_1\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \csr0[16]_i_1\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \csr0[17]_i_1\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \csr0[18]_i_1\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \csr0[19]_i_1\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \csr0[1]_i_1\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \csr0[20]_i_1\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \csr0[21]_i_1\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \csr0[22]_i_1\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \csr0[23]_i_1\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \csr0[24]_i_1\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \csr0[25]_i_1\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \csr0[26]_i_1\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \csr0[27]_i_1\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \csr0[28]_i_1\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \csr0[29]_i_1\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \csr0[2]_i_1\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \csr0[30]_i_1\ : label is "soft_lutpair20";
  attribute SOFT_HLUTNM of \csr0[31]_i_2\ : label is "soft_lutpair20";
  attribute SOFT_HLUTNM of \csr0[31]_i_4\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \csr0[3]_i_1\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \csr0[4]_i_1\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \csr0[5]_i_1\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \csr0[6]_i_1\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \csr0[7]_i_1\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \csr0[8]_i_1\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \csr0[9]_i_1\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \csr1[0]_i_1\ : label is "soft_lutpair21";
  attribute SOFT_HLUTNM of \csr1[10]_i_1\ : label is "soft_lutpair26";
  attribute SOFT_HLUTNM of \csr1[11]_i_1\ : label is "soft_lutpair26";
  attribute SOFT_HLUTNM of \csr1[12]_i_1\ : label is "soft_lutpair27";
  attribute SOFT_HLUTNM of \csr1[13]_i_1\ : label is "soft_lutpair27";
  attribute SOFT_HLUTNM of \csr1[14]_i_1\ : label is "soft_lutpair28";
  attribute SOFT_HLUTNM of \csr1[15]_i_1\ : label is "soft_lutpair28";
  attribute SOFT_HLUTNM of \csr1[16]_i_1\ : label is "soft_lutpair29";
  attribute SOFT_HLUTNM of \csr1[17]_i_1\ : label is "soft_lutpair29";
  attribute SOFT_HLUTNM of \csr1[18]_i_1\ : label is "soft_lutpair30";
  attribute SOFT_HLUTNM of \csr1[19]_i_1\ : label is "soft_lutpair30";
  attribute SOFT_HLUTNM of \csr1[1]_i_1\ : label is "soft_lutpair21";
  attribute SOFT_HLUTNM of \csr1[20]_i_1\ : label is "soft_lutpair31";
  attribute SOFT_HLUTNM of \csr1[21]_i_1\ : label is "soft_lutpair31";
  attribute SOFT_HLUTNM of \csr1[22]_i_1\ : label is "soft_lutpair32";
  attribute SOFT_HLUTNM of \csr1[23]_i_1\ : label is "soft_lutpair32";
  attribute SOFT_HLUTNM of \csr1[24]_i_1\ : label is "soft_lutpair33";
  attribute SOFT_HLUTNM of \csr1[25]_i_1\ : label is "soft_lutpair33";
  attribute SOFT_HLUTNM of \csr1[26]_i_1\ : label is "soft_lutpair34";
  attribute SOFT_HLUTNM of \csr1[27]_i_1\ : label is "soft_lutpair34";
  attribute SOFT_HLUTNM of \csr1[28]_i_1\ : label is "soft_lutpair35";
  attribute SOFT_HLUTNM of \csr1[29]_i_1\ : label is "soft_lutpair35";
  attribute SOFT_HLUTNM of \csr1[2]_i_1\ : label is "soft_lutpair22";
  attribute SOFT_HLUTNM of \csr1[30]_i_1\ : label is "soft_lutpair36";
  attribute SOFT_HLUTNM of \csr1[31]_i_2\ : label is "soft_lutpair36";
  attribute SOFT_HLUTNM of \csr1[3]_i_1\ : label is "soft_lutpair22";
  attribute SOFT_HLUTNM of \csr1[4]_i_1\ : label is "soft_lutpair23";
  attribute SOFT_HLUTNM of \csr1[5]_i_1\ : label is "soft_lutpair23";
  attribute SOFT_HLUTNM of \csr1[6]_i_1\ : label is "soft_lutpair24";
  attribute SOFT_HLUTNM of \csr1[7]_i_1\ : label is "soft_lutpair24";
  attribute SOFT_HLUTNM of \csr1[8]_i_1\ : label is "soft_lutpair25";
  attribute SOFT_HLUTNM of \csr1[9]_i_1\ : label is "soft_lutpair25";
  attribute SOFT_HLUTNM of \csr2[0]_i_1\ : label is "soft_lutpair37";
  attribute SOFT_HLUTNM of \csr2[10]_i_1\ : label is "soft_lutpair42";
  attribute SOFT_HLUTNM of \csr2[11]_i_1\ : label is "soft_lutpair42";
  attribute SOFT_HLUTNM of \csr2[12]_i_1\ : label is "soft_lutpair43";
  attribute SOFT_HLUTNM of \csr2[13]_i_1\ : label is "soft_lutpair43";
  attribute SOFT_HLUTNM of \csr2[14]_i_1\ : label is "soft_lutpair44";
  attribute SOFT_HLUTNM of \csr2[15]_i_1\ : label is "soft_lutpair44";
  attribute SOFT_HLUTNM of \csr2[16]_i_1\ : label is "soft_lutpair45";
  attribute SOFT_HLUTNM of \csr2[17]_i_1\ : label is "soft_lutpair45";
  attribute SOFT_HLUTNM of \csr2[18]_i_1\ : label is "soft_lutpair46";
  attribute SOFT_HLUTNM of \csr2[19]_i_1\ : label is "soft_lutpair46";
  attribute SOFT_HLUTNM of \csr2[1]_i_1\ : label is "soft_lutpair37";
  attribute SOFT_HLUTNM of \csr2[20]_i_1\ : label is "soft_lutpair47";
  attribute SOFT_HLUTNM of \csr2[21]_i_1\ : label is "soft_lutpair47";
  attribute SOFT_HLUTNM of \csr2[22]_i_1\ : label is "soft_lutpair48";
  attribute SOFT_HLUTNM of \csr2[23]_i_1\ : label is "soft_lutpair48";
  attribute SOFT_HLUTNM of \csr2[24]_i_1\ : label is "soft_lutpair49";
  attribute SOFT_HLUTNM of \csr2[25]_i_1\ : label is "soft_lutpair49";
  attribute SOFT_HLUTNM of \csr2[26]_i_1\ : label is "soft_lutpair50";
  attribute SOFT_HLUTNM of \csr2[27]_i_1\ : label is "soft_lutpair50";
  attribute SOFT_HLUTNM of \csr2[28]_i_1\ : label is "soft_lutpair51";
  attribute SOFT_HLUTNM of \csr2[29]_i_1\ : label is "soft_lutpair51";
  attribute SOFT_HLUTNM of \csr2[2]_i_1\ : label is "soft_lutpair38";
  attribute SOFT_HLUTNM of \csr2[30]_i_1\ : label is "soft_lutpair52";
  attribute SOFT_HLUTNM of \csr2[31]_i_2\ : label is "soft_lutpair52";
  attribute SOFT_HLUTNM of \csr2[3]_i_1\ : label is "soft_lutpair38";
  attribute SOFT_HLUTNM of \csr2[4]_i_1\ : label is "soft_lutpair39";
  attribute SOFT_HLUTNM of \csr2[5]_i_1\ : label is "soft_lutpair39";
  attribute SOFT_HLUTNM of \csr2[6]_i_1\ : label is "soft_lutpair40";
  attribute SOFT_HLUTNM of \csr2[7]_i_1\ : label is "soft_lutpair40";
  attribute SOFT_HLUTNM of \csr2[8]_i_1\ : label is "soft_lutpair41";
  attribute SOFT_HLUTNM of \csr2[9]_i_1\ : label is "soft_lutpair41";
  attribute SOFT_HLUTNM of \csr3[0]_i_1\ : label is "soft_lutpair53";
  attribute SOFT_HLUTNM of \csr3[10]_i_1\ : label is "soft_lutpair58";
  attribute SOFT_HLUTNM of \csr3[11]_i_1\ : label is "soft_lutpair58";
  attribute SOFT_HLUTNM of \csr3[12]_i_1\ : label is "soft_lutpair59";
  attribute SOFT_HLUTNM of \csr3[13]_i_1\ : label is "soft_lutpair59";
  attribute SOFT_HLUTNM of \csr3[14]_i_1\ : label is "soft_lutpair60";
  attribute SOFT_HLUTNM of \csr3[15]_i_1\ : label is "soft_lutpair60";
  attribute SOFT_HLUTNM of \csr3[16]_i_1\ : label is "soft_lutpair61";
  attribute SOFT_HLUTNM of \csr3[17]_i_1\ : label is "soft_lutpair61";
  attribute SOFT_HLUTNM of \csr3[18]_i_1\ : label is "soft_lutpair62";
  attribute SOFT_HLUTNM of \csr3[19]_i_1\ : label is "soft_lutpair62";
  attribute SOFT_HLUTNM of \csr3[1]_i_1\ : label is "soft_lutpair53";
  attribute SOFT_HLUTNM of \csr3[20]_i_1\ : label is "soft_lutpair63";
  attribute SOFT_HLUTNM of \csr3[21]_i_1\ : label is "soft_lutpair63";
  attribute SOFT_HLUTNM of \csr3[22]_i_1\ : label is "soft_lutpair64";
  attribute SOFT_HLUTNM of \csr3[23]_i_1\ : label is "soft_lutpair64";
  attribute SOFT_HLUTNM of \csr3[24]_i_1\ : label is "soft_lutpair65";
  attribute SOFT_HLUTNM of \csr3[25]_i_1\ : label is "soft_lutpair65";
  attribute SOFT_HLUTNM of \csr3[26]_i_1\ : label is "soft_lutpair66";
  attribute SOFT_HLUTNM of \csr3[27]_i_1\ : label is "soft_lutpair66";
  attribute SOFT_HLUTNM of \csr3[28]_i_1\ : label is "soft_lutpair67";
  attribute SOFT_HLUTNM of \csr3[29]_i_1\ : label is "soft_lutpair67";
  attribute SOFT_HLUTNM of \csr3[2]_i_1\ : label is "soft_lutpair54";
  attribute SOFT_HLUTNM of \csr3[30]_i_1\ : label is "soft_lutpair68";
  attribute SOFT_HLUTNM of \csr3[31]_i_2\ : label is "soft_lutpair68";
  attribute SOFT_HLUTNM of \csr3[3]_i_1\ : label is "soft_lutpair54";
  attribute SOFT_HLUTNM of \csr3[4]_i_1\ : label is "soft_lutpair55";
  attribute SOFT_HLUTNM of \csr3[5]_i_1\ : label is "soft_lutpair55";
  attribute SOFT_HLUTNM of \csr3[6]_i_1\ : label is "soft_lutpair56";
  attribute SOFT_HLUTNM of \csr3[7]_i_1\ : label is "soft_lutpair56";
  attribute SOFT_HLUTNM of \csr3[8]_i_1\ : label is "soft_lutpair57";
  attribute SOFT_HLUTNM of \csr3[9]_i_1\ : label is "soft_lutpair57";
  attribute SOFT_HLUTNM of \csr4[0]_i_1\ : label is "soft_lutpair69";
  attribute SOFT_HLUTNM of \csr4[10]_i_1\ : label is "soft_lutpair74";
  attribute SOFT_HLUTNM of \csr4[11]_i_1\ : label is "soft_lutpair74";
  attribute SOFT_HLUTNM of \csr4[12]_i_1\ : label is "soft_lutpair75";
  attribute SOFT_HLUTNM of \csr4[13]_i_1\ : label is "soft_lutpair75";
  attribute SOFT_HLUTNM of \csr4[14]_i_1\ : label is "soft_lutpair76";
  attribute SOFT_HLUTNM of \csr4[15]_i_1\ : label is "soft_lutpair76";
  attribute SOFT_HLUTNM of \csr4[16]_i_1\ : label is "soft_lutpair77";
  attribute SOFT_HLUTNM of \csr4[17]_i_1\ : label is "soft_lutpair77";
  attribute SOFT_HLUTNM of \csr4[18]_i_1\ : label is "soft_lutpair78";
  attribute SOFT_HLUTNM of \csr4[19]_i_1\ : label is "soft_lutpair78";
  attribute SOFT_HLUTNM of \csr4[1]_i_1\ : label is "soft_lutpair69";
  attribute SOFT_HLUTNM of \csr4[20]_i_1\ : label is "soft_lutpair79";
  attribute SOFT_HLUTNM of \csr4[21]_i_1\ : label is "soft_lutpair79";
  attribute SOFT_HLUTNM of \csr4[22]_i_1\ : label is "soft_lutpair80";
  attribute SOFT_HLUTNM of \csr4[23]_i_1\ : label is "soft_lutpair80";
  attribute SOFT_HLUTNM of \csr4[24]_i_1\ : label is "soft_lutpair81";
  attribute SOFT_HLUTNM of \csr4[25]_i_1\ : label is "soft_lutpair81";
  attribute SOFT_HLUTNM of \csr4[26]_i_1\ : label is "soft_lutpair82";
  attribute SOFT_HLUTNM of \csr4[27]_i_1\ : label is "soft_lutpair82";
  attribute SOFT_HLUTNM of \csr4[28]_i_1\ : label is "soft_lutpair83";
  attribute SOFT_HLUTNM of \csr4[29]_i_1\ : label is "soft_lutpair83";
  attribute SOFT_HLUTNM of \csr4[2]_i_1\ : label is "soft_lutpair70";
  attribute SOFT_HLUTNM of \csr4[30]_i_1\ : label is "soft_lutpair84";
  attribute SOFT_HLUTNM of \csr4[31]_i_2\ : label is "soft_lutpair84";
  attribute SOFT_HLUTNM of \csr4[3]_i_1\ : label is "soft_lutpair70";
  attribute SOFT_HLUTNM of \csr4[4]_i_1\ : label is "soft_lutpair71";
  attribute SOFT_HLUTNM of \csr4[5]_i_1\ : label is "soft_lutpair71";
  attribute SOFT_HLUTNM of \csr4[6]_i_1\ : label is "soft_lutpair72";
  attribute SOFT_HLUTNM of \csr4[7]_i_1\ : label is "soft_lutpair72";
  attribute SOFT_HLUTNM of \csr4[8]_i_1\ : label is "soft_lutpair73";
  attribute SOFT_HLUTNM of \csr4[9]_i_1\ : label is "soft_lutpair73";
  attribute SOFT_HLUTNM of \csr5[0]_i_1\ : label is "soft_lutpair85";
  attribute SOFT_HLUTNM of \csr5[10]_i_1\ : label is "soft_lutpair90";
  attribute SOFT_HLUTNM of \csr5[11]_i_1\ : label is "soft_lutpair90";
  attribute SOFT_HLUTNM of \csr5[12]_i_1\ : label is "soft_lutpair91";
  attribute SOFT_HLUTNM of \csr5[13]_i_1\ : label is "soft_lutpair91";
  attribute SOFT_HLUTNM of \csr5[14]_i_1\ : label is "soft_lutpair92";
  attribute SOFT_HLUTNM of \csr5[15]_i_1\ : label is "soft_lutpair92";
  attribute SOFT_HLUTNM of \csr5[16]_i_1\ : label is "soft_lutpair93";
  attribute SOFT_HLUTNM of \csr5[17]_i_1\ : label is "soft_lutpair93";
  attribute SOFT_HLUTNM of \csr5[18]_i_1\ : label is "soft_lutpair94";
  attribute SOFT_HLUTNM of \csr5[19]_i_1\ : label is "soft_lutpair94";
  attribute SOFT_HLUTNM of \csr5[1]_i_1\ : label is "soft_lutpair85";
  attribute SOFT_HLUTNM of \csr5[20]_i_1\ : label is "soft_lutpair95";
  attribute SOFT_HLUTNM of \csr5[21]_i_1\ : label is "soft_lutpair95";
  attribute SOFT_HLUTNM of \csr5[22]_i_1\ : label is "soft_lutpair96";
  attribute SOFT_HLUTNM of \csr5[23]_i_1\ : label is "soft_lutpair96";
  attribute SOFT_HLUTNM of \csr5[24]_i_1\ : label is "soft_lutpair97";
  attribute SOFT_HLUTNM of \csr5[25]_i_1\ : label is "soft_lutpair97";
  attribute SOFT_HLUTNM of \csr5[26]_i_1\ : label is "soft_lutpair98";
  attribute SOFT_HLUTNM of \csr5[27]_i_1\ : label is "soft_lutpair98";
  attribute SOFT_HLUTNM of \csr5[28]_i_1\ : label is "soft_lutpair99";
  attribute SOFT_HLUTNM of \csr5[29]_i_1\ : label is "soft_lutpair99";
  attribute SOFT_HLUTNM of \csr5[2]_i_1\ : label is "soft_lutpair86";
  attribute SOFT_HLUTNM of \csr5[30]_i_1\ : label is "soft_lutpair100";
  attribute SOFT_HLUTNM of \csr5[31]_i_2\ : label is "soft_lutpair100";
  attribute SOFT_HLUTNM of \csr5[3]_i_1\ : label is "soft_lutpair86";
  attribute SOFT_HLUTNM of \csr5[4]_i_1\ : label is "soft_lutpair87";
  attribute SOFT_HLUTNM of \csr5[5]_i_1\ : label is "soft_lutpair87";
  attribute SOFT_HLUTNM of \csr5[6]_i_1\ : label is "soft_lutpair88";
  attribute SOFT_HLUTNM of \csr5[7]_i_1\ : label is "soft_lutpair88";
  attribute SOFT_HLUTNM of \csr5[8]_i_1\ : label is "soft_lutpair89";
  attribute SOFT_HLUTNM of \csr5[9]_i_1\ : label is "soft_lutpair89";
  attribute SOFT_HLUTNM of \csr6[0]_i_1\ : label is "soft_lutpair101";
  attribute SOFT_HLUTNM of \csr6[10]_i_1\ : label is "soft_lutpair106";
  attribute SOFT_HLUTNM of \csr6[11]_i_1\ : label is "soft_lutpair106";
  attribute SOFT_HLUTNM of \csr6[12]_i_1\ : label is "soft_lutpair107";
  attribute SOFT_HLUTNM of \csr6[13]_i_1\ : label is "soft_lutpair107";
  attribute SOFT_HLUTNM of \csr6[14]_i_1\ : label is "soft_lutpair108";
  attribute SOFT_HLUTNM of \csr6[15]_i_1\ : label is "soft_lutpair108";
  attribute SOFT_HLUTNM of \csr6[16]_i_1\ : label is "soft_lutpair109";
  attribute SOFT_HLUTNM of \csr6[17]_i_1\ : label is "soft_lutpair109";
  attribute SOFT_HLUTNM of \csr6[18]_i_1\ : label is "soft_lutpair110";
  attribute SOFT_HLUTNM of \csr6[19]_i_1\ : label is "soft_lutpair110";
  attribute SOFT_HLUTNM of \csr6[1]_i_1\ : label is "soft_lutpair101";
  attribute SOFT_HLUTNM of \csr6[20]_i_1\ : label is "soft_lutpair111";
  attribute SOFT_HLUTNM of \csr6[21]_i_1\ : label is "soft_lutpair111";
  attribute SOFT_HLUTNM of \csr6[22]_i_1\ : label is "soft_lutpair112";
  attribute SOFT_HLUTNM of \csr6[23]_i_1\ : label is "soft_lutpair112";
  attribute SOFT_HLUTNM of \csr6[24]_i_1\ : label is "soft_lutpair113";
  attribute SOFT_HLUTNM of \csr6[25]_i_1\ : label is "soft_lutpair113";
  attribute SOFT_HLUTNM of \csr6[26]_i_1\ : label is "soft_lutpair114";
  attribute SOFT_HLUTNM of \csr6[27]_i_1\ : label is "soft_lutpair114";
  attribute SOFT_HLUTNM of \csr6[28]_i_1\ : label is "soft_lutpair115";
  attribute SOFT_HLUTNM of \csr6[29]_i_1\ : label is "soft_lutpair115";
  attribute SOFT_HLUTNM of \csr6[2]_i_1\ : label is "soft_lutpair102";
  attribute SOFT_HLUTNM of \csr6[30]_i_1\ : label is "soft_lutpair116";
  attribute SOFT_HLUTNM of \csr6[31]_i_2\ : label is "soft_lutpair116";
  attribute SOFT_HLUTNM of \csr6[3]_i_1\ : label is "soft_lutpair102";
  attribute SOFT_HLUTNM of \csr6[4]_i_1\ : label is "soft_lutpair103";
  attribute SOFT_HLUTNM of \csr6[5]_i_1\ : label is "soft_lutpair103";
  attribute SOFT_HLUTNM of \csr6[6]_i_1\ : label is "soft_lutpair104";
  attribute SOFT_HLUTNM of \csr6[7]_i_1\ : label is "soft_lutpair104";
  attribute SOFT_HLUTNM of \csr6[8]_i_1\ : label is "soft_lutpair105";
  attribute SOFT_HLUTNM of \csr6[9]_i_1\ : label is "soft_lutpair105";
  attribute SOFT_HLUTNM of \csr7[0]_i_1\ : label is "soft_lutpair117";
  attribute SOFT_HLUTNM of \csr7[10]_i_1\ : label is "soft_lutpair122";
  attribute SOFT_HLUTNM of \csr7[11]_i_1\ : label is "soft_lutpair122";
  attribute SOFT_HLUTNM of \csr7[12]_i_1\ : label is "soft_lutpair123";
  attribute SOFT_HLUTNM of \csr7[13]_i_1\ : label is "soft_lutpair123";
  attribute SOFT_HLUTNM of \csr7[14]_i_1\ : label is "soft_lutpair124";
  attribute SOFT_HLUTNM of \csr7[15]_i_1\ : label is "soft_lutpair124";
  attribute SOFT_HLUTNM of \csr7[16]_i_1\ : label is "soft_lutpair125";
  attribute SOFT_HLUTNM of \csr7[17]_i_1\ : label is "soft_lutpair125";
  attribute SOFT_HLUTNM of \csr7[18]_i_1\ : label is "soft_lutpair126";
  attribute SOFT_HLUTNM of \csr7[19]_i_1\ : label is "soft_lutpair126";
  attribute SOFT_HLUTNM of \csr7[1]_i_1\ : label is "soft_lutpair117";
  attribute SOFT_HLUTNM of \csr7[20]_i_1\ : label is "soft_lutpair127";
  attribute SOFT_HLUTNM of \csr7[21]_i_1\ : label is "soft_lutpair127";
  attribute SOFT_HLUTNM of \csr7[22]_i_1\ : label is "soft_lutpair128";
  attribute SOFT_HLUTNM of \csr7[23]_i_1\ : label is "soft_lutpair128";
  attribute SOFT_HLUTNM of \csr7[24]_i_1\ : label is "soft_lutpair129";
  attribute SOFT_HLUTNM of \csr7[25]_i_1\ : label is "soft_lutpair129";
  attribute SOFT_HLUTNM of \csr7[26]_i_1\ : label is "soft_lutpair130";
  attribute SOFT_HLUTNM of \csr7[27]_i_1\ : label is "soft_lutpair130";
  attribute SOFT_HLUTNM of \csr7[28]_i_1\ : label is "soft_lutpair131";
  attribute SOFT_HLUTNM of \csr7[29]_i_1\ : label is "soft_lutpair131";
  attribute SOFT_HLUTNM of \csr7[2]_i_1\ : label is "soft_lutpair118";
  attribute SOFT_HLUTNM of \csr7[30]_i_1\ : label is "soft_lutpair132";
  attribute SOFT_HLUTNM of \csr7[31]_i_2\ : label is "soft_lutpair132";
  attribute SOFT_HLUTNM of \csr7[3]_i_1\ : label is "soft_lutpair118";
  attribute SOFT_HLUTNM of \csr7[4]_i_1\ : label is "soft_lutpair119";
  attribute SOFT_HLUTNM of \csr7[5]_i_1\ : label is "soft_lutpair119";
  attribute SOFT_HLUTNM of \csr7[6]_i_1\ : label is "soft_lutpair120";
  attribute SOFT_HLUTNM of \csr7[7]_i_1\ : label is "soft_lutpair120";
  attribute SOFT_HLUTNM of \csr7[8]_i_1\ : label is "soft_lutpair121";
  attribute SOFT_HLUTNM of \csr7[9]_i_1\ : label is "soft_lutpair121";
  attribute SOFT_HLUTNM of dma_done_INST_0 : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \rstate[0]_i_1\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \rstate[1]_i_1\ : label is "soft_lutpair0";
  attribute FSM_ENCODED_STATES : string;
  attribute FSM_ENCODED_STATES of \rstate_reg[0]\ : label is "RDDATA:010,RDIDLE:001,iSTATE:100";
  attribute FSM_ENCODED_STATES of \rstate_reg[1]\ : label is "RDDATA:010,RDIDLE:001,iSTATE:100";
  attribute SOFT_HLUTNM of s_axi_csrs_arready_INST_0 : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of s_axi_csrs_awready_INST_0 : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of s_axi_csrs_bvalid_INST_0 : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of s_axi_csrs_rvalid_INST_0 : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of s_axi_csrs_wready_INST_0 : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \state[0]_i_2\ : label is "soft_lutpair1";
  attribute FSM_ENCODED_STATES of \state_reg[0]\ : label is "S_WR:000010,S_WRDATA:000100,S_WRRESP:001000,S_RD:010000,S_RDDATA:100000,S_IDLE:000001";
  attribute FSM_ENCODED_STATES of \state_reg[1]\ : label is "S_WR:000010,S_WRDATA:000100,S_WRRESP:001000,S_RD:010000,S_RDDATA:100000,S_IDLE:000001";
  attribute FSM_ENCODED_STATES of \state_reg[2]\ : label is "S_WR:000010,S_WRDATA:000100,S_WRRESP:001000,S_RD:010000,S_RDDATA:100000,S_IDLE:000001";
  attribute FSM_ENCODED_STATES of \state_reg[3]\ : label is "S_WR:000010,S_WRDATA:000100,S_WRRESP:001000,S_RD:010000,S_RDDATA:100000,S_IDLE:000001";
  attribute FSM_ENCODED_STATES of \state_reg[4]\ : label is "S_WR:000010,S_WRDATA:000100,S_WRRESP:001000,S_RD:010000,S_RDDATA:100000,S_IDLE:000001";
  attribute FSM_ENCODED_STATES of \state_reg[5]\ : label is "S_WR:000010,S_WRDATA:000100,S_WRRESP:001000,S_RD:010000,S_RDDATA:100000,S_IDLE:000001";
  attribute FSM_ENCODED_STATES of \wstate_reg[0]\ : label is "WRDATA:0010,WRRESP:0100,WRIDLE:0001,iSTATE:1000";
  attribute FSM_ENCODED_STATES of \wstate_reg[1]\ : label is "WRDATA:0010,WRRESP:0100,WRIDLE:0001,iSTATE:1000";
  attribute FSM_ENCODED_STATES of \wstate_reg[2]\ : label is "WRDATA:0010,WRRESP:0100,WRIDLE:0001,iSTATE:1000";
  attribute FSM_ENCODED_STATES of \wstate_reg[3]\ : label is "WRDATA:0010,WRRESP:0100,WRIDLE:0001,iSTATE:1000";
begin
  csr0_c2f(31 downto 0) <= \^csr0_c2f\(31 downto 0);
  csr1_c2f(31 downto 0) <= \^csr1_c2f\(31 downto 0);
  csr2_c2f(31 downto 0) <= \^csr2_c2f\(31 downto 0);
  csr3_c2f(31 downto 0) <= \^csr3_c2f\(31 downto 0);
  csr4_c2f(31 downto 0) <= \^csr4_c2f\(31 downto 0);
  csr5_c2f(31 downto 0) <= \^csr5_c2f\(31 downto 0);
  csr6_c2f(31 downto 0) <= \^csr6_c2f\(31 downto 0);
  csr7_c2f(31 downto 0) <= \^csr7_c2f\(31 downto 0);
  dma_error <= \^dma_error\;
  m_axi_dma_rready <= \^m_axi_dma_rready\;
  s_axi_csrs_wready <= \^s_axi_csrs_wready\;
\csr0[0]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(0),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr0_c2f\(0),
      O => csr00(0)
    );
\csr0[10]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(10),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr0_c2f\(10),
      O => csr00(10)
    );
\csr0[11]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(11),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr0_c2f\(11),
      O => csr00(11)
    );
\csr0[12]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(12),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr0_c2f\(12),
      O => csr00(12)
    );
\csr0[13]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(13),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr0_c2f\(13),
      O => csr00(13)
    );
\csr0[14]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(14),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr0_c2f\(14),
      O => csr00(14)
    );
\csr0[15]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(15),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr0_c2f\(15),
      O => csr00(15)
    );
\csr0[16]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(16),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr0_c2f\(16),
      O => csr00(16)
    );
\csr0[17]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(17),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr0_c2f\(17),
      O => csr00(17)
    );
\csr0[18]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(18),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr0_c2f\(18),
      O => csr00(18)
    );
\csr0[19]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(19),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr0_c2f\(19),
      O => csr00(19)
    );
\csr0[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(1),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr0_c2f\(1),
      O => csr00(1)
    );
\csr0[20]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(20),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr0_c2f\(20),
      O => csr00(20)
    );
\csr0[21]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(21),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr0_c2f\(21),
      O => csr00(21)
    );
\csr0[22]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(22),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr0_c2f\(22),
      O => csr00(22)
    );
\csr0[23]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(23),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr0_c2f\(23),
      O => csr00(23)
    );
\csr0[24]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(24),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr0_c2f\(24),
      O => csr00(24)
    );
\csr0[25]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(25),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr0_c2f\(25),
      O => csr00(25)
    );
\csr0[26]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(26),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr0_c2f\(26),
      O => csr00(26)
    );
\csr0[27]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(27),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr0_c2f\(27),
      O => csr00(27)
    );
\csr0[28]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(28),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr0_c2f\(28),
      O => csr00(28)
    );
\csr0[29]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(29),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr0_c2f\(29),
      O => csr00(29)
    );
\csr0[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(2),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr0_c2f\(2),
      O => csr00(2)
    );
\csr0[30]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(30),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr0_c2f\(30),
      O => csr00(30)
    );
\csr0[31]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0004"
    )
        port map (
      I0 => waddr(3),
      I1 => \csr0[31]_i_3_n_0\,
      I2 => waddr(4),
      I3 => waddr(2),
      O => \csr0[31]_i_1_n_0\
    );
\csr0[31]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(31),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr0_c2f\(31),
      O => csr00(31)
    );
\csr0[31]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000400"
    )
        port map (
      I0 => waddr(0),
      I1 => s_axi_csrs_wvalid,
      I2 => wstate(0),
      I3 => wstate(1),
      I4 => \csr0[31]_i_4_n_0\,
      I5 => waddr(1),
      O => \csr0[31]_i_3_n_0\
    );
\csr0[31]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => wstate(2),
      I1 => wstate(3),
      O => \csr0[31]_i_4_n_0\
    );
\csr0[3]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(3),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr0_c2f\(3),
      O => csr00(3)
    );
\csr0[4]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(4),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr0_c2f\(4),
      O => csr00(4)
    );
\csr0[5]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(5),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr0_c2f\(5),
      O => csr00(5)
    );
\csr0[6]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(6),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr0_c2f\(6),
      O => csr00(6)
    );
\csr0[7]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(7),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr0_c2f\(7),
      O => csr00(7)
    );
\csr0[8]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(8),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr0_c2f\(8),
      O => csr00(8)
    );
\csr0[9]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(9),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr0_c2f\(9),
      O => csr00(9)
    );
\csr0_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr0[31]_i_1_n_0\,
      D => csr00(0),
      Q => \^csr0_c2f\(0),
      R => '0'
    );
\csr0_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr0[31]_i_1_n_0\,
      D => csr00(10),
      Q => \^csr0_c2f\(10),
      R => '0'
    );
\csr0_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr0[31]_i_1_n_0\,
      D => csr00(11),
      Q => \^csr0_c2f\(11),
      R => '0'
    );
\csr0_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr0[31]_i_1_n_0\,
      D => csr00(12),
      Q => \^csr0_c2f\(12),
      R => '0'
    );
\csr0_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr0[31]_i_1_n_0\,
      D => csr00(13),
      Q => \^csr0_c2f\(13),
      R => '0'
    );
\csr0_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr0[31]_i_1_n_0\,
      D => csr00(14),
      Q => \^csr0_c2f\(14),
      R => '0'
    );
\csr0_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr0[31]_i_1_n_0\,
      D => csr00(15),
      Q => \^csr0_c2f\(15),
      R => '0'
    );
\csr0_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr0[31]_i_1_n_0\,
      D => csr00(16),
      Q => \^csr0_c2f\(16),
      R => '0'
    );
\csr0_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr0[31]_i_1_n_0\,
      D => csr00(17),
      Q => \^csr0_c2f\(17),
      R => '0'
    );
\csr0_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr0[31]_i_1_n_0\,
      D => csr00(18),
      Q => \^csr0_c2f\(18),
      R => '0'
    );
\csr0_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr0[31]_i_1_n_0\,
      D => csr00(19),
      Q => \^csr0_c2f\(19),
      R => '0'
    );
\csr0_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr0[31]_i_1_n_0\,
      D => csr00(1),
      Q => \^csr0_c2f\(1),
      R => '0'
    );
\csr0_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr0[31]_i_1_n_0\,
      D => csr00(20),
      Q => \^csr0_c2f\(20),
      R => '0'
    );
\csr0_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr0[31]_i_1_n_0\,
      D => csr00(21),
      Q => \^csr0_c2f\(21),
      R => '0'
    );
\csr0_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr0[31]_i_1_n_0\,
      D => csr00(22),
      Q => \^csr0_c2f\(22),
      R => '0'
    );
\csr0_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr0[31]_i_1_n_0\,
      D => csr00(23),
      Q => \^csr0_c2f\(23),
      R => '0'
    );
\csr0_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr0[31]_i_1_n_0\,
      D => csr00(24),
      Q => \^csr0_c2f\(24),
      R => '0'
    );
\csr0_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr0[31]_i_1_n_0\,
      D => csr00(25),
      Q => \^csr0_c2f\(25),
      R => '0'
    );
\csr0_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr0[31]_i_1_n_0\,
      D => csr00(26),
      Q => \^csr0_c2f\(26),
      R => '0'
    );
\csr0_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr0[31]_i_1_n_0\,
      D => csr00(27),
      Q => \^csr0_c2f\(27),
      R => '0'
    );
\csr0_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr0[31]_i_1_n_0\,
      D => csr00(28),
      Q => \^csr0_c2f\(28),
      R => '0'
    );
\csr0_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr0[31]_i_1_n_0\,
      D => csr00(29),
      Q => \^csr0_c2f\(29),
      R => '0'
    );
\csr0_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr0[31]_i_1_n_0\,
      D => csr00(2),
      Q => \^csr0_c2f\(2),
      R => '0'
    );
\csr0_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr0[31]_i_1_n_0\,
      D => csr00(30),
      Q => \^csr0_c2f\(30),
      R => '0'
    );
\csr0_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr0[31]_i_1_n_0\,
      D => csr00(31),
      Q => \^csr0_c2f\(31),
      R => '0'
    );
\csr0_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr0[31]_i_1_n_0\,
      D => csr00(3),
      Q => \^csr0_c2f\(3),
      R => '0'
    );
\csr0_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr0[31]_i_1_n_0\,
      D => csr00(4),
      Q => \^csr0_c2f\(4),
      R => '0'
    );
\csr0_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr0[31]_i_1_n_0\,
      D => csr00(5),
      Q => \^csr0_c2f\(5),
      R => '0'
    );
\csr0_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr0[31]_i_1_n_0\,
      D => csr00(6),
      Q => \^csr0_c2f\(6),
      R => '0'
    );
\csr0_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr0[31]_i_1_n_0\,
      D => csr00(7),
      Q => \^csr0_c2f\(7),
      R => '0'
    );
\csr0_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr0[31]_i_1_n_0\,
      D => csr00(8),
      Q => \^csr0_c2f\(8),
      R => '0'
    );
\csr0_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr0[31]_i_1_n_0\,
      D => csr00(9),
      Q => \^csr0_c2f\(9),
      R => '0'
    );
\csr1[0]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(0),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr1_c2f\(0),
      O => csr10(0)
    );
\csr1[10]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(10),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr1_c2f\(10),
      O => csr10(10)
    );
\csr1[11]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(11),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr1_c2f\(11),
      O => csr10(11)
    );
\csr1[12]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(12),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr1_c2f\(12),
      O => csr10(12)
    );
\csr1[13]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(13),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr1_c2f\(13),
      O => csr10(13)
    );
\csr1[14]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(14),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr1_c2f\(14),
      O => csr10(14)
    );
\csr1[15]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(15),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr1_c2f\(15),
      O => csr10(15)
    );
\csr1[16]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(16),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr1_c2f\(16),
      O => csr10(16)
    );
\csr1[17]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(17),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr1_c2f\(17),
      O => csr10(17)
    );
\csr1[18]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(18),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr1_c2f\(18),
      O => csr10(18)
    );
\csr1[19]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(19),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr1_c2f\(19),
      O => csr10(19)
    );
\csr1[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(1),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr1_c2f\(1),
      O => csr10(1)
    );
\csr1[20]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(20),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr1_c2f\(20),
      O => csr10(20)
    );
\csr1[21]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(21),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr1_c2f\(21),
      O => csr10(21)
    );
\csr1[22]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(22),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr1_c2f\(22),
      O => csr10(22)
    );
\csr1[23]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(23),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr1_c2f\(23),
      O => csr10(23)
    );
\csr1[24]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(24),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr1_c2f\(24),
      O => csr10(24)
    );
\csr1[25]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(25),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr1_c2f\(25),
      O => csr10(25)
    );
\csr1[26]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(26),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr1_c2f\(26),
      O => csr10(26)
    );
\csr1[27]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(27),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr1_c2f\(27),
      O => csr10(27)
    );
\csr1[28]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(28),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr1_c2f\(28),
      O => csr10(28)
    );
\csr1[29]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(29),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr1_c2f\(29),
      O => csr10(29)
    );
\csr1[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(2),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr1_c2f\(2),
      O => csr10(2)
    );
\csr1[30]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(30),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr1_c2f\(30),
      O => csr10(30)
    );
\csr1[31]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0020"
    )
        port map (
      I0 => waddr(2),
      I1 => waddr(3),
      I2 => \csr0[31]_i_3_n_0\,
      I3 => waddr(4),
      O => \csr1[31]_i_1_n_0\
    );
\csr1[31]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(31),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr1_c2f\(31),
      O => csr10(31)
    );
\csr1[3]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(3),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr1_c2f\(3),
      O => csr10(3)
    );
\csr1[4]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(4),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr1_c2f\(4),
      O => csr10(4)
    );
\csr1[5]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(5),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr1_c2f\(5),
      O => csr10(5)
    );
\csr1[6]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(6),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr1_c2f\(6),
      O => csr10(6)
    );
\csr1[7]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(7),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr1_c2f\(7),
      O => csr10(7)
    );
\csr1[8]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(8),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr1_c2f\(8),
      O => csr10(8)
    );
\csr1[9]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(9),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr1_c2f\(9),
      O => csr10(9)
    );
\csr1_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr1[31]_i_1_n_0\,
      D => csr10(0),
      Q => \^csr1_c2f\(0),
      R => '0'
    );
\csr1_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr1[31]_i_1_n_0\,
      D => csr10(10),
      Q => \^csr1_c2f\(10),
      R => '0'
    );
\csr1_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr1[31]_i_1_n_0\,
      D => csr10(11),
      Q => \^csr1_c2f\(11),
      R => '0'
    );
\csr1_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr1[31]_i_1_n_0\,
      D => csr10(12),
      Q => \^csr1_c2f\(12),
      R => '0'
    );
\csr1_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr1[31]_i_1_n_0\,
      D => csr10(13),
      Q => \^csr1_c2f\(13),
      R => '0'
    );
\csr1_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr1[31]_i_1_n_0\,
      D => csr10(14),
      Q => \^csr1_c2f\(14),
      R => '0'
    );
\csr1_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr1[31]_i_1_n_0\,
      D => csr10(15),
      Q => \^csr1_c2f\(15),
      R => '0'
    );
\csr1_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr1[31]_i_1_n_0\,
      D => csr10(16),
      Q => \^csr1_c2f\(16),
      R => '0'
    );
\csr1_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr1[31]_i_1_n_0\,
      D => csr10(17),
      Q => \^csr1_c2f\(17),
      R => '0'
    );
\csr1_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr1[31]_i_1_n_0\,
      D => csr10(18),
      Q => \^csr1_c2f\(18),
      R => '0'
    );
\csr1_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr1[31]_i_1_n_0\,
      D => csr10(19),
      Q => \^csr1_c2f\(19),
      R => '0'
    );
\csr1_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr1[31]_i_1_n_0\,
      D => csr10(1),
      Q => \^csr1_c2f\(1),
      R => '0'
    );
\csr1_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr1[31]_i_1_n_0\,
      D => csr10(20),
      Q => \^csr1_c2f\(20),
      R => '0'
    );
\csr1_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr1[31]_i_1_n_0\,
      D => csr10(21),
      Q => \^csr1_c2f\(21),
      R => '0'
    );
\csr1_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr1[31]_i_1_n_0\,
      D => csr10(22),
      Q => \^csr1_c2f\(22),
      R => '0'
    );
\csr1_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr1[31]_i_1_n_0\,
      D => csr10(23),
      Q => \^csr1_c2f\(23),
      R => '0'
    );
\csr1_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr1[31]_i_1_n_0\,
      D => csr10(24),
      Q => \^csr1_c2f\(24),
      R => '0'
    );
\csr1_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr1[31]_i_1_n_0\,
      D => csr10(25),
      Q => \^csr1_c2f\(25),
      R => '0'
    );
\csr1_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr1[31]_i_1_n_0\,
      D => csr10(26),
      Q => \^csr1_c2f\(26),
      R => '0'
    );
\csr1_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr1[31]_i_1_n_0\,
      D => csr10(27),
      Q => \^csr1_c2f\(27),
      R => '0'
    );
\csr1_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr1[31]_i_1_n_0\,
      D => csr10(28),
      Q => \^csr1_c2f\(28),
      R => '0'
    );
\csr1_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr1[31]_i_1_n_0\,
      D => csr10(29),
      Q => \^csr1_c2f\(29),
      R => '0'
    );
\csr1_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr1[31]_i_1_n_0\,
      D => csr10(2),
      Q => \^csr1_c2f\(2),
      R => '0'
    );
\csr1_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr1[31]_i_1_n_0\,
      D => csr10(30),
      Q => \^csr1_c2f\(30),
      R => '0'
    );
\csr1_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr1[31]_i_1_n_0\,
      D => csr10(31),
      Q => \^csr1_c2f\(31),
      R => '0'
    );
\csr1_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr1[31]_i_1_n_0\,
      D => csr10(3),
      Q => \^csr1_c2f\(3),
      R => '0'
    );
\csr1_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr1[31]_i_1_n_0\,
      D => csr10(4),
      Q => \^csr1_c2f\(4),
      R => '0'
    );
\csr1_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr1[31]_i_1_n_0\,
      D => csr10(5),
      Q => \^csr1_c2f\(5),
      R => '0'
    );
\csr1_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr1[31]_i_1_n_0\,
      D => csr10(6),
      Q => \^csr1_c2f\(6),
      R => '0'
    );
\csr1_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr1[31]_i_1_n_0\,
      D => csr10(7),
      Q => \^csr1_c2f\(7),
      R => '0'
    );
\csr1_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr1[31]_i_1_n_0\,
      D => csr10(8),
      Q => \^csr1_c2f\(8),
      R => '0'
    );
\csr1_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr1[31]_i_1_n_0\,
      D => csr10(9),
      Q => \^csr1_c2f\(9),
      R => '0'
    );
\csr2[0]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(0),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr2_c2f\(0),
      O => csr20(0)
    );
\csr2[10]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(10),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr2_c2f\(10),
      O => csr20(10)
    );
\csr2[11]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(11),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr2_c2f\(11),
      O => csr20(11)
    );
\csr2[12]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(12),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr2_c2f\(12),
      O => csr20(12)
    );
\csr2[13]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(13),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr2_c2f\(13),
      O => csr20(13)
    );
\csr2[14]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(14),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr2_c2f\(14),
      O => csr20(14)
    );
\csr2[15]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(15),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr2_c2f\(15),
      O => csr20(15)
    );
\csr2[16]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(16),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr2_c2f\(16),
      O => csr20(16)
    );
\csr2[17]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(17),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr2_c2f\(17),
      O => csr20(17)
    );
\csr2[18]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(18),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr2_c2f\(18),
      O => csr20(18)
    );
\csr2[19]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(19),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr2_c2f\(19),
      O => csr20(19)
    );
\csr2[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(1),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr2_c2f\(1),
      O => csr20(1)
    );
\csr2[20]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(20),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr2_c2f\(20),
      O => csr20(20)
    );
\csr2[21]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(21),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr2_c2f\(21),
      O => csr20(21)
    );
\csr2[22]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(22),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr2_c2f\(22),
      O => csr20(22)
    );
\csr2[23]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(23),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr2_c2f\(23),
      O => csr20(23)
    );
\csr2[24]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(24),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr2_c2f\(24),
      O => csr20(24)
    );
\csr2[25]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(25),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr2_c2f\(25),
      O => csr20(25)
    );
\csr2[26]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(26),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr2_c2f\(26),
      O => csr20(26)
    );
\csr2[27]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(27),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr2_c2f\(27),
      O => csr20(27)
    );
\csr2[28]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(28),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr2_c2f\(28),
      O => csr20(28)
    );
\csr2[29]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(29),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr2_c2f\(29),
      O => csr20(29)
    );
\csr2[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(2),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr2_c2f\(2),
      O => csr20(2)
    );
\csr2[30]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(30),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr2_c2f\(30),
      O => csr20(30)
    );
\csr2[31]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0020"
    )
        port map (
      I0 => \csr0[31]_i_3_n_0\,
      I1 => waddr(4),
      I2 => waddr(3),
      I3 => waddr(2),
      O => \csr2[31]_i_1_n_0\
    );
\csr2[31]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(31),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr2_c2f\(31),
      O => csr20(31)
    );
\csr2[3]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(3),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr2_c2f\(3),
      O => csr20(3)
    );
\csr2[4]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(4),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr2_c2f\(4),
      O => csr20(4)
    );
\csr2[5]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(5),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr2_c2f\(5),
      O => csr20(5)
    );
\csr2[6]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(6),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr2_c2f\(6),
      O => csr20(6)
    );
\csr2[7]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(7),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr2_c2f\(7),
      O => csr20(7)
    );
\csr2[8]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(8),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr2_c2f\(8),
      O => csr20(8)
    );
\csr2[9]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(9),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr2_c2f\(9),
      O => csr20(9)
    );
\csr2_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr2[31]_i_1_n_0\,
      D => csr20(0),
      Q => \^csr2_c2f\(0),
      R => '0'
    );
\csr2_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr2[31]_i_1_n_0\,
      D => csr20(10),
      Q => \^csr2_c2f\(10),
      R => '0'
    );
\csr2_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr2[31]_i_1_n_0\,
      D => csr20(11),
      Q => \^csr2_c2f\(11),
      R => '0'
    );
\csr2_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr2[31]_i_1_n_0\,
      D => csr20(12),
      Q => \^csr2_c2f\(12),
      R => '0'
    );
\csr2_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr2[31]_i_1_n_0\,
      D => csr20(13),
      Q => \^csr2_c2f\(13),
      R => '0'
    );
\csr2_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr2[31]_i_1_n_0\,
      D => csr20(14),
      Q => \^csr2_c2f\(14),
      R => '0'
    );
\csr2_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr2[31]_i_1_n_0\,
      D => csr20(15),
      Q => \^csr2_c2f\(15),
      R => '0'
    );
\csr2_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr2[31]_i_1_n_0\,
      D => csr20(16),
      Q => \^csr2_c2f\(16),
      R => '0'
    );
\csr2_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr2[31]_i_1_n_0\,
      D => csr20(17),
      Q => \^csr2_c2f\(17),
      R => '0'
    );
\csr2_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr2[31]_i_1_n_0\,
      D => csr20(18),
      Q => \^csr2_c2f\(18),
      R => '0'
    );
\csr2_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr2[31]_i_1_n_0\,
      D => csr20(19),
      Q => \^csr2_c2f\(19),
      R => '0'
    );
\csr2_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr2[31]_i_1_n_0\,
      D => csr20(1),
      Q => \^csr2_c2f\(1),
      R => '0'
    );
\csr2_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr2[31]_i_1_n_0\,
      D => csr20(20),
      Q => \^csr2_c2f\(20),
      R => '0'
    );
\csr2_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr2[31]_i_1_n_0\,
      D => csr20(21),
      Q => \^csr2_c2f\(21),
      R => '0'
    );
\csr2_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr2[31]_i_1_n_0\,
      D => csr20(22),
      Q => \^csr2_c2f\(22),
      R => '0'
    );
\csr2_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr2[31]_i_1_n_0\,
      D => csr20(23),
      Q => \^csr2_c2f\(23),
      R => '0'
    );
\csr2_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr2[31]_i_1_n_0\,
      D => csr20(24),
      Q => \^csr2_c2f\(24),
      R => '0'
    );
\csr2_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr2[31]_i_1_n_0\,
      D => csr20(25),
      Q => \^csr2_c2f\(25),
      R => '0'
    );
\csr2_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr2[31]_i_1_n_0\,
      D => csr20(26),
      Q => \^csr2_c2f\(26),
      R => '0'
    );
\csr2_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr2[31]_i_1_n_0\,
      D => csr20(27),
      Q => \^csr2_c2f\(27),
      R => '0'
    );
\csr2_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr2[31]_i_1_n_0\,
      D => csr20(28),
      Q => \^csr2_c2f\(28),
      R => '0'
    );
\csr2_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr2[31]_i_1_n_0\,
      D => csr20(29),
      Q => \^csr2_c2f\(29),
      R => '0'
    );
\csr2_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr2[31]_i_1_n_0\,
      D => csr20(2),
      Q => \^csr2_c2f\(2),
      R => '0'
    );
\csr2_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr2[31]_i_1_n_0\,
      D => csr20(30),
      Q => \^csr2_c2f\(30),
      R => '0'
    );
\csr2_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr2[31]_i_1_n_0\,
      D => csr20(31),
      Q => \^csr2_c2f\(31),
      R => '0'
    );
\csr2_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr2[31]_i_1_n_0\,
      D => csr20(3),
      Q => \^csr2_c2f\(3),
      R => '0'
    );
\csr2_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr2[31]_i_1_n_0\,
      D => csr20(4),
      Q => \^csr2_c2f\(4),
      R => '0'
    );
\csr2_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr2[31]_i_1_n_0\,
      D => csr20(5),
      Q => \^csr2_c2f\(5),
      R => '0'
    );
\csr2_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr2[31]_i_1_n_0\,
      D => csr20(6),
      Q => \^csr2_c2f\(6),
      R => '0'
    );
\csr2_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr2[31]_i_1_n_0\,
      D => csr20(7),
      Q => \^csr2_c2f\(7),
      R => '0'
    );
\csr2_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr2[31]_i_1_n_0\,
      D => csr20(8),
      Q => \^csr2_c2f\(8),
      R => '0'
    );
\csr2_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr2[31]_i_1_n_0\,
      D => csr20(9),
      Q => \^csr2_c2f\(9),
      R => '0'
    );
\csr3[0]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(0),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr3_c2f\(0),
      O => csr30(0)
    );
\csr3[10]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(10),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr3_c2f\(10),
      O => csr30(10)
    );
\csr3[11]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(11),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr3_c2f\(11),
      O => csr30(11)
    );
\csr3[12]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(12),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr3_c2f\(12),
      O => csr30(12)
    );
\csr3[13]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(13),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr3_c2f\(13),
      O => csr30(13)
    );
\csr3[14]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(14),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr3_c2f\(14),
      O => csr30(14)
    );
\csr3[15]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(15),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr3_c2f\(15),
      O => csr30(15)
    );
\csr3[16]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(16),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr3_c2f\(16),
      O => csr30(16)
    );
\csr3[17]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(17),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr3_c2f\(17),
      O => csr30(17)
    );
\csr3[18]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(18),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr3_c2f\(18),
      O => csr30(18)
    );
\csr3[19]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(19),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr3_c2f\(19),
      O => csr30(19)
    );
\csr3[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(1),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr3_c2f\(1),
      O => csr30(1)
    );
\csr3[20]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(20),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr3_c2f\(20),
      O => csr30(20)
    );
\csr3[21]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(21),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr3_c2f\(21),
      O => csr30(21)
    );
\csr3[22]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(22),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr3_c2f\(22),
      O => csr30(22)
    );
\csr3[23]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(23),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr3_c2f\(23),
      O => csr30(23)
    );
\csr3[24]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(24),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr3_c2f\(24),
      O => csr30(24)
    );
\csr3[25]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(25),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr3_c2f\(25),
      O => csr30(25)
    );
\csr3[26]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(26),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr3_c2f\(26),
      O => csr30(26)
    );
\csr3[27]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(27),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr3_c2f\(27),
      O => csr30(27)
    );
\csr3[28]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(28),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr3_c2f\(28),
      O => csr30(28)
    );
\csr3[29]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(29),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr3_c2f\(29),
      O => csr30(29)
    );
\csr3[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(2),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr3_c2f\(2),
      O => csr30(2)
    );
\csr3[30]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(30),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr3_c2f\(30),
      O => csr30(30)
    );
\csr3[31]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0800"
    )
        port map (
      I0 => waddr(2),
      I1 => waddr(3),
      I2 => waddr(4),
      I3 => \csr0[31]_i_3_n_0\,
      O => \csr3[31]_i_1_n_0\
    );
\csr3[31]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(31),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr3_c2f\(31),
      O => csr30(31)
    );
\csr3[3]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(3),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr3_c2f\(3),
      O => csr30(3)
    );
\csr3[4]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(4),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr3_c2f\(4),
      O => csr30(4)
    );
\csr3[5]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(5),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr3_c2f\(5),
      O => csr30(5)
    );
\csr3[6]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(6),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr3_c2f\(6),
      O => csr30(6)
    );
\csr3[7]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(7),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr3_c2f\(7),
      O => csr30(7)
    );
\csr3[8]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(8),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr3_c2f\(8),
      O => csr30(8)
    );
\csr3[9]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(9),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr3_c2f\(9),
      O => csr30(9)
    );
\csr3_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr3[31]_i_1_n_0\,
      D => csr30(0),
      Q => \^csr3_c2f\(0),
      R => '0'
    );
\csr3_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr3[31]_i_1_n_0\,
      D => csr30(10),
      Q => \^csr3_c2f\(10),
      R => '0'
    );
\csr3_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr3[31]_i_1_n_0\,
      D => csr30(11),
      Q => \^csr3_c2f\(11),
      R => '0'
    );
\csr3_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr3[31]_i_1_n_0\,
      D => csr30(12),
      Q => \^csr3_c2f\(12),
      R => '0'
    );
\csr3_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr3[31]_i_1_n_0\,
      D => csr30(13),
      Q => \^csr3_c2f\(13),
      R => '0'
    );
\csr3_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr3[31]_i_1_n_0\,
      D => csr30(14),
      Q => \^csr3_c2f\(14),
      R => '0'
    );
\csr3_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr3[31]_i_1_n_0\,
      D => csr30(15),
      Q => \^csr3_c2f\(15),
      R => '0'
    );
\csr3_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr3[31]_i_1_n_0\,
      D => csr30(16),
      Q => \^csr3_c2f\(16),
      R => '0'
    );
\csr3_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr3[31]_i_1_n_0\,
      D => csr30(17),
      Q => \^csr3_c2f\(17),
      R => '0'
    );
\csr3_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr3[31]_i_1_n_0\,
      D => csr30(18),
      Q => \^csr3_c2f\(18),
      R => '0'
    );
\csr3_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr3[31]_i_1_n_0\,
      D => csr30(19),
      Q => \^csr3_c2f\(19),
      R => '0'
    );
\csr3_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr3[31]_i_1_n_0\,
      D => csr30(1),
      Q => \^csr3_c2f\(1),
      R => '0'
    );
\csr3_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr3[31]_i_1_n_0\,
      D => csr30(20),
      Q => \^csr3_c2f\(20),
      R => '0'
    );
\csr3_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr3[31]_i_1_n_0\,
      D => csr30(21),
      Q => \^csr3_c2f\(21),
      R => '0'
    );
\csr3_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr3[31]_i_1_n_0\,
      D => csr30(22),
      Q => \^csr3_c2f\(22),
      R => '0'
    );
\csr3_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr3[31]_i_1_n_0\,
      D => csr30(23),
      Q => \^csr3_c2f\(23),
      R => '0'
    );
\csr3_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr3[31]_i_1_n_0\,
      D => csr30(24),
      Q => \^csr3_c2f\(24),
      R => '0'
    );
\csr3_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr3[31]_i_1_n_0\,
      D => csr30(25),
      Q => \^csr3_c2f\(25),
      R => '0'
    );
\csr3_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr3[31]_i_1_n_0\,
      D => csr30(26),
      Q => \^csr3_c2f\(26),
      R => '0'
    );
\csr3_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr3[31]_i_1_n_0\,
      D => csr30(27),
      Q => \^csr3_c2f\(27),
      R => '0'
    );
\csr3_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr3[31]_i_1_n_0\,
      D => csr30(28),
      Q => \^csr3_c2f\(28),
      R => '0'
    );
\csr3_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr3[31]_i_1_n_0\,
      D => csr30(29),
      Q => \^csr3_c2f\(29),
      R => '0'
    );
\csr3_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr3[31]_i_1_n_0\,
      D => csr30(2),
      Q => \^csr3_c2f\(2),
      R => '0'
    );
\csr3_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr3[31]_i_1_n_0\,
      D => csr30(30),
      Q => \^csr3_c2f\(30),
      R => '0'
    );
\csr3_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr3[31]_i_1_n_0\,
      D => csr30(31),
      Q => \^csr3_c2f\(31),
      R => '0'
    );
\csr3_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr3[31]_i_1_n_0\,
      D => csr30(3),
      Q => \^csr3_c2f\(3),
      R => '0'
    );
\csr3_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr3[31]_i_1_n_0\,
      D => csr30(4),
      Q => \^csr3_c2f\(4),
      R => '0'
    );
\csr3_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr3[31]_i_1_n_0\,
      D => csr30(5),
      Q => \^csr3_c2f\(5),
      R => '0'
    );
\csr3_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr3[31]_i_1_n_0\,
      D => csr30(6),
      Q => \^csr3_c2f\(6),
      R => '0'
    );
\csr3_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr3[31]_i_1_n_0\,
      D => csr30(7),
      Q => \^csr3_c2f\(7),
      R => '0'
    );
\csr3_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr3[31]_i_1_n_0\,
      D => csr30(8),
      Q => \^csr3_c2f\(8),
      R => '0'
    );
\csr3_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr3[31]_i_1_n_0\,
      D => csr30(9),
      Q => \^csr3_c2f\(9),
      R => '0'
    );
\csr4[0]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(0),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr4_c2f\(0),
      O => csr40(0)
    );
\csr4[10]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(10),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr4_c2f\(10),
      O => csr40(10)
    );
\csr4[11]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(11),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr4_c2f\(11),
      O => csr40(11)
    );
\csr4[12]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(12),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr4_c2f\(12),
      O => csr40(12)
    );
\csr4[13]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(13),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr4_c2f\(13),
      O => csr40(13)
    );
\csr4[14]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(14),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr4_c2f\(14),
      O => csr40(14)
    );
\csr4[15]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(15),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr4_c2f\(15),
      O => csr40(15)
    );
\csr4[16]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(16),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr4_c2f\(16),
      O => csr40(16)
    );
\csr4[17]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(17),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr4_c2f\(17),
      O => csr40(17)
    );
\csr4[18]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(18),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr4_c2f\(18),
      O => csr40(18)
    );
\csr4[19]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(19),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr4_c2f\(19),
      O => csr40(19)
    );
\csr4[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(1),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr4_c2f\(1),
      O => csr40(1)
    );
\csr4[20]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(20),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr4_c2f\(20),
      O => csr40(20)
    );
\csr4[21]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(21),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr4_c2f\(21),
      O => csr40(21)
    );
\csr4[22]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(22),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr4_c2f\(22),
      O => csr40(22)
    );
\csr4[23]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(23),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr4_c2f\(23),
      O => csr40(23)
    );
\csr4[24]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(24),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr4_c2f\(24),
      O => csr40(24)
    );
\csr4[25]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(25),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr4_c2f\(25),
      O => csr40(25)
    );
\csr4[26]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(26),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr4_c2f\(26),
      O => csr40(26)
    );
\csr4[27]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(27),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr4_c2f\(27),
      O => csr40(27)
    );
\csr4[28]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(28),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr4_c2f\(28),
      O => csr40(28)
    );
\csr4[29]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(29),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr4_c2f\(29),
      O => csr40(29)
    );
\csr4[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(2),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr4_c2f\(2),
      O => csr40(2)
    );
\csr4[30]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(30),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr4_c2f\(30),
      O => csr40(30)
    );
\csr4[31]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => waddr(3),
      I1 => \csr4[31]_i_3_n_0\,
      I2 => waddr(2),
      O => \csr4[31]_i_1_n_0\
    );
\csr4[31]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(31),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr4_c2f\(31),
      O => csr40(31)
    );
\csr4[31]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00002000"
    )
        port map (
      I0 => waddr(4),
      I1 => waddr(1),
      I2 => \^s_axi_csrs_wready\,
      I3 => s_axi_csrs_wvalid,
      I4 => waddr(0),
      O => \csr4[31]_i_3_n_0\
    );
\csr4[3]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(3),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr4_c2f\(3),
      O => csr40(3)
    );
\csr4[4]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(4),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr4_c2f\(4),
      O => csr40(4)
    );
\csr4[5]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(5),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr4_c2f\(5),
      O => csr40(5)
    );
\csr4[6]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(6),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr4_c2f\(6),
      O => csr40(6)
    );
\csr4[7]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(7),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr4_c2f\(7),
      O => csr40(7)
    );
\csr4[8]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(8),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr4_c2f\(8),
      O => csr40(8)
    );
\csr4[9]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(9),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr4_c2f\(9),
      O => csr40(9)
    );
\csr4_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr4[31]_i_1_n_0\,
      D => csr40(0),
      Q => \^csr4_c2f\(0),
      R => '0'
    );
\csr4_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr4[31]_i_1_n_0\,
      D => csr40(10),
      Q => \^csr4_c2f\(10),
      R => '0'
    );
\csr4_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr4[31]_i_1_n_0\,
      D => csr40(11),
      Q => \^csr4_c2f\(11),
      R => '0'
    );
\csr4_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr4[31]_i_1_n_0\,
      D => csr40(12),
      Q => \^csr4_c2f\(12),
      R => '0'
    );
\csr4_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr4[31]_i_1_n_0\,
      D => csr40(13),
      Q => \^csr4_c2f\(13),
      R => '0'
    );
\csr4_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr4[31]_i_1_n_0\,
      D => csr40(14),
      Q => \^csr4_c2f\(14),
      R => '0'
    );
\csr4_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr4[31]_i_1_n_0\,
      D => csr40(15),
      Q => \^csr4_c2f\(15),
      R => '0'
    );
\csr4_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr4[31]_i_1_n_0\,
      D => csr40(16),
      Q => \^csr4_c2f\(16),
      R => '0'
    );
\csr4_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr4[31]_i_1_n_0\,
      D => csr40(17),
      Q => \^csr4_c2f\(17),
      R => '0'
    );
\csr4_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr4[31]_i_1_n_0\,
      D => csr40(18),
      Q => \^csr4_c2f\(18),
      R => '0'
    );
\csr4_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr4[31]_i_1_n_0\,
      D => csr40(19),
      Q => \^csr4_c2f\(19),
      R => '0'
    );
\csr4_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr4[31]_i_1_n_0\,
      D => csr40(1),
      Q => \^csr4_c2f\(1),
      R => '0'
    );
\csr4_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr4[31]_i_1_n_0\,
      D => csr40(20),
      Q => \^csr4_c2f\(20),
      R => '0'
    );
\csr4_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr4[31]_i_1_n_0\,
      D => csr40(21),
      Q => \^csr4_c2f\(21),
      R => '0'
    );
\csr4_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr4[31]_i_1_n_0\,
      D => csr40(22),
      Q => \^csr4_c2f\(22),
      R => '0'
    );
\csr4_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr4[31]_i_1_n_0\,
      D => csr40(23),
      Q => \^csr4_c2f\(23),
      R => '0'
    );
\csr4_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr4[31]_i_1_n_0\,
      D => csr40(24),
      Q => \^csr4_c2f\(24),
      R => '0'
    );
\csr4_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr4[31]_i_1_n_0\,
      D => csr40(25),
      Q => \^csr4_c2f\(25),
      R => '0'
    );
\csr4_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr4[31]_i_1_n_0\,
      D => csr40(26),
      Q => \^csr4_c2f\(26),
      R => '0'
    );
\csr4_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr4[31]_i_1_n_0\,
      D => csr40(27),
      Q => \^csr4_c2f\(27),
      R => '0'
    );
\csr4_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr4[31]_i_1_n_0\,
      D => csr40(28),
      Q => \^csr4_c2f\(28),
      R => '0'
    );
\csr4_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr4[31]_i_1_n_0\,
      D => csr40(29),
      Q => \^csr4_c2f\(29),
      R => '0'
    );
\csr4_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr4[31]_i_1_n_0\,
      D => csr40(2),
      Q => \^csr4_c2f\(2),
      R => '0'
    );
\csr4_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr4[31]_i_1_n_0\,
      D => csr40(30),
      Q => \^csr4_c2f\(30),
      R => '0'
    );
\csr4_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr4[31]_i_1_n_0\,
      D => csr40(31),
      Q => \^csr4_c2f\(31),
      R => '0'
    );
\csr4_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr4[31]_i_1_n_0\,
      D => csr40(3),
      Q => \^csr4_c2f\(3),
      R => '0'
    );
\csr4_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr4[31]_i_1_n_0\,
      D => csr40(4),
      Q => \^csr4_c2f\(4),
      R => '0'
    );
\csr4_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr4[31]_i_1_n_0\,
      D => csr40(5),
      Q => \^csr4_c2f\(5),
      R => '0'
    );
\csr4_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr4[31]_i_1_n_0\,
      D => csr40(6),
      Q => \^csr4_c2f\(6),
      R => '0'
    );
\csr4_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr4[31]_i_1_n_0\,
      D => csr40(7),
      Q => \^csr4_c2f\(7),
      R => '0'
    );
\csr4_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr4[31]_i_1_n_0\,
      D => csr40(8),
      Q => \^csr4_c2f\(8),
      R => '0'
    );
\csr4_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr4[31]_i_1_n_0\,
      D => csr40(9),
      Q => \^csr4_c2f\(9),
      R => '0'
    );
\csr5[0]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(0),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr5_c2f\(0),
      O => csr50(0)
    );
\csr5[10]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(10),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr5_c2f\(10),
      O => csr50(10)
    );
\csr5[11]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(11),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr5_c2f\(11),
      O => csr50(11)
    );
\csr5[12]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(12),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr5_c2f\(12),
      O => csr50(12)
    );
\csr5[13]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(13),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr5_c2f\(13),
      O => csr50(13)
    );
\csr5[14]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(14),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr5_c2f\(14),
      O => csr50(14)
    );
\csr5[15]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(15),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr5_c2f\(15),
      O => csr50(15)
    );
\csr5[16]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(16),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr5_c2f\(16),
      O => csr50(16)
    );
\csr5[17]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(17),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr5_c2f\(17),
      O => csr50(17)
    );
\csr5[18]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(18),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr5_c2f\(18),
      O => csr50(18)
    );
\csr5[19]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(19),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr5_c2f\(19),
      O => csr50(19)
    );
\csr5[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(1),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr5_c2f\(1),
      O => csr50(1)
    );
\csr5[20]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(20),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr5_c2f\(20),
      O => csr50(20)
    );
\csr5[21]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(21),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr5_c2f\(21),
      O => csr50(21)
    );
\csr5[22]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(22),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr5_c2f\(22),
      O => csr50(22)
    );
\csr5[23]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(23),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr5_c2f\(23),
      O => csr50(23)
    );
\csr5[24]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(24),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr5_c2f\(24),
      O => csr50(24)
    );
\csr5[25]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(25),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr5_c2f\(25),
      O => csr50(25)
    );
\csr5[26]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(26),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr5_c2f\(26),
      O => csr50(26)
    );
\csr5[27]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(27),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr5_c2f\(27),
      O => csr50(27)
    );
\csr5[28]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(28),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr5_c2f\(28),
      O => csr50(28)
    );
\csr5[29]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(29),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr5_c2f\(29),
      O => csr50(29)
    );
\csr5[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(2),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr5_c2f\(2),
      O => csr50(2)
    );
\csr5[30]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(30),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr5_c2f\(30),
      O => csr50(30)
    );
\csr5[31]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"20"
    )
        port map (
      I0 => waddr(2),
      I1 => waddr(3),
      I2 => \csr4[31]_i_3_n_0\,
      O => \csr5[31]_i_1_n_0\
    );
\csr5[31]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(31),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr5_c2f\(31),
      O => csr50(31)
    );
\csr5[3]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(3),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr5_c2f\(3),
      O => csr50(3)
    );
\csr5[4]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(4),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr5_c2f\(4),
      O => csr50(4)
    );
\csr5[5]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(5),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr5_c2f\(5),
      O => csr50(5)
    );
\csr5[6]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(6),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr5_c2f\(6),
      O => csr50(6)
    );
\csr5[7]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(7),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr5_c2f\(7),
      O => csr50(7)
    );
\csr5[8]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(8),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr5_c2f\(8),
      O => csr50(8)
    );
\csr5[9]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(9),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr5_c2f\(9),
      O => csr50(9)
    );
\csr5_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr5[31]_i_1_n_0\,
      D => csr50(0),
      Q => \^csr5_c2f\(0),
      R => '0'
    );
\csr5_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr5[31]_i_1_n_0\,
      D => csr50(10),
      Q => \^csr5_c2f\(10),
      R => '0'
    );
\csr5_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr5[31]_i_1_n_0\,
      D => csr50(11),
      Q => \^csr5_c2f\(11),
      R => '0'
    );
\csr5_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr5[31]_i_1_n_0\,
      D => csr50(12),
      Q => \^csr5_c2f\(12),
      R => '0'
    );
\csr5_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr5[31]_i_1_n_0\,
      D => csr50(13),
      Q => \^csr5_c2f\(13),
      R => '0'
    );
\csr5_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr5[31]_i_1_n_0\,
      D => csr50(14),
      Q => \^csr5_c2f\(14),
      R => '0'
    );
\csr5_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr5[31]_i_1_n_0\,
      D => csr50(15),
      Q => \^csr5_c2f\(15),
      R => '0'
    );
\csr5_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr5[31]_i_1_n_0\,
      D => csr50(16),
      Q => \^csr5_c2f\(16),
      R => '0'
    );
\csr5_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr5[31]_i_1_n_0\,
      D => csr50(17),
      Q => \^csr5_c2f\(17),
      R => '0'
    );
\csr5_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr5[31]_i_1_n_0\,
      D => csr50(18),
      Q => \^csr5_c2f\(18),
      R => '0'
    );
\csr5_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr5[31]_i_1_n_0\,
      D => csr50(19),
      Q => \^csr5_c2f\(19),
      R => '0'
    );
\csr5_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr5[31]_i_1_n_0\,
      D => csr50(1),
      Q => \^csr5_c2f\(1),
      R => '0'
    );
\csr5_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr5[31]_i_1_n_0\,
      D => csr50(20),
      Q => \^csr5_c2f\(20),
      R => '0'
    );
\csr5_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr5[31]_i_1_n_0\,
      D => csr50(21),
      Q => \^csr5_c2f\(21),
      R => '0'
    );
\csr5_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr5[31]_i_1_n_0\,
      D => csr50(22),
      Q => \^csr5_c2f\(22),
      R => '0'
    );
\csr5_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr5[31]_i_1_n_0\,
      D => csr50(23),
      Q => \^csr5_c2f\(23),
      R => '0'
    );
\csr5_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr5[31]_i_1_n_0\,
      D => csr50(24),
      Q => \^csr5_c2f\(24),
      R => '0'
    );
\csr5_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr5[31]_i_1_n_0\,
      D => csr50(25),
      Q => \^csr5_c2f\(25),
      R => '0'
    );
\csr5_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr5[31]_i_1_n_0\,
      D => csr50(26),
      Q => \^csr5_c2f\(26),
      R => '0'
    );
\csr5_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr5[31]_i_1_n_0\,
      D => csr50(27),
      Q => \^csr5_c2f\(27),
      R => '0'
    );
\csr5_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr5[31]_i_1_n_0\,
      D => csr50(28),
      Q => \^csr5_c2f\(28),
      R => '0'
    );
\csr5_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr5[31]_i_1_n_0\,
      D => csr50(29),
      Q => \^csr5_c2f\(29),
      R => '0'
    );
\csr5_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr5[31]_i_1_n_0\,
      D => csr50(2),
      Q => \^csr5_c2f\(2),
      R => '0'
    );
\csr5_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr5[31]_i_1_n_0\,
      D => csr50(30),
      Q => \^csr5_c2f\(30),
      R => '0'
    );
\csr5_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr5[31]_i_1_n_0\,
      D => csr50(31),
      Q => \^csr5_c2f\(31),
      R => '0'
    );
\csr5_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr5[31]_i_1_n_0\,
      D => csr50(3),
      Q => \^csr5_c2f\(3),
      R => '0'
    );
\csr5_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr5[31]_i_1_n_0\,
      D => csr50(4),
      Q => \^csr5_c2f\(4),
      R => '0'
    );
\csr5_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr5[31]_i_1_n_0\,
      D => csr50(5),
      Q => \^csr5_c2f\(5),
      R => '0'
    );
\csr5_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr5[31]_i_1_n_0\,
      D => csr50(6),
      Q => \^csr5_c2f\(6),
      R => '0'
    );
\csr5_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr5[31]_i_1_n_0\,
      D => csr50(7),
      Q => \^csr5_c2f\(7),
      R => '0'
    );
\csr5_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr5[31]_i_1_n_0\,
      D => csr50(8),
      Q => \^csr5_c2f\(8),
      R => '0'
    );
\csr5_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr5[31]_i_1_n_0\,
      D => csr50(9),
      Q => \^csr5_c2f\(9),
      R => '0'
    );
\csr6[0]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(0),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr6_c2f\(0),
      O => csr60(0)
    );
\csr6[10]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(10),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr6_c2f\(10),
      O => csr60(10)
    );
\csr6[11]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(11),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr6_c2f\(11),
      O => csr60(11)
    );
\csr6[12]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(12),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr6_c2f\(12),
      O => csr60(12)
    );
\csr6[13]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(13),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr6_c2f\(13),
      O => csr60(13)
    );
\csr6[14]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(14),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr6_c2f\(14),
      O => csr60(14)
    );
\csr6[15]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(15),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr6_c2f\(15),
      O => csr60(15)
    );
\csr6[16]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(16),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr6_c2f\(16),
      O => csr60(16)
    );
\csr6[17]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(17),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr6_c2f\(17),
      O => csr60(17)
    );
\csr6[18]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(18),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr6_c2f\(18),
      O => csr60(18)
    );
\csr6[19]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(19),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr6_c2f\(19),
      O => csr60(19)
    );
\csr6[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(1),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr6_c2f\(1),
      O => csr60(1)
    );
\csr6[20]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(20),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr6_c2f\(20),
      O => csr60(20)
    );
\csr6[21]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(21),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr6_c2f\(21),
      O => csr60(21)
    );
\csr6[22]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(22),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr6_c2f\(22),
      O => csr60(22)
    );
\csr6[23]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(23),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr6_c2f\(23),
      O => csr60(23)
    );
\csr6[24]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(24),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr6_c2f\(24),
      O => csr60(24)
    );
\csr6[25]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(25),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr6_c2f\(25),
      O => csr60(25)
    );
\csr6[26]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(26),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr6_c2f\(26),
      O => csr60(26)
    );
\csr6[27]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(27),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr6_c2f\(27),
      O => csr60(27)
    );
\csr6[28]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(28),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr6_c2f\(28),
      O => csr60(28)
    );
\csr6[29]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(29),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr6_c2f\(29),
      O => csr60(29)
    );
\csr6[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(2),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr6_c2f\(2),
      O => csr60(2)
    );
\csr6[30]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(30),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr6_c2f\(30),
      O => csr60(30)
    );
\csr6[31]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"08"
    )
        port map (
      I0 => \csr4[31]_i_3_n_0\,
      I1 => waddr(3),
      I2 => waddr(2),
      O => \csr6[31]_i_1_n_0\
    );
\csr6[31]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(31),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr6_c2f\(31),
      O => csr60(31)
    );
\csr6[3]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(3),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr6_c2f\(3),
      O => csr60(3)
    );
\csr6[4]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(4),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr6_c2f\(4),
      O => csr60(4)
    );
\csr6[5]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(5),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr6_c2f\(5),
      O => csr60(5)
    );
\csr6[6]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(6),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr6_c2f\(6),
      O => csr60(6)
    );
\csr6[7]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(7),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr6_c2f\(7),
      O => csr60(7)
    );
\csr6[8]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(8),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr6_c2f\(8),
      O => csr60(8)
    );
\csr6[9]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(9),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr6_c2f\(9),
      O => csr60(9)
    );
\csr6_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr6[31]_i_1_n_0\,
      D => csr60(0),
      Q => \^csr6_c2f\(0),
      R => '0'
    );
\csr6_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr6[31]_i_1_n_0\,
      D => csr60(10),
      Q => \^csr6_c2f\(10),
      R => '0'
    );
\csr6_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr6[31]_i_1_n_0\,
      D => csr60(11),
      Q => \^csr6_c2f\(11),
      R => '0'
    );
\csr6_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr6[31]_i_1_n_0\,
      D => csr60(12),
      Q => \^csr6_c2f\(12),
      R => '0'
    );
\csr6_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr6[31]_i_1_n_0\,
      D => csr60(13),
      Q => \^csr6_c2f\(13),
      R => '0'
    );
\csr6_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr6[31]_i_1_n_0\,
      D => csr60(14),
      Q => \^csr6_c2f\(14),
      R => '0'
    );
\csr6_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr6[31]_i_1_n_0\,
      D => csr60(15),
      Q => \^csr6_c2f\(15),
      R => '0'
    );
\csr6_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr6[31]_i_1_n_0\,
      D => csr60(16),
      Q => \^csr6_c2f\(16),
      R => '0'
    );
\csr6_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr6[31]_i_1_n_0\,
      D => csr60(17),
      Q => \^csr6_c2f\(17),
      R => '0'
    );
\csr6_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr6[31]_i_1_n_0\,
      D => csr60(18),
      Q => \^csr6_c2f\(18),
      R => '0'
    );
\csr6_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr6[31]_i_1_n_0\,
      D => csr60(19),
      Q => \^csr6_c2f\(19),
      R => '0'
    );
\csr6_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr6[31]_i_1_n_0\,
      D => csr60(1),
      Q => \^csr6_c2f\(1),
      R => '0'
    );
\csr6_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr6[31]_i_1_n_0\,
      D => csr60(20),
      Q => \^csr6_c2f\(20),
      R => '0'
    );
\csr6_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr6[31]_i_1_n_0\,
      D => csr60(21),
      Q => \^csr6_c2f\(21),
      R => '0'
    );
\csr6_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr6[31]_i_1_n_0\,
      D => csr60(22),
      Q => \^csr6_c2f\(22),
      R => '0'
    );
\csr6_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr6[31]_i_1_n_0\,
      D => csr60(23),
      Q => \^csr6_c2f\(23),
      R => '0'
    );
\csr6_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr6[31]_i_1_n_0\,
      D => csr60(24),
      Q => \^csr6_c2f\(24),
      R => '0'
    );
\csr6_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr6[31]_i_1_n_0\,
      D => csr60(25),
      Q => \^csr6_c2f\(25),
      R => '0'
    );
\csr6_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr6[31]_i_1_n_0\,
      D => csr60(26),
      Q => \^csr6_c2f\(26),
      R => '0'
    );
\csr6_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr6[31]_i_1_n_0\,
      D => csr60(27),
      Q => \^csr6_c2f\(27),
      R => '0'
    );
\csr6_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr6[31]_i_1_n_0\,
      D => csr60(28),
      Q => \^csr6_c2f\(28),
      R => '0'
    );
\csr6_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr6[31]_i_1_n_0\,
      D => csr60(29),
      Q => \^csr6_c2f\(29),
      R => '0'
    );
\csr6_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr6[31]_i_1_n_0\,
      D => csr60(2),
      Q => \^csr6_c2f\(2),
      R => '0'
    );
\csr6_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr6[31]_i_1_n_0\,
      D => csr60(30),
      Q => \^csr6_c2f\(30),
      R => '0'
    );
\csr6_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr6[31]_i_1_n_0\,
      D => csr60(31),
      Q => \^csr6_c2f\(31),
      R => '0'
    );
\csr6_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr6[31]_i_1_n_0\,
      D => csr60(3),
      Q => \^csr6_c2f\(3),
      R => '0'
    );
\csr6_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr6[31]_i_1_n_0\,
      D => csr60(4),
      Q => \^csr6_c2f\(4),
      R => '0'
    );
\csr6_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr6[31]_i_1_n_0\,
      D => csr60(5),
      Q => \^csr6_c2f\(5),
      R => '0'
    );
\csr6_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr6[31]_i_1_n_0\,
      D => csr60(6),
      Q => \^csr6_c2f\(6),
      R => '0'
    );
\csr6_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr6[31]_i_1_n_0\,
      D => csr60(7),
      Q => \^csr6_c2f\(7),
      R => '0'
    );
\csr6_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr6[31]_i_1_n_0\,
      D => csr60(8),
      Q => \^csr6_c2f\(8),
      R => '0'
    );
\csr6_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr6[31]_i_1_n_0\,
      D => csr60(9),
      Q => \^csr6_c2f\(9),
      R => '0'
    );
\csr7[0]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(0),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr7_c2f\(0),
      O => csr70(0)
    );
\csr7[10]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(10),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr7_c2f\(10),
      O => csr70(10)
    );
\csr7[11]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(11),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr7_c2f\(11),
      O => csr70(11)
    );
\csr7[12]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(12),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr7_c2f\(12),
      O => csr70(12)
    );
\csr7[13]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(13),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr7_c2f\(13),
      O => csr70(13)
    );
\csr7[14]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(14),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr7_c2f\(14),
      O => csr70(14)
    );
\csr7[15]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(15),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr7_c2f\(15),
      O => csr70(15)
    );
\csr7[16]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(16),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr7_c2f\(16),
      O => csr70(16)
    );
\csr7[17]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(17),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr7_c2f\(17),
      O => csr70(17)
    );
\csr7[18]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(18),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr7_c2f\(18),
      O => csr70(18)
    );
\csr7[19]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(19),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr7_c2f\(19),
      O => csr70(19)
    );
\csr7[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(1),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr7_c2f\(1),
      O => csr70(1)
    );
\csr7[20]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(20),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr7_c2f\(20),
      O => csr70(20)
    );
\csr7[21]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(21),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr7_c2f\(21),
      O => csr70(21)
    );
\csr7[22]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(22),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr7_c2f\(22),
      O => csr70(22)
    );
\csr7[23]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(23),
      I1 => s_axi_csrs_wstrb(2),
      I2 => \^csr7_c2f\(23),
      O => csr70(23)
    );
\csr7[24]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(24),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr7_c2f\(24),
      O => csr70(24)
    );
\csr7[25]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(25),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr7_c2f\(25),
      O => csr70(25)
    );
\csr7[26]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(26),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr7_c2f\(26),
      O => csr70(26)
    );
\csr7[27]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(27),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr7_c2f\(27),
      O => csr70(27)
    );
\csr7[28]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(28),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr7_c2f\(28),
      O => csr70(28)
    );
\csr7[29]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(29),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr7_c2f\(29),
      O => csr70(29)
    );
\csr7[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(2),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr7_c2f\(2),
      O => csr70(2)
    );
\csr7[30]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(30),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr7_c2f\(30),
      O => csr70(30)
    );
\csr7[31]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"80"
    )
        port map (
      I0 => waddr(2),
      I1 => \csr4[31]_i_3_n_0\,
      I2 => waddr(3),
      O => \csr7[31]_i_1_n_0\
    );
\csr7[31]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(31),
      I1 => s_axi_csrs_wstrb(3),
      I2 => \^csr7_c2f\(31),
      O => csr70(31)
    );
\csr7[3]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(3),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr7_c2f\(3),
      O => csr70(3)
    );
\csr7[4]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(4),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr7_c2f\(4),
      O => csr70(4)
    );
\csr7[5]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(5),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr7_c2f\(5),
      O => csr70(5)
    );
\csr7[6]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(6),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr7_c2f\(6),
      O => csr70(6)
    );
\csr7[7]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(7),
      I1 => s_axi_csrs_wstrb(0),
      I2 => \^csr7_c2f\(7),
      O => csr70(7)
    );
\csr7[8]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(8),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr7_c2f\(8),
      O => csr70(8)
    );
\csr7[9]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axi_csrs_wdata(9),
      I1 => s_axi_csrs_wstrb(1),
      I2 => \^csr7_c2f\(9),
      O => csr70(9)
    );
\csr7_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr7[31]_i_1_n_0\,
      D => csr70(0),
      Q => \^csr7_c2f\(0),
      R => '0'
    );
\csr7_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr7[31]_i_1_n_0\,
      D => csr70(10),
      Q => \^csr7_c2f\(10),
      R => '0'
    );
\csr7_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr7[31]_i_1_n_0\,
      D => csr70(11),
      Q => \^csr7_c2f\(11),
      R => '0'
    );
\csr7_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr7[31]_i_1_n_0\,
      D => csr70(12),
      Q => \^csr7_c2f\(12),
      R => '0'
    );
\csr7_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr7[31]_i_1_n_0\,
      D => csr70(13),
      Q => \^csr7_c2f\(13),
      R => '0'
    );
\csr7_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr7[31]_i_1_n_0\,
      D => csr70(14),
      Q => \^csr7_c2f\(14),
      R => '0'
    );
\csr7_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr7[31]_i_1_n_0\,
      D => csr70(15),
      Q => \^csr7_c2f\(15),
      R => '0'
    );
\csr7_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr7[31]_i_1_n_0\,
      D => csr70(16),
      Q => \^csr7_c2f\(16),
      R => '0'
    );
\csr7_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr7[31]_i_1_n_0\,
      D => csr70(17),
      Q => \^csr7_c2f\(17),
      R => '0'
    );
\csr7_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr7[31]_i_1_n_0\,
      D => csr70(18),
      Q => \^csr7_c2f\(18),
      R => '0'
    );
\csr7_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr7[31]_i_1_n_0\,
      D => csr70(19),
      Q => \^csr7_c2f\(19),
      R => '0'
    );
\csr7_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr7[31]_i_1_n_0\,
      D => csr70(1),
      Q => \^csr7_c2f\(1),
      R => '0'
    );
\csr7_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr7[31]_i_1_n_0\,
      D => csr70(20),
      Q => \^csr7_c2f\(20),
      R => '0'
    );
\csr7_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr7[31]_i_1_n_0\,
      D => csr70(21),
      Q => \^csr7_c2f\(21),
      R => '0'
    );
\csr7_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr7[31]_i_1_n_0\,
      D => csr70(22),
      Q => \^csr7_c2f\(22),
      R => '0'
    );
\csr7_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr7[31]_i_1_n_0\,
      D => csr70(23),
      Q => \^csr7_c2f\(23),
      R => '0'
    );
\csr7_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr7[31]_i_1_n_0\,
      D => csr70(24),
      Q => \^csr7_c2f\(24),
      R => '0'
    );
\csr7_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr7[31]_i_1_n_0\,
      D => csr70(25),
      Q => \^csr7_c2f\(25),
      R => '0'
    );
\csr7_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr7[31]_i_1_n_0\,
      D => csr70(26),
      Q => \^csr7_c2f\(26),
      R => '0'
    );
\csr7_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr7[31]_i_1_n_0\,
      D => csr70(27),
      Q => \^csr7_c2f\(27),
      R => '0'
    );
\csr7_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr7[31]_i_1_n_0\,
      D => csr70(28),
      Q => \^csr7_c2f\(28),
      R => '0'
    );
\csr7_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr7[31]_i_1_n_0\,
      D => csr70(29),
      Q => \^csr7_c2f\(29),
      R => '0'
    );
\csr7_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr7[31]_i_1_n_0\,
      D => csr70(2),
      Q => \^csr7_c2f\(2),
      R => '0'
    );
\csr7_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr7[31]_i_1_n_0\,
      D => csr70(30),
      Q => \^csr7_c2f\(30),
      R => '0'
    );
\csr7_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr7[31]_i_1_n_0\,
      D => csr70(31),
      Q => \^csr7_c2f\(31),
      R => '0'
    );
\csr7_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr7[31]_i_1_n_0\,
      D => csr70(3),
      Q => \^csr7_c2f\(3),
      R => '0'
    );
\csr7_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr7[31]_i_1_n_0\,
      D => csr70(4),
      Q => \^csr7_c2f\(4),
      R => '0'
    );
\csr7_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr7[31]_i_1_n_0\,
      D => csr70(5),
      Q => \^csr7_c2f\(5),
      R => '0'
    );
\csr7_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr7[31]_i_1_n_0\,
      D => csr70(6),
      Q => \^csr7_c2f\(6),
      R => '0'
    );
\csr7_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr7[31]_i_1_n_0\,
      D => csr70(7),
      Q => \^csr7_c2f\(7),
      R => '0'
    );
\csr7_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr7[31]_i_1_n_0\,
      D => csr70(8),
      Q => \^csr7_c2f\(8),
      R => '0'
    );
\csr7_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \csr7[31]_i_1_n_0\,
      D => csr70(9),
      Q => \^csr7_c2f\(9),
      R => '0'
    );
dma_done_INST_0: unisim.vcomponents.LUT3
    generic map(
      INIT => X"F8"
    )
        port map (
      I0 => m_axi_dma_rvalid,
      I1 => \^m_axi_dma_rready\,
      I2 => m_axi_dma_bvalid,
      O => dma_done
    );
dma_error_set_i_1: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => aresetn,
      O => dma_error_set_i_1_n_0
    );
dma_error_set_i_2: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => \wrong_addr0__6\,
      I1 => wrong_addr00_in,
      I2 => \^dma_error\,
      O => dma_error_set_i_2_n_0
    );
dma_error_set_i_3: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAAAA8"
    )
        port map (
      I0 => dma_f2c_start,
      I1 => dma_error_set_i_5_n_0,
      I2 => dma_f2c_addr(0),
      I3 => dma_f2c_addr(2),
      I4 => dma_f2c_addr(1),
      O => \wrong_addr0__6\
    );
dma_error_set_i_4: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAAAA8"
    )
        port map (
      I0 => dma_c2f_start,
      I1 => dma_error_set_i_6_n_0,
      I2 => dma_c2f_addr(0),
      I3 => dma_c2f_addr(2),
      I4 => dma_c2f_addr(1),
      O => wrong_addr00_in
    );
dma_error_set_i_5: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => dma_f2c_addr(4),
      I1 => dma_f2c_addr(3),
      I2 => dma_f2c_addr(6),
      I3 => dma_f2c_addr(5),
      O => dma_error_set_i_5_n_0
    );
dma_error_set_i_6: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => dma_c2f_addr(4),
      I1 => dma_c2f_addr(3),
      I2 => dma_c2f_addr(6),
      I3 => dma_c2f_addr(5),
      O => dma_error_set_i_6_n_0
    );
dma_error_set_reg: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => dma_error_set_i_2_n_0,
      Q => \^dma_error\,
      R => dma_error_set_i_1_n_0
    );
dma_idle_INST_0: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000004"
    )
        port map (
      I0 => state(1),
      I1 => state(0),
      I2 => state(3),
      I3 => state(5),
      I4 => state(4),
      I5 => state(2),
      O => dma_idle
    );
m_axi_dma_arvalid_INST_0: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000100"
    )
        port map (
      I0 => state(5),
      I1 => state(1),
      I2 => state(0),
      I3 => state(4),
      I4 => state(3),
      I5 => state(2),
      O => m_axi_dma_arvalid
    );
m_axi_dma_awvalid_INST_0: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000004"
    )
        port map (
      I0 => state(0),
      I1 => state(1),
      I2 => state(3),
      I3 => state(5),
      I4 => state(4),
      I5 => state(2),
      O => m_axi_dma_awvalid
    );
m_axi_dma_bready_INST_0: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000002"
    )
        port map (
      I0 => state(3),
      I1 => state(2),
      I2 => state(5),
      I3 => state(4),
      I4 => state(1),
      I5 => state(0),
      O => m_axi_dma_bready
    );
m_axi_dma_rready_INST_0: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000100"
    )
        port map (
      I0 => state(1),
      I1 => state(4),
      I2 => state(0),
      I3 => state(5),
      I4 => state(3),
      I5 => state(2),
      O => \^m_axi_dma_rready\
    );
m_axi_dma_wlast_INST_0: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000010"
    )
        port map (
      I0 => state(0),
      I1 => state(1),
      I2 => state(2),
      I3 => state(3),
      I4 => state(5),
      I5 => state(4),
      O => m_axi_dma_wvalid
    );
next_state: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000100010116"
    )
        port map (
      I0 => state(0),
      I1 => state(1),
      I2 => state(2),
      I3 => state(3),
      I4 => state(4),
      I5 => state(5),
      O => next_state_n_0
    );
\rdata[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr3_f2c(0),
      I1 => csr2_f2c(0),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr1_f2c(0),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr0_f2c(0),
      O => \rdata[0]_i_2_n_0\
    );
\rdata[0]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr7_f2c(0),
      I1 => csr6_f2c(0),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr5_f2c(0),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr4_f2c(0),
      O => \rdata[0]_i_3_n_0\
    );
\rdata[10]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr3_f2c(10),
      I1 => csr2_f2c(10),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr1_f2c(10),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr0_f2c(10),
      O => \rdata[10]_i_2_n_0\
    );
\rdata[10]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr7_f2c(10),
      I1 => csr6_f2c(10),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr5_f2c(10),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr4_f2c(10),
      O => \rdata[10]_i_3_n_0\
    );
\rdata[11]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr3_f2c(11),
      I1 => csr2_f2c(11),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr1_f2c(11),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr0_f2c(11),
      O => \rdata[11]_i_2_n_0\
    );
\rdata[11]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr7_f2c(11),
      I1 => csr6_f2c(11),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr5_f2c(11),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr4_f2c(11),
      O => \rdata[11]_i_3_n_0\
    );
\rdata[12]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr3_f2c(12),
      I1 => csr2_f2c(12),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr1_f2c(12),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr0_f2c(12),
      O => \rdata[12]_i_2_n_0\
    );
\rdata[12]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr7_f2c(12),
      I1 => csr6_f2c(12),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr5_f2c(12),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr4_f2c(12),
      O => \rdata[12]_i_3_n_0\
    );
\rdata[13]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr3_f2c(13),
      I1 => csr2_f2c(13),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr1_f2c(13),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr0_f2c(13),
      O => \rdata[13]_i_2_n_0\
    );
\rdata[13]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr7_f2c(13),
      I1 => csr6_f2c(13),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr5_f2c(13),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr4_f2c(13),
      O => \rdata[13]_i_3_n_0\
    );
\rdata[14]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr3_f2c(14),
      I1 => csr2_f2c(14),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr1_f2c(14),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr0_f2c(14),
      O => \rdata[14]_i_2_n_0\
    );
\rdata[14]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr7_f2c(14),
      I1 => csr6_f2c(14),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr5_f2c(14),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr4_f2c(14),
      O => \rdata[14]_i_3_n_0\
    );
\rdata[15]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr3_f2c(15),
      I1 => csr2_f2c(15),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr1_f2c(15),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr0_f2c(15),
      O => \rdata[15]_i_2_n_0\
    );
\rdata[15]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr7_f2c(15),
      I1 => csr6_f2c(15),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr5_f2c(15),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr4_f2c(15),
      O => \rdata[15]_i_3_n_0\
    );
\rdata[16]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr3_f2c(16),
      I1 => csr2_f2c(16),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr1_f2c(16),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr0_f2c(16),
      O => \rdata[16]_i_2_n_0\
    );
\rdata[16]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr7_f2c(16),
      I1 => csr6_f2c(16),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr5_f2c(16),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr4_f2c(16),
      O => \rdata[16]_i_3_n_0\
    );
\rdata[17]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr3_f2c(17),
      I1 => csr2_f2c(17),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr1_f2c(17),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr0_f2c(17),
      O => \rdata[17]_i_2_n_0\
    );
\rdata[17]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr7_f2c(17),
      I1 => csr6_f2c(17),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr5_f2c(17),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr4_f2c(17),
      O => \rdata[17]_i_3_n_0\
    );
\rdata[18]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr3_f2c(18),
      I1 => csr2_f2c(18),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr1_f2c(18),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr0_f2c(18),
      O => \rdata[18]_i_2_n_0\
    );
\rdata[18]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr7_f2c(18),
      I1 => csr6_f2c(18),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr5_f2c(18),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr4_f2c(18),
      O => \rdata[18]_i_3_n_0\
    );
\rdata[19]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr3_f2c(19),
      I1 => csr2_f2c(19),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr1_f2c(19),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr0_f2c(19),
      O => \rdata[19]_i_2_n_0\
    );
\rdata[19]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr7_f2c(19),
      I1 => csr6_f2c(19),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr5_f2c(19),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr4_f2c(19),
      O => \rdata[19]_i_3_n_0\
    );
\rdata[1]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr3_f2c(1),
      I1 => csr2_f2c(1),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr1_f2c(1),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr0_f2c(1),
      O => \rdata[1]_i_2_n_0\
    );
\rdata[1]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr7_f2c(1),
      I1 => csr6_f2c(1),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr5_f2c(1),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr4_f2c(1),
      O => \rdata[1]_i_3_n_0\
    );
\rdata[20]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr3_f2c(20),
      I1 => csr2_f2c(20),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr1_f2c(20),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr0_f2c(20),
      O => \rdata[20]_i_2_n_0\
    );
\rdata[20]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr7_f2c(20),
      I1 => csr6_f2c(20),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr5_f2c(20),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr4_f2c(20),
      O => \rdata[20]_i_3_n_0\
    );
\rdata[21]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr3_f2c(21),
      I1 => csr2_f2c(21),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr1_f2c(21),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr0_f2c(21),
      O => \rdata[21]_i_2_n_0\
    );
\rdata[21]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr7_f2c(21),
      I1 => csr6_f2c(21),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr5_f2c(21),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr4_f2c(21),
      O => \rdata[21]_i_3_n_0\
    );
\rdata[22]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr3_f2c(22),
      I1 => csr2_f2c(22),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr1_f2c(22),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr0_f2c(22),
      O => \rdata[22]_i_2_n_0\
    );
\rdata[22]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr7_f2c(22),
      I1 => csr6_f2c(22),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr5_f2c(22),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr4_f2c(22),
      O => \rdata[22]_i_3_n_0\
    );
\rdata[23]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr3_f2c(23),
      I1 => csr2_f2c(23),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr1_f2c(23),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr0_f2c(23),
      O => \rdata[23]_i_2_n_0\
    );
\rdata[23]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr7_f2c(23),
      I1 => csr6_f2c(23),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr5_f2c(23),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr4_f2c(23),
      O => \rdata[23]_i_3_n_0\
    );
\rdata[24]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr3_f2c(24),
      I1 => csr2_f2c(24),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr1_f2c(24),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr0_f2c(24),
      O => \rdata[24]_i_2_n_0\
    );
\rdata[24]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr7_f2c(24),
      I1 => csr6_f2c(24),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr5_f2c(24),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr4_f2c(24),
      O => \rdata[24]_i_3_n_0\
    );
\rdata[25]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr3_f2c(25),
      I1 => csr2_f2c(25),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr1_f2c(25),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr0_f2c(25),
      O => \rdata[25]_i_2_n_0\
    );
\rdata[25]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr7_f2c(25),
      I1 => csr6_f2c(25),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr5_f2c(25),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr4_f2c(25),
      O => \rdata[25]_i_3_n_0\
    );
\rdata[26]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr3_f2c(26),
      I1 => csr2_f2c(26),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr1_f2c(26),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr0_f2c(26),
      O => \rdata[26]_i_2_n_0\
    );
\rdata[26]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr7_f2c(26),
      I1 => csr6_f2c(26),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr5_f2c(26),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr4_f2c(26),
      O => \rdata[26]_i_3_n_0\
    );
\rdata[27]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr3_f2c(27),
      I1 => csr2_f2c(27),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr1_f2c(27),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr0_f2c(27),
      O => \rdata[27]_i_2_n_0\
    );
\rdata[27]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr7_f2c(27),
      I1 => csr6_f2c(27),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr5_f2c(27),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr4_f2c(27),
      O => \rdata[27]_i_3_n_0\
    );
\rdata[28]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr3_f2c(28),
      I1 => csr2_f2c(28),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr1_f2c(28),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr0_f2c(28),
      O => \rdata[28]_i_2_n_0\
    );
\rdata[28]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr7_f2c(28),
      I1 => csr6_f2c(28),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr5_f2c(28),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr4_f2c(28),
      O => \rdata[28]_i_3_n_0\
    );
\rdata[29]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr3_f2c(29),
      I1 => csr2_f2c(29),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr1_f2c(29),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr0_f2c(29),
      O => \rdata[29]_i_2_n_0\
    );
\rdata[29]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr7_f2c(29),
      I1 => csr6_f2c(29),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr5_f2c(29),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr4_f2c(29),
      O => \rdata[29]_i_3_n_0\
    );
\rdata[2]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr3_f2c(2),
      I1 => csr2_f2c(2),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr1_f2c(2),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr0_f2c(2),
      O => \rdata[2]_i_2_n_0\
    );
\rdata[2]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr7_f2c(2),
      I1 => csr6_f2c(2),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr5_f2c(2),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr4_f2c(2),
      O => \rdata[2]_i_3_n_0\
    );
\rdata[30]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr3_f2c(30),
      I1 => csr2_f2c(30),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr1_f2c(30),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr0_f2c(30),
      O => \rdata[30]_i_2_n_0\
    );
\rdata[30]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr7_f2c(30),
      I1 => csr6_f2c(30),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr5_f2c(30),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr4_f2c(30),
      O => \rdata[30]_i_3_n_0\
    );
\rdata[31]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000E000000000"
    )
        port map (
      I0 => s_axi_csrs_araddr(1),
      I1 => s_axi_csrs_araddr(0),
      I2 => rstate(0),
      I3 => wstate(3),
      I4 => rstate(1),
      I5 => s_axi_csrs_arvalid,
      O => \rdata[31]_i_1_n_0\
    );
\rdata[31]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0200"
    )
        port map (
      I0 => s_axi_csrs_arvalid,
      I1 => rstate(1),
      I2 => wstate(3),
      I3 => rstate(0),
      O => ar_hs
    );
\rdata[31]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"BA"
    )
        port map (
      I0 => s_axi_csrs_araddr(1),
      I1 => s_axi_csrs_araddr(0),
      I2 => s_axi_csrs_araddr(4),
      O => \rdata[31]_i_4_n_0\
    );
\rdata[31]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr3_f2c(31),
      I1 => csr2_f2c(31),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr1_f2c(31),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr0_f2c(31),
      O => \rdata[31]_i_5_n_0\
    );
\rdata[31]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr7_f2c(31),
      I1 => csr6_f2c(31),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr5_f2c(31),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr4_f2c(31),
      O => \rdata[31]_i_6_n_0\
    );
\rdata[3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr3_f2c(3),
      I1 => csr2_f2c(3),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr1_f2c(3),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr0_f2c(3),
      O => \rdata[3]_i_2_n_0\
    );
\rdata[3]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr7_f2c(3),
      I1 => csr6_f2c(3),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr5_f2c(3),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr4_f2c(3),
      O => \rdata[3]_i_3_n_0\
    );
\rdata[4]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr3_f2c(4),
      I1 => csr2_f2c(4),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr1_f2c(4),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr0_f2c(4),
      O => \rdata[4]_i_2_n_0\
    );
\rdata[4]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr7_f2c(4),
      I1 => csr6_f2c(4),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr5_f2c(4),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr4_f2c(4),
      O => \rdata[4]_i_3_n_0\
    );
\rdata[5]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr3_f2c(5),
      I1 => csr2_f2c(5),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr1_f2c(5),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr0_f2c(5),
      O => \rdata[5]_i_2_n_0\
    );
\rdata[5]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr7_f2c(5),
      I1 => csr6_f2c(5),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr5_f2c(5),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr4_f2c(5),
      O => \rdata[5]_i_3_n_0\
    );
\rdata[6]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr3_f2c(6),
      I1 => csr2_f2c(6),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr1_f2c(6),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr0_f2c(6),
      O => \rdata[6]_i_2_n_0\
    );
\rdata[6]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr7_f2c(6),
      I1 => csr6_f2c(6),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr5_f2c(6),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr4_f2c(6),
      O => \rdata[6]_i_3_n_0\
    );
\rdata[7]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr3_f2c(7),
      I1 => csr2_f2c(7),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr1_f2c(7),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr0_f2c(7),
      O => \rdata[7]_i_2_n_0\
    );
\rdata[7]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr7_f2c(7),
      I1 => csr6_f2c(7),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr5_f2c(7),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr4_f2c(7),
      O => \rdata[7]_i_3_n_0\
    );
\rdata[8]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr3_f2c(8),
      I1 => csr2_f2c(8),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr1_f2c(8),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr0_f2c(8),
      O => \rdata[8]_i_2_n_0\
    );
\rdata[8]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr7_f2c(8),
      I1 => csr6_f2c(8),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr5_f2c(8),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr4_f2c(8),
      O => \rdata[8]_i_3_n_0\
    );
\rdata[9]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr3_f2c(9),
      I1 => csr2_f2c(9),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr1_f2c(9),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr0_f2c(9),
      O => \rdata[9]_i_2_n_0\
    );
\rdata[9]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => csr7_f2c(9),
      I1 => csr6_f2c(9),
      I2 => s_axi_csrs_araddr(3),
      I3 => csr5_f2c(9),
      I4 => s_axi_csrs_araddr(2),
      I5 => csr4_f2c(9),
      O => \rdata[9]_i_3_n_0\
    );
\rdata_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ar_hs,
      D => \rdata_reg[0]_i_1_n_0\,
      Q => s_axi_csrs_rdata(0),
      R => \rdata[31]_i_1_n_0\
    );
\rdata_reg[0]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \rdata[0]_i_2_n_0\,
      I1 => \rdata[0]_i_3_n_0\,
      O => \rdata_reg[0]_i_1_n_0\,
      S => \rdata[31]_i_4_n_0\
    );
\rdata_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ar_hs,
      D => \rdata_reg[10]_i_1_n_0\,
      Q => s_axi_csrs_rdata(10),
      R => \rdata[31]_i_1_n_0\
    );
\rdata_reg[10]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \rdata[10]_i_2_n_0\,
      I1 => \rdata[10]_i_3_n_0\,
      O => \rdata_reg[10]_i_1_n_0\,
      S => \rdata[31]_i_4_n_0\
    );
\rdata_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ar_hs,
      D => \rdata_reg[11]_i_1_n_0\,
      Q => s_axi_csrs_rdata(11),
      R => \rdata[31]_i_1_n_0\
    );
\rdata_reg[11]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \rdata[11]_i_2_n_0\,
      I1 => \rdata[11]_i_3_n_0\,
      O => \rdata_reg[11]_i_1_n_0\,
      S => \rdata[31]_i_4_n_0\
    );
\rdata_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ar_hs,
      D => \rdata_reg[12]_i_1_n_0\,
      Q => s_axi_csrs_rdata(12),
      R => \rdata[31]_i_1_n_0\
    );
\rdata_reg[12]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \rdata[12]_i_2_n_0\,
      I1 => \rdata[12]_i_3_n_0\,
      O => \rdata_reg[12]_i_1_n_0\,
      S => \rdata[31]_i_4_n_0\
    );
\rdata_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ar_hs,
      D => \rdata_reg[13]_i_1_n_0\,
      Q => s_axi_csrs_rdata(13),
      R => \rdata[31]_i_1_n_0\
    );
\rdata_reg[13]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \rdata[13]_i_2_n_0\,
      I1 => \rdata[13]_i_3_n_0\,
      O => \rdata_reg[13]_i_1_n_0\,
      S => \rdata[31]_i_4_n_0\
    );
\rdata_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ar_hs,
      D => \rdata_reg[14]_i_1_n_0\,
      Q => s_axi_csrs_rdata(14),
      R => \rdata[31]_i_1_n_0\
    );
\rdata_reg[14]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \rdata[14]_i_2_n_0\,
      I1 => \rdata[14]_i_3_n_0\,
      O => \rdata_reg[14]_i_1_n_0\,
      S => \rdata[31]_i_4_n_0\
    );
\rdata_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ar_hs,
      D => \rdata_reg[15]_i_1_n_0\,
      Q => s_axi_csrs_rdata(15),
      R => \rdata[31]_i_1_n_0\
    );
\rdata_reg[15]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \rdata[15]_i_2_n_0\,
      I1 => \rdata[15]_i_3_n_0\,
      O => \rdata_reg[15]_i_1_n_0\,
      S => \rdata[31]_i_4_n_0\
    );
\rdata_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ar_hs,
      D => \rdata_reg[16]_i_1_n_0\,
      Q => s_axi_csrs_rdata(16),
      R => \rdata[31]_i_1_n_0\
    );
\rdata_reg[16]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \rdata[16]_i_2_n_0\,
      I1 => \rdata[16]_i_3_n_0\,
      O => \rdata_reg[16]_i_1_n_0\,
      S => \rdata[31]_i_4_n_0\
    );
\rdata_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ar_hs,
      D => \rdata_reg[17]_i_1_n_0\,
      Q => s_axi_csrs_rdata(17),
      R => \rdata[31]_i_1_n_0\
    );
\rdata_reg[17]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \rdata[17]_i_2_n_0\,
      I1 => \rdata[17]_i_3_n_0\,
      O => \rdata_reg[17]_i_1_n_0\,
      S => \rdata[31]_i_4_n_0\
    );
\rdata_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ar_hs,
      D => \rdata_reg[18]_i_1_n_0\,
      Q => s_axi_csrs_rdata(18),
      R => \rdata[31]_i_1_n_0\
    );
\rdata_reg[18]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \rdata[18]_i_2_n_0\,
      I1 => \rdata[18]_i_3_n_0\,
      O => \rdata_reg[18]_i_1_n_0\,
      S => \rdata[31]_i_4_n_0\
    );
\rdata_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ar_hs,
      D => \rdata_reg[19]_i_1_n_0\,
      Q => s_axi_csrs_rdata(19),
      R => \rdata[31]_i_1_n_0\
    );
\rdata_reg[19]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \rdata[19]_i_2_n_0\,
      I1 => \rdata[19]_i_3_n_0\,
      O => \rdata_reg[19]_i_1_n_0\,
      S => \rdata[31]_i_4_n_0\
    );
\rdata_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ar_hs,
      D => \rdata_reg[1]_i_1_n_0\,
      Q => s_axi_csrs_rdata(1),
      R => \rdata[31]_i_1_n_0\
    );
\rdata_reg[1]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \rdata[1]_i_2_n_0\,
      I1 => \rdata[1]_i_3_n_0\,
      O => \rdata_reg[1]_i_1_n_0\,
      S => \rdata[31]_i_4_n_0\
    );
\rdata_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ar_hs,
      D => \rdata_reg[20]_i_1_n_0\,
      Q => s_axi_csrs_rdata(20),
      R => \rdata[31]_i_1_n_0\
    );
\rdata_reg[20]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \rdata[20]_i_2_n_0\,
      I1 => \rdata[20]_i_3_n_0\,
      O => \rdata_reg[20]_i_1_n_0\,
      S => \rdata[31]_i_4_n_0\
    );
\rdata_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ar_hs,
      D => \rdata_reg[21]_i_1_n_0\,
      Q => s_axi_csrs_rdata(21),
      R => \rdata[31]_i_1_n_0\
    );
\rdata_reg[21]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \rdata[21]_i_2_n_0\,
      I1 => \rdata[21]_i_3_n_0\,
      O => \rdata_reg[21]_i_1_n_0\,
      S => \rdata[31]_i_4_n_0\
    );
\rdata_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ar_hs,
      D => \rdata_reg[22]_i_1_n_0\,
      Q => s_axi_csrs_rdata(22),
      R => \rdata[31]_i_1_n_0\
    );
\rdata_reg[22]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \rdata[22]_i_2_n_0\,
      I1 => \rdata[22]_i_3_n_0\,
      O => \rdata_reg[22]_i_1_n_0\,
      S => \rdata[31]_i_4_n_0\
    );
\rdata_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ar_hs,
      D => \rdata_reg[23]_i_1_n_0\,
      Q => s_axi_csrs_rdata(23),
      R => \rdata[31]_i_1_n_0\
    );
\rdata_reg[23]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \rdata[23]_i_2_n_0\,
      I1 => \rdata[23]_i_3_n_0\,
      O => \rdata_reg[23]_i_1_n_0\,
      S => \rdata[31]_i_4_n_0\
    );
\rdata_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ar_hs,
      D => \rdata_reg[24]_i_1_n_0\,
      Q => s_axi_csrs_rdata(24),
      R => \rdata[31]_i_1_n_0\
    );
\rdata_reg[24]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \rdata[24]_i_2_n_0\,
      I1 => \rdata[24]_i_3_n_0\,
      O => \rdata_reg[24]_i_1_n_0\,
      S => \rdata[31]_i_4_n_0\
    );
\rdata_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ar_hs,
      D => \rdata_reg[25]_i_1_n_0\,
      Q => s_axi_csrs_rdata(25),
      R => \rdata[31]_i_1_n_0\
    );
\rdata_reg[25]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \rdata[25]_i_2_n_0\,
      I1 => \rdata[25]_i_3_n_0\,
      O => \rdata_reg[25]_i_1_n_0\,
      S => \rdata[31]_i_4_n_0\
    );
\rdata_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ar_hs,
      D => \rdata_reg[26]_i_1_n_0\,
      Q => s_axi_csrs_rdata(26),
      R => \rdata[31]_i_1_n_0\
    );
\rdata_reg[26]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \rdata[26]_i_2_n_0\,
      I1 => \rdata[26]_i_3_n_0\,
      O => \rdata_reg[26]_i_1_n_0\,
      S => \rdata[31]_i_4_n_0\
    );
\rdata_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ar_hs,
      D => \rdata_reg[27]_i_1_n_0\,
      Q => s_axi_csrs_rdata(27),
      R => \rdata[31]_i_1_n_0\
    );
\rdata_reg[27]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \rdata[27]_i_2_n_0\,
      I1 => \rdata[27]_i_3_n_0\,
      O => \rdata_reg[27]_i_1_n_0\,
      S => \rdata[31]_i_4_n_0\
    );
\rdata_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ar_hs,
      D => \rdata_reg[28]_i_1_n_0\,
      Q => s_axi_csrs_rdata(28),
      R => \rdata[31]_i_1_n_0\
    );
\rdata_reg[28]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \rdata[28]_i_2_n_0\,
      I1 => \rdata[28]_i_3_n_0\,
      O => \rdata_reg[28]_i_1_n_0\,
      S => \rdata[31]_i_4_n_0\
    );
\rdata_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ar_hs,
      D => \rdata_reg[29]_i_1_n_0\,
      Q => s_axi_csrs_rdata(29),
      R => \rdata[31]_i_1_n_0\
    );
\rdata_reg[29]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \rdata[29]_i_2_n_0\,
      I1 => \rdata[29]_i_3_n_0\,
      O => \rdata_reg[29]_i_1_n_0\,
      S => \rdata[31]_i_4_n_0\
    );
\rdata_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ar_hs,
      D => \rdata_reg[2]_i_1_n_0\,
      Q => s_axi_csrs_rdata(2),
      R => \rdata[31]_i_1_n_0\
    );
\rdata_reg[2]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \rdata[2]_i_2_n_0\,
      I1 => \rdata[2]_i_3_n_0\,
      O => \rdata_reg[2]_i_1_n_0\,
      S => \rdata[31]_i_4_n_0\
    );
\rdata_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ar_hs,
      D => \rdata_reg[30]_i_1_n_0\,
      Q => s_axi_csrs_rdata(30),
      R => \rdata[31]_i_1_n_0\
    );
\rdata_reg[30]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \rdata[30]_i_2_n_0\,
      I1 => \rdata[30]_i_3_n_0\,
      O => \rdata_reg[30]_i_1_n_0\,
      S => \rdata[31]_i_4_n_0\
    );
\rdata_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ar_hs,
      D => \rdata_reg[31]_i_3_n_0\,
      Q => s_axi_csrs_rdata(31),
      R => \rdata[31]_i_1_n_0\
    );
\rdata_reg[31]_i_3\: unisim.vcomponents.MUXF7
     port map (
      I0 => \rdata[31]_i_5_n_0\,
      I1 => \rdata[31]_i_6_n_0\,
      O => \rdata_reg[31]_i_3_n_0\,
      S => \rdata[31]_i_4_n_0\
    );
\rdata_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ar_hs,
      D => \rdata_reg[3]_i_1_n_0\,
      Q => s_axi_csrs_rdata(3),
      R => \rdata[31]_i_1_n_0\
    );
\rdata_reg[3]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \rdata[3]_i_2_n_0\,
      I1 => \rdata[3]_i_3_n_0\,
      O => \rdata_reg[3]_i_1_n_0\,
      S => \rdata[31]_i_4_n_0\
    );
\rdata_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ar_hs,
      D => \rdata_reg[4]_i_1_n_0\,
      Q => s_axi_csrs_rdata(4),
      R => \rdata[31]_i_1_n_0\
    );
\rdata_reg[4]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \rdata[4]_i_2_n_0\,
      I1 => \rdata[4]_i_3_n_0\,
      O => \rdata_reg[4]_i_1_n_0\,
      S => \rdata[31]_i_4_n_0\
    );
\rdata_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ar_hs,
      D => \rdata_reg[5]_i_1_n_0\,
      Q => s_axi_csrs_rdata(5),
      R => \rdata[31]_i_1_n_0\
    );
\rdata_reg[5]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \rdata[5]_i_2_n_0\,
      I1 => \rdata[5]_i_3_n_0\,
      O => \rdata_reg[5]_i_1_n_0\,
      S => \rdata[31]_i_4_n_0\
    );
\rdata_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ar_hs,
      D => \rdata_reg[6]_i_1_n_0\,
      Q => s_axi_csrs_rdata(6),
      R => \rdata[31]_i_1_n_0\
    );
\rdata_reg[6]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \rdata[6]_i_2_n_0\,
      I1 => \rdata[6]_i_3_n_0\,
      O => \rdata_reg[6]_i_1_n_0\,
      S => \rdata[31]_i_4_n_0\
    );
\rdata_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ar_hs,
      D => \rdata_reg[7]_i_1_n_0\,
      Q => s_axi_csrs_rdata(7),
      R => \rdata[31]_i_1_n_0\
    );
\rdata_reg[7]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \rdata[7]_i_2_n_0\,
      I1 => \rdata[7]_i_3_n_0\,
      O => \rdata_reg[7]_i_1_n_0\,
      S => \rdata[31]_i_4_n_0\
    );
\rdata_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ar_hs,
      D => \rdata_reg[8]_i_1_n_0\,
      Q => s_axi_csrs_rdata(8),
      R => \rdata[31]_i_1_n_0\
    );
\rdata_reg[8]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \rdata[8]_i_2_n_0\,
      I1 => \rdata[8]_i_3_n_0\,
      O => \rdata_reg[8]_i_1_n_0\,
      S => \rdata[31]_i_4_n_0\
    );
\rdata_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ar_hs,
      D => \rdata_reg[9]_i_1_n_0\,
      Q => s_axi_csrs_rdata(9),
      R => \rdata[31]_i_1_n_0\
    );
\rdata_reg[9]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \rdata[9]_i_2_n_0\,
      I1 => \rdata[9]_i_3_n_0\,
      O => \rdata_reg[9]_i_1_n_0\,
      S => \rdata[31]_i_4_n_0\
    );
\rstate[0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFD9FFFB"
    )
        port map (
      I0 => rstate(0),
      I1 => rstate(1),
      I2 => s_axi_csrs_rready,
      I3 => wstate(3),
      I4 => s_axi_csrs_arvalid,
      O => rnext(0)
    );
\rstate[1]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000838"
    )
        port map (
      I0 => s_axi_csrs_arvalid,
      I1 => rstate(0),
      I2 => rstate(1),
      I3 => s_axi_csrs_rready,
      I4 => wstate(3),
      O => rnext(1)
    );
\rstate_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => rnext(0),
      Q => rstate(0),
      R => dma_error_set_i_1_n_0
    );
\rstate_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => rnext(1),
      Q => rstate(1),
      R => dma_error_set_i_1_n_0
    );
s_axi_csrs_arready_INST_0: unisim.vcomponents.LUT3
    generic map(
      INIT => X"02"
    )
        port map (
      I0 => rstate(0),
      I1 => wstate(3),
      I2 => rstate(1),
      O => s_axi_csrs_arready
    );
s_axi_csrs_awready_INST_0: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0010"
    )
        port map (
      I0 => wstate(3),
      I1 => wstate(2),
      I2 => wstate(0),
      I3 => wstate(1),
      O => s_axi_csrs_awready
    );
s_axi_csrs_bvalid_INST_0: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0010"
    )
        port map (
      I0 => wstate(3),
      I1 => wstate(0),
      I2 => wstate(2),
      I3 => wstate(1),
      O => s_axi_csrs_bvalid
    );
s_axi_csrs_rvalid_INST_0: unisim.vcomponents.LUT3
    generic map(
      INIT => X"02"
    )
        port map (
      I0 => rstate(1),
      I1 => wstate(3),
      I2 => rstate(0),
      O => s_axi_csrs_rvalid
    );
s_axi_csrs_wready_INST_0: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0010"
    )
        port map (
      I0 => wstate(3),
      I1 => wstate(2),
      I2 => wstate(1),
      I3 => wstate(0),
      O => \^s_axi_csrs_wready\
    );
\state[0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAEFFFF"
    )
        port map (
      I0 => \state[0]_i_2_n_0\,
      I1 => state(0),
      I2 => dma_c2f_start,
      I3 => dma_f2c_start,
      I4 => next_state_n_0,
      O => \state[0]_i_1_n_0\
    );
\state[0]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F888"
    )
        port map (
      I0 => m_axi_dma_bvalid,
      I1 => state(3),
      I2 => m_axi_dma_rvalid,
      I3 => state(5),
      O => \state[0]_i_2_n_0\
    );
\state[1]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AA080808"
    )
        port map (
      I0 => next_state_n_0,
      I1 => state(1),
      I2 => m_axi_dma_awready,
      I3 => state(0),
      I4 => dma_f2c_start,
      O => \next_state__0\(1)
    );
\state[2]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AA080808"
    )
        port map (
      I0 => next_state_n_0,
      I1 => state(2),
      I2 => m_axi_dma_wready,
      I3 => state(1),
      I4 => m_axi_dma_awready,
      O => \next_state__0\(2)
    );
\state[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AA080808"
    )
        port map (
      I0 => next_state_n_0,
      I1 => state(3),
      I2 => m_axi_dma_bvalid,
      I3 => state(2),
      I4 => m_axi_dma_wready,
      O => \next_state__0\(3)
    );
\state[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0808AA0808080808"
    )
        port map (
      I0 => next_state_n_0,
      I1 => state(4),
      I2 => m_axi_dma_arready,
      I3 => state(0),
      I4 => dma_f2c_start,
      I5 => dma_c2f_start,
      O => \next_state__0\(4)
    );
\state[5]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AA080808"
    )
        port map (
      I0 => next_state_n_0,
      I1 => state(5),
      I2 => m_axi_dma_rvalid,
      I3 => state(4),
      I4 => m_axi_dma_arready,
      O => \next_state__0\(5)
    );
\state_reg[0]\: unisim.vcomponents.FDSE
    generic map(
      INIT => '1'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \state[0]_i_1_n_0\,
      Q => state(0),
      S => dma_error_set_i_1_n_0
    );
\state_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \next_state__0\(1),
      Q => state(1),
      R => dma_error_set_i_1_n_0
    );
\state_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \next_state__0\(2),
      Q => state(2),
      R => dma_error_set_i_1_n_0
    );
\state_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \next_state__0\(3),
      Q => state(3),
      R => dma_error_set_i_1_n_0
    );
\state_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \next_state__0\(4),
      Q => state(4),
      R => dma_error_set_i_1_n_0
    );
\state_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \next_state__0\(5),
      Q => state(5),
      R => dma_error_set_i_1_n_0
    );
\waddr[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000020"
    )
        port map (
      I0 => s_axi_csrs_awvalid,
      I1 => wstate(1),
      I2 => wstate(0),
      I3 => wstate(2),
      I4 => wstate(3),
      O => aw_hs
    );
\waddr_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => aw_hs,
      D => s_axi_csrs_awaddr(0),
      Q => waddr(0),
      R => '0'
    );
\waddr_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => aw_hs,
      D => s_axi_csrs_awaddr(1),
      Q => waddr(1),
      R => '0'
    );
\waddr_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => aw_hs,
      D => s_axi_csrs_awaddr(2),
      Q => waddr(2),
      R => '0'
    );
\waddr_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => aw_hs,
      D => s_axi_csrs_awaddr(3),
      Q => waddr(3),
      R => '0'
    );
\waddr_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => aw_hs,
      D => s_axi_csrs_awaddr(4),
      Q => waddr(4),
      R => '0'
    );
\wstate[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFAFFFFFAEFFAEF"
    )
        port map (
      I0 => wstate(3),
      I1 => s_axi_csrs_bready,
      I2 => wstate(2),
      I3 => wstate(1),
      I4 => s_axi_csrs_awvalid,
      I5 => wstate(0),
      O => wnext(0)
    );
\wstate[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000003404"
    )
        port map (
      I0 => s_axi_csrs_wvalid,
      I1 => wstate(1),
      I2 => wstate(0),
      I3 => s_axi_csrs_awvalid,
      I4 => wstate(3),
      I5 => wstate(2),
      O => \wstate[1]_i_1_n_0\
    );
\wstate[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0005001000000010"
    )
        port map (
      I0 => wstate(0),
      I1 => s_axi_csrs_bready,
      I2 => wstate(2),
      I3 => wstate(3),
      I4 => wstate(1),
      I5 => s_axi_csrs_wvalid,
      O => wnext(2)
    );
\wstate_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => wnext(0),
      Q => wstate(0),
      R => dma_error_set_i_1_n_0
    );
\wstate_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \wstate[1]_i_1_n_0\,
      Q => wstate(1),
      R => dma_error_set_i_1_n_0
    );
\wstate_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => wnext(2),
      Q => wstate(2),
      R => dma_error_set_i_1_n_0
    );
\wstate_reg[3]\: unisim.vcomponents.FDSE
    generic map(
      INIT => '1'
    )
        port map (
      C => aclk,
      CE => '1',
      D => '0',
      Q => wstate(3),
      S => dma_error_set_i_1_n_0
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity ecdsa_project_interfacer_0_0 is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    m_axi_dma_awvalid : out STD_LOGIC;
    m_axi_dma_awready : in STD_LOGIC;
    m_axi_dma_awaddr : out STD_LOGIC_VECTOR ( 31 downto 0 );
    m_axi_dma_awlen : out STD_LOGIC_VECTOR ( 7 downto 0 );
    m_axi_dma_awburst : out STD_LOGIC_VECTOR ( 1 downto 0 );
    m_axi_dma_wvalid : out STD_LOGIC;
    m_axi_dma_wready : in STD_LOGIC;
    m_axi_dma_wdata : out STD_LOGIC_VECTOR ( 1023 downto 0 );
    m_axi_dma_wlast : out STD_LOGIC;
    m_axi_dma_bvalid : in STD_LOGIC;
    m_axi_dma_bready : out STD_LOGIC;
    m_axi_dma_arvalid : out STD_LOGIC;
    m_axi_dma_arready : in STD_LOGIC;
    m_axi_dma_araddr : out STD_LOGIC_VECTOR ( 31 downto 0 );
    m_axi_dma_arlen : out STD_LOGIC_VECTOR ( 7 downto 0 );
    m_axi_dma_arburst : out STD_LOGIC_VECTOR ( 1 downto 0 );
    m_axi_dma_rvalid : in STD_LOGIC;
    m_axi_dma_rready : out STD_LOGIC;
    m_axi_dma_rdata : in STD_LOGIC_VECTOR ( 1023 downto 0 );
    m_axi_dma_rlast : in STD_LOGIC;
    s_axi_csrs_awvalid : in STD_LOGIC;
    s_axi_csrs_awready : out STD_LOGIC;
    s_axi_csrs_awaddr : in STD_LOGIC_VECTOR ( 11 downto 0 );
    s_axi_csrs_wvalid : in STD_LOGIC;
    s_axi_csrs_wready : out STD_LOGIC;
    s_axi_csrs_wdata : in STD_LOGIC_VECTOR ( 31 downto 0 );
    s_axi_csrs_wstrb : in STD_LOGIC_VECTOR ( 3 downto 0 );
    s_axi_csrs_bvalid : out STD_LOGIC;
    s_axi_csrs_bready : in STD_LOGIC;
    s_axi_csrs_bresp : out STD_LOGIC_VECTOR ( 1 downto 0 );
    s_axi_csrs_arvalid : in STD_LOGIC;
    s_axi_csrs_arready : out STD_LOGIC;
    s_axi_csrs_araddr : in STD_LOGIC_VECTOR ( 11 downto 0 );
    s_axi_csrs_rvalid : out STD_LOGIC;
    s_axi_csrs_rready : in STD_LOGIC;
    s_axi_csrs_rdata : out STD_LOGIC_VECTOR ( 31 downto 0 );
    s_axi_csrs_rresp : out STD_LOGIC_VECTOR ( 1 downto 0 );
    csr0_c2f : out STD_LOGIC_VECTOR ( 31 downto 0 );
    csr0_f2c : in STD_LOGIC_VECTOR ( 31 downto 0 );
    csr1_c2f : out STD_LOGIC_VECTOR ( 31 downto 0 );
    csr1_f2c : in STD_LOGIC_VECTOR ( 31 downto 0 );
    csr2_c2f : out STD_LOGIC_VECTOR ( 31 downto 0 );
    csr2_f2c : in STD_LOGIC_VECTOR ( 31 downto 0 );
    csr3_c2f : out STD_LOGIC_VECTOR ( 31 downto 0 );
    csr3_f2c : in STD_LOGIC_VECTOR ( 31 downto 0 );
    csr4_c2f : out STD_LOGIC_VECTOR ( 31 downto 0 );
    csr4_f2c : in STD_LOGIC_VECTOR ( 31 downto 0 );
    csr5_c2f : out STD_LOGIC_VECTOR ( 31 downto 0 );
    csr5_f2c : in STD_LOGIC_VECTOR ( 31 downto 0 );
    csr6_c2f : out STD_LOGIC_VECTOR ( 31 downto 0 );
    csr6_f2c : in STD_LOGIC_VECTOR ( 31 downto 0 );
    csr7_c2f : out STD_LOGIC_VECTOR ( 31 downto 0 );
    csr7_f2c : in STD_LOGIC_VECTOR ( 31 downto 0 );
    dma_c2f_start : in STD_LOGIC;
    dma_f2c_start : in STD_LOGIC;
    dma_c2f_data : out STD_LOGIC_VECTOR ( 1023 downto 0 );
    dma_f2c_data : in STD_LOGIC_VECTOR ( 1023 downto 0 );
    dma_c2f_addr : in STD_LOGIC_VECTOR ( 31 downto 0 );
    dma_f2c_addr : in STD_LOGIC_VECTOR ( 31 downto 0 );
    dma_done : out STD_LOGIC;
    dma_idle : out STD_LOGIC;
    dma_error : out STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of ecdsa_project_interfacer_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of ecdsa_project_interfacer_0_0 : entity is "ecdsa_project_interfacer_0_0,interfacer,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of ecdsa_project_interfacer_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of ecdsa_project_interfacer_0_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of ecdsa_project_interfacer_0_0 : entity is "interfacer,Vivado 2023.1";
end ecdsa_project_interfacer_0_0;

architecture STRUCTURE of ecdsa_project_interfacer_0_0 is
  signal \<const0>\ : STD_LOGIC;
  signal \<const1>\ : STD_LOGIC;
  signal \^dma_c2f_addr\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \^dma_f2c_addr\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \^dma_f2c_data\ : STD_LOGIC_VECTOR ( 1023 downto 0 );
  signal \^m_axi_dma_rdata\ : STD_LOGIC_VECTOR ( 1023 downto 0 );
  signal \^m_axi_dma_wvalid\ : STD_LOGIC;
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of aclk : signal is "xilinx.com:signal:clock:1.0 aclk CLK";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of aclk : signal is "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF m_axi_dma:s_axi_csrs, ASSOCIATED_RESET aresetn, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN ecdsa_project_processing_system7_0_0_FCLK_CLK0, INSERT_VIP 0";
  attribute X_INTERFACE_INFO of aresetn : signal is "xilinx.com:signal:reset:1.0 aresetn RST";
  attribute X_INTERFACE_PARAMETER of aresetn : signal is "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0";
  attribute X_INTERFACE_INFO of m_axi_dma_arready : signal is "xilinx.com:interface:aximm:1.0 m_axi_dma ARREADY";
  attribute X_INTERFACE_INFO of m_axi_dma_arvalid : signal is "xilinx.com:interface:aximm:1.0 m_axi_dma ARVALID";
  attribute X_INTERFACE_INFO of m_axi_dma_awready : signal is "xilinx.com:interface:aximm:1.0 m_axi_dma AWREADY";
  attribute X_INTERFACE_INFO of m_axi_dma_awvalid : signal is "xilinx.com:interface:aximm:1.0 m_axi_dma AWVALID";
  attribute X_INTERFACE_INFO of m_axi_dma_bready : signal is "xilinx.com:interface:aximm:1.0 m_axi_dma BREADY";
  attribute X_INTERFACE_INFO of m_axi_dma_bvalid : signal is "xilinx.com:interface:aximm:1.0 m_axi_dma BVALID";
  attribute X_INTERFACE_INFO of m_axi_dma_rlast : signal is "xilinx.com:interface:aximm:1.0 m_axi_dma RLAST";
  attribute X_INTERFACE_PARAMETER of m_axi_dma_rlast : signal is "XIL_INTERFACENAME m_axi_dma, DATA_WIDTH 1024, PROTOCOL AXI4, FREQ_HZ 100000000, ID_WIDTH 0, ADDR_WIDTH 32, AWUSER_WIDTH 0, ARUSER_WIDTH 0, WUSER_WIDTH 0, RUSER_WIDTH 0, BUSER_WIDTH 0, READ_WRITE_MODE READ_WRITE, HAS_BURST 1, HAS_LOCK 0, HAS_PROT 0, HAS_CACHE 0, HAS_QOS 0, HAS_REGION 0, HAS_WSTRB 0, HAS_BRESP 0, HAS_RRESP 0, SUPPORTS_NARROW_BURST 0, NUM_READ_OUTSTANDING 2, NUM_WRITE_OUTSTANDING 2, MAX_BURST_LENGTH 256, PHASE 0.0, CLK_DOMAIN ecdsa_project_processing_system7_0_0_FCLK_CLK0, NUM_READ_THREADS 1, NUM_WRITE_THREADS 1, RUSER_BITS_PER_BYTE 0, WUSER_BITS_PER_BYTE 0, INSERT_VIP 0";
  attribute X_INTERFACE_INFO of m_axi_dma_rready : signal is "xilinx.com:interface:aximm:1.0 m_axi_dma RREADY";
  attribute X_INTERFACE_INFO of m_axi_dma_rvalid : signal is "xilinx.com:interface:aximm:1.0 m_axi_dma RVALID";
  attribute X_INTERFACE_INFO of m_axi_dma_wlast : signal is "xilinx.com:interface:aximm:1.0 m_axi_dma WLAST";
  attribute X_INTERFACE_INFO of m_axi_dma_wready : signal is "xilinx.com:interface:aximm:1.0 m_axi_dma WREADY";
  attribute X_INTERFACE_INFO of m_axi_dma_wvalid : signal is "xilinx.com:interface:aximm:1.0 m_axi_dma WVALID";
  attribute X_INTERFACE_INFO of s_axi_csrs_arready : signal is "xilinx.com:interface:aximm:1.0 s_axi_csrs ARREADY";
  attribute X_INTERFACE_INFO of s_axi_csrs_arvalid : signal is "xilinx.com:interface:aximm:1.0 s_axi_csrs ARVALID";
  attribute X_INTERFACE_INFO of s_axi_csrs_awready : signal is "xilinx.com:interface:aximm:1.0 s_axi_csrs AWREADY";
  attribute X_INTERFACE_INFO of s_axi_csrs_awvalid : signal is "xilinx.com:interface:aximm:1.0 s_axi_csrs AWVALID";
  attribute X_INTERFACE_INFO of s_axi_csrs_bready : signal is "xilinx.com:interface:aximm:1.0 s_axi_csrs BREADY";
  attribute X_INTERFACE_INFO of s_axi_csrs_bvalid : signal is "xilinx.com:interface:aximm:1.0 s_axi_csrs BVALID";
  attribute X_INTERFACE_INFO of s_axi_csrs_rready : signal is "xilinx.com:interface:aximm:1.0 s_axi_csrs RREADY";
  attribute X_INTERFACE_INFO of s_axi_csrs_rvalid : signal is "xilinx.com:interface:aximm:1.0 s_axi_csrs RVALID";
  attribute X_INTERFACE_INFO of s_axi_csrs_wready : signal is "xilinx.com:interface:aximm:1.0 s_axi_csrs WREADY";
  attribute X_INTERFACE_INFO of s_axi_csrs_wvalid : signal is "xilinx.com:interface:aximm:1.0 s_axi_csrs WVALID";
  attribute X_INTERFACE_INFO of m_axi_dma_araddr : signal is "xilinx.com:interface:aximm:1.0 m_axi_dma ARADDR";
  attribute X_INTERFACE_INFO of m_axi_dma_arburst : signal is "xilinx.com:interface:aximm:1.0 m_axi_dma ARBURST";
  attribute X_INTERFACE_INFO of m_axi_dma_arlen : signal is "xilinx.com:interface:aximm:1.0 m_axi_dma ARLEN";
  attribute X_INTERFACE_INFO of m_axi_dma_awaddr : signal is "xilinx.com:interface:aximm:1.0 m_axi_dma AWADDR";
  attribute X_INTERFACE_INFO of m_axi_dma_awburst : signal is "xilinx.com:interface:aximm:1.0 m_axi_dma AWBURST";
  attribute X_INTERFACE_INFO of m_axi_dma_awlen : signal is "xilinx.com:interface:aximm:1.0 m_axi_dma AWLEN";
  attribute X_INTERFACE_INFO of m_axi_dma_rdata : signal is "xilinx.com:interface:aximm:1.0 m_axi_dma RDATA";
  attribute X_INTERFACE_INFO of m_axi_dma_wdata : signal is "xilinx.com:interface:aximm:1.0 m_axi_dma WDATA";
  attribute X_INTERFACE_INFO of s_axi_csrs_araddr : signal is "xilinx.com:interface:aximm:1.0 s_axi_csrs ARADDR";
  attribute X_INTERFACE_INFO of s_axi_csrs_awaddr : signal is "xilinx.com:interface:aximm:1.0 s_axi_csrs AWADDR";
  attribute X_INTERFACE_INFO of s_axi_csrs_bresp : signal is "xilinx.com:interface:aximm:1.0 s_axi_csrs BRESP";
  attribute X_INTERFACE_INFO of s_axi_csrs_rdata : signal is "xilinx.com:interface:aximm:1.0 s_axi_csrs RDATA";
  attribute X_INTERFACE_INFO of s_axi_csrs_rresp : signal is "xilinx.com:interface:aximm:1.0 s_axi_csrs RRESP";
  attribute X_INTERFACE_PARAMETER of s_axi_csrs_rresp : signal is "XIL_INTERFACENAME s_axi_csrs, DATA_WIDTH 32, PROTOCOL AXI4LITE, FREQ_HZ 100000000, ID_WIDTH 0, ADDR_WIDTH 12, AWUSER_WIDTH 0, ARUSER_WIDTH 0, WUSER_WIDTH 0, RUSER_WIDTH 0, BUSER_WIDTH 0, READ_WRITE_MODE READ_WRITE, HAS_BURST 0, HAS_LOCK 0, HAS_PROT 0, HAS_CACHE 0, HAS_QOS 0, HAS_REGION 0, HAS_WSTRB 1, HAS_BRESP 1, HAS_RRESP 1, SUPPORTS_NARROW_BURST 0, NUM_READ_OUTSTANDING 1, NUM_WRITE_OUTSTANDING 1, MAX_BURST_LENGTH 1, PHASE 0.0, CLK_DOMAIN ecdsa_project_processing_system7_0_0_FCLK_CLK0, NUM_READ_THREADS 4, NUM_WRITE_THREADS 4, RUSER_BITS_PER_BYTE 0, WUSER_BITS_PER_BYTE 0, INSERT_VIP 0";
  attribute X_INTERFACE_INFO of s_axi_csrs_wdata : signal is "xilinx.com:interface:aximm:1.0 s_axi_csrs WDATA";
  attribute X_INTERFACE_INFO of s_axi_csrs_wstrb : signal is "xilinx.com:interface:aximm:1.0 s_axi_csrs WSTRB";
begin
  \^dma_c2f_addr\(31 downto 0) <= dma_c2f_addr(31 downto 0);
  \^dma_f2c_addr\(31 downto 0) <= dma_f2c_addr(31 downto 0);
  \^dma_f2c_data\(1023 downto 0) <= dma_f2c_data(1023 downto 0);
  \^m_axi_dma_rdata\(1023 downto 0) <= m_axi_dma_rdata(1023 downto 0);
  dma_c2f_data(1023 downto 0) <= \^m_axi_dma_rdata\(1023 downto 0);
  m_axi_dma_araddr(31 downto 0) <= \^dma_c2f_addr\(31 downto 0);
  m_axi_dma_arburst(1) <= \<const0>\;
  m_axi_dma_arburst(0) <= \<const1>\;
  m_axi_dma_arlen(7) <= \<const0>\;
  m_axi_dma_arlen(6) <= \<const0>\;
  m_axi_dma_arlen(5) <= \<const0>\;
  m_axi_dma_arlen(4) <= \<const0>\;
  m_axi_dma_arlen(3) <= \<const0>\;
  m_axi_dma_arlen(2) <= \<const0>\;
  m_axi_dma_arlen(1) <= \<const0>\;
  m_axi_dma_arlen(0) <= \<const0>\;
  m_axi_dma_awaddr(31 downto 0) <= \^dma_f2c_addr\(31 downto 0);
  m_axi_dma_awburst(1) <= \<const0>\;
  m_axi_dma_awburst(0) <= \<const1>\;
  m_axi_dma_awlen(7) <= \<const0>\;
  m_axi_dma_awlen(6) <= \<const0>\;
  m_axi_dma_awlen(5) <= \<const0>\;
  m_axi_dma_awlen(4) <= \<const0>\;
  m_axi_dma_awlen(3) <= \<const0>\;
  m_axi_dma_awlen(2) <= \<const0>\;
  m_axi_dma_awlen(1) <= \<const0>\;
  m_axi_dma_awlen(0) <= \<const0>\;
  m_axi_dma_wdata(1023 downto 0) <= \^dma_f2c_data\(1023 downto 0);
  m_axi_dma_wlast <= \^m_axi_dma_wvalid\;
  m_axi_dma_wvalid <= \^m_axi_dma_wvalid\;
  s_axi_csrs_bresp(1) <= \<const0>\;
  s_axi_csrs_bresp(0) <= \<const0>\;
  s_axi_csrs_rresp(1) <= \<const0>\;
  s_axi_csrs_rresp(0) <= \<const0>\;
GND: unisim.vcomponents.GND
     port map (
      G => \<const0>\
    );
VCC: unisim.vcomponents.VCC
     port map (
      P => \<const1>\
    );
inst: entity work.ecdsa_project_interfacer_0_0_interfacer
     port map (
      aclk => aclk,
      aresetn => aresetn,
      csr0_c2f(31 downto 0) => csr0_c2f(31 downto 0),
      csr0_f2c(31 downto 0) => csr0_f2c(31 downto 0),
      csr1_c2f(31 downto 0) => csr1_c2f(31 downto 0),
      csr1_f2c(31 downto 0) => csr1_f2c(31 downto 0),
      csr2_c2f(31 downto 0) => csr2_c2f(31 downto 0),
      csr2_f2c(31 downto 0) => csr2_f2c(31 downto 0),
      csr3_c2f(31 downto 0) => csr3_c2f(31 downto 0),
      csr3_f2c(31 downto 0) => csr3_f2c(31 downto 0),
      csr4_c2f(31 downto 0) => csr4_c2f(31 downto 0),
      csr4_f2c(31 downto 0) => csr4_f2c(31 downto 0),
      csr5_c2f(31 downto 0) => csr5_c2f(31 downto 0),
      csr5_f2c(31 downto 0) => csr5_f2c(31 downto 0),
      csr6_c2f(31 downto 0) => csr6_c2f(31 downto 0),
      csr6_f2c(31 downto 0) => csr6_f2c(31 downto 0),
      csr7_c2f(31 downto 0) => csr7_c2f(31 downto 0),
      csr7_f2c(31 downto 0) => csr7_f2c(31 downto 0),
      dma_c2f_addr(6 downto 0) => \^dma_c2f_addr\(6 downto 0),
      dma_c2f_start => dma_c2f_start,
      dma_done => dma_done,
      dma_error => dma_error,
      dma_f2c_addr(6 downto 0) => \^dma_f2c_addr\(6 downto 0),
      dma_f2c_start => dma_f2c_start,
      dma_idle => dma_idle,
      m_axi_dma_arready => m_axi_dma_arready,
      m_axi_dma_arvalid => m_axi_dma_arvalid,
      m_axi_dma_awready => m_axi_dma_awready,
      m_axi_dma_awvalid => m_axi_dma_awvalid,
      m_axi_dma_bready => m_axi_dma_bready,
      m_axi_dma_bvalid => m_axi_dma_bvalid,
      m_axi_dma_rready => m_axi_dma_rready,
      m_axi_dma_rvalid => m_axi_dma_rvalid,
      m_axi_dma_wready => m_axi_dma_wready,
      m_axi_dma_wvalid => \^m_axi_dma_wvalid\,
      s_axi_csrs_araddr(4 downto 0) => s_axi_csrs_araddr(4 downto 0),
      s_axi_csrs_arready => s_axi_csrs_arready,
      s_axi_csrs_arvalid => s_axi_csrs_arvalid,
      s_axi_csrs_awaddr(4 downto 0) => s_axi_csrs_awaddr(4 downto 0),
      s_axi_csrs_awready => s_axi_csrs_awready,
      s_axi_csrs_awvalid => s_axi_csrs_awvalid,
      s_axi_csrs_bready => s_axi_csrs_bready,
      s_axi_csrs_bvalid => s_axi_csrs_bvalid,
      s_axi_csrs_rdata(31 downto 0) => s_axi_csrs_rdata(31 downto 0),
      s_axi_csrs_rready => s_axi_csrs_rready,
      s_axi_csrs_rvalid => s_axi_csrs_rvalid,
      s_axi_csrs_wdata(31 downto 0) => s_axi_csrs_wdata(31 downto 0),
      s_axi_csrs_wready => s_axi_csrs_wready,
      s_axi_csrs_wstrb(3 downto 0) => s_axi_csrs_wstrb(3 downto 0),
      s_axi_csrs_wvalid => s_axi_csrs_wvalid
    );
end STRUCTURE;
