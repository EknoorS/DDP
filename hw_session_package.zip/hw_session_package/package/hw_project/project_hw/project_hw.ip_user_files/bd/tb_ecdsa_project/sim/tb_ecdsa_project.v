//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2023.1 (lin64) Build 3865809 Sun May  7 15:04:56 MDT 2023
//Date        : Wed Nov 25 14:42:31 2026
//Host        : pc-klas1-14.esat.kuleuven.be running 64-bit Rocky Linux 9.9 (Blue Onyx)
//Command     : generate_target tb_ecdsa_project.bd
//Design      : tb_ecdsa_project
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CORE_GENERATION_INFO = "tb_ecdsa_project,IP_Integrator,{x_ipVendor=xilinx.com,x_ipLibrary=BlockDiagram,x_ipName=tb_ecdsa_project,x_ipVersion=1.00.a,x_ipLanguage=VERILOG,numBlks=4,numReposBlks=4,numNonXlnxBlks=0,numHierBlks=0,maxHierDepth=0,numSysgenBlks=0,numHlsBlks=0,numHdlrefBlks=3,numPkgbdBlks=0,bdsource=USER,synth_mode=OOC_per_IP}" *) (* HW_HANDOFF = "tb_ecdsa_project.hwdef" *) 
module tb_ecdsa_project
   (clk,
    leds,
    mem_addr,
    mem_clk,
    mem_din,
    mem_dout,
    mem_en,
    mem_rst,
    mem_we,
    resetn,
    s_axi_csrs_araddr,
    s_axi_csrs_arready,
    s_axi_csrs_arvalid,
    s_axi_csrs_awaddr,
    s_axi_csrs_awready,
    s_axi_csrs_awvalid,
    s_axi_csrs_bready,
    s_axi_csrs_bresp,
    s_axi_csrs_bvalid,
    s_axi_csrs_rdata,
    s_axi_csrs_rready,
    s_axi_csrs_rresp,
    s_axi_csrs_rvalid,
    s_axi_csrs_wdata,
    s_axi_csrs_wready,
    s_axi_csrs_wstrb,
    s_axi_csrs_wvalid);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK.CLK CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK.CLK, ASSOCIATED_BUSIF s_axi_csrs, ASSOCIATED_RESET resetn, CLK_DOMAIN ecdsa_project_processing_system7_0_0_FCLK_CLK0, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, INSERT_VIP 0, PHASE 0.0" *) input clk;
  output [3:0]leds;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 mem ADDR" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME mem, MASTER_TYPE BRAM_CTRL, MEM_ECC NONE, MEM_SIZE 16384, MEM_WIDTH 1024, READ_LATENCY 1, READ_WRITE_MODE READ_WRITE" *) input [13:0]mem_addr;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 mem CLK" *) input mem_clk;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 mem DIN" *) input [1023:0]mem_din;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 mem DOUT" *) output [1023:0]mem_dout;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 mem EN" *) input mem_en;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 mem RST" *) input mem_rst;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 mem WE" *) input [127:0]mem_we;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 RST.RESETN RST" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME RST.RESETN, INSERT_VIP 0, POLARITY ACTIVE_LOW" *) input resetn;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs ARADDR" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME s_axi_csrs, ADDR_WIDTH 12, ARUSER_WIDTH 0, AWUSER_WIDTH 0, BUSER_WIDTH 0, CLK_DOMAIN ecdsa_project_processing_system7_0_0_FCLK_CLK0, DATA_WIDTH 32, FREQ_HZ 100000000, HAS_BRESP 1, HAS_BURST 0, HAS_CACHE 0, HAS_LOCK 0, HAS_PROT 0, HAS_QOS 0, HAS_REGION 0, HAS_RRESP 1, HAS_WSTRB 1, ID_WIDTH 0, INSERT_VIP 0, MAX_BURST_LENGTH 1, NUM_READ_OUTSTANDING 1, NUM_READ_THREADS 4, NUM_WRITE_OUTSTANDING 1, NUM_WRITE_THREADS 4, PHASE 0.0, PROTOCOL AXI4LITE, READ_WRITE_MODE READ_WRITE, RUSER_BITS_PER_BYTE 0, RUSER_WIDTH 0, SUPPORTS_NARROW_BURST 0, WUSER_BITS_PER_BYTE 0, WUSER_WIDTH 0" *) input [11:0]s_axi_csrs_araddr;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs ARREADY" *) output s_axi_csrs_arready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs ARVALID" *) input s_axi_csrs_arvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs AWADDR" *) input [11:0]s_axi_csrs_awaddr;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs AWREADY" *) output s_axi_csrs_awready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs AWVALID" *) input s_axi_csrs_awvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs BREADY" *) input s_axi_csrs_bready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs BRESP" *) output [1:0]s_axi_csrs_bresp;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs BVALID" *) output s_axi_csrs_bvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs RDATA" *) output [31:0]s_axi_csrs_rdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs RREADY" *) input s_axi_csrs_rready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs RRESP" *) output [1:0]s_axi_csrs_rresp;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs RVALID" *) output s_axi_csrs_rvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs WDATA" *) input [31:0]s_axi_csrs_wdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs WREADY" *) output s_axi_csrs_wready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs WSTRB" *) input [3:0]s_axi_csrs_wstrb;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 s_axi_csrs WVALID" *) input s_axi_csrs_wvalid;

  wire Net;
  wire [15:0]axi_bram_ctrl_0_BRAM_PORTA_ADDR;
  wire axi_bram_ctrl_0_BRAM_PORTA_CLK;
  wire [1023:0]axi_bram_ctrl_0_BRAM_PORTA_DIN;
  wire [1023:0]axi_bram_ctrl_0_BRAM_PORTA_DOUT;
  wire axi_bram_ctrl_0_BRAM_PORTA_EN;
  wire axi_bram_ctrl_0_BRAM_PORTA_RST;
  wire [127:0]axi_bram_ctrl_0_BRAM_PORTA_WE;
  wire [31:0]ecdsa_0_dma_rx_address;
  wire ecdsa_0_dma_rx_start;
  wire [31:0]ecdsa_0_dma_tx_address;
  wire [1023:0]ecdsa_0_dma_tx_data;
  wire ecdsa_0_dma_tx_start;
  wire [3:0]ecdsa_0_leds;
  wire [31:0]ecdsa_0_rout0;
  wire [31:0]ecdsa_0_rout1;
  wire [31:0]ecdsa_0_rout2;
  wire [31:0]ecdsa_0_rout3;
  wire [31:0]ecdsa_0_rout4;
  wire [31:0]ecdsa_0_rout5;
  wire [31:0]ecdsa_0_rout6;
  wire [31:0]ecdsa_0_rout7;
  wire [31:0]interfacer_0_csr0_c2f;
  wire [31:0]interfacer_0_csr1_c2f;
  wire [31:0]interfacer_0_csr2_c2f;
  wire [31:0]interfacer_0_csr3_c2f;
  wire [31:0]interfacer_0_csr4_c2f;
  wire [31:0]interfacer_0_csr5_c2f;
  wire [31:0]interfacer_0_csr6_c2f;
  wire [31:0]interfacer_0_csr7_c2f;
  wire [1023:0]interfacer_0_dma_c2f_data;
  wire interfacer_0_dma_done;
  wire interfacer_0_dma_error;
  wire interfacer_0_dma_idle;
  wire [31:0]interfacer_0_m_axi_dma_ARADDR;
  wire [1:0]interfacer_0_m_axi_dma_ARBURST;
  wire [7:0]interfacer_0_m_axi_dma_ARLEN;
  wire interfacer_0_m_axi_dma_ARREADY;
  wire interfacer_0_m_axi_dma_ARVALID;
  wire [31:0]interfacer_0_m_axi_dma_AWADDR;
  wire [1:0]interfacer_0_m_axi_dma_AWBURST;
  wire [7:0]interfacer_0_m_axi_dma_AWLEN;
  wire interfacer_0_m_axi_dma_AWREADY;
  wire interfacer_0_m_axi_dma_AWVALID;
  wire interfacer_0_m_axi_dma_BREADY;
  wire interfacer_0_m_axi_dma_BVALID;
  wire [1023:0]interfacer_0_m_axi_dma_RDATA;
  wire interfacer_0_m_axi_dma_RLAST;
  wire interfacer_0_m_axi_dma_RREADY;
  wire interfacer_0_m_axi_dma_RVALID;
  wire [1023:0]interfacer_0_m_axi_dma_WDATA;
  wire interfacer_0_m_axi_dma_WLAST;
  wire interfacer_0_m_axi_dma_WREADY;
  wire interfacer_0_m_axi_dma_WVALID;
  wire [13:0]mem_1_ADDR;
  wire mem_1_CLK;
  wire [1023:0]mem_1_DIN;
  wire [1023:0]mem_1_DOUT;
  wire mem_1_EN;
  wire mem_1_RST;
  wire [127:0]mem_1_WE;
  wire rst_ps7_0_100M_peripheral_aresetn;
  wire [11:0]s_axi_csrs_1_ARADDR;
  wire s_axi_csrs_1_ARREADY;
  wire s_axi_csrs_1_ARVALID;
  wire [11:0]s_axi_csrs_1_AWADDR;
  wire s_axi_csrs_1_AWREADY;
  wire s_axi_csrs_1_AWVALID;
  wire s_axi_csrs_1_BREADY;
  wire [1:0]s_axi_csrs_1_BRESP;
  wire s_axi_csrs_1_BVALID;
  wire [31:0]s_axi_csrs_1_RDATA;
  wire s_axi_csrs_1_RREADY;
  wire [1:0]s_axi_csrs_1_RRESP;
  wire s_axi_csrs_1_RVALID;
  wire [31:0]s_axi_csrs_1_WDATA;
  wire s_axi_csrs_1_WREADY;
  wire [3:0]s_axi_csrs_1_WSTRB;
  wire s_axi_csrs_1_WVALID;

  assign Net = clk;
  assign leds[3:0] = ecdsa_0_leds;
  assign mem_1_ADDR = mem_addr[13:0];
  assign mem_1_CLK = mem_clk;
  assign mem_1_DIN = mem_din[1023:0];
  assign mem_1_EN = mem_en;
  assign mem_1_RST = mem_rst;
  assign mem_1_WE = mem_we[127:0];
  assign mem_dout[1023:0] = mem_1_DOUT;
  assign rst_ps7_0_100M_peripheral_aresetn = resetn;
  assign s_axi_csrs_1_ARADDR = s_axi_csrs_araddr[11:0];
  assign s_axi_csrs_1_ARVALID = s_axi_csrs_arvalid;
  assign s_axi_csrs_1_AWADDR = s_axi_csrs_awaddr[11:0];
  assign s_axi_csrs_1_AWVALID = s_axi_csrs_awvalid;
  assign s_axi_csrs_1_BREADY = s_axi_csrs_bready;
  assign s_axi_csrs_1_RREADY = s_axi_csrs_rready;
  assign s_axi_csrs_1_WDATA = s_axi_csrs_wdata[31:0];
  assign s_axi_csrs_1_WSTRB = s_axi_csrs_wstrb[3:0];
  assign s_axi_csrs_1_WVALID = s_axi_csrs_wvalid;
  assign s_axi_csrs_arready = s_axi_csrs_1_ARREADY;
  assign s_axi_csrs_awready = s_axi_csrs_1_AWREADY;
  assign s_axi_csrs_bresp[1:0] = s_axi_csrs_1_BRESP;
  assign s_axi_csrs_bvalid = s_axi_csrs_1_BVALID;
  assign s_axi_csrs_rdata[31:0] = s_axi_csrs_1_RDATA;
  assign s_axi_csrs_rresp[1:0] = s_axi_csrs_1_RRESP;
  assign s_axi_csrs_rvalid = s_axi_csrs_1_RVALID;
  assign s_axi_csrs_wready = s_axi_csrs_1_WREADY;
  tb_ecdsa_project_axi_bram_ctrl_0_0 axi_bram_ctrl_0
       (.bram_addr_a(axi_bram_ctrl_0_BRAM_PORTA_ADDR),
        .bram_clk_a(axi_bram_ctrl_0_BRAM_PORTA_CLK),
        .bram_en_a(axi_bram_ctrl_0_BRAM_PORTA_EN),
        .bram_rddata_a(axi_bram_ctrl_0_BRAM_PORTA_DOUT),
        .bram_rst_a(axi_bram_ctrl_0_BRAM_PORTA_RST),
        .bram_we_a(axi_bram_ctrl_0_BRAM_PORTA_WE),
        .bram_wrdata_a(axi_bram_ctrl_0_BRAM_PORTA_DIN),
        .s_axi_aclk(Net),
        .s_axi_araddr(interfacer_0_m_axi_dma_ARADDR[15:0]),
        .s_axi_arburst(interfacer_0_m_axi_dma_ARBURST),
        .s_axi_arcache({1'b0,1'b0,1'b1,1'b1}),
        .s_axi_aresetn(rst_ps7_0_100M_peripheral_aresetn),
        .s_axi_arlen(interfacer_0_m_axi_dma_ARLEN),
        .s_axi_arlock(1'b0),
        .s_axi_arprot({1'b0,1'b0,1'b0}),
        .s_axi_arready(interfacer_0_m_axi_dma_ARREADY),
        .s_axi_arsize({1'b1,1'b1,1'b1}),
        .s_axi_arvalid(interfacer_0_m_axi_dma_ARVALID),
        .s_axi_awaddr(interfacer_0_m_axi_dma_AWADDR[15:0]),
        .s_axi_awburst(interfacer_0_m_axi_dma_AWBURST),
        .s_axi_awcache({1'b0,1'b0,1'b1,1'b1}),
        .s_axi_awlen(interfacer_0_m_axi_dma_AWLEN),
        .s_axi_awlock(1'b0),
        .s_axi_awprot({1'b0,1'b0,1'b0}),
        .s_axi_awready(interfacer_0_m_axi_dma_AWREADY),
        .s_axi_awsize({1'b1,1'b1,1'b1}),
        .s_axi_awvalid(interfacer_0_m_axi_dma_AWVALID),
        .s_axi_bready(interfacer_0_m_axi_dma_BREADY),
        .s_axi_bvalid(interfacer_0_m_axi_dma_BVALID),
        .s_axi_rdata(interfacer_0_m_axi_dma_RDATA),
        .s_axi_rlast(interfacer_0_m_axi_dma_RLAST),
        .s_axi_rready(interfacer_0_m_axi_dma_RREADY),
        .s_axi_rvalid(interfacer_0_m_axi_dma_RVALID),
        .s_axi_wdata(interfacer_0_m_axi_dma_WDATA),
        .s_axi_wlast(interfacer_0_m_axi_dma_WLAST),
        .s_axi_wready(interfacer_0_m_axi_dma_WREADY),
        .s_axi_wstrb({1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .s_axi_wvalid(interfacer_0_m_axi_dma_WVALID));
  tb_ecdsa_project_ecdsa_0_0 ecdsa_0
       (.clk(Net),
        .dma_done(interfacer_0_dma_done),
        .dma_error(interfacer_0_dma_error),
        .dma_idle(interfacer_0_dma_idle),
        .dma_rx_address(ecdsa_0_dma_rx_address),
        .dma_rx_data(interfacer_0_dma_c2f_data),
        .dma_rx_start(ecdsa_0_dma_rx_start),
        .dma_tx_address(ecdsa_0_dma_tx_address),
        .dma_tx_data(ecdsa_0_dma_tx_data),
        .dma_tx_start(ecdsa_0_dma_tx_start),
        .leds(ecdsa_0_leds),
        .resetn(rst_ps7_0_100M_peripheral_aresetn),
        .rin0(interfacer_0_csr0_c2f),
        .rin1(interfacer_0_csr1_c2f),
        .rin2(interfacer_0_csr2_c2f),
        .rin3(interfacer_0_csr3_c2f),
        .rin4(interfacer_0_csr4_c2f),
        .rin5(interfacer_0_csr5_c2f),
        .rin6(interfacer_0_csr6_c2f),
        .rin7(interfacer_0_csr7_c2f),
        .rout0(ecdsa_0_rout0),
        .rout1(ecdsa_0_rout1),
        .rout2(ecdsa_0_rout2),
        .rout3(ecdsa_0_rout3),
        .rout4(ecdsa_0_rout4),
        .rout5(ecdsa_0_rout5),
        .rout6(ecdsa_0_rout6),
        .rout7(ecdsa_0_rout7));
  tb_ecdsa_project_interfacer_0_0 interfacer_0
       (.aclk(Net),
        .aresetn(rst_ps7_0_100M_peripheral_aresetn),
        .csr0_c2f(interfacer_0_csr0_c2f),
        .csr0_f2c(ecdsa_0_rout0),
        .csr1_c2f(interfacer_0_csr1_c2f),
        .csr1_f2c(ecdsa_0_rout1),
        .csr2_c2f(interfacer_0_csr2_c2f),
        .csr2_f2c(ecdsa_0_rout2),
        .csr3_c2f(interfacer_0_csr3_c2f),
        .csr3_f2c(ecdsa_0_rout3),
        .csr4_c2f(interfacer_0_csr4_c2f),
        .csr4_f2c(ecdsa_0_rout4),
        .csr5_c2f(interfacer_0_csr5_c2f),
        .csr5_f2c(ecdsa_0_rout5),
        .csr6_c2f(interfacer_0_csr6_c2f),
        .csr6_f2c(ecdsa_0_rout6),
        .csr7_c2f(interfacer_0_csr7_c2f),
        .csr7_f2c(ecdsa_0_rout7),
        .dma_c2f_addr(ecdsa_0_dma_rx_address),
        .dma_c2f_data(interfacer_0_dma_c2f_data),
        .dma_c2f_start(ecdsa_0_dma_rx_start),
        .dma_done(interfacer_0_dma_done),
        .dma_error(interfacer_0_dma_error),
        .dma_f2c_addr(ecdsa_0_dma_tx_address),
        .dma_f2c_data(ecdsa_0_dma_tx_data),
        .dma_f2c_start(ecdsa_0_dma_tx_start),
        .dma_idle(interfacer_0_dma_idle),
        .m_axi_dma_araddr(interfacer_0_m_axi_dma_ARADDR),
        .m_axi_dma_arburst(interfacer_0_m_axi_dma_ARBURST),
        .m_axi_dma_arlen(interfacer_0_m_axi_dma_ARLEN),
        .m_axi_dma_arready(interfacer_0_m_axi_dma_ARREADY),
        .m_axi_dma_arvalid(interfacer_0_m_axi_dma_ARVALID),
        .m_axi_dma_awaddr(interfacer_0_m_axi_dma_AWADDR),
        .m_axi_dma_awburst(interfacer_0_m_axi_dma_AWBURST),
        .m_axi_dma_awlen(interfacer_0_m_axi_dma_AWLEN),
        .m_axi_dma_awready(interfacer_0_m_axi_dma_AWREADY),
        .m_axi_dma_awvalid(interfacer_0_m_axi_dma_AWVALID),
        .m_axi_dma_bready(interfacer_0_m_axi_dma_BREADY),
        .m_axi_dma_bvalid(interfacer_0_m_axi_dma_BVALID),
        .m_axi_dma_rdata(interfacer_0_m_axi_dma_RDATA),
        .m_axi_dma_rlast(interfacer_0_m_axi_dma_RLAST),
        .m_axi_dma_rready(interfacer_0_m_axi_dma_RREADY),
        .m_axi_dma_rvalid(interfacer_0_m_axi_dma_RVALID),
        .m_axi_dma_wdata(interfacer_0_m_axi_dma_WDATA),
        .m_axi_dma_wlast(interfacer_0_m_axi_dma_WLAST),
        .m_axi_dma_wready(interfacer_0_m_axi_dma_WREADY),
        .m_axi_dma_wvalid(interfacer_0_m_axi_dma_WVALID),
        .s_axi_csrs_araddr(s_axi_csrs_1_ARADDR),
        .s_axi_csrs_arready(s_axi_csrs_1_ARREADY),
        .s_axi_csrs_arvalid(s_axi_csrs_1_ARVALID),
        .s_axi_csrs_awaddr(s_axi_csrs_1_AWADDR),
        .s_axi_csrs_awready(s_axi_csrs_1_AWREADY),
        .s_axi_csrs_awvalid(s_axi_csrs_1_AWVALID),
        .s_axi_csrs_bready(s_axi_csrs_1_BREADY),
        .s_axi_csrs_bresp(s_axi_csrs_1_BRESP),
        .s_axi_csrs_bvalid(s_axi_csrs_1_BVALID),
        .s_axi_csrs_rdata(s_axi_csrs_1_RDATA),
        .s_axi_csrs_rready(s_axi_csrs_1_RREADY),
        .s_axi_csrs_rresp(s_axi_csrs_1_RRESP),
        .s_axi_csrs_rvalid(s_axi_csrs_1_RVALID),
        .s_axi_csrs_wdata(s_axi_csrs_1_WDATA),
        .s_axi_csrs_wready(s_axi_csrs_1_WREADY),
        .s_axi_csrs_wstrb(s_axi_csrs_1_WSTRB),
        .s_axi_csrs_wvalid(s_axi_csrs_1_WVALID));
  tb_ecdsa_project_tb_mem_0_0 tb_mem_0
       (.bram_addr_a(axi_bram_ctrl_0_BRAM_PORTA_ADDR[13:0]),
        .bram_addr_b(mem_1_ADDR),
        .bram_clk_a(axi_bram_ctrl_0_BRAM_PORTA_CLK),
        .bram_clk_b(mem_1_CLK),
        .bram_en_a(axi_bram_ctrl_0_BRAM_PORTA_EN),
        .bram_en_b(mem_1_EN),
        .bram_rddata_a(axi_bram_ctrl_0_BRAM_PORTA_DOUT),
        .bram_rddata_b(mem_1_DOUT),
        .bram_rst_a(axi_bram_ctrl_0_BRAM_PORTA_RST),
        .bram_rst_b(mem_1_RST),
        .bram_we_a(axi_bram_ctrl_0_BRAM_PORTA_WE),
        .bram_we_b(mem_1_WE),
        .bram_wrdata_a(axi_bram_ctrl_0_BRAM_PORTA_DIN),
        .bram_wrdata_b(mem_1_DIN));
endmodule
