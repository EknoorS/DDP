transcript off
onbreak {quit -force}
onerror {quit -force}
transcript on

asim +access +r +m+tb_ecdsa_project  -L axi_bram_ctrl_v4_1_8 -L xil_defaultlib -L unisims_ver -L unimacro_ver -L secureip -O5 xil_defaultlib.tb_ecdsa_project xil_defaultlib.glbl

do {tb_ecdsa_project.udo}

run 1000ns

endsim

quit -force
