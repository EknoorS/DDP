vlib questa_lib/work
vlib questa_lib/msim

vlib questa_lib/msim/axi_bram_ctrl_v4_1_8
vlib questa_lib/msim/xil_defaultlib

vmap axi_bram_ctrl_v4_1_8 questa_lib/msim/axi_bram_ctrl_v4_1_8
vmap xil_defaultlib questa_lib/msim/xil_defaultlib

vcom -work axi_bram_ctrl_v4_1_8 -64 -93  \
"../../../../project_hw.gen/sources_1/bd/tb_ecdsa_project/ipshared/85f5/hdl/axi_bram_ctrl_v4_1_rfs.vhd" \

vcom -work xil_defaultlib -64 -93  \
"../../../bd/tb_ecdsa_project/ip/tb_ecdsa_project_axi_bram_ctrl_0_0/sim/tb_ecdsa_project_axi_bram_ctrl_0_0.vhd" \

vlog -work xil_defaultlib -64 -incr -mfcu  \
"../../../bd/tb_ecdsa_project/ip/tb_ecdsa_project_tb_mem_0_0/sim/tb_ecdsa_project_tb_mem_0_0.v" \
"../../../bd/tb_ecdsa_project/ip/tb_ecdsa_project_ecdsa_0_0/sim/tb_ecdsa_project_ecdsa_0_0.v" \
"../../../bd/tb_ecdsa_project/ip/tb_ecdsa_project_interfacer_0_0/sim/tb_ecdsa_project_interfacer_0_0.v" \
"../../../bd/tb_ecdsa_project/sim/tb_ecdsa_project.v" \

vlog -work xil_defaultlib \
"glbl.v"

