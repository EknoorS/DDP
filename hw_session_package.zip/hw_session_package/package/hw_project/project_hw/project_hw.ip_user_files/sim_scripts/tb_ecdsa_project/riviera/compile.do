transcript off
onbreak {quit -force}
onerror {quit -force}
transcript on

vlib work
vmap -link {/users/students/r1083141/DDP/DDP/hw_session_package/package/hw_project/project_hw/project_hw.cache/compile_simlib/riviera}
vlib riviera/axi_bram_ctrl_v4_1_8
vlib riviera/xil_defaultlib

vcom -work axi_bram_ctrl_v4_1_8 -93  -incr \
"../../../../project_hw.gen/sources_1/bd/tb_ecdsa_project/ipshared/85f5/hdl/axi_bram_ctrl_v4_1_rfs.vhd" \

vcom -work xil_defaultlib -93  -incr \
"../../../bd/tb_ecdsa_project/ip/tb_ecdsa_project_axi_bram_ctrl_0_0/sim/tb_ecdsa_project_axi_bram_ctrl_0_0.vhd" \

vlog -work xil_defaultlib  -incr -v2k5 -l axi_bram_ctrl_v4_1_8 -l xil_defaultlib \
"../../../bd/tb_ecdsa_project/ip/tb_ecdsa_project_tb_mem_0_0/sim/tb_ecdsa_project_tb_mem_0_0.v" \
"../../../bd/tb_ecdsa_project/ip/tb_ecdsa_project_ecdsa_0_0/sim/tb_ecdsa_project_ecdsa_0_0.v" \
"../../../bd/tb_ecdsa_project/ip/tb_ecdsa_project_interfacer_0_0/sim/tb_ecdsa_project_interfacer_0_0.v" \
"../../../bd/tb_ecdsa_project/sim/tb_ecdsa_project.v" \

vlog -work xil_defaultlib \
"glbl.v"

