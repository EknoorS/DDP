transcript off
onbreak {quit -force}
onerror {quit -force}
transcript on

vlib work
vmap -link {}
vlib activehdl/axi_bram_ctrl_v4_1_8
vlib activehdl/xil_defaultlib

vcom -work axi_bram_ctrl_v4_1_8 -93  \
"../../../../project_hw.gen/sources_1/bd/tb_ecdsa_project/ipshared/85f5/hdl/axi_bram_ctrl_v4_1_rfs.vhd" \

vcom -work xil_defaultlib -93  \
"../../../bd/tb_ecdsa_project/ip/tb_ecdsa_project_axi_bram_ctrl_0_0/sim/tb_ecdsa_project_axi_bram_ctrl_0_0.vhd" \

vlog -work xil_defaultlib  -v2k5 -l axi_bram_ctrl_v4_1_8 -l xil_defaultlib \
"../../../bd/tb_ecdsa_project/ip/tb_ecdsa_project_tb_mem_0_0/sim/tb_ecdsa_project_tb_mem_0_0.v" \
"../../../bd/tb_ecdsa_project/ip/tb_ecdsa_project_ecdsa_0_0/sim/tb_ecdsa_project_ecdsa_0_0.v" \
"../../../bd/tb_ecdsa_project/ip/tb_ecdsa_project_interfacer_0_0/sim/tb_ecdsa_project_interfacer_0_0.v" \
"../../../bd/tb_ecdsa_project/sim/tb_ecdsa_project.v" \

vlog -work xil_defaultlib \
"glbl.v"

